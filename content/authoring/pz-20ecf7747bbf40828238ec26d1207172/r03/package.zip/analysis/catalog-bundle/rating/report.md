# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: 93a9430a643ea5f1764570d6276458d0cff898b0bd80e256b744c3bc5d7be0f3
Status: rated (required_r4)
Profile scope: line_prefix

| Contribution | Exact value |
| --- | --- |
| demand | 9/2 |
| search | 0 |
| workload | 0 |

Score: 9/2; level: 5 / 5.
Without workload: 9/2; level: 5.
Lower boundary: 4; distance: 1/2.
Upper boundary: -; distance: -.
Nearest boundary distance: 1/2.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Required R4 uses a fixed anchor; line profiles are prefixes, not complete pair measurements.
