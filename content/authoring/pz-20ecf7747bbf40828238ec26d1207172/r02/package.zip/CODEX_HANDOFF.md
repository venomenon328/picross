# Vorlage für die anschließende Nutzerfreigabe

Dieser Text ist eine kopierbare Übergabevorlage. Die Motivfreigabe ist noch nicht erteilt. Erst nach tatsächlicher Bestätigung durch den Menschen als Auftrag 3 verwenden.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Ich gebe die vorgelegte Motivvorlage M-r02 mit dem vorgeschlagenen Parameterkorridor frei: 30×33 empfohlen, 36×40 alternativ, monochrom, genau 1 Vordergrundfarbe ohne Leer, area/contain und die in parameters.json benannten Crops.
Führe Standardauftrag 3 bis zum geprüften content_ready-Paket aus; keine Spielregistrierung.
Rätsel-ID: pz-20ecf7747bbf40828238ec26d1207172. Paket: content/authoring/pz-20ecf7747bbf40828238ec26d1207172/r02/package.zip.
Lade den aktuellen Index, prüfe Paket-/Inventar-/Bildfreigabebindungen und protokolliere diese tatsächliche Motivfreigabe. Beginne mit den vier vorgeschlagenen Kandidaten; Linien-/Paarprofilprüfung, gegebenenfalls gezielte Reparatur, unabhängiger Endproof, Herkunft, Gestaltung und Schwierigkeit gemäß aktuellem Regelwerk vollständig belegen.
Repositoryablage nach §6 ist beauftragt; Ablage-PR nach erfolgreichen Pflichtprüfungen mergen. Zur Endabnahme anhalten.
```
