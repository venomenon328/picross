# Qualle · Standardauftrag 2

pz-20ecf7747bbf40828238ec26d1207172 / r02 · Kategorie wasserwelt · Quellen-/Werkzeugcommit d53e1b700ab82fb2b1219038639294f6b1ed47a9.
Regelwerk 0.5.0, Dokumentrevision 23. Tatsächlicher Auftrag unverändert in approvals/user-instruction.txt.

Der Mensch hat Abschlussbild B-r01 aus dem auf main gesicherten r01 ausdrücklich freigegeben. Die bytegleiche Quelldatei reveal/option-b-r01.png trägt SHA-256 91a20121593a44b0f7c41c2db6a1025a62f3c89f9c40927f2cb52ceb8513e29d. Ihre konkrete Freigabe und Herkunft werden separat gebunden. Nach der Auswahl arbeitet die Abstraktion faithful; der ursprüngliche freie Entwurfsauftrag wird nicht umgeschrieben.

Ziel ist eine vereinfachte gespeicherte monochrome Illustration mit genau einer Vordergrundfarbe ohne Leer. Die native Bildableitung erhält Glockenneigung, Dreiviertelansicht, diagonalen Bewegungsfluss und die Hauptnegativräume. Falten werden zu drei großen Bändern zusammengefasst; Radialadern, Farbflecken, feinste Fäden, Schattierung und kleinteilige Rüschen entfallen. Eine zweite gezielte Bildrevision verstärkt Tentakel und reduziert schmale Glockenlinien. M-r01 bleibt als ersetzter Arbeitsstand erhalten; ausschließlich M-r02 wird zur Motivfreigabe vorgelegt.

Offene Maße wurden mit drei konkreten Konfigurationen verglichen; Empfehlung 30×33, zulässige größere Alternative 36×40 nach vorgeschlagenem Korridor. Noch keine Motivfreigabe, Matrix, Hinweise, Solver-/Proof-/Schwierigkeitsproduktion oder Spielintegration. Der beauftragte Ablage-Merge ist davon getrennt.
