# Größenvergleich und Vorschlag

| Konfiguration | Motivtreue und Darstellbarkeit | Erwartetes Lösbarkeitsrisiko | Spielgefühl |
| --- | --- | --- | --- |
| 24×26, Mono, 1 Farbe | Kompakt, Glocke bleibt deutlich; Zwischenräume und Tentakel müssten stärker zusammengefasst werden. | Höheres Darstellungs-/Zerfallsrisiko der dünneren Nebenformen; kein Logiknachweis. | Kurze kompakte Bearbeitung, weniger Motivdetails. |
| **30×33, Mono, 1 Farbe** | Empfehlung: proportionale Hochform; Glocke, drei Hauptbänder und große Negativräume haben einen ausgewogenen Umfang. | Randregel und vollständige Deduktion noch ungeprüft; Schwellen und Gegenkandidat sind sinnvoll. | 990 Zellen, mittlerer Bearbeitungsumfang; keine Schwierigkeitszusage. |
| 36×40, Mono, 1 Farbe | Mehr Platz für getrennte Tentakel und Negativräume, nahezu gleiches Seitenverhältnis. | Mehr Einzelverläufe können Logik erschweren; Größe garantiert keine Lösbarkeit. | 1440 Zellen, längere Bearbeitung; nicht automatisch schwieriger. |

Der vorgeschlagene Freigabekorridor umfasst 30×33 und 36×40 mit genau einer Vordergrundfarbe plus Leer. 24×26 ist nur die verglichene stärker reduzierte Alternative und gehört nicht zum vorgeschlagenen Korridor. Standard ist 30×33, area, contain, enger transparenter Außenbeschnitt [15,25,1183,1297]. Der vollständige Crop [0,0,1199,1312] ist als gleich motivtreue Alternative ausdrücklich mit vorgeschlagen. Keine gefüllten Teile abschneiden oder strecken. Die Quelldatei selbst bleibt unbeschnitten.

Nach Motivfreigabe zuerst vier gezielte Raster: 30×33 und 36×40, je Schwelle 176/208, alpha_below 32, enger Crop. Noch keine Matrix erzeugt. Der Leerhintergrund ist weiß, die einzige geplante Vordergrund-ID ink ist schwarz; Antialiaswerte des hochauflösenden PNGs sind keine zusätzlichen Rasterfarben. Tatsächliche Rasterfarbzahl, Randregel, Eindeutigkeit und Schwierigkeit werden erst an der Produktion geprüft. Parameterdetails stehen in parameters.json.
