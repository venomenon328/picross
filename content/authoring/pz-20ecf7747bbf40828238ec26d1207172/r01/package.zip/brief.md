# Qualle · Standardauftrag 1

ID: pz-20ecf7747bbf40828238ec26d1207172; Paketrevision: r01; Kategorie: wasserwelt (Wasserwelt).
Quellen-/Werkzeugcommit: efd52aad96046764cf7a38e7817e28edddf655b7. Regelwerk: 0.5.0, Dokumentrevision 23.

## Tatsächlicher Auftrag

„Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Starte Standardauftrag 1: Abschlussbildauswahl.
Motiv: Qualle
Rätselmodus (Abschlussbild immer farbig): monochrom.
Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.“

## Gestaltung und Grenzen

Eine einzelne erkennbare Qualle: gewölbte Glocke mit gelapptem Rand, breite gefaltete Mundarme und frei schwingende Tentakel mit Negativräumen. Ruhige warme handgezeichnete 2D-Illustration, farbig und detailliert, mit zurückhaltender Schattierung. Echte transparente Außenflächen und Zwischenräume; helle Motivbestandteile erhalten. Keine Schrift, kein Gesicht, keine Unterwasserszene oder zusätzliche Objekte.

Arbeitsweise free: keine fremde oder bindende Ausgangsbildvorlage. Pose, Glockenproportionen und Farbgebung werden zwischen drei Optionen bewusst variiert. Nach Bildfreigabe sind Identität, Pose, Hauptproportionen und wichtige Negativräume der gewählten Datei verbindlich; die konkrete Merkmalliste wird mit der menschlichen Auswahl gebunden.

Späterer Rätselmodus mono mit genau einer Vordergrundfarbe; Abschlussbild immer farbig. Rasterbreite, Rasterhöhe und Parameterkorridor bleiben offen. Kein Raster, keine Motivabstraktion, keine Hinweise, keine Logik- oder Schwierigkeitsergebnisse in diesem Auftrag. Alle drei Optionen bleiben bis zur Auswahl erhalten. Ablage ist keine Spielregistrierung und keine Bildfreigabe.
