# Chocolate Hills · Abschlussbildauswahl

Auftrag 1, freie Motivübertragung (`free`) aus Text ohne bindende Bildreferenz.
Wunsch: ungefähr 30 × 20 Zellen, farbig. Farbzahl offen; keine Rasterpalette oder
Lösbarkeit zugesagt. Kategorie: `landschaften-natur` (Landschaften & Natur).

Motivkern: wiederkehrende glatte, rundliche Kegelhügel, braune bis ockerfarbene
Grasflanken und grüne Täler; räumliche Staffelung statt einer Gebirgskette.
Die illustrativen Ansichten geben keine genaue reale Topografie wieder.
Beibehalten werden die hügelbestimmte Silhouette, ruhige Flächen, warme Konturen,
die Beziehungen zwischen Hügeln und Tälern und eine organische transparente Außenform.
Keine Gebäude, Menschen, Schrift oder ergänzenden touristischen Attraktionen.

Drei farbige detaillierte Illustrationen, keine Motivvorlagen. Erste Bildrunde
wegen zu naturalistischer Mikrotextur verworfen. Stilrevision erhält die jeweilige
Komposition und zeichnet Hügel, Schattenflächen und Vegetation deutlicher aus.
Einzeldateien r02 sind die aktuelle Auswahl; r01 bleibt als Bearbeitungsquelle erhalten.

Sachreferenzen wurden nur textlich zur Motivklärung genutzt, keine fremden Bildpixel:
[UNESCO](https://whc.unesco.org/en/tentativelists/5024) beschreibt die Kegelformen und
braun werdende Grasdecke; [Philippine Department of Tourism](https://www.tourismphilippines.com.au/where/bohol)
bestätigt den jahreszeitlichen Braun-/Grünwechsel. Zugriff: 28.10.2026.

Nächster erlaubter Auftrag: `2 · Bild freigeben & abstrahieren` nach ausdrücklicher
Auswahl und Freigabe einer konkreten r02-Datei. Bei Korrekturwunsch zuerst neue
Bildrevision vorlegen. Repositoryablage/Merge nimmt keine Bilddatei redaktionell ab.
