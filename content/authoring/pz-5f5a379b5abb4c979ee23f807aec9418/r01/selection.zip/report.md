# Chocolate Hills · Auftrag 1

ID `pz-5f5a379b5abb4c979ee23f807aec9418` · Paket `r01` · Status `reveal_review` · 28.10.2026.
Authoring 0.5.0, Dokumentrevision 23; Quellen-/Toolstand `06f0f09b4faca3c6f383923eca4c59b8b795bb74`.
Inventarhash steht ohne Selbstreferenz in `handoff.json` und im äußeren Record.

| Variante (Bildrevision r02) | Charakter und Abwägung |
| --- | --- |
| A – Weites Hügelpanorama | Breite Staffelung; kleine hintere Hügel später stärker zusammenfassen. |
| B – Nahblick mit Talöffnung | **Empfehlung**: größere Hauptformen und deutlicher Talraum für ungefähr 30 × 20. |
| C – Hügelfeld aus erhöhter Sicht | Ausgeprägte Wiederholung, höhere Dichte und mehr Reduktionsbedarf. |

Die angebotenen PNG-Einzeldateien stehen unter `images/`; `visual-review.json`
bindet alle fünf Gestaltungskriterien je Bild. `review/paper-comparison.png`
zeigt eine statische Montage auf dem tatsächlichen Buchpapier sowie 112/140-px-
Bildräume auf Kartenpapier für UI100/125. Alpha technisch vorhanden; keine sichtbaren
hellen Säume oder Bildkästen. Keine native Laufzeitprüfung behauptet.
Runde 1 wurde stilistisch verworfen; Quellenbytes und tatsächliche Prompts bleiben
für die Ableitung erhalten. 3 Erzeugungen + 3 Stilkorrekturen, aktive Menschenzeit unbekannt.

Wunschmaße 30 × 20 (600 Zellen, ungefähr), Modus farbig, Vordergrundfarbzahl offen.
Keine Motivvorlage, Zellmatrix, Hinweise, Palette oder Schwierigkeitsstufe erzeugt.
Randregel, Deduktion, unabhängiger Proof, Reparatur, Schwierigkeit und Zieladapter
sind in dieser frühen Bildphase nicht anwendbar und bleiben für die Produktion offen.
Abschlussbildfreigabe, Motivfreigabe und Endabnahme sind ausdrücklich offen.

Nutzungsgrundlage: nativ im Nutzerauftrag erzeugte Illustrationen, ausschließlich
eigene generierte Referenzpixel für die Stilrevision; externe Sachreferenzen nur textlich.
Keine Spielregistrierung. Repositoryablage samt Merge ist beauftragt und bedeutet
keine redaktionelle Bildabnahme. Paket-/Inventar-/Handoff-Prüfung erfolgt am geschriebenen ZIP.

Nächster Schritt: **2 · Bild freigeben & abstrahieren**. Menschliche Auswahl und
ausdrückliche Freigabe der konkreten r02-Datei; bei Änderungen neue Bildrevision vorlegen.
