# Codex-Übergabe · Auftrag 3 nach Motivfreigabe

Noch keine Motivfreigabe im aktuellen Auftrag. Die Datei und den Korridor muss
der Nutzer tatsächlich freigeben; dieser Text ist eine Übergabe, kein Freigabebeleg.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Rätsel-ID: pz-5f5a379b5abb4c979ee23f807aec9418; Paketrevision r02.
Paket: content/authoring/pz-5f5a379b5abb4c979ee23f807aec9418/r02/package.zip.
Lade den aktuellen Index/Record auf main; prüfe Paket, Handoff, Inventar,
Abschlussbildfreigabe und Motivbezug gegen die gespeicherten Bytes.
Abschlussbild ist ausdrücklich A-r01, SHA-256 37006bfe03d3800da227acfe8c210868c00e66bb27710f14c17c1c07af1b8a81.
Motivvorlage ist images/motif-m-r01.png (M-r01), SHA-256 2eac0685a9743d9a45540fad657d742324a577e5b178bd970b4b88052656fb9a.
Vor Produktion tatsächliche menschliche Freigabe genau dieser Motivdatei und
des Korridors aus configuration.json binden. Ohne sie bei der Motivfreigabe stoppen.
Empfehlung: 36 × 16, farbig, 4 Vordergrundfarben.
Korridor: 36 × 16 oder 27 × 12, jeweils 3 oder 4 Vordergrundfarben;
area, fit=exact, voller Crop [0,0,1881,836], Alpha unter 128 leer.
Vier gezielte Kandidaten aus den zwei Größen und zwei Paletten; pro Design
eigenes neues Importziel. Keine Wirkung aus Area-Farbschwellen behaupten.
Das ungefähre ursprüngliche Wunschmaß 30 × 20 ist keine freigegebene Alternative
zum ausdrücklich zu bestätigenden Korridor. Keine Streckung oder neue Komposition.
Motivinvarianten, Detailverluste und Palettenrollen aus invariants.json und
configuration.json erhalten; kein motivfremder Randanker.
Produktion mit aktueller vollständiger Quellen-/Dateiprüfung, zuerst full-line-color;
bei geeignetem bestätigtem Linienfixpunkt Profilwahl und begrenzte Reparatur nach
§4.2.1/4.4 ausschöpfen. Alle nötigen unabhängigen Proof-/Herkunftsgates belegen.
Schwierigkeit nach aktuellem Produktionsstandard (auf main Methode 0.4 prüfen),
keine Stufe aus Größe/Farbzahl ableiten. Keine rätselspezifischen CI-Tests.
Bis zum regulären Endabnahmestopp von Standardauftrag 3 arbeiten und §6 sichern.
Keine Spielregistrierung oder Endabnahme aus dem Motivfreigabeauftrag ableiten.
Repositoryablage/PR/Merge nur gemäß dem tatsächlichen Auftrag behandeln.
```

Die menschliche Freigabe kann den gesamten aufgeführten Variantenkorridor binden.
Für die spätere ZA-1-Übergabe zusätzlich die tatsächlich gewählte Parameterkombination
nach dessen vorhandenen Freigabe-/Handofffeldern korrekt zuordnen; ursprünglichen
Wortlaut und akzeptierten Korridor erhalten. Keine Freigabe selbst erzeugen.
