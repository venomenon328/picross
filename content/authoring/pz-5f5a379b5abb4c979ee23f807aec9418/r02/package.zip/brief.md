# Chocolate Hills · Auftrag 2

ID `pz-5f5a379b5abb4c979ee23f807aec9418`, Paket `r02`, Kategorie `landschaften-natur`.
Ursprünglicher Wunsch ungefähr 30 × 20, Modus farbig, Farbzahl offen.
Die aktuelle Nutzererklärung gibt ausdrücklich **A-r01** frei. Diese Datei ist
eindeutig als ältere Quelle unter `r01/retained-sources/reveal-a-r01.png` vorhanden;
die zuletzt angebotene Stilüberarbeitung **A-r02 wird nicht umgedeutet oder freigegeben**.
Die Freigabe bindet den Originalhash `37006bfe03d3800da227acfe8c210868c00e66bb27710f14c17c1c07af1b8a81` und den Wortlaut in
`approvals/user-request.txt`. Frühere redaktionelle Stileinschätzungen in r01
bleiben historisch unverändert; es wird keine zusätzliche Ausnahmeerklärung erfunden.

Aus genau A-r01 wurde nativ die getrennte Motivvorlage M-r01 abgeleitet.
Hauptkegel, Staffelung, Perspektive und Talöffnung bleiben erhalten; Gras/Laub und
kleine Oberflächennuancen sind zu großen Flächen zusammengefasst.
Die Abstraktion ist noch keine Zellmatrix und braucht ihre eigene menschliche Freigabe.

Empfehlung: 36 × 16, vier Vordergrundfarben, 576 Zellen statt ungefähr 600.
Das 9:4-Panorama passt so unverzerrt, ohne viel ungenutzte Höhe. Zulässiger
vorgeschlagener Korridor: 36 × 16 oder 27 × 12, jeweils drei oder vier Farben,
`area`, `fit=exact`, voller Crop `[0,0,1881,836]`; nur nach Motivfreigabe wirksam.
Vierfarbenpalette: zwei Braunrollen für Helligkeit/Rundung, zwei Grünrollen für
Tal versus Vegetation. Die Dreieralternative legt nur die Braunrollen zusammen.
Konfiguration, Abwägungen und vier gezielte spätere Kandidaten in `configuration.json`.

Herkunft/Nutzungsgrundlage: nativ im Nutzerauftrag erzeugte Bilder ohne fremde
Bildpixel. Original-Reveal, dessen ursprünglicher Prompt und seine Provenienz
sind enthalten. Verworfenes A-r02 sowie B/C werden nur mit Commit/Pfad/Hash in
`decisions.json` referenziert; keine alten ZIPs oder fremden Quellenkopien im Paket.

Nächster Schritt: `3 · Motiv freigeben & produzieren`, erst nach tatsächlicher
Freigabe der Datei M-r01 samt vorgeschlagenem Korridor. Keine Produktion/Registrierung
oder vorweggenommene Motiv-/Endabnahme in diesem Auftrag.
