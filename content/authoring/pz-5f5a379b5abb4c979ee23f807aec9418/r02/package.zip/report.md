# Chocolate Hills · Auftrag 2

`pz-5f5a379b5abb4c979ee23f807aec9418` · Paket r02 · `motif_review` · 28.10.2026 · Authoring 0.5.0.
Gelesener Quellen-/Toolstand `e10f7f230cdd9d9deaafa672158c103ab52d40ec`; Inventarhash ohne Selbstreferenz im Handoff/Record.

**Abschlussbild:** A-r01, menschlich freigegeben; Originalbytes und Freigabebeleg
enthalten. A-r02 bleibt ungewählt. **Motiv:** M-r01 nativ aus den gebundenen Bytes
abgeleitet, menschliche Motivfreigabe und Endabnahme noch offen.

| Konfiguration | Abwägung |
| --- | --- |
| **36 × 16 / 4 Farben (576 Zellen)** | Empfehlung: Panorama 9:4 unverzerrt, klarer Talraum, fast der gewünschte Umfang 600. |
| 30 × 20 / 4 (600) | Mehr Leerhöhe, ungünstigerer Fit zum Panorama; nicht im vorgeschlagenen Korridor. |
| 27 × 12 / 3 (324) | Kompakt, aber kleine ferne Kegel und die farbliche Schattentrennung werden schwächer. |

Korridor: 36 × 16 oder 27 × 12, drei/vier Vordergrundfarben, voller Crop und exact-Fit;
noch vorgeschlagen. Vier Rollen: helles Hügelbraun, Schattenbraun, Talgrün, Vegetationsgrün.
Reduktion auf drei vereinigt die Brauntöne und erhält beide Grünrollen.
Farbwunsch offen, tatsächlich verwendete Vordergrundfarben noch null: keine Matrix.

Die fünf Gestaltungskriterien der Motivvorlage sind in `review/visual-review.json`
begründet erfüllt. Bildvergleich auf tatsächlichem Buchpapier groß und bei 112 px:
gleiche Haupthügel, Reihenfolge, Perspektive und Talöffnung, transparente Außenform
ohne sichtbaren Bildkasten/Saum. Gras-/Laubmikrotextur und feinste Lichtnuancen entfallen.
Palette ist ein Produktionsvorschlag; PNG-Antialias-/Tonvarianten sind keine Zellfarben.

1 nativer Bildaufruf in dieser Phase, keine Korrekturrunde. Aktive Menschenzeit unbekannt.
Beide Bilddateien, Ursprungsprompt und Nutzungsgrundlage erhalten; keine fremden Bildpixel.
Keine Matrix, Hinweise, Lösbarkeit, Schwierigkeit oder Zielintegration behauptet;
Randregel und unabhängige Logik-/Herkunftsprüfung stehen erst mit Auftrag 3 an.
Reparatur entfällt hier mangels Rasterproduktion. Native Spieltests/ZA-1-Inspektion
sind für diese frühe Bildphase nicht erforderlich, nicht als bestanden ausgegeben.

Nächster Schritt: **3 · Motiv freigeben & produzieren**. Konkrete Datei M-r01 und
Parameterkorridor menschlich freigeben; kompakte Codex-Übergabe in `CODEX_HANDOFF.md`.
Dieser Ablagemerge ersetzt keine Motiv- oder Endabnahme und integriert kein Spielrätsel.
