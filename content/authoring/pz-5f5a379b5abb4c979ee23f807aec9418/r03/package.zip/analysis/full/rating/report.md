# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: 1545024484b34ec5f126c279506463e99450873c22b33ba98ac4adf62e19c6d8
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 61/28 |
| search | 83/96 |
| workload | 1/4 |

Score: 2213/672; level: 4 / 5.
Without workload: 2045/672; level: 4.
Lower boundary: 3; distance: 197/672.
Upper boundary: 4; distance: 475/672.
Nearest boundary distance: 197/672.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
