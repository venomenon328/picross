# Petronas Towers · Abschlussbildauswahl r01

Standardauftrag 1. Rätselmodus monochrom; das Abschlussbild bleibt farbig. Rastermaße offen, genau eine spätere Vordergrundfarbe ergibt sich aus Mono. Keine Rasterproduktion vor konkreter Motivfreigabe.

Arbeitsweise free: freie illustrative Übertragung des Textmotivs, keine bindende Bildreferenz. Motivkern: beide vollständigen Zwillingstürme, abgestufte Kronen und Spitzen, gerippte Fassaden, Skybridge mit Stützen und offene Zwischenräume. Keine Zusatzskyline, Texte oder Logos. Kategorie gebaeude-bauwerke.

Drei native Bildaufrufe. A: frontale Tagesansicht. B: schräge warme Tagesansicht. C: beleuchtete Abendansicht. Original-RGBA unverändert erhalten. Die Feinzeichnung wird in Auftrag 2 aus genau der gewählten Bilddatei reduziert; Maße erst dort empfehlen. Keine Lösbarkeitszusage.

Auftrag: Repositoryablage nach §6 einschließlich Commit/Push, Ablage-PR und Merge nach erfolgreichen Pflichtprüfungen. Auswahl, Bildfreigabe, Motivfreigabe und Endabnahme offen.

Gelesener Repository-/Werkzeugstand: main@d675b20cd6c367e5e98a493096c53f18e49324a9. Regelwerk 0.5.0, Dokumentrevision 23.
