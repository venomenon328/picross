# Codex-Übergabe · Standardauftrag 3

Status: fachlich vorbereitet, durch die noch fehlende menschliche Motivfreigabe gesperrt. Keine Produktion in Standardauftrag 2.

Bevorzugter Weg: Codex. Selbst umsetzbar: Teilweise; Bild-/Datei-/Repositoryschritte sind verfügbar, ein vollständiger ausführbarer Repositorycheckout wurde hier nicht eingerichtet/geprüft. Python 3.12.14 und Pillow 12.3.0 sind vorhanden. Codex: GPT-6.1 Sol — Reasoning: High, sofern auswählbar. Mehrstufige Produktion mit Motivschutz und unabhängigen Nachweisen; lokaler High-Standard. Quellenprüfung und Grenzen in codex-execution.json. Kein Mehragentenmodus beauftragt.

Die folgende Kopiervorlage ist ausdrücklich KEINE bereits erteilte Motivfreigabe. Erst verwenden, wenn der Eigentümer MA-r02 samt proposed-parameters.json tatsächlich akzeptiert. Das Absenden des Freigabesatzes ist seine Erklärung. Das versiegelte Paket enthält die vollständigen Bilder und Bindungen; keine weiteren Uploads nötig.

~~~~text
Arbeite in venomenon328/picross@main; lies zuerst die aktuelle AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Paket: content/authoring/pz-9d08697a30c749258b742ac979de9def/r02/package.zip · r02; Rätsel-ID: pz-9d08697a30c749258b742ac979de9def.
Ich gebe die vorgelegte Motivvorlage MA-r02 (motifs/MA-r02.png, SHA-256 ae1ca12459c6297c6e349a21af18314dc74ce53cf2195cbcc27bf4a449003341) samt proposed-parameters.json frei: empfohlen 30 × 50, zulässig ausschließlich 28 × 48 oder 30 × 50, monochrom, eine Vordergrundfarbe plus Leer; A-r01 bleibt das farbige Abschlussbild.
Führe Standardauftrag 3 gemäß Paket und Workflow bis content_ready zur redaktionellen Endabnahme aus; keine Spielregistrierung. Repositoryablage nach §6 einschließlich Commit/Push, PR und Ablagemerge nach erfolgreichen Pflichtprüfungen ist beauftragt. Nutze einen neuen Arbeitsbranch vom aktuellen main; bewahre r01/r02 unverändert.
~~~~

Nach Ablagemerge den Paketstand über den aktuellen Index auflösen; Source-/Toolcommit dieser Übergabe: cb47a1e9a2ebd534378921c383728bb8a2427dc7. Der konkrete spätere Freigabetext und sein Zeitpunkt müssen in der neuen Produktionsrevision protokolliert werden. Die vorliegende Freigabe von A-r01 ist in approvals/reveal-A-r01.json dateigebunden.
