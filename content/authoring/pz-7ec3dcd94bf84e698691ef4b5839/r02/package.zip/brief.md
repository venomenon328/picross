# Grüne Erbse · gezielte Abschlussbildkorrektur

Auftrag vom 12.10.2026: nur A-r01 bearbeiten, den Böbbel/Stielansatz oben rechts entfernen. Alle übrigen Merkmale, Stil, Farbigkeit und Detailtiefe erhalten. Ausgangspunkt ist die tatsächlich aus dem indexgebundenen r01-ZIP geladene Datei.

Farbiges Rätsel, Rastermaße offen. Kategorie gemuese-pilze-kraeuter. Keine Abstraktion, Rasterproduktion, Werkzeugänderungen oder Katalogregistrierung. Native Bildbearbeitung mit genau A-r01 als Referenz; Ausgabe A-r02.

Autorisiert sind Paketablage auf Arbeitsbranch, Commit/Push, Draft-PR und bedingter Merge nach vollständigem Diff-/Selbstreview und allen ausgewählten Pflichtprüfungen; main danach verifizieren. Kein Release/Deployment. Der Korrekturauftrag ist keine Abschlussbildfreigabe.
