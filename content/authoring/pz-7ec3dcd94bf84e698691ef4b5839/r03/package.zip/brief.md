# Grüne Erbse · Abstraktion aus freigegebenem A-r02

Auftrag vom 12.10.2026: farbiges Rätsel; 2–3 Rasterkonfigurationen empfehlen und eine getrennte vereinfachte Motivvorlage aus der tatsächlich freigegebenen Datei erzeugen. Identität, Perspektive, Aufbau, Hauptproportionen und wichtige Negativflächen bewahren.

A-r02 wird unverändert übernommen; MA-r01 ist eine separate native Bildableitung für empfohlene 24 × 24 mit drei Vordergrundfarben. Empfehlung ist keine Nutzerfreigabe. Keine Rasterproduktion vor separater Abstraktionsfreigabe. Kategorie gemuese-pilze-kraeuter. Paketablage, Arbeitsbranch, Commit/Push, Draft-PR und bedingter Merge nach vollständigem Diff-/Selbstreview und Pflichtchecks sind ausdrücklich beauftragt. Keine Werkzeugänderung, Katalogregistrierung oder Veröffentlichung.
