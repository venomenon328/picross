# A-r02 → MA-r01 · Abstraktionsfreigabe offen

ID pz-7ec3dcd94bf84e698691ef4b5839, Paket r03, Status motif_review, 12.10.2026, Regelwerk 0.4.1 / Dokumentrevision 4, Quellen-/Toolcommit 660ea63ec90f0e6b608eb11ed036106f012cbc87. Inventarhash im handoff.json.

Die tatsächliche menschliche Abschlussbildfreigabe ist mit UTC-Zeit, Originalerklärung und vollständigem SHA-256 in approvals/reveal-A-r02.json gebunden. A-r02 ist bytegleich zum indexgebundenen r02-Paket. Abstraktionsfreigabe und Endabnahme sind offen.

## Konfiguration

20 × 20, 400 Zellen, drei Grüntöne: kompakt; Kontur/Falten gröber. 24 × 24, 576 Zellen, drei Grüntöne: empfohlen, organische Rundung und drei gut zusammenhängende Hauptflächen ohne unnötige Zusatzdetails. 30 × 30, 900 Zellen, vier Grüntöne: mehr Schattierungsnuancen, höherer Bearbeitungsumfang, wenig weiterer Motivnutzen. Quadrat passt zur annähernd runden Erbse; Rechteck würde Leerraum vergrößern oder das Motiv verzerren. Große Flächen könnten Überlappungsansätze bieten; Symmetrie kann Mehrdeutigkeiten, dünne Farbbänder können fragmentierte Hinweise verursachen. Dies sind Risiken, keine Solverergebnisse. Rastergröße ist keine Schwierigkeitsstufe. Schwierigkeit, Technikbedarf und Lösungszeit noch nicht bestimmt.

## Sichtvergleich der tatsächlichen Dateien

reveal/A-r02.png und motif/MA-r01.png: einzelne grüne Erbse, Perspektive und Bildaufbau erhalten; gerundete leicht asymmetrische Kontur bleibt eng am Original. Licht links oben, dunkle rechte/untere Seite und umlaufender heller Leerraum erhalten. Kein neuer Stielansatz. Die Abstraktion bleibt warm und ruhig, mit organischen klaren Formen. Kleine Abweichungen der äußeren Kontur durch native Ableitung sichtbar; keine geometrische Pixelidentität behauptet.

Detailverluste: Pinsel-/Hauttextur, winzige Glanzlichter und untere linke Hautfalte entfallen. Mehrere Falten oben rechts werden in die breite Schattenform überführt. Der weiche Bodenschatten entfällt; Hintergrund wird Leerfläche. Feine kontinuierliche Modellierung wird auf drei Hauptfarbrollen reduziert. Restliche sanfte Farbverläufe/Antialiasing sind im nativen Bild vorhanden: Es ist keine bereits exakt quantisierte Dreifarbmatrix. Die schmalen Spitzen der rechten Binnenkante müssen später innerhalb der genehmigten Vereinfachung ohne isolierte Einzelzellen umgesetzt werden; gelingt das nicht motivtreu, erneute Motivrevision/Freigabe.

## Nachweise und offene Gates

Ein nativer Bildbearbeitungsaufruf, keine Nachbearbeitung. Quelle, Prompt, tatsächliche unbekannte Einstellungen und Nutzungsgrundlage in provenance/. ZIP-Dateimenge, CRC, Pfade, Größen, SHA-256 und lesbare Handoffkopie geprüft (äußerer validation.json). Alte r01/r02-ZIPs unverändert. Menschliche Freigabe wird nachträglich außerhalb des versiegelten r02-Pakets ergänzt, im neuen r03 vor Versiegelung mitgeführt. Keine nachgelagerten Freigaben vorhanden oder zurückzusetzen.

Kein Raster/Kandidat und keine Hinweise: Randregel, Lösbarkeit, unabhängiger Proof, Endmatrixgleichheit, Rastergestaltung und L1–L5 noch nicht anwendbar. Kein ZA-1-inspect in dieser frühen Bildphase, kein Export, keine Registrierung. Probespielen nicht durchgeführt und optional. Aktive Menschenzeit nicht erfasst. PR #82 ist auf main vorhanden; schlanke Inhalts-CI statt Produktionsprüfungen in CI. Nächster erlaubter Schritt: ausdrückliche Freigabe genau MA-r01 samt vorgeschlagenem 24×24-/Dreifarbkorridor; bis dahin keine Rasterproduktion.
