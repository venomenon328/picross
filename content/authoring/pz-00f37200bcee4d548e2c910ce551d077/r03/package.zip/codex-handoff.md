# Codex-Übergabe · Farbproduktion · noch nicht gestartet

MC-r01 ist eine neue vorgeschlagene Motivdatei. Die B-r01-Freigabe und der
Ablagemerge sind keine Motiv-/Korridorfreigabe. Tatsächliche Nutzerannahme abwarten.

```text
Arbeite nach aktueller AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md
in venomenon328/picross@main. Löse pz-00f37200bcee4d548e2c910ce551d077 r03 über den Authoringindex auf:
content/authoring/pz-00f37200bcee4d548e2c910ce551d077/r03/package.zip.
Prüfe ZIP/Handoff/Inventar, die gültige B-r01-Freigabe und request-update.md.
Maßgeblich ist color; das wiederholte Mono-Formularfeld ist ausdrücklich überholt.
Erst nach meiner ausdrücklichen Freigabe von motifs/MC-r01.png samt parameters.json
starte Standardauftrag 3; vorher keine Rasterproduktion.

MC-r01 SHA-256 6d8ab1271f79dd82ee90ecf00f0202300b2109d729101f006c92000f1ebe493e.
B-r01 SHA-256 5c0b9e57e2a66edfcdd223d72718383c62b205766eb59247bac0a290aaa81070 bleibt unverändert.
Empfohlen 20×22 mit vier Farben; zugelassen 22×24 und reduzierte drei Farben.
Vier gezielte Kandidaten aus config/: zwei Größen × zwei Paletten, jeweils
area-128. Im color-area-Pfad sind Schwellen wirkungslos; keine Scheinvarianten.
Bewahre einzelne diagonale Hälfte, große helle Schnittfläche, pinke Schale,
grüne Spitzen, sechs getrennte Kerne und wichtige Negativräume. Viererpalette:
Creme ist Vordergrund, nicht Leer. Bei drei Farben ist das Fleisch Negativraum.
Führe gemäß Workflow Profilwahl, nötigenfalls begrenzte Reparatur, unabhängige
Nachweise, Herkunft/Endmatrix, Randregel und aktuelle Schwierigkeit aus.
Keine Bestandsreplays oder rätselspezifischen CI-Tests. Liefere Raster und
vollständiges Paket zur gesonderten Endabnahme; noch keine Spielregistrierung.
```

Modell/Reasoning wählt der Nutzer in der Oberfläche gemäß Authoring §3.
