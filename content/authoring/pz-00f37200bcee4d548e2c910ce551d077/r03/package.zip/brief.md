# Drachenfrucht · farbige Motivvorlage MC-r01

ID pz-00f37200bcee4d548e2c910ce551d077; Paket r03; Kategorie obst-nuesse; Quellen-/Toolbasis d75bcfa2fc9b522f274afbf1664a4dc6f67b1f8a.
Authoring 0.5.0 / Dokumentrevision 23. Standardauftrag 2, noch keine Rasterproduktion.

Der aktuelle explizite Wunsch ist Farbe; das wiederholte Formularfeld monochrom
ist überholt. Wörtlicher Auftrag und Auslegung: request-update.md. Die unveränderte
B-r01-Freigabe bleibt gültig. MC-r01 wurde direkt aus dessen Originalbytes erzeugt,
nicht aus der vorherigen unfreigegebenen Mono-Vorlage MB-r01.

Empfohlen: 20 × 22, vier Vordergrundfarben plus Leer. Alternative: 22 × 24 sowie
eine reduzierte Dreierpalette. Vier gezielte spätere Kandidaten aus diesen beiden
Größen und Paletten; kein wirkungsloser Farbschwellenvergleich. parameters.json
und config/ enthalten die konkreten Vorschläge, noch keine menschliche Annahme.

Pink trennt die Schale, Grün die Spitzen, Dunkel die Kerne/Konturen; Creme erhält
die Schnittfläche als zusammenhängende Vordergrundfläche. Bei drei Farben wird
Creme zu Leer/Negativraum. Jede Farbe hat eine benannte Rolle, kein Zusatz nur
für einen technischen Lösbarkeitserfolg. Tatsächliche Rasterfarbzahl noch offen.

Bewahren: eine diagonale Hälfte, Krone oben links, große helle ovale Schnittfläche
vorn rechts, pinke Schale links/unten, grüne gebogene Schuppen, sechs getrennte
Kerne und wichtige Außenzwischenräume. Feine Hautstruktur, viele Samen und
Schattierung sind bewusst vereinfacht. Keine Lösbarkeits-/Schwierigkeitszusage.

Freigegeben ist nur B-r01. Vor Rasterproduktion muss MC-r01 samt vorgeschlagenem
Korridor ausdrücklich menschlich freigegeben werden. Die beauftragte Ablage samt
bedingtem Merge ist keine Inhaltsfreigabe. r02 bleibt als früherer Mono-Vorschlag
unverändert erhalten und ist als aktiver Vorschlag durch diesen Farbauftrag abgelöst.
