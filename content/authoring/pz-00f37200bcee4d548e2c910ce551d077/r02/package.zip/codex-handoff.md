# Codex-Übergabe · Standardauftrag 3 · noch nicht gestartet

Dieses Dokument protokolliert keine Motivfreigabe. Vor Produktion muss eine
tatsächliche Nutzerfreigabe für MB-r01 und den Korridor aus parameters.json
vorliegen; die B-r01-Freigabe allein genügt nicht.

```text
Arbeite nach der aktuellen AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md
in venomenon328/picross@main. Löse pz-00f37200bcee4d548e2c910ce551d077 r02 zuerst über den Authoringindex auf:
content/authoring/pz-00f37200bcee4d548e2c910ce551d077/r02/package.zip.
Prüfe ZIP, Handoff, Inventar, B-r01-Freigabe und Quellenbindung. Erst nach meiner
ausdrücklichen Freigabe der Datei motifs/MB-r01.png samt parameters.json starte
Standardauftrag 3. Fehlt sie, keine Rasterproduktion beginnen.

Empfehlung 20×22, zugelassene Alternative 22×24, monochrom/1 Ink plus Leer.
MB-r01 SHA-256: bb0ebf8105e0a73f036953ab0bb70e2d4ac70f7cdd211aa6deb8fac2a8bb739c.
Abschlussbild reveals/B-r01.png unverändert, SHA-256:
5c0b9e57e2a66edfcdd223d72718383c62b205766eb59247bac0a290aaa81070.
Bewahre Diagonale, große helle Schnittfläche, dunkle linke/untere Schale,
Schuppenrand, sechs getrennte Kerne und wichtige helle Zwischenräume.
Nutze die vier gezielten Kandidaten aus config/design-20x22.json und
config/design-22x24.json; danach Profilwahl, begrenzte motivgeschützte Reparatur,
unabhängige Nachweise, Herkunft/Endmatrix, Randregel und aktuelle Schwierigkeit
gemäß Workflow. Keine Bestandsreplays oder rätselspezifischen CI-Tests.
Liefere Endraster, Vergleich, vollständige Produktionsbelege und Paket zur
gesonderten Endabnahme. Noch keine Spielregistrierung.
```

Modell/Reasoning wählt der Nutzer in der Oberfläche gemäß Authoring §3.
Der Authoringablauf ist kein Auftrag zur Änderung von Produktionswerkzeugen.
