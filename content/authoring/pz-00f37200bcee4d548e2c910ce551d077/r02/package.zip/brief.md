# Drachenfrucht · Motivvorlage MB-r01

ID pz-00f37200bcee4d548e2c910ce551d077, Paket r02, Kategorie obst-nuesse. Standardauftrag 2 nach Authoring
0.5.0 / Dokumentrevision 23, aktuelle Repository-/Toolbasis 2cc94a80cc1ca4bb2a200c3741baf06bf92e44b3.

Nutzerwunsch: ungefähr 20 × 20 monochrom. Tatsächlich freigegeben wurde B-r01,
SHA-256 5c0b9e57e2a66edfcdd223d72718383c62b205766eb59247bac0a290aaa81070; Freigabe und Originalerklärung unter approvals/.
Das farbige Abschlussbild bleibt bytegleich. Nur die separate Motivdatei wird
vereinfacht. Ihre Ableitung ist in motifs/MB-r01.provenance.json gebunden.

Empfohlen: 20 × 22, alternativ 22 × 24, jeweils Mono mit genau einer Ink-ID.
20 × 20 wird verglichen, aber wegen des länglichen Motivbereichs nicht in den
Produktionskorridor aufgenommen. Der Korridor ist vorgeschlagen, nicht abgenommen.
Proportionale exakte Crops und vier gezielte Kandidaten sind in parameters.json
und config/ vorbereitet. Keine Streckung, keine Drehung, keine Motivbeschneidung.

Bewahren: einzelne diagonal liegende Hälfte, Krone oben links, große helle
Schnittfläche vorn rechts, dunkle Schale links/unten, charakteristischer
Schuppenrand, sechs getrennte Kernformen und wichtige helle Zwischenräume.
Verlorene Details: Farben, Schattierung, Oberflächentextur, feine Schuppennähte
und die große Zahl winziger Kerne. Keine Maß-/Lösbarkeits-/Schwierigkeitszusage.

Auftrag enthält Repositoryablage und bedingten Ablagemerge. Vor jeder eigentlichen
Rasterproduktion muss der Nutzer MB-r01 samt vorgeschlagenem Korridor freigeben.
Danach folgt Standardauftrag 3; Endabnahme und Registrierung sind spätere Schritte.
