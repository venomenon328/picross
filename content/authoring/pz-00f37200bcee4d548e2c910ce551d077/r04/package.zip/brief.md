# Drachenfrucht · r04 · begrenzte Produktion blockiert

pz-00f37200bcee4d548e2c910ce551d077; Kategorie obst-nuesse. Quellen-/Toolcommit 983e511bfdd2b99f8c5eeceabeb5819a8172a00b. Authoring 0.5.0, Dokumentrevision 23.

MC-r01 und der gesamte unveränderte Korridor aus r03 sind tatsächlich freigegeben (approvals/motif-evidence.md). B-r01 bleibt bytegleich. Beide Bilddateien, Herkunft, Rechte, Prompts und ursprüngliche Abschlussbildfreigabe bleiben erhalten.

Vier gezielte Designs: 20×22/22×24 mit vier/drei Vordergrundfarben, area-128, proportionale konkrete Crops. Viererpalette: Pink Schale, Grün Schuppenspitzen, Creme gefülltes Fruchtfleisch, Dunkel Kerne/Konturen; bei drei Farben wird das Fleisch Leer. Farbzahl wurde an jeder Matrix gezählt.

Geschützt bleiben einzelne diagonale Hälfte, große ovale helle Schnittfläche, Schale links/unten, grüne Schuppen, sechs getrennte dunkle Kerne und wichtige Außenräume. Genau die dunklen Kernformen scheitern beim Import. Kein finaler Kandidat ausgewählt; stärkere Profilprüfung und zwei begrenzte RP-5-Runden liefern keine freigabefähige Fassung. Einzelheiten: report.md und review/.
