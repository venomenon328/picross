# Drachenfrucht · Abschlussbildauswahl r01

Auftrag vom 23.10.2026: Standardauftrag 1 nach PUZZLE_AUTHORING 0.5.0,
Dokumentrevision 23. Rätsel-ID: pz-00f37200bcee4d548e2c910ce551d077. Kategorie: obst-nuesse (Obst & Nüsse).
Quellen-/Toolstand: venomenon328/picross@98d13fc84db99e5c1377a55cac141914aba5f990.

Wunsch: ungefähr 20 × 20 Zellen (400 Zellen als Ziel), monochrom.
Mono bedeutet später genau eine Vordergrundfarbe plus Leer; kein Wunsch nach
einer bestimmten RGB-Farbe. Das Abschlussbild bleibt vollständig farbig.
Die Maße sind noch kein freigegebener Parameterkorridor.

Freie Interpretation des Motivtexts ohne fremde Bildreferenz (working_mode=free).
Drei farbige detaillierte Einzelillustrationen, echte transparente Außenflächen,
ruhige 2D-Konturen, kräftige pinke Schale und gelbgrüne Schuppenspitzen.
Die angebotenen Kompositionen und ihre jeweils zu bewahrenden Merkmale stehen
in handoff.json/reveal_options. Alle drei Originaldateien bleiben unverändert.

Empfehlung: A-r01. Die einzelne Frucht konzentriert den knappen Rasterraum auf
den charakteristischen Schuppenrand. B besitzt eine klare Schnittfläche, deren
viele Kerne später stark zu reduzieren wären. C benötigt bei 20 × 20 eine
besonders klare Trennung der beiden überlappenden Körper.

Erlaubt sind Ablage nach §6, Commit/Push, PR und Ablagemerge nach Pflichtchecks.
Hier endet Auftrag 1 bei reveal_review. Es gibt weder eine Bildfreigabe noch
eine Motivvorlage, Matrix, Hinweise, Deduktions- oder Schwierigkeitsbewertung.
Nach tatsächlicher Auswahl/Freigabe folgt Auftrag 2. Keine automatische
Abstraktion und keine Spielregistrierung aus dieser Ablagefreigabe ableiten.
