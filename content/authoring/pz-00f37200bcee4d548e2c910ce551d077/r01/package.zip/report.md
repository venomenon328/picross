# Drachenfrucht r01 · reveal_review

- ID: pz-00f37200bcee4d548e2c910ce551d077; 23.10.2026; Regelwerk 0.5.0, Dokumentrevision 23.
- Quellen/Toolcommit: 98d13fc84db99e5c1377a55cac141914aba5f990. Originalinventar: inventory.json;
  sein SHA-256 ist im Handoff und äußeren Repositoryrecord gebunden.
- Drei farbige transparente Original-PNGs: reveals/A-r01.png (ganze Frucht),
  reveals/B-r01.png (Hälfte), reveals/C-r01.png (beide). Je 1254 × 1254 RGBA.
- Empfehlung A-r01: beste Konzentration auf eine charakteristische Silhouette.
  B verlangt starke Kernreduktion; C teilt die kleine Rasterfläche auf zwei Körper.
  Keine Variante gewählt oder abgelehnt; Auswahl bleibt menschlich.
- Wunsch: ungefähr 20 × 20, monochrom. Tatsächliche Maße/Farbzahl des Rasters:
  noch offen. Parameterkorridor und Motivvorlage entstehen erst in Auftrag 2.
- Sichtprüfung: alle fünf Stil-/Motivkriterien erfüllt, siehe visual-review.json.
  visual-review.png zeigt große/kleine statische Ansichten auf echtem Projektpapier.
  Außenflächen transparent, Schnittfleisch bei B/C erhalten. Schwache Alpha-Spuren
  nahe einigen Canvasrändern ohne sichtbaren Kasten; keine globale Freistellung.
- Herkunft/Nutzungsgrundlage und echte Prompts: provenance.json, generation.json,
  prompts/*.txt. Drei native Bildaufrufe, keine Überarbeitung, Menschenzeit unbekannt.
- Bildfreigabe, Motivfreigabe und Endabnahme: ausdrücklich offen.
  Raster, Hinweise, Randregel, Proof, Herkunftsrekonstruktion zur Matrix,
  Schwierigkeit und Zieladapter: noch nicht anwendbar; keine Erfolgsbehauptung.
  Reparatur entfällt: noch kein Raster. Lösungszeit nicht geschätzt.
- Datei-/Inventar-/ZIP-Prüfung erfolgt am geschriebenen Paket; Nachweis separat
  im äußeren Repositoryrecord/PR, ohne die versiegelten Originale umzuschreiben.
- Nächster Schritt: 2 · Bild freigeben & abstrahieren. Mensch wählt A-r01/B-r01/C-r01
  und gibt genau die gezeigte Datei frei. Keine Motiv- oder Rasterproduktion davor.
