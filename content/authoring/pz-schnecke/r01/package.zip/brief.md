# Motivbriefing · Schnecke · Schritt 1

Job: pz-schnecke, Revision r01. Kategorie: insekten-kleine-tiere (Insekten & kleine Tiere).
Auftrag: https://github.com/venomenon328/picross/issues/610
Gelesene Repository-/Werkzeugbasis: 187e37bb2471c03f75a2b365ed3e341150b94f66. Authoring 0.8.0, Dokumentrevision 4.

Neues Motiv ohne Eingangsbild oder vorhandenen Produktionsdatensatz. Freie erste Gestaltung (free). Drei eigenständige detaillierte farbige Abschlussbilder, ruhige warme handgezeichnete 2D-Illustrationen auf echtem transparentem PNG-Grund. Einzelne Schnecke mit spiraligem Haus, zusammenhängendem Kriechfuß, zwei langen Augenfühlern und zwei kurzen Tastfühlern. Motivgerechte Wachstumszeichnung, Hautdetails und zurückhaltende Schattierung. Keine Schrift, Wasserzeichen oder zusätzlichen Gegenstände.

Verbindliche frühe Vorgaben für das SPÄTERE Lösungsraster:
- Breite: ungefähr 20 Zellen.
- Höhe: ungefähr 14 Zellen.
- Rastermodus: monochrom (mono).
- Vordergrundfarben: genau eine tatsächlich verwendete Vordergrundfarbe; Leer zählt nicht.
- Das Abschlussbild bleibt detailliert und farbig, unabhängig von der Rasterfarbzahl.

Diese Wünsche im Folgeauftrag erhalten. Die beiden Achsen sind ungefähr, nicht exakt; noch keine konkrete Importkonfiguration und kein menschlich freigegebener Parameterkorridor. Konkrete Abstraktion und angemessenen Korridor erst nach der ausdrücklichen Freigabe eines gespeicherten Originalbilds vorlegen. Keine Lösbarkeit oder Schwierigkeit für das künftige Raster behauptet.

Angebote: A-r01 nach rechts, goldbraunes Haus/salbeigrüner Körper; B-r01 nach links aufgerichtet, rotbraunes Haus/ockerfarbener Körper; C-r01 leichte Dreiviertelansicht nach rechts, cremefarbenes Haus/blaugrauer Körper. Empfehlung A-r01 wegen klarer Seitenansicht und breiter zusammenhängender Hauptform. Empfehlung ist keine menschliche Wahl.

Nächste Entscheidung: konkretes unverändertes Abschlussbild A-r01, B-r01 oder C-r01 auswählen und ausdrücklich freigeben oder eine Korrektur benennen. Danach im selben Branch eine neue Revision für Schritt 2 erstellen; aus genau den gewählten gespeicherten Bytes abstrahieren. Keine Motivvorlage, Raster oder Hinweise in Schritt 1.

Befugnisse: Commit, Push, Draft-PR im Umfang dieses Schritts; kein Merge. Keine zusätzliche Abschlussbereinigung lokaler Arbeitsdaten beauftragt. Späterer fachlicher Produktionsabschluss nach Authoring §9 bleibt getrennt und ist jetzt nicht fällig.
