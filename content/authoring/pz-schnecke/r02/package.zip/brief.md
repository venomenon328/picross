# Schnecke · M-r02 und Parameter zur Freigabe

Kategorie: insekten-kleine-tiere. Quelle: pz-schnecke/r01 am Commit a21053055074553f16f0cd139c1177b7fa9c1e7c.
Verbindliche Regeln: aktueller main 187e37bb2471c03f75a2b365ed3e341150b94f66, Authoring 0.8.0 Dokumentrevision 4.
Das ursprüngliche Briefing bleibt bytegleich in brief-r01.md erhalten.
Frühe Wünsche bleiben ungefähr 20 Zellen Breite und 14 Zellen Höhe, mono mit genau einer Vordergrundfarbe.
Tatsächlich neue Entscheidung: unverändertes A-r01 gewählt und freigegeben; Beleg step2-order.txt und reveal-approval.json.

M-r02 ist die separate native vorlagentreue ImageGen-Ableitung genau dieses Originals.
Erhalten: rechte Kriechrichtung, Seitenansicht, großes rundes Spiralhaus links, langer niedriger Fuß/Schwanz,
rechts angehobener Kopf mit zwei langen getrennten Augenfühlern und zwei kurzen Tastfühlern.
Reduziert: Farbe, Schalenrippen, Hautstruktur, Licht und Schatten; kräftiger transparenter Spiralraum,
gekräftigte Fühler und vereinfachter Haus-/Fußübergang. Das Abschlussbild bleibt unverändert detailliert und farbig.

## Empfohlener Korridor (Vorschlag, nicht freigegeben)

20×14 als bevorzugter Importstart: trifft beide ungefähren Wünsche, hält die breite Seitenansicht
und bietet überschaubaren Umfang (280 Zellen). Spiralraum und Fühler können bei Mono knappe Stellen sein.
22×16 als Detailreserve (352 Zellen): mehr Raum für Spiralwindung und Fühlertrennung bei etwas größerem Umfang.
18×12 als kompakte Alternative (216 Zellen): weniger Arbeit, aber größtes Risiko zusammenlaufender Binnenräume.
Diese Größen sagen weder Lösbarkeit noch eine Schwierigkeitsstufe voraus. Keine zusätzliche Farbe.

Der geschlossene Vorschlag parameters.json hält beide Endmaße ungefähr: Breite 18–22, Höhe 12–16,
Ziel 20×14, mono und genau eine tatsächlich verwendete Vordergrundfarbe ink (empfohlen #282828).
Leer/Transparenz zählt nicht. Die Motiv-PNG enthält Antialiasing und geringe dunkle Tonvariation;
das ist keine Rasterpalette. Erst Schritt 3 erzeugt exakt ink/leer und zählt die tatsächliche Nutzung.
Explizite Importstarts: 20×14, 22×16, 18×12 mit area/contain und vollständigem Bildausschnitt
[0,0,1499,1049]; keine Verzerrung, neue Pose, Spiegelung oder abgeschnittenen Motivteile.
Vier gezielte Kandidaten in Schritt 3, nicht jeder Korridorwert als blinde Suche.

Zur Freigabe gehört die begrenzte Erlaubnis für motivtreue feste Zellkorrekturen (höchstens zwei
Positionen pro Endkandidat, vorab mit Plan/Schutzmaske gebunden) und ausschließlich bereits leere
Außenlinien an allen vier Seiten gemäß FIXED_RASTER. Endmaße müssen im genannten Korridor bleiben.
Spiralraum, Fühlerzwischenraum und Hauptformen sind gefüllt UND leer zu schützen. Gute Raster nicht
unnötig ändern; keine materiellen Änderungen, Logikanker oder nachträglich erweiterten Editlisten.
Jede tatsächliche Rasteränderung verlangt die frischen vollständigen Nachweise aus Authoring §4.
Materielle Motivänderungen benötigen eine erneute konkrete menschliche Freigabe.

Stand motif_review: M-r02 und der gesamte Korridor sind noch nicht freigegeben. Keine Zellmatrix,
Hinweise, Solver-, Proof-, Difficulty-, Hintergrund- oder Integrationsarbeit durchgeführt.
Nächste Entscheidung: genau diese Motivdatei und parameters.json freigeben oder gezielte Korrektur nennen.
Erst danach Schritt 3. Commit/Push/Draft-PR erlaubt; kein Merge, keine zusätzliche lokale Abschlussbereinigung.
Der fachliche Abschluss nach Authoring §9 ist vor Endabnahme und Mainintegration nicht fällig.
