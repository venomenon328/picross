# Schnecke · Rasterangebote in Schritt 3

Tatsächlicher Auftrag step3-order.txt; freigegebene unveränderte M-r02 aus r02@4f5ddc5e09896661eec393af8e14db4fc5d81e4b.
Reveal A-r01 und seine echte Freigabe bleiben unverändert. Kategorie insekten-kleine-tiere.
Frühe Wünsche bleiben ungefähr20×14, mono mit genau1 Vordergrundfarbe. Freigegebene Endbreite18..22,
Endhöhe12..16, Ziel20×14: konkrete Importstarts werden nicht zu exakten Endmaßen umgedeutet.
Feste kleine motivtreue Korrekturen und ausschließlich leerer Außenbeschnitt sind tatsächlich autorisiert.
Kumulative6 Importe/2 feste Korrekturrunden, je Endstand2 Zellen; keine manuelle Sonderautorisierung.
R-A-r05:18×12, Mittel, aus20×14/area128. R-B-r06:20×12, Schwer, aus22×16/area144.
Empfehlung R-B-r06 wegen größerem Spiralraum und höherem belegtem Motivanteil; R-A-r05 ist kompakter.
Empfehlung ist keine Auswahl. Keine Rasterwahl, Hintergrundentscheidung, Endfreigabe oder Integration.
