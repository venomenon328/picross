# Nächster Auftrag · 4 · Abnehmen & ins Spiel integrieren

Zuerst Arbeitsindex/Record und dieses versiegelte r03-ZIP auf main laden.
Handoff, Inventar und echte spätere Endfreigabe binden. Die tatsächliche Endabnahme
ist derzeit offen; nicht aus der Motivfreigabe oder dem Ablage-Merge erfinden.

Endkandidat production/30x10-coverage / area-218, 30×10, mono, genau eine
Vordergrundfarbe, voller Crop, area/exact, alpha40, threshold218. Vollständiger
unabhängig bestätigter full-line-mono-Nachweis und Quellenrekonstruktion liegen vor.
Die unveränderten A-r01-/M-r01-Originale samt tatsächlichen Freigaben bleiben enthalten.
review/final-comparison.png und report.md bilden die Endabnahmevorlage.

Aktuelle Methode0.4: analysis/checked.json und vollständiges analysis/full-Bundle,
L1/medium. difficulty.json ist die gesonderte historische 0.1-Form für ZA-1,
keine alternative aktive Neubewertung. Bei späterem Export den geprüften Input
auf die tatsächlichen Definitionsbytes rebindend übernehmen; keine Routineanalyse.

Erst mit tatsächlicher Endabnahme und Auftrag4: export → rebind → plan/register
nach dem aktuellen Regelwerk. Kategorie saeuger, ID unverändert, gewöhnlich
Runtime-Revision1; kollisionsfreien Stem/Slot beim Start prüfen. Keine Routine-
Spieler-/Chromium-/Bestandsreplays. Nach tatsächlichem Integrationsmerge §9.
