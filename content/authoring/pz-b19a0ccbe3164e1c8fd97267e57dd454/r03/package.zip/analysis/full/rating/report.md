# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: cabae1fa218854bd3e4772118c350b369de468b4f6cacb594a860587b35aa9f4
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 1/4 |
| search | 405/1984 |
| workload | 0 |

Score: 901/1984; level: 1 / 5.
Without workload: 901/1984; level: 1.
Lower boundary: -; distance: -.
Upper boundary: 1; distance: 1083/1984.
Nearest boundary distance: 1083/1984.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
