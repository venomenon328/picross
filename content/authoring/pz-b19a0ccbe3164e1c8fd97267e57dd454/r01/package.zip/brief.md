# Fledermaus · Abschlussbildauswahl r01

Auftrag: Standardauftrag 1 nach docs/ai-workflows/PUZZLE_AUTHORING.md.
Motiv: Fledermaus. Rasterwunsch ungefähr 25 × 15 Zellen, monochrom mit genau
einer Vordergrundfarbe plus Leer; alle Abschlussbilder bleiben farbig.
Kategorie: saeuger / Säugetiere, nach prägendem Hauptgegenstand.

Textauftrag ohne Bildreferenz; freie Motivübertragung (working_mode=free).
Unverzichtbar: eine Fledermaus, zwei erkennbare Ohren, Fellkörper, zwei anatomisch
plausible Membranflügel mit Fingerstreben und charakteristisch gebuchteten Rändern.
Keine konkrete Tierart zugesagt. Warme ruhige 2D-Illustration mit ausgearbeiteter
Binnenzeichnung und echten transparenten Außenflächen. Keine Umgebung, Schrift
oder Raster. Flügelhaltung und Farbgebung dürfen zwischen den Vorschlägen variieren.

Die konkrete Pose, Proportionen, wichtigen Negativräume und Konturen der später
ausgewählten Datei werden erst mit ihrer tatsächlichen Freigabe verbindlich.
Kein Parameterkorridor freigegeben, keine Abstraktion oder Zellmatrix erstellt.

Autorisierung: Repositoryablage nach §6, Commit/Push/Draft-PR und bedingter Merge
des Ablage-PR nach erfolgreichen Pflichtprüfungen. Der Auftrag enthält keine
Abschlussbild-, Motiv- oder Endfreigabe. Nächster Halt: echte Abschlussbildfreigabe.
