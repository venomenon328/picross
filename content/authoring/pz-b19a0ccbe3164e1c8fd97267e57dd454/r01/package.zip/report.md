# Fledermaus · r01 · reveal_review

Stand: 2026-10-27T23:09:50Z. ID: pz-b19a0ccbe3164e1c8fd97267e57dd454. Regelwerk 0.5.0, Dokumentrevision 23.
Quell-/Toolstand: main@2f6a197368a4123be2cc833dc901381d315f5043.
Wunsch: ungefähr 25 × 15, monochrom, eine Vordergrundfarbe plus Leer.
Keine tatsächliche Matrix, Farbzählung, Schwierigkeit oder Lösungszeit vorhanden.

- A-r01: Frontal mit waagerechten Flügeln, einfachste Symmetrie, sehr flache Form.
- B-r01: Gleitflug in Dreiviertelansicht, lebendig; erhöhte Abstraktionsanforderung.
- C-r01: angehobene Flügel, stärkere Höhennutzung. Empfehlung für den Rasterwunsch.

Alle drei tatsächlichen PNG-Einzeldateien bleiben im Paket unverändert erhalten.
Erkennbarkeit, Silhouette/Proportionen, Details/Negativräume, Palette/Mono-Lesbarkeit
und Serienästhetik jeweils erfüllt, mit Begründungen in review/image-checks.json.
Transparenz, volle Bilddarstellung und repräsentative Kataloggrößen 100/125 %
auf einem Ausschnitt des tatsächlichen Buchpapiers sind statisch gesichtet.
review/selection-on-paper.png ist die Auswahlhilfe, kein Ersatz für die Originale.
Die Membranen besitzen ausgearbeitete Binnenzeichnung, der Körper Fellzeichnung.

Bildquelle: native Neugenerierung ohne Fremdbildreferenzen. Die tatsächlichen
Prompts und offengelegten Einstellungen sind gespeichert; unbekannte Einstellungen
sind not_exposed. Drei Bildaufrufe, keine Korrekturrunde, Menschenzeit nicht erfasst.

Alle menschlichen Bild-/Motiv-/Endfreigaben sind offen. Vor Abstraktion muss der
Nutzer genau A-r01, B-r01 oder C-r01 ausdrücklich als Abschlussbild freigeben.
Keine Rasterproduktion, Reparatur, Logikprüfung, Analyse, ZA-1-Zertifizierung oder
Spielintegration ausgeführt; diese Arbeiten gehören zu späteren Standardaufträgen.
Kein materialisierter Parameterkorridor vor der Bildauswahl, keine Lösbarkeit zugesagt.

Die Ablage erhält einen getrennten vollständigen Dateidiff-/Bindungscheck und den
automatisch ausgewählten schlanken Inhalts-CI-Pfad. Die dazugehörigen aktuellen
Head-/Basis-/Run-/Mergebelege liegen im PR; keine Tests allein wegen neuer Bilder.
