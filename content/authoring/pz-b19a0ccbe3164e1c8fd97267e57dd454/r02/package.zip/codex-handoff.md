# Übergabe für Standardauftrag 3 · Fledermaus

Repository venomenon328/picross, Ziel main, ID pz-b19a0ccbe3164e1c8fd97267e57dd454, Paketrevision r02.
Einstieg AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md auf dem dann aktuellen
beauftragten Branch. Aktueller Stand ist motif_review, noch nicht motif_approved.

Das Abschlussbild A-r01 ist tatsächlich freigegeben: reveals/A-r01.png, SHA-256
7f433913a79a5e25e3fec423a2c05eeab675bb76b386cc09d05b7f0f2901c27c; Beleg approvals/reveal-A-r01.json und approvals/user-request.md.
Vorlage motifs/M-r01.png (M-r01), SHA-256 7ba635b32475f06d476b5c5572369eb1b4921ea2d2492d637c74f0b14f384887.
Das neue Paket enthält alle tatsächlich benötigten Bytes; r01 muss für verworfene
Varianten nicht geladen werden. Frühere Originalbindungen stehen in sources.json.

Vor Produktionsstart die tatsächliche neue menschliche Motivfreigabe samt
configuration.json und invariants.json protokollieren. Aus dem aktuellen Auftrag
keine Motiv- oder Endfreigabe ableiten. Die Vorlage erst dann rasterisieren.
Vorgeschlagen: 27 × 9 und 30 × 10, mono, genau eine Vordergrundfarbe, volle
2172 × 724 Quelle, crop [0,0,2172,724], fit exact, area. Die beiden vorbereiteten
Designs besitzen je zwei Schwellwerte: vier geplante Kandidaten, noch keiner erzeugt.
Nur echte unterschiedliche Matrizen zählen als verschiedene Kandidaten.

Der Import, vollständiger unabhängiger Nachweis, aktive Schwierigkeit und
begrenzte Reparatur nach dem aktuellen Regelwerk gehören ausschließlich zum
späteren Auftrag 3. Insbesondere keine Lösbarkeit aus der Silhouette behaupten.
Formschutz und erlaubte Verluste: invariants.json. Materielle Änderung oder
anderer Crop/Modus braucht die entsprechende Freigabe.

Für die reguläre Authoring-Bindung approved_parameters und tatsächlichen
Motivfreigabebeleg erst aus der Erklärung des Menschen erzeugen. Bei zwei
freigegebenen Größen die Erklärung als gemeinsame Evidenz behalten und die
konkret ausgewählte Parametersatzbindung zum endgültigen Kandidaten führen.
Keine erfundene Vorabfreigabe oder nachträgliche Umdeutung des ursprünglichen 25 × 15.

Auftrag 3 endet beim geprüften content_ready-Paket und der redaktionellen
Endabnahmevorlage. Noch keine ZA-1-Registrierung. Kein Spielerbuild/Chromium oder
rätselspezifischer Testbestand allein wegen neuer Inhalte. Ablage- und eventuelle
Mergebefugnisse nach dem tatsächlichen Folgeauftrag prüfen. Modell/Reasoning wird
in der Oberfläche gewählt; diese Datei ist keine Modell-API-Anweisung.
