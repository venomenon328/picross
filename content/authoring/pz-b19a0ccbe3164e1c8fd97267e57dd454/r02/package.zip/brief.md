# Fledermaus · Standardauftrag 2 · r02

Nutzerwunsch unverändert: ungefähr 25 × 15, monochrom, genau eine Vordergrundfarbe
ohne Leer. Kategorie saeuger / Säugetiere. Stabile ID pz-b19a0ccbe3164e1c8fd97267e57dd454.
Tatsächlich freigegeben ist A-r01, nicht die frühere Empfehlung C-r01.
Die ausgewählten Originalbytes bleiben unter reveals/A-r01.png unverändert.
Freigabe und ursprüngliche Paketbindung: approvals/reveal-A-r01.json.

Die Motivvorlage motifs/M-r01.png ist aus genau dieser Datei nativ abgeleitet;
sie ist eine kontinuierliche Illustration und noch keine Zellmatrix.
Nach der Auswahl gilt working_mode=faithful; freie Neupose ist nicht erlaubt.
Zu bewahrende Form und zulässige Detailverluste stehen in invariants.json.

Empfehlung 27 × 9, Alternative 30 × 10, jeweils 3:1, mono, eine Vordergrundfarbe.
Die flache A-Pose passt nicht sinnvoll in das ursprüngliche 5:3-Ziel; ungefähr
erlaubt die begründete Größenempfehlung. Originalwunsch und vorgeschlagener
Korridor bleiben separat. configuration.json und config/ enthalten die exakten
Vorschläge; approved_parameters bleibt bis zur tatsächlichen Motivfreigabe leer.

Umfang: Bildfreigabe protokollieren, Motivvorlage/Konfiguration/Codex-Handoff,
Repositoryablage und bedingter Ablage-Merge nach Pflichtprüfungen. Kein Auftrag 3
vor tatsächlicher Motivfreigabe; keine Spielregistrierung oder Endabnahme.
