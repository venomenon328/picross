# Fortsetzung

Aktuellen main, AGENTS.md und Pflichtquellen lesen; Index auf r05 auflösen.
ZIP/Handoff/Inventar und äußeren ZA-1-inspect-Bericht kontrollieren.
Auswahl production/c30x45-4c / area; unveränderte MA-r04 und B-r02.
Nur nach tatsächlicher menschlicher Endabnahme für dieses Inventar Auftrag 4:
externe approval.json, export → plan → register, Pflichtchecks und beauftragter Merge.
Die Repositoryablage ist bereits beauftragt; sie erteilt keine Endabnahme.
Nach tatsächlicher Spielintegration Abschnitt 9 anwenden; jetzt keine Bereinigung.
