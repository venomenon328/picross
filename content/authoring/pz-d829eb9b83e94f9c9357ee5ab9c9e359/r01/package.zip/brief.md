# Marie Curie · Abschlussbildauswahl

Standardauftrag 1; Ausgangspunkt main@d0d57131ea74846be14756b78e5763a9ae13bb11; 2026-10-17T10:21:57.185605+00:00.
Motiv: Marie Curie. Rasterbreite offen, Höhe ungefähr 40; farbig, Farbzahl offen.
Kategorie: menschen-berufe (Menschen & Berufe).
Freie historische Illustration (working_mode=free), keine bereitgestellte Bildreferenz.
Identitätskern: längliches Gesicht, hohe Stirn, zurückgenommenes welliges Haar mit Dutt,
markante Nase, ernster konzentrierter Ausdruck, hochgeschlossenes zeittypisches Kleid.
Variieren dürfen Blickrichtung, Bildausschnitt, Kleidfarbe und ein einzelner Laborkolben.
Der Kolben in C ist ein illustratives Berufsattribut, keine Rekonstruktion eines Experiments.
Ruhige warme 2D-Illustration; Hauptformen müssen später abstrahierbar bleiben.
Keine Schrift, Strahlenzeichen, Leuchteffekte, Rahmen oder Umgebung zur Flächenfüllung.
Keine Rasterproduktion, Motivvorlage, Bildfreigabe oder Spielregistrierung in Auftrag 1.
Repositoryablage nach §6 und Merge nach Pflichtprüfungen ausdrücklich beauftragt.

