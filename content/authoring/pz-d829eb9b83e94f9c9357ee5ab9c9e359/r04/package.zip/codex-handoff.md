# Wiederaufnahme

1. Aktuellen main und AGENTS.md / PUZZLE_AUTHORING samt Pflichtquellen lesen.
2. Arbeitsindex auf r04 von pz-d829eb9b83e94f9c9357ee5ab9c9e359 auflösen und alle Hashes prüfen.
3. Nur nach tatsächlicher Freigabe von motif/MA-r04.png und configuration.json
   Standardauftrag 3 ausführen. Die alte Freigabe MA-r03 gilt nicht für MA-r04.
4. Vier neue Kandidaten gemäß configuration.json; Kragenband und getrennte
   Nasen-/Munddarstellung ausdrücklich visuell prüfen. Alte Proofs nicht übertragen.
5. Freigegebenes B-r02 bytegleich halten; keine Spielregistrierung vor Endabnahme.

Repositoryablage samt bedingtem Merge ist bereits beauftragt. Dieses Dokument
erteilt selbst keine Bild-, Raster- oder Endfreigabe.
