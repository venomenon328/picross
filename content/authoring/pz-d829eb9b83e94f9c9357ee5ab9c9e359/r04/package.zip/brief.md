# Marie Curie · korrigierte Motivvorlage MA-r04

ID pz-d829eb9b83e94f9c9357ee5ab9c9e359; Paket r04; Quelle main@f48a9cc23537b06d86661bf1f4a5658e463a211b; Kategorie menschen-berufe.
Der Nutzer hat nach dem visuellen Fehlschlag aller vier logisch zertifizierten
MA-r03-Raster eine neue Motivvorlage beauftragt. Die Belege liegen unverändert in
r03 auf main, PR #226. MA-r04 ist eine neue Freigabevorlage, keine freigegebene Quelle.

B-r02 bleibt bytegleich und verbindliche Identitäts-/Kompositionsreferenz. Geändert:
breiter durchgehender weißer Kragen, getrennte Nasen-/Mundformen, zusammengefasste
Haarwellen. Erhalten: Blickrichtung, hohe Stirn, langes Gesicht, Nase, Augenpositionen,
Dutt rechts, Schulter-/Kopfproportionen und vollständiger 2:3-Ausschnitt.
Empfehlung unverändert 28×42, farbig, vier Vordergrundfarben; Korridor gemäß
configuration.json 26×39, 28×42, 30×45 mit drei/vier Farben. Keine Spiegelung/Streckung.
MA-r04 plus Korridor müssen vor jedem neuen Rasterimport ausdrücklich freigegeben werden.
