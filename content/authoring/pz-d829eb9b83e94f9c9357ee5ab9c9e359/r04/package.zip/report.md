# Marie Curie · r04 · neue Motivfreigabevorlage

**motif_review**, 17.10.2026; pz-d829eb9b83e94f9c9357ee5ab9c9e359; Regelwerk 0.5.0 / Revision 14;
Quelle main@f48a9cc23537b06d86661bf1f4a5658e463a211b. Inventarhash in handoff.json und äußerem record.json.

Der Auftrag „Neue Motivvorlage vorbereiten“ ist ausgeführt. **MA-r04 ist noch nicht
freigegeben.** Abschlussbild B-r02 bleibt unverändert freigegeben. Endabnahme offen.
[Bildvergleich](comparison.png), [Motiv MA-r04](motif/MA-r04.png), [B-r02](reveal/B-r02.png).

Korrektur: breiter durchgehender heller Kragen, mehr freie Hautfläche zwischen
Nasen-/Mundmarken, gröbere Haarwellen. Blickrichtung, Stirn, langes Gesicht,
Nasenprofil, Augenpositionen, Dutt und Schulterumriss bleiben erhalten. Feine
Kragenbögen, Haarsträhnen und Gesichtslinien entfallen. Menschlicher Abgleich
dieser materiellen Abstraktionsänderungen erforderlich; visual-review.json.

Empfehlung 28×42 = 1176 Zellen, farbig, vier Vordergrundfarben: Aubergine
Kleid/Kontur, Braun Haar, Pfirsich Haut, Terrakotta Schatten. Zulässiger Vorschlag
26×39/28×42/30×45 mit 3–4 Farben; Parameter und Alternativen in configuration.json.
Noch keine tatsächliche Matrixfarbzahl. Quelldatei 1024×1536 mit Glättung/Resttonwerten.

Keine Rasterproduktion aus MA-r04, keine neue Lösbarkeits- oder Randregelzusage.
Alle vier MA-r03-Raster waren full-line-color zertifiziert, aber visuell verworfen;
Originalbelege unverändert in r03 / PR #226, genauer Commit/Hash in decisions.json.
Keine RP-5-Reparatur oder nachträgliche Umwertung dieser Raster. Schwierigkeit
für MA-r04 nicht geschätzt, Lösungszeit unbekannt. Ein nativer Bildaufruf,
Menschenzeit nicht erfasst; tatsächlicher Prompt in MA-r04-prompt.txt.

Datei-/Inventar-/Bildfreigabebindungen geprüft. Nutzung: neu generierter Projektinhalt
ohne übernommene Fremdassetbytes, siehe Provenienz. Kein Zieladapterexport oder
Runtimeeintrag. **Nächster Schritt: 3 · Motiv freigeben & produzieren** –
MA-r04 samt Korridor ausdrücklich freigeben, danach Produktion/Prüfung neu ausführen.
