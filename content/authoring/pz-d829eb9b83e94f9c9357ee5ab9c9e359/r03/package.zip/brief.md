# Marie Curie · Produktion r03

ID pz-d829eb9b83e94f9c9357ee5ab9c9e359; Quelle/Tools main@76dbeaf85c83018f7dbc47522ef290a26ba251b7; Kategorie menschen-berufe.
MA-r03 und der Korridor sind durch den Auftrag tatsächlich freigegeben.
Abschlussbild B-r02 bleibt bytegleich. Empfehlung 28×42, vier Vordergrundfarben;
zulässig 26×39, 28×42, 30×45 mit drei/vier Farben, vollständiger Ausschnitt 1024×1536,
proportional exakt 2:3. Keine Spiegelung, Streckung oder materielle Motivänderung.

Geschützt sind Dreiviertelansicht nach links, hohe Stirn, langes Gesicht, Nase,
Augenproportionen und ernster Mund, Haarwellen/Dutt rechts, dunkles hochgeschlossenes
Kleid und heller Kragen, Kopf-/Schulterproportionen und wichtige Negativräume.
Vier gezielte Direktimporte nach configuration.json wurden vollständig geprüft.
Alle sind logisch zertifiziert, aber keiner ist visuell freigabefähig: insbesondere
verschwindet das geschützte helle Kragenband. Status blocked; kein Endkandidat.
