# Marie Curie · r03 · Produktionsbefund

**Status blocked, kein Endabnahmekandidat.** 17.10.2026; ID pz-d829eb9b83e94f9c9357ee5ab9c9e359;
Regelwerk 0.5.0 / Dokumentrevision 14; Tools/Quelle 76dbeaf85c83018f7dbc47522ef290a26ba251b7.
Inventar-SHA-256 steht ohne Selbstreferenz in handoff.json und im äußeren record.json.

Abschlussbild B-r02 und Motiv MA-r03 sind tatsächlich freigegeben (reveal-approval.json,
motif-approval.json); B-r02 ist bytegleich. Endabnahme offen. [Bildvergleich](comparison.png),
[vier echte Raster](candidates.png), Einzelraster mit/ohne Gitter unter audit/.

Vier Kandidaten: 26×39/4 (1014 Zellen), 28×42/3 und /4 (1176), 30×45/4 (1350).
Gewünscht/empfohlen vier Farben; Istzahlen 4/3/4/4 automatisch gezählt. Aubergine
trägt Kleid/Konturen, Braun Haar, Pfirsich Haut, Terrakotta Gesichtsschatten.
Alle behalten den vollständigen 2:3-Ausschnitt; kein Spiegeln/Strecken/Zelledit.
26×39/4 trennt Nase/Mund am besten, ist aber nur Vergleichsreferenz: **der geschützte
helle Kragen fehlt in allen vier Rastern**. Bei 28×42/4 und 30×45/4 verschmelzen
Nasen-/Mundflächen; drei Farben schwächen Gesicht/Hals zusätzlich. Kein Motivpass.

**Technisch bestanden, alle vier:** Produktmaße, tatsächliche Palette, Randregel,
vollständige Deduktion full-line-color vom unbekannten Start, frischer unabhängiger
DAG-Prüfer, vollständige Herkunftsrekonstruktion Bild→Normalisierung→Matrix→Hinweise,
exakte Endmatrix und Vorschau. Das vollständige Zertifikat belegt auch Eindeutigkeit.
[Belege](audit/summary.json). Alle Matrizen verschieden. Kein Paar-/Suchlauf nötig.
Keine RP-5-Reparatur: kein Logikdefizit; kein visuell geeigneter Kandidat, und die
erforderliche Kragen-/Gesichtskorrektur berührt geschützte Merkmale (§§2.4/4.4).

Schwierigkeit je verworfenem Kandidaten vorläufig L2, Bereich L1–L4, low,
editorial_estimate; Details/Techniken in difficulty.json. Breite Kleidanker und
verteilte Fortschritte, vor jedem Schritt alle Linien geprüft: mindestens 10–15
produktive Linien vor Restaufräumen, keine numerische Engstelle. Kein vollständiger
R0–R3-Klassifikator, keine menschliche Kalibrierung. Lösungszeit nicht geschätzt.

Nutzungsgrundlage: neu generierter Projektinhalt, keine Fremdassetbytes (provenance.json).
Vier Kandidaten, acht Importaufrufe einschließlich vier UTF-8-Metadatenkorrekturen;
Matrix-/Logikgleichheit der Wiederholung bestätigt. Keine neuen Bildaufrufe,
keine Reparatur; Menschenzeit nicht erfasst. Probespiel optional/nicht durchgeführt.
ZA-1-Export nicht ausgeführt: visuelle Inhaltsgates fehlen. Kein Spielstart/Build nötig.

**Nächster Schritt: Korrigieren oder Fehler beheben.** Neue Motivvorlage mit auf 28×42
sichtbar breiterem hellem Kragen und klar getrennten Gesichtszügen vorbereiten und
erneut menschlich freigeben; danach neue Rasterproduktion. Keine vorhandene
Freigabe wird auf geänderte Bildbytes übertragen. Paketablage ist keine Inhaltsabnahme.
