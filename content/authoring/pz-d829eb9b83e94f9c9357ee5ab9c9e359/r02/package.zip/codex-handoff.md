# Codex-Übergabe · nach ausdrücklicher Motivfreigabe

Aktueller Status: motif_review. Dieser Text erteilt keine Motivfreigabe.
Bevorzugter Weg für Auftrag 3: Codex. Selbst umsetzbar: Ja, Bild-/Repository-/Werkzeugwege
sind verfügbar; die menschliche Motivfreigabe bleibt vorgelagert. Noch keine startbereite
Produktionsfreigabe und deshalb keine verbindliche Modellwahl für einen jetzt laufenden Auftrag.

Nach menschlicher Freigabe der exakten Datei motif/MA-r03.png
(1091629b51a115a8c8b35eb917b3ec69a37d7dae11b6a56ec5b115a2ee4cef3b) und des Korridors aus configuration.json kann folgender Folgeauftrag
im aktuellen Workflow ausgeführt werden:

```text
Arbeite in venomenon328/picross@main; Einstieg AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Lade content/authoring/pz-d829eb9b83e94f9c9357ee5ab9c9e359/r02/package.zip über den Arbeitsindex.
Standardauftrag 3 erst nach tatsächlicher menschlicher Freigabe von MA-r03 samt configuration.json:
Freigabe dateigebunden protokollieren, dann Motiv produzieren, prüfen und zur Endabnahme vorlegen.
Startempfehlung 28×42, farbig, vier Vordergrundfarben; vier Kandidaten und erlaubte Varianten stehen in configuration.json.
Abschlussbild B-r02 unverändert erhalten; keine Spielregistrierung oder selbst erteilte Endfreigabe.
Repositoryablage gemäß §6 fortführen; Ablage-PR nach Pflichtprüfungen mergen.
```

Die Freigabe im echten Folgeauftrag muss mindestens MA-r03 und den Größen-/Palettenkorridor
eindeutig benennen; der bloße Aufruf dieser Datei ersetzt sie nicht. Neue Quellen/AGENTS am
tatsächlichen Produktionsstand lesen. Linienprofil zuerst, erforderlichenfalls aktuelles
Paarlinien-/Reparaturverfahren gemäß Regelwerk. Keine rätselspezifischen CI-Tests.

