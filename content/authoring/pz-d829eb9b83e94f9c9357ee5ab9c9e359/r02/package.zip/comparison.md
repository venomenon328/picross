# Bildvergleich

| Abschlussbild B-r02 · freigegeben | Motivvorlage MA-r03 · Freigabe offen |
| --- | --- |
| ![B-r02](reveal/B-r02.png) | ![MA-r03](motif/MA-r03.png) |

Detailverluste: Haarsträhnen und Stofffalten zusammengefasst, Kragen und Schatten vereinfacht.
Gesichtsvergleich und Parameterkorridor müssen gemeinsam mit MA-r03 freigegeben werden.

