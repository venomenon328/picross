# Marie Curie · Motivvorlage

Standardauftrag 2 auf main@b6c2d6a84ead757da15911550f53c64bfe90ccdd; 2026-10-17T10:32:53.138428+00:00.
Ausgewähltes und ausdrücklich freigegebenes Abschlussbild B-r02, unveränderte Bytes.
Kategorie menschen-berufe. Breite offen, Höhe ungefähr 40; farbig; Farbzahl offen.
Motivvorlage MA-r03 ist eine vorlagentreue Abstraktion aus B-r02 und noch NICHT freigegeben.
Parametervergleich, Palette, vier gezielte Kandidaten und enger Korridor: configuration.json.
Motivinvarianten: Dreiviertelansicht nach links, hohe Stirn/längliches Gesicht/markante Nase,
ernster Mund, Augenproportionen, Haarwellen mit Dutt rechts, hochgeschlossenes Kleid/Kragen.
Keine neuen Requisiten, Spiegelung, Motivwechsel, Streckung oder materielle Gesichtskorrektur.
Empfehlung 28×42 / vier Farben plus Leer; Alternativen 26×39 und 30×45.
Dateibasierter Stopp motif_review; keine Matrix, Hinweise oder Proofs erzeugt.

