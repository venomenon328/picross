# Endabnahmevorlage · Tomate · r03

Bitte `qa/final-comparison.png`, das echte Raster `final/raster-15x15.png` sowie `final/raster-grid.png` und das unveränderte Abschlussbild `reveals/A-r01.png` beurteilen. Ausgewählt ist `production/c15-2`, Variante `area-128`, 15×15, Rot/Grün plus Leer. Die Schattenmodellierung entfällt bewusst; Stielkurve und Blattspitzen sind stark abstrahiert. Alle vier Kandidaten sind zertifiziert, die Auswahl ist redaktionell begründet.

Technische Inhaltsgates sind belegt; der geschriebene ZIP wird zusätzlich durch ZA-1 inspiziert und dessen Ergebnis außen gebunden. Die aktuelle Methode 0.3 ergibt L3/Mittel, instrumented/medium, keine menschliche Kalibrierung. Menschliches Probespielen ist optional. Kein technischer Blocker; menschliche Endabnahme vor Export/Registrierung offen.

Mögliche tatsächliche Erklärung nach eigener Sichtung: „Ich nehme das Endraster c15-2/area-128 und das Abschlussbild A-r01 im Paket r03 der Rätsel-ID pz-e2e5092925ce4821a9219be7816b5931 redaktionell ab. Führe Standardauftrag 4 aus.“ Die endgültigen Inventar-/Handoff-/ZIP-Hashes stehen im äußeren Record und werden bei der späteren tatsächlichen Erklärung automatisch aus den Dateien gebunden. Dieser Text selbst erteilt keine Freigabe. Ein ausdrücklich gewollter Korrekturwunsch ist stattdessen konkret zu benennen.
