# Übergabe für Auftrag 3

Vorbereitete Dateien: `motifs/MA-r01.png`, bytegleiches `reveals/A-r01.png`, tatsächliche Revealfreigabe, Provenienzen, Bildvergleich und vier strikte Design-JSONs. Keine technischen Blocker; **menschliche Motivfreigabe offen**. Erst deren tatsächliche Erklärung darf Motivgate und `approved_parameters` setzen. Dieser Text ist eine Kopiervorlage für den Nutzer, keine erfundene Freigabe.

Standardarbeitsteilung: Codex für die nachgelagerte Rasterproduktion. Modell/Reasoning werden vom Nutzer in der tatsächlichen Oberfläche gewählt; wegen der noch offenen Motivfreigabe wird hier keine unbedingte Startfähigkeit oder bestimmte Konto-Modellverfügbarkeit behauptet.

Nach eigener Sichtfreigabe kann der Nutzer diesen Auftrag senden und den dann tatsächlichen Paketcommit einsetzen bzw. über den Arbeitsindex auflösen:

```text
Arbeite in venomenon328/picross@main; lies zuerst die aktuelle AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md samt Pflichtquellen.
Ich gebe Motivvorlage MA-r01 und den vollständigen vorgeschlagenen Parameterkorridor aus configuration.json frei.
Führe Standardauftrag 3 bis content_ready und zur redaktionellen Endabnahmevorlage aus.
Rätsel-ID: pz-e2e5092925ce4821a9219be7816b5931; Paket: content/authoring/pz-e2e5092925ce4821a9219be7816b5931/r02/package.zip, Revision r02. A-r01 bleibt unverändert freigegeben.
Empfehlung: 15×15, farbig, drei Vordergrundfarben; Vergleichskorridor ausschließlich 15×15/16×16 mit zwei/drei Farben, vier vorbereitete Designs, fester Crop und Motivinvarianten laut Paket.
Lade den tatsächlichen Paketstand aus dem aktuellen Arbeitsindex, prüfe Originalhashes und protokolliere diese reale Motivfreigabe vor dem Import. Produziere und prüfe gemäß Workflow einschließlich begrenzter Reparatur und SD-0.3; bei Paarprofilwahl zusätzlich PAIRED_LINES vollständig lesen.
Repositoryablage nach §6 ist beauftragt. Ablage-PR nach erfolgreichen Pflichtprüfungen mergen. Noch keine Spielregistrierung ohne spätere echte Endabnahme.
```

Den jeweils aktuellen Quellbranch/Commit aus der zugehörigen Chatübergabe oder dem bestätigten Main-Paketstand verwenden; keinen noch nicht existierenden Sicherungscommit in das versiegelte Paket hineinbehaupten.
