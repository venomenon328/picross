# Tomate · Standardauftrag 2

pz-e2e5092925ce4821a9219be7816b5931 · r02 · `motif_review` · 2026-10-23 · Regelwerk 0.5.0 / Dokumentrevision 23 · Werkzeug-/Quellcommit `ad265183803deef3d6a84571dc898653a8b982c9`.

Abschlussbild **A-r01** ist tatsächlich vom Nutzer freigegeben: `approvals/reveal-approval.json` und Originalerklärung. Bildbytes `853f8cfd9dd984dd244e0093e7f83719f9285c8ffcc3df61585fabb301e34e74` unverändert aus dem erneut geladenen und hashgeprüften r01-Paket. Neue Motivvorlage **MA-r01**, `e6fdefa4a047f8282f918f45bd5b5dd311e7f97cf487090b32394bf89c0f564a`, nativ aus genau diesen Bildbytes abgeleitet. Nur diese eine gezielte Abstraktion erzeugt, keine Korrekturrunde.

Empfehlung **15 × 15, farbig, drei Farben**: Rot als Frucht, Dunkelrot für breite Rundungsschatten, Grün als Kelch/Stiel. Reduzierte Alternative mit zwei Farben verliert die Schattenmodellierung. Exakt vorgeschlagener Korridor: 15 × 15 oder 16 × 16, zwei oder drei Vordergrundfarben, feste vier Designs. Crop `[35,35,1221,1221]`, `fit=exact`, Area, Alpha 128, technische Leerkomposition weiß. `configuration.md` trennt Motivtreue, erwartetes ungeprüftes Lösbarkeitsrisiko und Umfang/Spielgefühl. Farbanzahl als Nutzerwunsch offen; tatsächlich verwendete Rasterfarben erst später zählen.

Erhalten: Rundform, Schultern, Dreiviertelansicht, Sternkelch, kräftiger linksgebogener Stiel. Reduziert: Hautstruktur, Adern, feinste Konturen, Glanzpunkte, Stielquerschnitt; Schatten zusammengefasst. Der native Motivbitmap besitzt leichte Resttonwerte und Antialiasing, keine bereits diskrete Matrix. Alle fünf redaktionellen Kriterien plus Transparenz sind dateibezogen als `erfüllt` begründet. `qa/comparison.png` zeigt beide Bilder groß und bei 112/140 px auf originalem Projektpapier. Statischer Vergleich, kein Godot-Test.

Dateibindungen, ZIP, Inventar, Handoffkopie, Freigabe-/Provenienzreferenzen und Designschema/Crop werden vor Ablage in einem frischen lesenden Prozess geprüft. Keine ZA-1-Inspektion eines frühen Bildpakets. Noch keine Matrix, Hinweise, Randregel-, Deduktions-, unabhängige Proof-, Endmatrix- oder Schwierigkeitsergebnisse; entsprechende Gates bleiben offen. Reparatur entfällt in dieser Phase. Kein Probespiel erforderlich, Lösungszeit nicht geschätzt, menschliche Aktivzeit nicht erfasst.

Nutzungsgrundlage: Nutzerauftrag und eigene native Bildausgaben, keine übernommenen Fremdassets; Provenienz liegt je Bild bei. r01 bleibt versiegelt unverändert, verworfene Optionen werden nur über ihren früheren genauen Commit/Paketmember und Hash referenziert. Keine verschachtelten ZIPs oder kopierten allgemeinen Toolquellen. Keine Runtime-Registrierung.

Nächster Schritt: **3 · Motiv freigeben & produzieren** nach tatsächlicher menschlicher Freigabe von MA-r01, Invarianten und Konfigurationskorridor. Codex-Kopiervorlage liegt bei. Keine technischen Blocker; Motiv- und Endabnahme ausdrücklich offen. Inventarhash steht ohne Selbstreferenz in Handoff und äußerem Record.
