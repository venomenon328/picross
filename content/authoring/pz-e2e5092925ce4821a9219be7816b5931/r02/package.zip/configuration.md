# Konfiguration und Freigabekorridor

| Konfiguration | Motivtreue / Darstellung | Erwartetes Lösbarkeitsrisiko, noch ungeprüft | Spielgefühl / Umfang |
| --- | --- | --- | --- |
| **15 × 15, 3 Farben (Empfehlung)** | Rundform, grüner Kelch und breite Schattenfläche bleiben getrennt. | Asymmetrischer Kelch/Schatten bieten Struktur, sind aber kein Deduktionsnachweis. Runde Flächen können dennoch einen Fixpunkt erzeugen. | 225 Zellen, kompakter Einstieg; drei funktionale Farbbereiche. Keine Schwierigkeitszusage. |
| 15 × 15, 2 Farben | Rot und Grün reichen für die Identität; die Rundmodellierung entfällt. | Weniger Farbgrenzen und große rote Fläche können die Linienlogik weniger strukturieren. Unabhängig zu prüfen. | Gleicher Umfang, weniger Farbwechsel; nicht automatisch logisch leichter. |
| 16 × 16, 3 Farben | Etwas mehr Raum für Kelch/Stiel und die Formgrenze des Schattens. | Andere Quantisierung ist eine echte Vergleichshypothese, kein vorweggenommener Erfolg. | 256 Zellen, 31 mehr als bei 15 × 15. |

Vorgeschlagener Korridor: ausschließlich **15 × 15 oder 16 × 16**, farbig, **zwei oder drei Vordergrundfarben plus Leer**. Die vier Designs bilden genau diese Kombinationen ab; 16 × 16 mit zwei Farben ist der reduzierte Gegenvergleich zur größeren Dreifarbkonfiguration. Vier gezielte Kandidaten erst in Auftrag 3, nach menschlicher Motivfreigabe.

Empfohlene Palette: `red #df3f2f` für die Frucht, `shade #9e2924` für die breite rechts/untere Schattenfläche, `green #477635` für Kelch und Stiel. Reduzierte Alternative: `red` und `green`; kein fast identisches zusätzliches Rot oder Grün. Die Motivdatei enthält native Kantenglättung und leichte Resttonwerte; die genannten Paletten sind die expliziten späteren diskreten Rasterpaletten. Tatsächliche Farbanzahl noch nicht gezählt, da keine Matrix erzeugt wurde.

Methode `area`, Alpha-Grenze 128, Leerhintergrund `#ffffff`, fester Crop `[35,35,1221,1221]`, `fit=exact` bei exakt quadratischem Crop und Ziel. Keine Stretching-/Letterbox-Überraschung durch ganzzahliges contain. Das neutrale Weiß ist ausschließlich die technische Leer-Komposition, keine weiße Vordergrundfarbe oder Bildmatte. Der Crop bindet die gespeicherten 1254 × 1254 Motivbytes; Hauptmotiv vollständig erhalten. Keine alternativen Crops oder wechselnden Thresholds vorgeschlagen.

Die Motivfreigabe muss MA-r01 und diesen vollständigen Korridor samt Invarianten aus `configuration.json` binden. `approved_parameters` bleibt bis dahin leer. Noch keine Import-/Lösbarkeits-, Randregel- oder Schwierigkeitsprüfung; die Entwürfe sind keine Produzentenergebnisse.
