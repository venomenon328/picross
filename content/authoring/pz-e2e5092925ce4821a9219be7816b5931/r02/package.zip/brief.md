# Tomate · Standardauftrag 2 · r02

ID `pz-e2e5092925ce4821a9219be7816b5931`. Quellen-/Werkzeugcommit `ad265183803deef3d6a84571dc898653a8b982c9`. Nutzerwunsch: ungefähr 15 × 15, farbig; Vordergrundfarbzahl offen. Kategorie `gemuese-pilze-kraeuter` unverändert. Der aktuelle Arbeitsindex sowie Inhalts-/Runtime-Registry sind geprüft; keine aktive Spielregistrierung dieser ID, kein neuerer offener Arbeits-PR.

Tatsächliche Abschlussbildfreigabe: A-r01, `reveals/A-r01.png`, SHA-256 `853f8cfd9dd984dd244e0093e7f83719f9285c8ffcc3df61585fabb301e34e74`; die vorliegende Erklärung und ihre Herkunft sind separat unter `approvals/` inventarisiert. Das detaillierte Abschlussbild bleibt bytegleich und farbig. Keine Änderung an r01 oder früher versiegelten Freigaben.

Aus genau diesen gespeicherten Bytes wurde mit nativer Bildbearbeitung MA-r01 abgeleitet: `motifs/MA-r01.png`, SHA-256 `e6fdefa4a047f8282f918f45bd5b5dd311e7f97cf487090b32394bf89c0f564a`. Hauptform, Perspektive und Kelch-/Stielbezug bleiben geschützt. Reduziert wurden Blattadern, Hautstruktur, feine Doppelkonturen, einzelne Glanzlichter und der sichtbare Stielquerschnitt; die Schattierung wird als große einfache Fläche geführt. Keine Matrix und keine Hinweise erzeugt.

`configuration.md` vergleicht 2-/3-Farboptionen und 15/16 Zellen. `configuration.json` enthält Empfehlung, exakte vier Konfigurationen, technischen Crop und Motivinvarianten. Diese Parameter sind vorgeschlagen, noch nicht menschlich freigegeben. Der Folgeauftrag für Codex bleibt bis zur konkreten Motivfreigabe gesperrt.

Repositoryablage nach §6 samt Commit/Push/PR und Merge nach Pflichtprüfungen beauftragt. Keine Spielintegration in dieser Phase. Der nächste erlaubte Schritt ist **3 · Motiv freigeben & produzieren**, nach tatsächlicher menschlicher Annahme von MA-r01 und Korridor.
