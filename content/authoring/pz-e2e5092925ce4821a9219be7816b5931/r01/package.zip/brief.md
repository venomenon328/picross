# Tomate · Abschlussbildauswahl r01

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING; Motiv Tomate, ungefähr 15 × 15 Zellen, farbiger Rätselmodus. Vordergrundfarbzahl offen. Repositoryablage nach §6 und Ablagemerge nach erfolgreichen Pflichtprüfungen ausdrücklich beauftragt.

Arbeitsweise `free`: freie Interpretation des Motivtexts, keine bereitgestellte Bildreferenz. Die angebotenen Varianten sind detaillierte farbige Abschlussillustrationen auf echtem transparentem Bildgrund, keine Motivvorlagen oder Raster. Hauptmerkmale: einzelne reife rote Tomate, klar erkennbarer grüner Kelch mit Stiel, charakteristische Fruchtform, ruhige Kontur-/Farbflächensprache. Keine Requisiten, Gesichter, Schrift oder dekorativer Rahmen.

Kategorie: `gemuese-pilze-kraeuter` (Gemüse, Pilze & Kräuter), gemäß prägendem Hauptgegenstand; Kategorien sind keine botanische Taxonomie. Index und Inhalts-/Runtime-Registry am Quellcommit gelesen; keine Tomatenproduktion oder ID-/Pfadkollision gefunden. Keine Bestandsrätsel einzeln geladen oder neu geprüft.

Die 15 × 15 sind eine ungefähre Zielgröße, noch kein freigegebener Parameterkorridor. Nach menschlicher Abschlussbildfreigabe in Auftrag 2 Palette und sinnvolle Maße empfehlen und genau aus dem gewählten Bild abstrahieren. Noch keine Farbzahl, Lösbarkeit, Schwierigkeit oder Motivfreigabe behauptet.

Native KI-Bildgenerierung in ChatGPT auf Nutzerauftrag, ohne Fremdreferenz und ohne direkte Modell-API. Herkunft und Nutzungsgrundlage: für dieses Projekt eigens aus generischem Motivtext erzeugte Bilder; keine übernommenen Fremdassets oder zusätzlichen Attributionsbedingungen bekannt. Kein Anspruch auf Exklusivität. Prompts und tatsächlich exponierte Einstellungen liegen bei.
