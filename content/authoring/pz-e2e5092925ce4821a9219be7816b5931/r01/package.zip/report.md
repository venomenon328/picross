# Tomate · Standardauftrag 1

pz-e2e5092925ce4821a9219be7816b5931 · r01 · `reveal_review` · 2026-10-23 · Regelwerk 0.5.0 / Dokumentrevision 23.
Gelesener Werkzeug-/Repositorystand: `53427be9a8abde4f21466fe16505ef3c6ad30339`. Das Inventar bindet sämtliche Nutzdateien; sein eigener Hash steht im Handoff und äußeren Record, ohne Selbstreferenz.

| Option | Gestaltung | Eignung für ungefähr 15 × 15 |
| --- | --- | --- |
| A-r01 | Runde rote Tomate, grüner Kelch, kurzer gebogener Stiel | Empfehlung: kompakte ikonische Hauptform; Schatten und Blattadern später vereinfachen. |
| B-r01 | Breite gerippte Fleischtomate | Charaktervoll; nur große Rippen erhalten, feine Täler nicht als einzelne Farbdetails übernehmen. |
| C-r01 | Diagonal liegende ovale Romatomate | Gut unterscheidbare Form; eventuell anderes Seitenverhältnis empfehlen, ohne die ungefähre Vorgabe stillschweigend festzuschreiben. |

Drei native PNG-Einzeldateien, jeweils 1254 × 1254 RGBA, echte Transparenz. Prompts und verfügbare Einstellungen mitgeführt. Originalbilder nicht verändert. `visual-review.json` dokumentiert alle fünf gestalterischen Kriterien und Transparenz je Option mit Status `erfüllt`; `qa/selection.png` zeigt die statische Sichtung auf dem originalen Projektpapier bei großer Ansicht und aktueller Kataloghöhe 112/140 px. Dies ist ausdrücklich kein nativer Spieltest.

Auftrag: farbig, Zielmaß ungefähr 15 × 15 (225 Zielzellen), Farbanzahl offen. Istmaße/-farbzahl einer Matrix, Parameterkorridor, Kandidat, Hinweise, Randregel, Herkunftsrekonstruktion ab Motiv, Logik, unabhängiger Proof, Endmatrixvergleich und Schwierigkeit sind in dieser frühen Bildphase noch nicht anwendbar. Keine Lösbarkeit zugesagt, keine Rasterproduktion oder Reparatur durchgeführt. Lösungszeit nicht geschätzt, menschliche Arbeitszeit nicht erfasst. Herkunft: eigens beauftragte native KI-Bilder ohne Fremdreferenz; siehe Provenienz.

Abschlussbildfreigabe, Motivfreigabe und redaktionelle Endabnahme sind ausdrücklich offen. Kein Bild ausgewählt. Keine Runtime-Registrierung. Keine technischen Zugriffsblocker verblieben.

Nächster erlaubter Auftrag: **2 · Bild freigeben & abstrahieren**. Der Nutzer benennt A-r01, B-r01 oder C-r01 und gibt genau diese Dateifassung frei oder beauftragt eine Korrektur. Die Freigabe bindet den bereits ermittelten Dateihash; der Nutzer muss ihn nicht abtippen.
