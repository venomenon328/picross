# Hamburger · Standardauftrag 2

ID `pz-b3368aea28ac4a11bf09e0dc9c48` · r02 · `motif_review` · 2026-10-13 · Regelwerk 0.4.1 / Dokumentrevision 5 · Quell-/Toolcommit `4ff96270675b873f6c770eee4df3abe8516327b6` · main-Basis `f666f87d36a0ea7fa3740202d08706f2215bc303`.
Inventarhash steht in handoff.json (ohne Selbstreferenz).

Abschlussbild A-r01: Original unverändert farbig, menschlich freigegeben am 13.10.2026; Datei/hash und Erklärung in approvals/reveal-A-r01.json. Daraus nativ abgeleitete MA-r01: separate PNG-Datei/hash, noch nicht menschlich freigegeben. Paarprüfung und alle fünf Gestaltungskriterien: quality.json; Detailverluste/Invarianten: detail-losses.json.

Empfohlene Konfiguration: **25 × 22, monochrom, 550 Zellen**, ink/Leer, area, exakter proportionaler Crop [14, 87, 1239, 1165]. Wunsch 25 × 25 war ausdrücklich ungefähr. Quellenkontur ist leicht breiter als hoch; 25 × 22 hält die Proportionen ohne zusätzliche vollständig leere Außenzeilen einzuplanen. 25 × 25 sowie 30 × 27 werden getrennt nach Motivtreue, Darstellbarkeit, ungeprüftem Logikrisiko und Spielgefühl verglichen. Vollständiger Designentwurf mit vier Schwellenhypothesen liegt vor, noch nicht importiert.

Erhalten: Frontperspektive, Kuppel/Boden/Patty und Schichtfolge. Reduziert: viele Sesamkörner zu drei Aussparungen, Salatfalten zu großen Lappen, alle Krusten-/Fleischtexturen und Schattierungen weg. Tomate als breite helle Zwischenfläche. Feine Tomatenunterkontur nicht identitätsentscheidend; Trennflächen bleiben geschützt.

Ausgeführt: Sichtvergleich tatsächlicher A-/MA-Dateien; PNG-Dekodierung/Hash/Dimensionen; allein in Quellauflösung ermittelter Motivbbox und proportionaler Croptest. Geprüfte Paket-/Inventar-/Freigabebindungen und bytegleiche Handoffkopie vor Ablage. Noch keine Rastermatrix, Hinweise, Randregel- oder Logikprüfung, kein unabhängiger Proof; keine Schwierigkeitenstufe oder Lösungszeit geschätzt. Keine Import-/Reparaturversuche. Kein ZA-1-inspect/Zieladapter in dieser Bildphase, keine Runtime-Registrierung.

Nutzungsgrundlage in beiden Bildprovenienzen; tatsächlicher nativer Bearbeitungsprompt in generation.json, Originalbytes unverändert. Ein Bildaufruf hier, insgesamt vier; aktive Menschenminuten nicht erfasst. B/C nur im früheren r01-Paket mit festem Commit/Hash referenziert, kein altes ZIP eingebettet. Abschlussbildfreigabe bestanden; Motiv- und Endfreigabe offen. Kein Probespiel (optional).

Nächster Schritt: menschliche Freigabe von MA-r01 samt 25×22-Korridor; anschließend Standardauftrag 3 über codex-handoff.md im selben Branch/PR. Es wurde kein Merge beauftragt oder ausgeführt.
