# Hamburger · Abschlussbildfreigabe und Abstraktion

ID `pz-b3368aea28ac4a11bf09e0dc9c48` · r02 · Kategorie `gerichte-herzhaftes` · Wunsch ungefähr 25 × 25, monochrom. A-r01 ist vom Nutzer am 13.10.2026 ausdrücklich freigegeben; Originaldatei/hash unverändert. Beleg: approvals/reveal-A-r01.json und tatsächlicher Wortlaut in approvals/reveal-evidence.md.

MA-r01 ist eine mit genau diesen gespeicherten Bytes nativ erzeugte, vorlagentreue (`faithful`) Mono-Abstraktion. Empfohlen: 25 × 22, 550 Zellen, eine Vordergrundfarbe `ink`. Details, Vergleich dreier Konfigurationen, fester Crop, ungestreckter Fit und vier Versuchshypothesen stehen in configuration.json/design-proposed.json. Noch keine Motivfreigabe, kein Import oder Raster.

Invarianten: Frontperspektive, breite gerundete Silhouette, Hauptproportionen und Schichtreihenfolge Deckel/Salat/Tomate/Patty/Boden; drei breite Sesamaussparungen und die wichtigen hellen Trennflächen. Details/zulässige Reduktionen stehen in detail-losses.json. Keine anderen Zutaten, kein neues Bildmotiv, keine abgeschnittenen Hauptformen, kein künstlicher Rahmen.

Nutzungsgrundlage: vom Nutzer beauftragte eigene KI-Erzeugung und Ableitung ohne Fremdassets; keine Exklusivrechtsbehauptung. Autorisierung: Standardauftrag 2, Paketsicherung/Commit/Push und Fortführung Draft-PR #110; kein Merge. Standardauftrag 3 wird erst mit tatsächlicher Motivfreigabe erlaubt. Offen ist die menschliche Freigabe von MA-r01 mit dem vorgeschlagenen Parameterkorridor.
