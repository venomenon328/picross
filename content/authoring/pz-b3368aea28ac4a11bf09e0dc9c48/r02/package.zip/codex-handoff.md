# Codex-Übergabe · Hamburger r02

Repository venomenon328/picross. Ziel main; vorhandener Arbeitsbranch `content/hamburger-b3368aea-r01`, Draft-PR #110. Produktions-ID `pz-b3368aea28ac4a11bf09e0dc9c48`. Aktuell `motif_review`, deshalb noch nicht für Rasterproduktion freigegeben.

Nach tatsächlicher menschlicher Freigabe von MA-r01 und der Konfiguration: Standardauftrag 3 gemäß aktueller AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md ausführen. Paket über den Arbeitsindex dieses Branches auflösen. `images/A-r01.png` ist separat freigegeben; `images/MA-r01.png` hat bewusst noch keinen Freigabebeleg. Alle Hashes, Herkunft, Bilder und Invarianten liegen dateibasiert vor. Freigabe nicht aus dem Übergabetext erfinden.

Vorgeschlagener Korridor: ausschließlich 25 × 22, mono/1 Vordergrundfarbe, `area`, `fit=exact`, Crop [14, 87, 1239, 1165]. `design-proposed.json` ist ein vollständiger strikter Designentwurf mit vier begründeten Schwellenvarianten, noch nicht ausgeführt. MA-Freigabe muss diese Datei/Hash, A-r01-Bezug und den Korridor binden. Exakte Regeln/Prüfungen/Reparatur/Difficulty/Packen folgen dem Workflow; keine Integration oder Merge in Standardauftrag 3.

Vor Rasterproduktion separate echte Motivfreigabe mit type=human_motif_approval, Akteur/UTC/Erklärung, Datei/Revision/Hash, derived_from_reveal_sha256, Parametern und tatsächlichem Evidencebeleg führen. Von der Freigabevorlage allein darf kein pass entstehen. In approved_parameters erst tatsächlich freigegebene Konfiguration aufnehmen.

Auftrag 2 wurde hier fertig ausgeführt. Für noch nicht beauftragte/allein durch die manuelle Motivfreigabe blockierte Produktion jetzt keine Modell-/Startbereitschaftszusage; Modellauswahl nach aktueller Workflowfassung bei tatsächlicher Ausführungsvorbereitung, in der Oberfläche, ohne Modell-API.

Direkt kopierbarer Folgeauftrag, **nur wenn der Mensch diese Vorlage und den Korridor tatsächlich freigibt**:

```text
Arbeite nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross.
Nutze Draft-PR #110 und den dortigen Arbeitsbranch; Paket pz-b3368aea28ac4a11bf09e0dc9c48/r02 über content/authoring/index.json laden und Hashes prüfen.
Ich gebe MA-r01 mit dem in configuration.json vorgeschlagenen Korridor 25 × 22, monochrom, frei. Verbindliche Referenz bleibt A-r01.
Führe Standardauftrag 3 bis content_ready zur Endabnahme aus. Repositoryablage nach §6 ist beauftragt; gleicher Draft-PR, kein Merge.
```
