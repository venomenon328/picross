# Hamburger · Produktionsauftrag 3

ID `pz-b3368aea28ac4a11bf09e0dc9c48` · r03 · Kategorie `gerichte-herzhaftes` (Gerichte & Herzhaftes).
Standardauftrag 3 bis zur Endabnahmevorlage und Repositoryablage auf bestehendem Branch `content/hamburger-b3368aea-r01` / Draft-PR #110; kein Merge, keine Spielregistrierung.
Tatsächlicher Nutzerwortlaut: [Motivfreigabe](approvals/motif-evidence.md). MA-r01 mit dem einzigen vorgeschlagenen Parameterkorridor aus r02 ist freigegeben; A-r01 bleibt unverändert die menschlich freigegebene Referenz.

Verbindlich 25 × 22, Mono, eine Vordergrundfarbe `ink` (#000000), Leer #ffffff, Area, Fit exact, Crop [14,87,1239,1165]. Keine Streckung. Vier vorab in r02 begründete Schwellenvarianten 80/112/144/176; [Konfiguration](configuration.json), [Design](design-proposed.json).
Invarianten: kompakte breite Frontansicht, gewölbter großer Deckel und gerundeter Boden, Reihenfolge Deckel/Salat/Tomate/einzelnes kräftiges Patty/Boden, drei helle Sesamaussparungen und wichtige helle Trennflächen, wenige breite Salatlappen. Nur unwichtige Antialiasing-/Konturdetails und die feine Tomatenunterkontur dürfen zusammengefasst werden. Keine zusätzlichen Zutaten, keine abgeschnittenen Hauptformen oder künstlichen Randpixel.
Nutzungsgrundlage: eigene vom Nutzer beauftragte KI-Erzeugung/Ableitung ohne Fremdassets; keine Exklusivrechtsbehauptung. Native Originalbytes, Prompts und bekannte Einstellungen bleiben erhalten. Produktion ab gespeicherten Bildbytes deterministisch; native Neugenerierung nicht versprochen.
