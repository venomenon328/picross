# Hamburger · Abschlussbildauswahl r01

Motivauftrag: Hamburger. Ungefähr 25 × 25 Zellen; später monochrom (`mono`), Abschlussbild immer farbig. Kategorie: `gerichte-herzhaftes` (Gerichte & Herzhaftes).
Arbeitsweise der initialen Bildgestaltung: `free`, freie Interpretation des Textmotivs ohne externe Bildreferenz. Nach tatsächlicher Bildfreigabe ist genau deren Perspektive, Silhouette und Schichtaufbau verbindlich.

Unverzichtbar: obere und untere Brötchenhälfte, deutliches Rindfleischpatty und erkennbare Füllung als geschichteter Hamburger. Die Farbvarianten verwenden Salat und Tomate, ohne Käse; Zwiebel/Sauce sind reversible Gestaltungsergänzungen. Keine Beilagen oder Schrift. Erlaubt sind natürliche Formabweichungen und motivgerechte Oberflächendetails im ruhigen warmen 2D-Stil.
Der Größenwunsch ist ungefähr und noch kein freigegebener Produktionskorridor. Keine Rastermatrix, Abstraktion, Hinweise, Proofs oder Lösbarkeits-/Schwierigkeitszusage in diesem Auftrag.

Herkunft: eigener Textauftrag des Nutzers in ChatGPT vom 13.10.2026; alle drei Originaldateien wurden dafür mit dem nativen Bildwerkzeug erzeugt. Keine Fremdvorlage oder Markenabbildung verwendet. Nutzungsgrundlage: vom Nutzer beauftragte KI-Erzeugung zur Verwendung im eigenen Picross-Projekt; dies ist keine Behauptung ausschließlicher Urheberrechte.
Repository-/Toolquellstand: `f666f87d36a0ea7fa3740202d08706f2215bc303`. Verbindlich: AGENTS.md, docs/dev-rules/WORKFLOW.md, docs/PROJECT_PROFILE.md und die auftragspflichtigen Fachquellen gemäß sources.json. Aktuelle Regeln vollständig gelesen; keine weiteren AGENTS.md-Bereichsregeln im Repositorytree.

Autorisierung: Standardauftrag 1 und Repositoryablage nach §6, Commit/Push und Draft-PR; kein Merge. Die nächste menschliche Abschlussbildfreigabe ist offen.
