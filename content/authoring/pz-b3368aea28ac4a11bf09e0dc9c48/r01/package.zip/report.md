# Hamburger · Standardauftrag 1

ID `pz-b3368aea28ac4a11bf09e0dc9c48` · Paket `r01` · `reveal_review` · 2026-10-13 · Regelwerk 0.4.1 / Dokumentrevision 5 · Quell-/Toolcommit `f666f87d36a0ea7fa3740202d08706f2215bc303`.
Inventarhash: gebunden in handoff.json (vermeidet Selbstreferenz des Berichts).

| Variante | Unterschied | Bewertung |
| --- | --- | --- |
| A-r01 | Frontansicht, Sesam, einfache Schichten | Empfehlung für ungefähr 25 × 25 mono |
| B-r01 | Leichte Dreiviertelansicht, sichtbare Zwiebel | Mehr räumlicher Charakter; anspruchsvollere Formabstraktion |
| C-r01 | Frontansicht, glatter Deckel, helle Sauce | Ruhige Deckelform; zusätzliche Saucenschicht |

Alle Varianten sind tatsächliche separate farbige PNGs (1254 × 1254, RGB); SHA-256 in decisions.json/generation.json/provenance.json. Originalbytes unverändert. Fünf Gestaltungskriterien je Bild einzeln mit Begründung in quality.json dokumentiert. Oberflächendetails werden erst nach Freigabe in der separaten Mono-Motivvorlage reduziert.

Größenwunsch: ungefähr 25 × 25 = ungefähr 625 Zellen, noch nicht produziert. Modus mono, Rasterpalette noch nicht verbindlich; Abschlussbildpalette vollfarbig. Schwierigkeit, Hinweise, Randregel, Deduktion, unabhängiger Prüfer und Endmatrixvergleich: nicht anwendbar in dieser Bildphase. Keine Abstraktion, keine Reparatur, keine Importversuche. Lösungszeit nicht geschätzt; menschliche aktive Zeit nicht erfasst. Native Bildaufrufe: drei. Probespiel nicht durchgeführt (optional).

Abschlussbildfreigabe, Abstraktionsfreigabe und Endabnahme sind offen. Keine ZA-1-Zertifizierung, Zielintegration oder Runtime-Registrierung. Nutzungsgrundlage und genaue Prompts: provenance.json und generation.json. Paketprüfungen: sichere ZIP-Dateimenge, vollständige Inventar-/Bildhashes, CRC, Record-/Handoffbindung und bytegleiche äußere Handoffkopie vor Repositoryablage.

Nächster erlaubter Schritt: menschliche Freigabe von A-r01, B-r01 oder C-r01, anschließend Standardauftrag 2 mit genau dieser gespeicherten Bilddatei auf demselben Branch/PR. Eine Freigabe mit Korrekturwunsch ersetzt die Freigabe der korrigierten Revision nicht.
