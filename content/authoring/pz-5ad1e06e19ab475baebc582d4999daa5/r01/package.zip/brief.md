# Gecko · Abschlussbildauswahl

ID: pz-5ad1e06e19ab475baebc582d4999daa5 · Paket r01 · Status reveal_review · 2026-10-14T16:06:19.181917+00:00

## Tatsächlicher Auftrag

Standardauftrag 1 nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main. Motiv Gecko; Größenwunsch 30 × 15 Zellen ungefähr (Breite × Höhe); Rätselmodus monochrom, Abschlussbild immer farbig. Repositoryablage nach §6, Commit/Push und Draft-PR beauftragt; kein Merge.

## Motiv und Arbeitsweise

Freie Motivinterpretation (free) aus Text ohne Referenzbild. Ein einzelner stilisierter Gecko, breiter Kopf mit markanten Augen, langer sich verjüngender Schwanz, vier Beine mit fächerförmig gespreizten Haftzehen. Ruhiger heller Hintergrund ohne weitere Objekte. Unterschiedliche Posen/Farbgebungen im gemeinsamen warmen handgezeichneten 2D-Stil. Keine exakte Tierart oder zoologische Detailzeichnung beauftragt. Die Zehen sind zeichnerisch vereinfacht; Haftflächen und vier Gliedmaßen bleiben erkennbar.

Alle drei Bilder sind neue farbige Einzeldateien, keine Motivvorlagen oder Raster. Erst die ausdrückliche Freigabe einer konkreten Bildrevision macht ihre Pose, Proportionen und Negativräume verbindlich. Die spätere Abstraktion darf Schuppen, Flecken, Schatten und feine Zehenzeichnung reduzieren. Der Wunsch 30 × 15 ist keine feste Grenze; Darstellbarkeit und Logik sind noch ungeprüft. Keine Lösbarkeit oder Schwierigkeit zugesagt.

Kategorie: insekten-kleine-tiere (Insekten & kleine Tiere), nach prägendem Hauptgegenstand und bestehender Zuordnung von Reptilien gemäß Kategorienvertrag; keine Taxonomieänderung.

## Quelle und Nutzungsgrundlage

Eigenständige beauftragte KI-Generierung für Picross; keine Fremdbilder oder Fremdassets eingebracht. Tatsächliche Prompts/Toolargumente stehen in generation.json; Modell/Seed/Qualitätsparameter sind not_exposed. Die PNG-Originalbytes werden unverändert gesichert. Keine menschlichen Freigaben vorhanden.

## Bindung und Grenze

Repository-/Toolstand: 22a3da76336fead97f87a4a0b229447ee1b36c69. Regelwerk 0.4.1, Dokumentrevision 8, Snapshot rulebook.md. Pflichtquellen unter diesem Commit: AGENTS.md, docs/dev-rules/WORKFLOW.md, docs/PROJECT_PROFILE.md, docs/PRODUCT_DEFINITION.md, docs/DESIGN_CONCEPT.md, docs/PUZZLE_PRODUCTION.md, tools/puzzle_production/README.md, docs/CATEGORIES.md, docs/ZA1_ADAPTER.md, docs/CI_POLICY.md und docs/DEVELOPMENT_ARCHIVE.md. Kategorienquelle, Arbeitsindex und Runtime-Registry wurden gelesen; kein bestehender Gecko-PR bei der aktuellen Suche.

Nächster erlaubter Schritt: Ausdrückliche menschliche Abschlussbildfreigabe A-r01/B-r01/C-r01; danach Standardauftrag 2 mit Konfiguration und daraus abgeleiteter Motivvorlage. Größenwunsch ungefähr 30 breit × 15 hoch, monochrom.
