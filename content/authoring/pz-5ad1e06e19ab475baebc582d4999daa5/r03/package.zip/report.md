# Gecko · Motivvorlage und Übergabe

pz-5ad1e06e19ab475baebc582d4999daa5 · r03 · motif_review · 2026-10-14T17:15:31.165107+00:00
Regelwerk 0.4.1 / Dokumentrevision 8; Repository/Tool bb79b6a265c6dc2cd3865925bf6c03e5a71d7ca6; Inventarhash im Handoff gebunden.

**Abschlussbild A-r02 freigegeben** durch Tobias Schröder am 14.10.2026 17:06:53Z. Beleg approvals/reveal-approval.json + reveal-evidence.md; PNG unverändert. **Motiv MA-r01 samt configuration.json noch offen**, ebenso Endabnahme. Keine selbst erteilte Freigabe.

Native vorlagentreue Abstraktion: gleiche Draufsicht, Kopf rechts, Schwanz links aufwärts, vier Beine und Fußfächer. Entfernt: Farbe, Schuppen, Flecken, Schattierung; Augen als zwei weiße Öffnungen. Bildvergleich und Begründungen in derivation.json. Ganze Figur zusammenhängend, große Negativräume erkennbar. Die echte kleine Rasteransicht existiert noch nicht.

| Option | Zellen | Begründung |
| --- | --- | --- |
| 30 × 12 | 360 | Kompakt, größerer Detailverlust an Zehen möglich. |
| **32 × 12** | **384** | **Empfehlung:** zusätzliche Breite bei unverzerrter flacher Silhouette. |
| 34 × 13 | 442 | Mehr Darstellungsraum; nur begründete Zusatzkandidaten. |

Wunsch ungefähr 30 × 15. Boundingbox 1725 × 644 ist flacher als der Bildcanvas; contain erzeugte bei 30×15 vier, bei 32×16 fünf zusätzliche Leerzeilen. Deshalb flacher vorgeschlagener Korridor. Mono: eine Vordergrundfarbe ink #000000, Leer #ffffff; area/contain, Crop [28, 107, 1753, 751], Schwellen 128/160. Genauere Vergleiche/zulässige Detailverluste in configuration.json; vorbereitete Designs unter designs/.

Dateibindung, tatsächliche Herkunft/Nutzungsgrundlage und redaktioneller Bildvergleich vorhanden. Produktmaße im Korridor ≤50. Randregel, Hinweise, deduktiver Proof, unabhängiger Verifier, Endmatrix, Schwierigkeit L1–L5 und Export: erst in Auftrag 3/4 prüfbar, kein Pass behauptet. Probespiel nicht durchgeführt und optional. Sieben Bildaufrufe insgesamt, davon ein Edit hier; keine Import-/Reparaturversuche, aktive Menschenzeit nicht erfasst.

Repositoryablage und bedingter Merge von PR #123 beauftragt; Lauf-/Mergebelege werden im PR geführt. Paket bleibt laufende Produktion auf main, kein Runtime-Inhalt. Kein Cleanup gemäß §9, solange nicht final ins Spiel integriert. Nächster Schritt: Motivfreigabe MA-r01 samt Korridor; danach codex-handoff.md / Standardauftrag 3.
