# Gecko · Standardauftrag 2

pz-5ad1e06e19ab475baebc582d4999daa5 · r03 · motif_review · 2026-10-14T17:15:31.165107+00:00
Repository-/Toolstand bb79b6a265c6dc2cd3865925bf6c03e5a71d7ca6, Ziel main; Regelwerk 0.4.1 / Dokumentrevision 8.
Aktuelle AGENTS.md tatsächlich gelesen; Pflichtquellen seit vorheriger vollständiger Lektüre unverändert geprüft. Aktueller PR #123 samt Kommentaren, index.json, registry.json und Kategorienquelle gelesen; r02-ZIP mit allen vorhandenen Bindungen geprüft.

Tatsächlicher Auftrag: A-r02 ausdrücklich freigegeben; Motivvorlage samt Konfiguration und Codex-Übergabe erstellen. Größenwunsch ungefähr 30 × 15, mono; Abschlussbild farbig. Repositoryablage und Merge des Ablage-PRs #123 nach Pflichtprüfung beauftragt. Erklärung und UTC-Zeit in approvals/reveal-evidence.md. Keine Motiv- oder Endabnahme und keine Spielregistrierung aus der Mergebefugnis ableiten.

Kategorie insekten-kleine-tiere. Abschlussbild: reveals/A-r02.png, bytegleich zur freigegebenen Quelle. Vorlagentreue Ableitung (faithful): motifs/MA-r01.png, separate native Bildbearbeitung, keine Überschreibung. Invarianten und Detailverluste stehen in derivation.json. Unverändert bleiben Draufsicht, Pose, Kopf-/Schwanzlage, vier Beine/Fußfächer und große Negativräume. Feine Farben/Schuppen/Flecken entfallen. Herkunft/Nutzungsgrundlage: beauftragte eigenständige KI-Generierung ohne Fremdassets.

Empfehlung 32 × 12 statt anfänglicher grober 32 × 16-Erwägung; gemessene Figur 1725 × 644 Pixel. Größenvergleich und eindeutig vorgeschlagener Korridor in configuration.json, drei strikt vorhandene Image-Designs unter designs/. Keine Rasterdaten erzeugt; Rand-/Logikprüfung erst in Auftrag 3. Alle Parameter sind vorgeschlagen, nicht menschlich genehmigt.

Nur A-r02 und die neue Motivvorlage im aktuellen Paket; B-r02/C-r02 über genaue frühere Fundorte/Hashes in decisions.json referenziert, alte Pakete unverändert. Kein altes ZIP eingebettet. Regelwerksnapshot als einzige allgemeine Dokumentkopie.

Nächster Schritt: menschliche Motivfreigabe MA-r01 samt configuration.json; danach Standardauftrag 3 gemäß codex-handoff.md bis zur Endabnahmevorlage, keine Registrierung.
