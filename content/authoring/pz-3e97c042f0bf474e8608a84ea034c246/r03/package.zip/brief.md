# Yin-Yang · Standardauftrag 3 · r03

Quelle main@c2cdf866e22c6065f67ae3b6ef539af2b206a8f6, r02/package.zip. Freigaben unverändert/neu in approvals/reveal.json und approvals/motif.json; tatsächlicher Auftrag in approvals/production-request.md.

Freigegeben: MA-r01 aus A-r01; 25×25 empfohlen,27×27 alternativ,30×30 begründete Reserve; Mono mit einer Vordergrundfarbe. Fester Crop[16,15,1231,1230], exact, area, Threshold128..208. parameters.json bleibt als bytegleicher freigegebener Originalkorridor erhalten; dessen alter vorgeschlagener Status wird durch die neue tatsächliche Freigabe abgelöst.

Hart erhalten: Kreisfrontansicht ohne Drehung/Spiegelung/Strecken, dunkle obere/linke Kommaform, heller oberer und dunkler unterer Punkt, beide geschlossen und getrennt, S-Grenze und Proportionen. Keine zusätzliche Dekoration oder künstlichen Logikanker. Kategorie mythen-fantasie.

Auftrag: Produktion, technische/visuelle Prüfung und bedingter Ablagemerge. Keine tatsächliche Endfreigabe vorhanden. Spielregistrierung bleibt nach Standardauftrag4 gesondert. Rechte/Prompts/Ableitungsbindung stehen bei den Originalbildern.

Endstand blocked: keine zulässige Endabnahmevorlage. Nächster Vorschlag ist gezielte Neuabstraktion MA-r02 mit kräftigerem vorhandenen Außenumriss, unveränderten Hauptformen und Punkten; neue Datei vor weiterer Produktion ausdrücklich freigeben lassen. Noch nicht erzeugt oder freigegeben.
