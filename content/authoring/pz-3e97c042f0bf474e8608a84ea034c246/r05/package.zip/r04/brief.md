# Yin-Yang · feste Nutzerkorrektur · r04

Quelle main@4c44334d306ea7dff304a3fe1d6131a9de608a2b, r03. Exakt die acht1-basierten Änderungen aus approvals/fixed-user-request.md an25×25/area-192; sieben ink→empty, einmal empty→ink. Alle übrigen617 Positionen hart geschützt. Kein Suchlauf oder zusätzlicher Eingriff, kein Wechsel der Originalbilder, Orientierung, Palette oder Grundgeometrie. Mono mit einer schwarzen Vordergrundfarbe. Kategorie mythen-fantasie.

Referenz ist weiterhin aus der freigegebenen MA-r01 und dem festen Crop[16,15,1231,1230] deterministisch rekonstruiert. Die neue Matrix ist ausdrücklich eine feste manuelle Ableitung, kein unveränderter Bildimport. Das bestehende Produktions-/Ablage-/bedingte Merge-Mandat wird fortgeführt. Der aktuelle Änderungsvorschlag ist keine Endabnahme und keine Freigabe eines neuen Bilds.

Die r03-Originale werden nicht geändert. Deren Handoff/Inventar als unveränderte Metadatenreferenz unter original-r03/ mitgeführt; dies ist keine behauptete Vollkopie von r03. ZIP-/Handoff-/Inventarhash und Quellcommit stehen in fixed-binding.json. Vollständige benötigte RP3-Referenz liegt unter paired-25/; sämtliche dort manifestgebundenen Dateien bleiben bytegleich.
