Bitte versuche, das Rätsel zu korrigieren.
