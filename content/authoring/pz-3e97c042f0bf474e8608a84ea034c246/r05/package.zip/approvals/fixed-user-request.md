Bei 25x25 area-192 könnten folgende Änderungen vorgenommen werden:
Pixel setzen bei Zeile 25, Spalte 17 (schließt die Kontur)
Pixel entfernen bei Zeile 9, Spalten 12, 13 und 14
Pixel entfernen bei Zeile 7, Spalte 11 und 15
Pixel entfernen bei Zeile 8, Spalte 11 und 15
