# Yin-Yang · Abschlussbildauswahl

Auftrag: Standardauftrag 1, drei farbige detaillierte Abschlussbilder.
Wunschbreite ungefähr 25 Zellen; Höhe offen; Rastermodus monochrom. Noch kein freigegebener Parameterkorridor.
Kategorie: mythen-fantasie (kulturell-philosophisches Symbol; nächstliegende bestehende Gruppe, keine neue Kategorie).
Freie Motivübertragung aus Text ohne externe Bildreferenz. Identitätskern: geschlossener Kreis, zwei komplementäre ineinandergreifende Kommaformen mit S-Grenze, je ein kontrastierender runder Punkt. Frontansicht, ruhiger Hintergrund; keine Schrift, Umgebung oder Zellfüll-Dekoration.
Materialdetails und Farben dürfen in der späteren Mono-Abstraktion entfallen. Kreisproportion, S-Verlauf und Punkte bleiben zu bewahren; keine Verzerrung zum Rechteck.
Abschlussbildwahl/Freigabe durch den Nutzer ist offen. Keine Abstraktion oder Rasterproduktion in dieser Phase. Die Vorgabe Yin-Yang ist ein erkennbares kulturelles Motiv, keine zufällige abstrakte Rauschmatrix.
Repositoryablage und bedingter Ablagemerge sind beauftragt. Eine spätere Integration benötigt weiterhin die Bild-, Motiv- und redaktionelle Endfreigabe.
