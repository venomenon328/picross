# Yin-Yang · Motivvorlage MA-r01

A-r01 ist durch die tatsächliche Erklärung vom 17.10.2026, 09:19:13 UTC freigegeben; Dateihash und Erklärung stehen in approvals/reveal.json und approvals/user-request.md. Die farbigen Originalbytes bleiben unverändert.

Wunsch: Breite ungefähr 25, Höhe offen, Mono. Empfehlung 25 × 25; 27 × 27 erste Alternative, 30 × 30 begründete Reserve. Ein Quadrat bewahrt die Kreisproportion, Rechtecke würden Leerraum oder Verzerrung erzeugen. parameters.json ist nur ein VORSCHLAG bis zur ausdrücklichen Motivfreigabe. Keine genehmigten Rasterparameter erfinden.

Aus genau den Originalbytes ist MA-r01 per nativer Bildbearbeitung entstanden. Entfernt: Glasur, Craquelé, Lichtreflexe, Schatten, Goldton und Materialtextur. Bestehende Außenkontur zu einer einfachen schwarzen Kontur zusammengefasst und für niedrige Rasterauflösung kräftiger lesbar gemacht. Hauptformen, Orientierung und Lage beider Punkte bleiben erhalten. Feinste Bildkantenglättung ist kein Zellzustand.

Identitätskern: annähernd kreisförmige Frontansicht; dunkle obere/linke Kommaform mit hellem Punkt oben, helle untere/rechte Kommaform mit dunklem Punkt unten; beide Punkte geschlossen und getrennt von S-Kurve/Umriss. Kein Drehen, Spiegeln, Strecken, Motivwechsel oder Zusatzrahmen. Bestehender Umriss ist Motivbestandteil, kein künstlicher Logikanker.

Kategorie unverändert mythen-fantasie. Nutzung und Ableitungsbindung stehen bei beiden Bilddateien. Verworfenes B/C nur historisch unter main@7313980e2f948a4dc519b9a136754ee03331d2a0, content/authoring/pz-3e97c042f0bf474e8608a84ea034c246/r01/package.zip. Keine alten ZIPs einbetten.

Standardauftrag 2 endet bei motif_review. Keine Zellmatrix, Hinweise, Logiknachweise, Reparatur oder Spielintegration erzeugen. Erst tatsächliche Motiv-/Parameterfreigabe startet Auftrag 3. Endabnahme vor Integration bleibt separat.
