# Codex-Übergabe · Standardauftrag 3

Bevorzugter Ausführungsweg: Codex für die noch anstehende deterministische Rasterproduktion und deren Prüf-/Reparaturschleifen. Technische Quellen/Dateien vollständig vorhanden; Start bleibt bis zur tatsächlichen Motivfreigabe gesperrt. Die offene menschliche Abnahme wird nicht als technische Nacharbeit behandelt. Kein Modell-/Reasoning-Versprechen oder behauptete Clientverfügbarkeit; Auswahl bei Start gemäß aktueller MODEL_SELECTION.md/MODEL_CATALOG.md prüfen.

Repository venomenon328/picross, Ziel main; Einstieg aktuelle AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md. Paketindex für pz-3e97c042f0bf474e8608a84ea034c246/r02 laden. Zuerst Handoff, Inventar und alle Datei-/Freigabebindungen prüfen. A-r01 ist freigegeben; MA-r01 samt parameters.json noch NICHT. Erst die tatsächliche Nutzererklärung mit Gegenstand/Hash/UTC-Zeit binden. Danach Standardauftrag 3 bis zur geprüften Rastervorlage zur Endabnahme ausführen, nicht integrieren.

25 × 25 empfohlen; zuerst vier gezielte Kandidaten aus designs/mono-25.json und designs/mono-27.json. 30 × 30 nur als begründete Reserve gemäß parameters.json und Regelwerk. Crop unverändert [16,15,1231,1230], exact, Mono, eine Vordergrundfarbe. designs sind gültige Konfigurationsvorlagen, kein ausgeführter Import. Erst nach Motivfreigabe aus motif/MA-r01.png importieren.

Kreis, Orientierung, beide Gegenpunkte, ihre Negativräume und S-Grenze schützen. Linienprofil zuerst; bei geeigneten stalled-Kandidaten Profilwahl und Reparatur nach Regelwerk. Keine errechnete Symmetrie als Solverregel, keine neuen Dekorationen/Rahmen oder erfundene Freigaben. Herkunft, tatsächliche Endmatrix, Logik, unabhängiger Proof, Randregel, visuelle Qualität und Schwierigkeit in Produktion prüfen. Keine rätselspezifischen CI-/Unit-Tests.

Repositoryablage samt bedingtem Ablagemerge ist im Nutzerauftrag enthalten; Bild-/Motiv-/Endfreigaben bleiben davon getrennt. Auftrag 3 endet vor Endabnahme und Integration. Keine geheimen Werkzeuge oder Modell-API.
