# 4 · Abnehmen & ins Spiel integrieren

r11/C-r03 ist vollständig deduktiv zertifiziert, Mehrdeutigkeitsblocker behoben.
Gesonderte tatsächliche Endfreigabe für unverändertes ZIP/Handoff/Inventar und
Auswahl contour aus candidates/C-r03/import erforderlich: Matrix6a48e53854d39c03df8510b44316bd086fc7b8c7649bb560a1de52ee3d2e3c32,
Logike21609d1e7b4408c3010e1cdd64a27a7ac924be4a2ccc891af110b30bd3613ef,RevealB-r02 unverändert. plans/C-r03.json ist die feste
flache Änderungsliste, Referenz imports/40x26/area-160. RP5-Herkunft/Replays zusätzlich
erhalten, keine neuen Freigaben daraus abgeleitet. Z3/S36leer,Z5/S8ink erhalten.

Erst mit tatsächlicher Erklärung externe approval.json und Owner/Autorisierung
nach ZA-1-v2 binden. permissions fixed_mono_edits=true,frame_exception=false,
superseded_content_blockers=[]; alte r10-Logikblocker sind durch neuen Proof behoben,
keine technische Ausnahme. Handoff state=blocked/manual_edit_record ist der
unterstützte Eingang. Dann ZA1export/plan/register nach tatsächlichem Auftrag;
keinen routinemäßigen inspect davor. Originalzip niemals für Endfreigabe umschreiben.
