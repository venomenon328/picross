# Carabao · Kopf und Hörner · r04

Status **motif_review**, neue Motivfreigabe offen · 2026-10-16T20:51:24.280923+00:00.
Regelwerk0.5.0 / Dokumentrevision14; Toolcommit `0fb6057079d75fcfa5ba03ba4d6d416794002057`.
Inventarhash außen im record.json; [Inventar](inventory.json).

Der Nutzer bittet, Kopf und Hörner im Raster besser zu erhalten. Zwei weitere
direkte Varianten38×23/128 und160 an freigegebenem MA-r01 bringen keine
überzeugende visuelle Verbesserung;128 vollständig gelöst,160 stalled.
[Frische unabhängige Belege](audit/compact-attempt.json); kein Mehrdeutigkeitsurteil.

Die neue [MA-r02](motif/MA-r02.png) zeigt breitere weiße Gesichts-/Stirnflächen,
deutlichere Schnauze/Ohren und kräftigere Horninnenräume.
[Freigegebenes A-r01](reveal/A-r01.png) bleibt bytegleich.
[Vergleich](preview/motif-comparison.png); [fünf visuelle Kriterien](visual-review.json).
Breiter Rumpf, Kopf-/Beinpose und Schwanz visuell erhalten; native Kantenänderungen
außerhalb des Kopfes vorhanden, keine Pixelidentität behauptet.

Vorgeschlagen weiter40×24,960 Zellen, mono, eine Vordergrundfarbe ink+EMPTY,
Crop[17,25,1519,944],contain,area128/160. Wunsch eine Farbe; tatsächlich verwendete
Matrixfarben noch unbekannt, da MA-r02 noch nicht rasterisiert wurde.
Rasterwirkung, Randregel, vollständige Logik, Endmatrix, Schwierigkeit und
Lösungszeit für MA-r02 ausdrücklich **ungeprüft/nicht geschätzt**.
Keine Reparatur einer freigegebenen Endmatrix, keine manuelle Rasterableitung.

Nutzungsgrundlage: nativ im Nutzerauftrag erzeugte KI-Bilder ohne Fremdassets.
Ein nativer Editaufruf, eine direkte Importuntersuchung mit zwei Kandidaten;
aktive Menschenzeit nicht erfasst. Probespiel optional und nicht durchgeführt.
Zieladapter-/Spielintegration nicht ausgeführt, keine Endabnahme.

Nächster Schritt: **3 · Motiv freigeben & produzieren**.
MA-r02 und neuer dateigebundener Korridor müssen dafür freigegeben werden.
PUZZLE_AUTHORING2.4 verlangt: „Vor jeder eigentlichen Rasterproduktion MUSS
die konkrete abstrahierte Motivdatei freigegeben sein“.
