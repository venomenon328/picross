# Carabao · Kopf-/Hornkorrektur · r04

ID pz-b5e2302bf71445c09caac76bbc2a7075; Kategorie saeuger; Quell-/Toolstand 0fb6057079d75fcfa5ba03ba4d6d416794002057.
Vorheriges versiegeltes r03 bleibt unverändert. Nutzerauftrag: request.md.
Die zusätzlich freigegebene Zellphase38×23 wurde an unverändertem MA-r01
mit area128/160 importiert: kein überzeugender Darstellungsgewinn.
Komplettes Bündel und frische unabhängige Prüfungen unter attempts/ und audit/.

Neue MA-r02 ist ein nativer Edit von MA-r01 mit A-r01 als verbindlicher
Pose-/Identitätsreferenz: breiter weißer Stirn-/Augenbereich, vereinfachte
Schnauze/Ohren, kräftigere zusammenhängende weiße Horninnenräume.
Die Darstellung ist schwarzweiße Formabstraktion, keine neue Fellzeichnung.
Breiter Rumpf, Kopf-/Beinstellung, Bauchzwischenräume und Schwanz visuell erhalten;
native Kanten-/Binnenformvariationen außerhalb des Kopfes sind vorhanden,
keine Pixelidentität behauptet. A-r01 unverändert.

40×24, mono, ink+Leer weiterhin vorgeschlagen. Neuer sourcegebundener Crop:
[17,25,1519,944], contain; Details: parameterkorridor.json.
MA-r02 und diese Parameter sind ausdrücklich noch nicht freigegeben.
Keine Matrix, Hinweise, Logik- oder Randregelzusage für MA-r02 vor Freigabe.
