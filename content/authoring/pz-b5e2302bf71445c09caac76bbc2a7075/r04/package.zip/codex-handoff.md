# Nächster Schritt: 3 · Motiv freigeben & produzieren

r04 befindet sich im motif_review. A-r01-Freigabe gültig, MA-r02/Korridor offen.
Nach tatsächlicher ausdrücklicher Freigabe von MA-r02 samt parameterkorridor.json
deren Erklärung/Akteur/UTC/Hash binden, neue40×24/128- und160-Kandidaten erzeugen
und gegen r03 visuell vergleichen. Dies ist eine gezielte Ersatzrunde nach
bereits sechs geprüften direkten MA-r01-Kandidaten, keine blinde Parametersuche.
Full-line-mono zuerst; bei geeigneter stalled-Variante vor logikbedingter Änderung
das Paarprofil prüfen. Aktiven begrenzten Reparaturauftrag nach4.4 beachten.
Neue Matrix/Hinweise, unabhängigen Proof, Endmatrix, Herkunft, Randregel,
Schwierigkeit und visuellen Vergleich nachweisen. Alte r03-Logik nicht wiederverwenden.
Keine Spielregistrierung vor tatsächlicher Endabnahme; Ablagemerge ist beauftragt.

Die kompakte MA-r01-Untersuchung ist ein Fehlversuchsbeleg, keine Zertifizierung
der MA-r02-Datei. Vollständige38×23-Bündel hier erhalten; r03-Vergleich über
0fb6057079d75fcfa5ba03ba4d6d416794002057. Alte Motivfreigabe nicht auf neue Gesichtsdarstellung übertragen.
