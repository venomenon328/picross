# Codex-Übergabe – Standardauftrag 3

Dateien und Konfiguration vorhanden; Start erst nach echter menschlicher
Freigabe von MA-r03 samt parameterkorridor.json. Diese Freigabe fehlt noch.
B-r02 ist bereits tatsächlich freigegeben; seine Bytes unverändert verwenden.
Keinen alten Ganzkörper-Import, Crop oder eine MA-r02-Freigabe übernehmen.

Nach Freigabe Erklärung, Akteur/UTC-Zeit, MA-Hash, B-Hash und Korridor binden.
Den Vierervergleich aus candidate_plan in parameterkorridor.json ausführen:
zwei Größen, je area-128/160. Die dritte Größe ist eine freizugebende Alternative,
kein zusätzlicher Routineimport. Designverträge sind vorbereitet, noch ungeprüfte
Produktionskonfigurationen. Keine Rasterproduktion fand in dieser Phase statt.

AGENTS.md und PUZZLE_AUTHORING samt Pflichtquellen lesen. Mit full-line-mono
beginnen; Profilwahl nach §4.2.1, bei Paarprüfung PAIRED_LINES vollständig lesen.
Herkunft, Normalisierung, Matrix/Hinweise, vollständigen unabhängigen Proof,
Endmatrix, Randregel, visuellen Vergleich und Schwierigkeit dateigebunden prüfen.
Nötige RP-5-Reparaturen nur innerhalb des freigegebenen Motivschutzes; keine freie
manuelle Zelländerung als regulären Import ausgeben. Keine CI-Fälle je Rätsel.
Finale Motiv-/Parameterbindung muss die gewählte zulässige Größe, Methode,
Farbzahl, Fit und den tatsächlichen Crop benennen. Andere materielle Formen oder
Korridorwerte benötigen Freigabe. Noch keine Spielregistrierung in Auftrag 3.

Kompakter Auftrag, erst nach gesondert erteilter Motiv-/Parameterfreigabe verwenden:

```text
Arbeite in venomenon328/picross@main nach AGENTS.md und
docs/ai-workflows/PUZZLE_AUTHORING.md samt Pflichtquellen.
Lade pz-b5e2302bf71445c09caac76bbc2a7075/r07 über content/authoring/index.json.
Führe nach ausdrücklicher Freigabe von MA-r03 samt Parameterkorridor
Standardauftrag 3 bis zum geprüften Endraster und zur Endabnahmevorlage aus.
Nutze codex-handoff.md und parameterkorridor.json im Paket; keine Spielregistrierung.
Repositoryablage nach §6 samt Ablagemerge nach Pflichtchecks ist beauftragt.
```
