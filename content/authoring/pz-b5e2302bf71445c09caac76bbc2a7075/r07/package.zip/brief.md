# Carabao-Kopf – Motivvorlage MA-r03

Stabile ID pz-b5e2302bf71445c09caac76bbc2a7075 · Paket r07 · Kategorie saeuger.
Standardauftrag 2 nach PUZZLE_AUTHORING 0.5.0 / Dokumentrevision 14.
B-r02 ist ausdrücklich freigegeben; Erklärung und Datei-/Paketbindung liegen
in approvals/. Das Abschlussbild bleibt bytegleich und farbig.
MA-r03 entstand durch native Schwarzweißabstraktion und eine gezielte
Verstärkung der Horn-/Ohrränder aus diesen gespeicherten Bytes. edit-chain.json
bindet beide tatsächlichen Schritte samt Zwischenbild und Prompts.
Der neue Name unterscheidet sie von den alten Ganzkörpervorlagen MA-r01/MA-r02.

Erhalten: linke Dreiviertelansicht, Augenpositionen/Blick, schwere Schnauze,
vollständige asymmetrische Hornbögen und Ohren sowie der kleine Kehlabschluss.
Wichtige freie Räume an Hörnern und Ohren sind geschützt. Keine Spiegelung,
neue Pose, Schulter, Streckung oder abgeschnittene Hornspitze.
Entfallen: dichte Oberflächentextur, Schattierungen, Hornrillen, feine Falten,
Ohrfransen und Haare. Breite weiße Augen-/Schnauzen-/Ohr-/Horninnenflächen
erhalten die wichtigsten Gesichtselemente innerhalb der schwarzen Hauptform.
Quelldateikanten sind geglättet; diskrete Zellen entstehen erst beim Import.

Nutzerwunsch ungefähr 40 × offen, mono. Empfehlung 40 × 26;
Alternativen und begründeter Vergleich stehen in parameterkorridor.json.
Genau eine Vordergrundfarbe ink plus Leer; die reale Matrixverwendung ist offen.
Vorgeschlagene Design-JSONs sind Konfigurationen, keine produzierten Rätsel.
Motiv-/Parameterfreigabe fehlen. Kein Raster, keine Hinweise oder Proofs erzeugt.
A-r02 und C-r02 bleiben ausschließlich als nicht gewählte Varianten im r06-Commit.
Frühere Produktionspakete und Freigaben bleiben unverändert dateigebunden erhalten.
