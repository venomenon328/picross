# Carabao – Auftrag 2

ID `pz-b5e2302bf71445c09caac76bbc2a7075` · Revision r02 · Status motif_review · 2026-10-16T20:11:53.171886+00:00
Regelwerk 0.5.0 / Dokumentrevision 14 · gelesener Tool-/Repositorycommit `f0ac64858893573298602f262b32274fd21278cb`.

A-r01 ist durch Tobias am 16.10.2026 ausdrücklich freigegeben und bytegleich
übernommen. Erklärung, Dateihash und Herkunft liegen in approvals/ und reveal/.
MA-r01 ist die nativ aus genau dieser Datei erzeugte monochrome Motivvorlage.
Keine Motivfreigabe oder Endabnahme wird behauptet. B/C bleiben im historischen r01.

Konfiguration: empfohlen 40×24 (960 Zellen), alternativ 38×23 oder 42×25,
mono, eine Vordergrundfarbe ink plus Leer. Vergleich von Motivtreue, Darstellbarkeit,
ungeprüftem Logikrisiko und Spielgefühl: parameterkorridor.json. Die gewünschte
Breite bleibt ungefähr 40; keine Farbe hinzugefügt. Verwendete Matrixfarben,
Schwierigkeit und Lösungszeit sind noch nicht bestimmt. Palette/Korridor sind Vorschläge.

Erhaltene Invarianten und Detailverluste: brief.md und visual-review.json.
Fünf visuelle Kriterien erfüllt im Selbstreview der Quelldateien; keine Abnahme des
noch nicht erzeugten Rasters. Bildmetrik: image-qa.json, keine Rasterproduktion.
Genau ein nativer Editaufruf, keine Überarbeitungsrunde; aktive Menschenzeit unbekannt.
Keine Import-/Reparaturrunde: erst nach Motivfreigabe anwendbar. Herkunft bis zur
Motivdatei ist gebunden; Normalisierung, Matrix, Hinweise, Logikproof, Randregel,
Schwierigkeit, finale Konsistenz und Zieladapterexport sind noch ausstehend.
Für diese frühe reine Ablage sind Spieltests, Builds und ZA-1-inspect nicht erforderlich.

Nächster erlaubter Schritt: 3 · Motiv freigeben & produzieren.
Motivdatei MA-r01 und der vorgeschlagene Korridor müssen dafür menschlich freigegeben
werden. Übergabe: codex-handoff.md. Ablagemerge ist beauftragt; Prüf-/Mergebelege
werden außen im PR geführt. Paket-/Inventarhash stehen außen im record.json.
