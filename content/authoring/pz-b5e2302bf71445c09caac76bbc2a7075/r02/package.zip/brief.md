# Carabao – vorlagentreue Abstraktion

ID: pz-b5e2302bf71445c09caac76bbc2a7075 · Paket r02 · Kategorie saeuger.
Standardauftrag 2 nach PUZZLE_AUTHORING 0.5.0 / Dokumentrevision 14.
Die tatsächliche Freigabe von A-r01 ist in approvals/reveal.json samt Erklärung gebunden.
Abschlussbildbytes bleiben unverändert. B-r01 und C-r01 sind nicht ausgewählt;
ihre Originale bleiben ausschließlich in r01 auf dem angegebenen Main-Commit.

Nutzerwunsch: ungefähr 40 × offen, mono. Empfehlung nach der tatsächlich erzeugten
Motivform: 40 × 24. Alternativen: 38 × 23 und 42 × 25, jeweils genau eine
Vordergrundfarbe plus Leer. Ausführlicher Vergleich, Grenzen und vier geplante
Rasterkandidaten: parameterkorridor.json. Alle Konfigurationen sind Vorschläge;
Motiv- und Parameterfreigabe fehlen weiterhin. Kein Raster wurde erzeugt.

Erhalten: Körper nach links, Kopf zum Betrachter, breite Rumpfform, zwei ausladende
Hornbögen, Ohren, vier Beine in derselben stehenden Pose sowie Schwanz rechts.
Die großen Negativräume unter dem Bauch, zwischen den Beinen und an den Hörnern
sind zu bewahren. Kein Drehen, Spiegeln, Reposieren, Strecken oder Abschneiden.
Erlaubt ist die motivgerechte Zusammenfassung feiner Ohrfransen, Augendetails,
Hufspalten und schmaler Binnenlinien; keine beliebige Änderung geschützter Formen.

Detailverluste: Hauttextur, Schatten, Hornrillen, kleine Falten und Bodenschatten
entfallen. Große schwarze Flächen und wenige weiße Innenformen tragen das Motiv.
Die erzeugte Quelldatei enthält geglättete Kanten; erst der spätere deterministische
Import erzeugt diskrete Zellwerte. Keine vorzeitige Lösbarkeits- oder Schwierigkeitszusage.
