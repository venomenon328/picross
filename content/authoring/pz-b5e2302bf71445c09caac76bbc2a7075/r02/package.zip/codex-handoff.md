# Codex-Übergabe – Standardauftrag 3

Vorbereitungsstatus: Dateien und Konfiguration vorhanden; Start erst nach der
tatsächlichen menschlichen Freigabe von MA-r01 samt parameterkorridor.json.
Es existiert noch keine solche Motivfreigabe. Kein Produktionslauf beauftragt.
Bei ausschließlich offenem menschlichem Gate keine Modell-/Reasoningempfehlung
als bereits startbereiten Auftrag ausgeben (MODEL_SELECTION §1).

Paket über content/authoring/index.json auf aktuellem main laden. r01 ist der
historische Variantenstand; r02 enthält die unveränderten freigegebenen A-r01-Bytes,
die tatsächliche Abschlussbildfreigabe, MA-r01 und den vorgeschlagenen Korridor.

Nach Freigabe: Erklärung samt Akteur/UTC-Zeit, MA-Hash, A-Hash und freigegebenen
Parametern binden. 40×24 mit area-128/160 und 42×25 mit area-128/160 sind die vier
geplanten Kandidaten. 38×23 bleibt eine freizugebende kompakte Alternative, kein
zusätzlicher Routineimport. Die Design-JSONs sind ungeprüfte Importkonfigurationen,
keine Rätsel oder zertifizierten Kandidaten. Zu Anfang full-line-mono; Profilprüfung
nach PUZZLE_AUTHORING §4.2.1, nötigenfalls PAIRED_LINES vollständig lesen. Bei
Fixpunkt nicht sofort das Raster umbauen. Herkunft, Randregel, unabhängiger Proof,
Endmatrix, visueller Vergleich und Schwierigkeit gehören in die Produktion.
RP-5-Reparaturen nur innerhalb des freigegebenen Motivschutzes; keine freien
manuellen Zellkorrekturen als regulären Import ausgeben. Keine CI-Einzelfälle.

Der tatsächliche Import muss exakt gespeicherte MA-r01-Bytes verwenden. Bei
gewähltem Maß das entsprechende Design übernehmen; nicht strecken. Finale
Motivfreigabe-/Parameterbindung muss die tatsächlich gewählte zulässige Größe,
Farbzahl, Methode, Fit und tatsächlichen Crop benennen. Nicht alle Alternativen
als bereits abschließend gewählt ausgeben. Andere Korridorwerte erfordern Freigabe.
Erst nach vollständiger Produktion Raster zur Endabnahme vorlegen; in Auftrag 3
keine Spielregistrierung. Repositoryablage mit passendem bedingtem Mergeauftrag
fortführen; Freigaben und Produktionsrevisionen nicht überschreiben.

Kompakter Auftrag, erst nach separat erteilter Motiv-/Parameterfreigabe verwenden:

```text
Arbeite in venomenon328/picross auf aktuellem main; lies AGENTS.md und
docs/ai-workflows/PUZZLE_AUTHORING.md samt Pflichtquellen.
Lade pz-b5e2302bf71445c09caac76bbc2a7075/r02 über content/authoring/index.json.
Führe nach der ausdrücklich erteilten Freigabe von MA-r01 samt Parameterkorridor
Standardauftrag 3 bis zum geprüften Endraster und zur redaktionellen Endabnahmevorlage aus.
Nutze codex-handoff.md und parameterkorridor.json im Paket; keine Spielregistrierung.
Repositoryablage nach §6 samt Ablagemerge nach erfolgreichen Pflichtchecks ist beauftragt.
```
