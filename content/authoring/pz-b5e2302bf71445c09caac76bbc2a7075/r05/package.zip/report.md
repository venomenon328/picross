# Carabao · neue Endabnahmevorlage r05

`pz-b5e2302bf71445c09caac76bbc2a7075` · **content_ready**, Endabnahme offen · 2026-10-16T21:01:36.972516+00:00.
Regelwerk0.5.0/Rev14; Toolcommit`5177ea41579962a9751012f44e1490e321782ef7`.
[Inventar](inventory.json), versiegelter SHA-256 außen im record.json.

A-r01 und MA-r02 samt Parametern tatsächlich durch Tobias freigegeben:
[Reveal](approvals/reveal.json),[Motiv](approvals/motif-r02.json).
**Gesonderte Endabnahme offen**, keine Spielregistrierung oder Zieladapterausgabe.

Auswahl40×24/area-160,mono,960 Zellen;466 gefüllt,494 leer,ink`#000000`+EMPTY.
Gewünschte und verwendete Vordergrundfarbzahl1; Schwarz trägt Tierform,
Leer Hintergrund/Gesichts-/Horninnenflächen.
[Echtes Raster](preview/final-raster-40x24.png),[Gitter](preview/final-raster-grid.png),
[A-r01](reveal/A-r01.png),[Vorher/Nachher](preview/final-comparison.png).
Beide neuen Kandidaten deduktiv vollständig;160 gewählt für zusammenhängendere
Kontur und ruhigere Rumpf-/Schwanzflächen.128 stärker fragmentiert.
[Prüfbelege](audit/candidates.json),[Entscheidungen](decisions.json).

**Technik PASS:** gültige Maße/Palette/Zellwerte, sourcegebundener Crop/Fit,
Original→Normalisierung→Matrix→Hinweise frisch rekonstruiert; full-line-mono,v1,
198 Schritte vom unbekannten Start unabhängig bestätigt, exakte Endmatrixgleichheit.
Vollständige Deduktion belegt zugleich Eindeutigkeit. Rand links/oben/unten belegt,
rechts leer: Formel erfüllt. Kein Paar-/Suchlauf oder Reparatur erforderlich,
weil geeigneter vollständiger Direktkandidat vorhanden;0 manuelle Zelledits.

**Gestaltung PASS im Selbstreview:** größere Gesichtsflächen und Horninnenräume
besser erhalten; gleiche Pose/Hauptproportionen und Bauch-/Beinzwischenräume.
Vier motivisch isolierte Horn-/Ohrzellen und weiterhin grobe Gesichts-/Hornspitzendetails
offengelegt. Belegung48,5%,keine leeren Innenlinien.
23 Zellunterschiede zu r03:22 lokal Kopf/Hörner,1 obere Rückenlinie;
[Vergleich zweier genehmigter Importe](audit/comparison-with-r03.json).
Kein Reparaturdiff. [Fünf Kriterien](visual-review.json); A-r01 bytegleich,
MA-r02 seit Freigabe unverändert. Nutzungsgrundlage in Provenienzdateien.

**Schwierigkeit L2 geschätzt**,plausibelL1–L4,editorial_estimate/low;
Überlappung/Verlängerung langer Rumpfblöcke. Alle64 Linien vor allen198 Schritten
geprüft,vor Aufräumen mindestens7 produktive Linien,keine numerische Engstelle;
kein validierter schwächerer Technikklassifikator.
[Bewertung](difficulty.json),[Checkpoints](audit/difficulty-checkpoints.json).
Bearbeitungsumfang960 Zellen; menschliche Lösungszeit **nicht geschätzt**.

Nativ im Nutzerauftrag erzeugte KI-Bilder ohne Fremdassets; keine Exklusivität.
Bisher3 Revealaufrufe+2 Motivedits;hier0 Bildaufrufe,1 Import/2 Kandidaten,
0 Reparaturen; aktive Menschenzeit nicht erfasst. Probespiel optional,nicht durchgeführt.
Native Spiel-/Buildprüfungen für reine Ablage nicht erforderlich.
Nächster Schritt:**4 · Abnehmen & ins Spiel integrieren**,nach tatsächlicher Endfreigabe.
