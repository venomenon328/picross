# Carabao · Raster aus MA-r02 · r05

ID pz-b5e2302bf71445c09caac76bbc2a7075; Kategorie saeuger; Regelwerk0.5.0 / Dokumentrevision14.
Tool-/Quellcommit 5177ea41579962a9751012f44e1490e321782ef7. Tatsächliche MA-r02-/Parameterfreigabe:
approvals/motif-r02.json samt vollständig protokollierter Frage und Nutzerantwort.
A-r01 bleibt die zuerst freigegebene verbindliche und bytegleiche Referenz.

Freigegeben40×24,mono,1 Vordergrundfarbe+Leer,area128/160,contain,
Crop[17,25,1519,944]. Zwei gezielte Ersatzkandidaten nach ursprünglichem
Viererkandidatenvergleich und zwei zusätzlichen38×23-Versuchen am MA-r01.
Beide neue Kandidaten vollständig zertifiziert, Auswahlarea160 aus visuellen Gründen.
Keine neuen Maße, Palette, Crops, Bild- oder manuellen Zellkorrekturen.

Erhalten: breiter niedriger Rumpf, Kopf links zum Betrachter, zwei perspektivisch
verschiedene Hornbögen, Ohren, vier Beine, Bauch-/Beinzwischenräume, Schwanz rechts.
Breitere weiße Gesichts-/Horninnenflächen sind ausdrücklich freigegebene
monochrome Abstraktion. Pupillen, Nasenlöcher, Lippen und Hornspitzen bleiben grob.
Native MA-r02-Kantenvariationen wurden vor Produktion offengelegt und freigegeben.
23 Matrixzellen unterscheiden sich von r03,22 am Kopf/Hörnern und1 am Rücken;
dies ist ein Vergleich, kein manueller Zellbearbeitungsplan.

Ziel: geprüfte Endabnahmevorlage und beauftragte Repositoryablage mit Ablagemerge.
Menschliche Endabnahme noch offen; keine Spielregistrierung oder Bereinigung.
