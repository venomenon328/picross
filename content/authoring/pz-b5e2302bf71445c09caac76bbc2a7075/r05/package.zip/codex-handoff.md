# Nächster Schritt:4 · Abnehmen & ins Spiel integrieren

r05 ist content_ready, menschliche Endabnahme offen. Originalhandoff/Inventar
nach Versiegelung unverändert lassen. Endfreigabe separat nach ZA-1 binden:
IDpz-b5e2302bf71445c09caac76bbc2a7075,Revisionr05,area-160 aus imports/40x24,
Matrixhashd7421c512898c546927ea5e80100adbedbc11a1622c76a2c299b488a84190257,Logikhashc92b07e958fa54fb2b60ab9623264620e519896216fe31a82c4be28634d9a08d,
RevealA-r01:8fa226c1a2e5b463f3e2c09551631bcf63f0a70ae46402f1ef1ae03b2050fd7f.
Vorlage:preview/final-comparison.png,preview/final-raster-grid.png,report.md.
Beide Bildfreigaben liegen vor; die Endabnahme folgt nicht aus Motivfreigabe
oder Ablagemerge. Keine manuelle Ableitung oder Ausnahme nötig.

Nach tatsächlichem Integrationsauftrag/Freigabe PUZZLE_AUTHORING§§8–9 ausführen.
Kategorie saeuger, stabile Produktions-ID erhalten; Runtime-Revision/Stem/Slot
explizit und kollisionsfrei wählen. Neue Registryeinträge nur über ZA-1.
Keine rätselspezifischen CI-Fälle oder routinemäßigen Bestands-/Spielreplays.
