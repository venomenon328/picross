# Carabao – Kopf · geschlossene Schnauzenkontur · r09

ID pz-b5e2302bf71445c09caac76bbc2a7075, Kategorie saeuger, Quelle/Toolcommit b8253c6d5b38d43a59dc77988a697bd2d59d52e5.
Aktueller Auftrag in contour-request.json. B-r02 und MA-r03 samt originalem
Parameterkorridor bleiben bytegleich und menschlich freigegeben.
Neue40×26-Monokandidaten A/B/C durch explizite feste Zellkorrekturen;16/18/20
Ergänzungen nur an Außen-/Lippenkontur der Schnauze. Hörner, Augen, Ohren und
Kopf-only-Proportionen wie r08. Keine Bildänderung oder neue Farben.

Alle drei Raster vollständig full-line-mono-zertifiziert. A empfohlen,
menschliche Auswahl/Endabnahme offen. Feste Mono-Ableitung benötigt zur
Zieladapterprüfung/-integration den externen ZA-1-v2-Vertrag einschließlich
exakter Endauswahl und Freigabe. Kein Owner-Override aus bloßem Wunsch erfunden.
Repositoryablage samt bedingtem Ablagemerge aus bestehendem Auftrag fortgesetzt.
