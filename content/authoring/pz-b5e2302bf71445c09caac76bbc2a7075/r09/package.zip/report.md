# Carabao – Kopf · drei korrigierte Raster · r09

`pz-b5e2302bf71445c09caac76bbc2a7075` · **Kandidaten zertifiziert; Auswahl/Endabnahme offen** · 2026-10-16T22:50:37.518599+00:00.
Regelwerk0.5.0/Rev14; Tool-/Quellcommit `b8253c6d5b38d43a59dc77988a697bd2d59d52e5`.
Inventarhash nach Versiegelung im äußeren Record. [Vergleich](preview/candidate-comparison.png),
[B-r02 und EmpfehlungA](preview/acceptance-A.png), [Prüfbelege](audit/candidates.json).

**A empfohlen:** schmale vollständig geschlossene Kontur,16 zusätzliche Schnauzenzellen,
444 gefüllt/596 leer,250 Proofschritte. **B:** rundere untere Vorderkante,18 Zellen,
446/594,256 Schritte. **C:** kräftigere Vorderkante,20 Zellen,448/592,252 Schritte.
Alle40×26/1040 Zellen,monochrom,gewünscht/verwendet genau1 Vordergrundfarbe ink+EMPTY.
Schwarz trägt Kopf/Kontur,Nasenformen;Leer trägt Hintergrund und Binnenräume.

**Geprüft:** Hinweise frisch abgeleitet,vollständigerfull-line-mono-v1-Nachweis vom
unbekannten Start,unabhängige Proofprüfung,exakte Endmatrix; Eindeutigkeit folgt
aus vollständiger Deduktion. Originalquelle→Normalisierung→Matrix→Hinweise rekonstruiert,
jede feste Änderung gegen vorher gespeicherten Plan/Schutzmaske replayt,neuen
Rasterquellimport vollständig rekonstruiert. Rand links/oben/unten belegt,rechts leer;
Produktmaße/Palette gültig. Keine Such-/Paar-/RP5-Runde erforderlich,alle drei solved.

**Konturprüfung:** Naseninnenraum33 Leerzellen und Unterlippenraum3 Leerzellen
in jeder Variante vierfach zusammenhängend,separat voneinander,kein Kontakt zu
irgendeinem Außenrand. Hörner, Augen, Ohren und alle Zeilen1–16 unverändert zu r08;
auch alle übrigen Werte außerhalb der Schnauze unverändert. A16/B18/C20 Einfügungen
am Schnauzenrand; vollständige feste Pläne und markierte Diffs im Paket.
[Fünf Gestaltungskriterien](visual-review.json). Kleine Pupillen/Lippen/Hornrillen
bleiben grob;vorderes Nasenloch berührt motivgerecht Außenkontur. HornspitzeZ1/S36
weiter diagonal verbunden. Alle drei Varianten vermeiden künstliche Randanker.

B-r02 und MA-r03 tatsächlich freigegeben,bytegleich;native Ableitung/Prompts vollständig.
Korrekturauftrag ist keine Endabnahme. Quellen-/Rechtegrundlage:nativ beauftragte
KI-Bilder ohne Fremdassets,keine Exklusivität behauptet. Keine neue Motivdatei.

**L2 geschätzt**,BereichL1–L4,editorial_estimate/low. Alle66 Linien vor jedem Proofschritt
ausgewertet;vor Aufräumen mindestensA5/B6/C7 produktive Linien,keine numerische
Engstelle. R0–R3-Notwendigkeit nicht validiert klassifiziert. Umfang1040 Zellen,
Lösungszeit nicht geschätzt,Probespiel optional/nicht durchgeführt.
Hier0 Bildaufrufe,3 erfolgreiche Importe,6 vorab abgewiesene source_id-Entwürfe,
0 Suchreparaturen;aktive Menschenzeit nicht erfasst. Historisch3 Revealaufrufe+2 Motivedits.

**Zieladapter noch nicht geprüft/exportiert:** feste bearbeitete Monoimporte benötigen
nach ZA-1-v2 auch für inspect die externe an Endauswahl/Plan/ZIP/Handoff/Inventar
gebundene menschliche Autorisierung plus Endfreigabe. Kein Beleg erfunden;
handoff.state=blocked hält diesen konkreten Freigabestopp fest,keine Logikstörung.
Kein content_ready/Katalogfähigkeit/Spielregistrierung behauptet. Native Spiel-/Buildtests
für diese reine Ablage nicht erforderlich. **Nächster Schritt:4 · Abnehmen & ins Spiel integrieren**,
nach konkreter menschlicher Auswahl und Endfreigabe der festen Konturkorrektur.
