# Nächster Schritt:4 · Abnehmen & ins Spiel integrieren

r09 enthält drei vollständig zertifizierte feste Mono-Korrekturen.A empfohlen;
Originalhandoff nennt A als technische Empfehlung,menschliche Auswahl offen.
Kein content_ready und keine ZA-1-Inspektion ohne tatsächliche externev2-Autorisierung
und Endfreigabe. Handoff state=blocked plus manual_edit_record=plans/A.json ist
der nach ZA-1-v2 unterstützte Eingang,keine Ausnahme von technischen Anforderungen.

Bei Freigabe von A: tatsächliche Erklärung außerhalbZIP als approval.json und
owner-override-v2/manual-authorization-v2 erfassen,an r09-ZIP/Handoff/Inventar,
plans/A.json und Referenz imports/40x26/area-160 sowie Auswahl binden:
Variantecontour, Matrix7ffc65af071bd1bccb643b3c847c9693750c77e74aaeec50b67cc3c4e2567482,Logik6814b3ec8b430315b0abfd6c22c50aa7a66385861fea75d3183126d1f0c12965,
RevealB-r02 b382978fca16415070b83cf41e5a684ee26ac81e87a94ab4824d0f06b89db280. permissions fixed_mono_edits=true,
frame_exception=false;keine Rand-Ausnahme nötig. superseded_content_blockers=[]
bleibt leer,keine technischen Blocker übergehen. Dann ZA-1export/plan/register
nach tatsächlichem Integrationsauftrag ausführen; keine künstlichen Freigaben.
Falls B/C ausgewählt, neue eindeutig gebundene Metadatenrevision mit passendem
Plan/Endauswahl und tatsächlicher Freigabe vorbereiten; r09 unverändert erhalten.
