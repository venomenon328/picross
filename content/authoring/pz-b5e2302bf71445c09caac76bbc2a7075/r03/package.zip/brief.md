# Carabao · Standardauftrag 3 · r03

ID pz-b5e2302bf71445c09caac76bbc2a7075, Kategorie saeuger; Regelwerk0.5.0 / Dokumentrevision14.
Repository-/Toolstand 4fbaabba6cce244ad792971d1f85fe7949f48f07. Aktueller Auftrag gibt MA-r01 samt dem
unveränderten r02-Parameterkorridor frei; Beleg: approvals/motif.json.
A-r01 war bereits ausdrücklich freigegeben und bleibt bytegleich.

Gewünscht ungefähr40×offen, monochrom. Erlaubt 38×23,40×24,42×25 mit
genau einer Vordergrundfarbe ink und Leer, area128/160, Crop[16,24,1519,944],
contain. Vier vorab geplante Kandidaten tatsächlich importiert; Auswahl40×24/160.
Erhalten: breiter Rumpf, Kopf links zum Betrachter, Hornbögen, Ohren, vier Beine,
Bauch-/Beinzwischenräume und hängender Schwanz rechts. Kein Drehen, Spiegeln,
Strecken, Beschnitt des Tiers, Randpixel oder Zusatzobjekt.
Freigegebene Detailreduktion: Textur/Schatten/Hornrillen entfallen; feine Ohr-,
Pupillen-, Huf- und Binnenlinien zusammenfassen. Konkrete Verluste und motivisch
isolierte Zellen: visual-review.json und finaler Bildvergleich.

Ziel dieses Auftrags: geprüfte Endabnahmevorlage mit Repositoryablage samt
beauftragtem Ablagemerge. Keine Spielregistrierung ohne gesonderte Endabnahme.
