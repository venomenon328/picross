# Carabao · Endabnahmevorlage r03

`pz-b5e2302bf71445c09caac76bbc2a7075` · **content_ready**, Endabnahme offen · 2026-10-16T20:29:20.494463+00:00
Regelwerk0.5.0/Rev14 · Toolcommit `4fbaabba6cce244ad792971d1f85fe7949f48f07`.
Inventar: [inventory.json](inventory.json); versiegelter Dateihash im äußeren record.json
(Inventar schließt diesen Bericht ein, daher kein zirkulärer Selbsthash).

**Bildfreigaben:** A-r01 und MA-r01 samt Korridor ausdrücklich durch Tobias;
[Reveal](approvals/reveal.json), [Motiv](approvals/motif.json).
**Endabnahme: offen**, keine Spielregistrierung oder Zieladapterausgabe.

**Auswahl:** 40×24,960 Zellen, mono, ink `#000000` + EMPTY;481 gefüllt/479 leer.
Gewünschte und verwendete Vordergrundfarbzahl1; Schwarz trägt Tierform,
Leer Hintergrund/Innenräume. [Echtes Raster](preview/final-raster-40x24.png),
[Gitter](preview/final-raster-grid.png), [Abschlussbild](reveal/A-r01.png),
[Vergleich](preview/final-comparison.png).
40×24/area-160 erhält die zusammenhängendere Silhouette.40×24/128 bleibt
mit4 offenen Zellen im Linienfixpunkt; beide42×25 verletzen die Randregel,
/128 hat zusätzlich8 offene Zellen. Kein Mehrdeutigkeitsurteil für Fixpunkte.
[Vergleichsbelege](audit/candidates.json), [Entscheidungen](decisions.json).

**Technik PASS:** Maße, Zellwerte/Palette, Crop/Fit, Original-/Normalisierung,
deterministische Matrix/Hinweise, unabhängiger vollständiger Proof vom unbekannten
Start und exakte Endmatrixgleichheit. Profil full-line-mono,v1,153 Schritte;
deduktive Vollständigkeit belegt zugleich Eindeutigkeit. Rand links/oben/unten
belegt, rechts leer: Formel erfüllt. Vier Kandidaten frisch im separaten
Prüferprozess rekonstruiert: [Audit](audit/candidates.json).
Paarprofil/Suchdiagnose nicht erforderlich: Endkandidat vollständig gelöst.
Reparaturrunden entfallen, weil geeigneter Direktkandidat vorliegt;0 Zelledits.

**Gestaltung PASS im Selbstreview:** Pose, Hauptproportionen, vier Beine,
Bauch-/Beinzwischenräume und Schwanz erhalten; stark quantisierte Horn-/
Gesichtsdetails. Zwei isolierte Horn-/Ohrspitzen quellgebunden akzeptiert.
Keine leeren Innenlinien, Belegung50,1%; keine zusätzlichen motivfremden Anker.
[Fünf Kriterien und Verluste](visual-review.json). A-r01 unverändert und
motivisch konsistent; Nutzungsgrundlage in beiden Provenienzdateien.

**Schwierigkeit L2**, plausibel L1–L4, editorial_estimate/low;
Überlappung/Verlängerung langer Rumpfblöcke dominiert die Schätzung.
Alle64 Linien vor allen153 Schritten geprüft: vor Aufräumen mindestens16
produktive Linien, keine numerische Engstelle; kein validierter schwächerer
Technikklassifikator. [Bewertung](difficulty.json), [Belege](audit/difficulty-checkpoints.json).
Bearbeitungsumfang960 Zellen; menschliche Lösungszeit **nicht geschätzt**.

Nativ im Nutzerauftrag erzeugte KI-Bilder ohne Fremdassets; keine Exklusivität
behauptet. Bisher3 Revealaufrufe+1 Motivedit; hier0 Bildaufrufe,2 Importe/4 Kandidaten,
0 Reparaturen; aktive Menschenzeit nicht erfasst. Probespiel nicht durchgeführt,
optional. Zieladapterexport wartet auf Endabnahme; native Spiel-/Buildprüfungen
für reine Ablage nicht erforderlich. Nächster Schritt: **4 · Abnehmen & ins Spiel integrieren**.
