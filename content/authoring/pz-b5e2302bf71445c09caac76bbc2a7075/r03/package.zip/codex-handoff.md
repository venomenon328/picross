# Wiederaufnahme: 4 · Abnehmen & ins Spiel integrieren

r03 ist content_ready und noch nicht menschlich endabgenommen.
Originalinventar und Handoff sind versiegelt. Endabnahme separat nach ZA-1
mit tatsächlicher Erklärung, Akteur/UTC, Originalhandoff-/Inventarhash und
exakter Auswahl binden. Auswahl: imports/40x24, area-160, Matrixhash
eff836211710273c54705754d6ad900a4f4b4c1d1270529e2588b70e3c38c41f, Logikhash 5c1911f2dff336a5382a238a65830e4d6d4bf0000084611d57cb4fd11973742e,
Reveal A-r01 8fa226c1a2e5b463f3e2c09551631bcf63f0a70ae46402f1ef1ae03b2050fd7f.
Endabnahmevorlage: preview/final-comparison.png, preview/final-raster-grid.png,
report.md, quality.json. Motiv-/Revealfreigaben sind bereits vorhanden.

Das beauftragte Ablagemerge allein ist keine Endabnahme. Nach tatsächlicher
Endfreigabe PUZZLE_AUTHORING §§8–9 samt aktuellen Pflichtquellen ausführen.
Produktions-ID unverändert; Kategorie saeuger. Runtime-Revision, Stem/Slot und
Name bei tatsächlichem Integrationsauftrag explizit und kollisionsfrei wählen.
Keine neuen CI-Einzelfälle, keine routinemäßigen Bestands-/Spielreplays.
Die ursprüngliche Freigabe/Integrationserlaubnis aus dem Chat auf Scope prüfen;
keine Freigabe aus Vorlagen oder pass-Flags erfinden.
