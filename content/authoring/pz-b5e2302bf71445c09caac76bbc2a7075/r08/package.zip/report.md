# Carabao – Kopf · Endabnahmevorlage r08

`pz-b5e2302bf71445c09caac76bbc2a7075` · **content_ready; Endabnahme offen** · 2026-10-16T21:58:24.716762+00:00.
Regelwerk0.5.0/Rev14; Tool-/Quellcommit `49fe10fc7370710050c933dc69e03ef6ed0e2520`.
[Inventar](inventory.json), SHA-256 nach Versiegelung im äußeren record.json.
[B-r02-Freigabe](approvals/reveal.json), [MA-r03-Freigabe](approvals/motif.json).

**Auswahl:**40×26/area160 + RP5 round-2 candidate-005,mono,1040 Zellen,
428 gefüllt/612 leer,genau1 Vordergrundfarbe ink#000000+EMPTY.
Schwarz trägt Kopf/Konturen/Auge/Nase,Leer Hintergrund und wichtige Innenräume.
[Echtes Raster](preview/final-raster-40x26.png),[Gitter](preview/final-raster-grid.png),
[B-r02](reveal/B-r02.png),[Bildvergleich](preview/final-comparison.png).
Vier Direktkandidaten verglichen:160 erhält Konturen besser;40×26 zusammenhängender
und14 offene Zellen statt118 bei42×28. Alle Direktimporte stalled; keine falsche
Zertifizierung. [Viererprüfung](audit/candidates.json),[Paarprüfung](audit/paired.json).

**Technik PASS:**Produktmaße,Palette,Rand links/oben/unten (rechts leer),
Quelle→Normalisierung→Matrix→Hinweise frisch rekonstruiert. Finalfull-line-mono/v1,
264 Schritte vom unbekannten Start, unabhängiger Prüfer und exakte Endmatrix.
Vollständige Deduktion beweist Eindeutigkeit. [Finalprüfung](audit/final.json),
[vollständiger Reparaturreplay](audit/repair-round-2.json).
Paarversuch40×26/160 ebenfalls stalled;128-Läufe und42×28/160-Prüfung erreichten
Arbeitsbudgetgrenzen, keine Freigabe daraus abgeleitet.

**Reparatur:**Runde1 mitmax2 Zellen,37 Bewertungen/296 Vorschlägen ohne Fund.
Runde2 andere Hypothese zu drei lokalen Konturambiguitäten,max3 vorab begründet,
6 Bewertungen/6 Vorschläge,Fundergebnis. Z3/S36 leer→ink (innere rechte Hornkante),
Z5/S8 ink→leer (innere linke Hornkante),Z18/S10 leer→ink (zweites Nasenloch).
[Diff/Schutzmaske](repairs/round-2/view.png),[Pläne/Entscheidungen](decisions.json).
Keine freien manuellen Zelledits. Alte Referenz unverändert, neuer Endproof.

**Gestaltung PASS im Selbstreview:**Hauptproportionen,Kopf-only-Pose,Hornspitzen,
große Horn-/Ohrinnenräume,Augenfenster und zwei Nasenlöcher erhalten.
Feine Augen-/Lippendetails und glatte Hornkurven bleiben grob; Mundkontur segmentiert.
Zwei motivisch isolierte Zellen (Z1/S36,Z24/S10) akzeptiert;Belegung41,2%,
keine leeren Innenlinien. [Fünf Kriterien](visual-review.json).
B-r02/MA-r03 seit Freigabe bytegleich; vollständige native Editkette erhalten.

**Schwierigkeit L2 geschätzt**,plausibelL1–L4,editorial_estimate/low;
Überlappung/Verlängerung breiter Kopfflächen und kurze Horn-/Augen-/Nasenblöcke.
Alle66 Linien vor264 Schritten geprüft,vor Restaufräumen mindestens6 produktive
Linien,keine numerische Engstelle;kein validierter schwächerer Technikklassifikator.
[Bewertung](difficulty.json). Umfang1040 Zellen,Lösungszeit **nicht geschätzt**.

Nativ beauftragte KI-Bilder ohne Fremdassets; keine Exklusivität behauptet.
Historisch3 Revealaufrufe+2 Motivedits;hier0 Bildaufrufe,4 Importe (4 unterschiedliche
Raster+4 Profilwiederprüfungen),2 Reparaturrunden;aktive Menschenzeit nicht erfasst.
Probespiel optional,nicht durchgeführt. ZA-1-Prüfung des geschriebenen ZIP außen;
Zieladapterexport/Spielregistrierung noch nicht erfolgt. Native Spiel-/Buildtests
für reine Authoringablage nicht erforderlich. Einzig offene Endfreigabe.
**Nächster Schritt:4 · Abnehmen & ins Spiel integrieren.**
