# Carabao – Kopf · r08

ID pz-b5e2302bf71445c09caac76bbc2a7075, Kategorie saeuger, Komposition head_only.
Regelwerk0.5.0/Revision14; Quelle/Toolcommit 49fe10fc7370710050c933dc69e03ef6ed0e2520.
Auftrag: Standardauftrag3 vollständig bis Endabnahmevorlage; Repositoryablage
und Ablagemerge nach Pflichtprüfungen. Tatsächliche Motiv-/Parameterfreigabe
in approvals/motif.json; B-r02-Freigabe in approvals/reveal.json.

Erhalten: Kopf mit vollständigen asymmetrischen Hornbögen und Ohren,
Dreiviertelansicht nach links, Schnauze links unten, Augenpositionen, große
Horninnenräume, ruhiger erwachsener Ausdruck, kleiner Kehlabschluss.
Keine Schultern/Körperteile oder Übernahme des alten Ganzkörperrasters.
Freigegeben38×25/40×26/42×28,mono,1 Farbe,contain,Crop[50,28,1504,983],area128/160.
Vier geplante Kandidaten; ausgewählt40×26/160 plus drei nichtmaterielle,
maskengeschützte RP5-Konturkorrekturen. Originalbild und Motiv bleiben bytegleich.
Kein Zusatzrahmen oder motivfremder Pixel. Endabnahme offen; keine Registrierung.
