# 4 · Abnehmen & ins Spiel integrieren

r08 ist content_ready. Gesonderte menschliche Endabnahme bindet nach ZA-1
das unveränderte Originalhandoff, Inventar und Endauswahl candidate-005,
Bundle repairs/round-2, Matrix b3a2d8547bd9106b05f16086f6f432447445dd206ec442f8f8ac3653875c06c4, Logik 80797b72747570b7945ec132afc0efaff1d96c62cb4a8188655785840b8f32c2,
Abschlussbild B-r02 b382978fca16415070b83cf41e5a684ee26ac81e87a94ab4824d0f06b89db280.
Vorlage preview/final-comparison.png und report.md; volle Reparaturdiffansicht
repairs/round-2/view.png. Zwei Runden, drei Konturänderungen, finalfull-line-mono.
Keine zusätzliche manuelle Ableitung/Ausnahme nötig. Endfreigabe außen aufnehmen,
versiegeltes ZIP nicht umschreiben. Erst mit tatsächlicher Endfreigabe/Auftrag
PUZZLE_AUTHORING§§8–9 ausführen; Kategorie saeuger und stabileID erhalten.
