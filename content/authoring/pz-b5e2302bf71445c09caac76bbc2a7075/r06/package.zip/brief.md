# Carabao – neue Abschlussbildauswahl: nur Kopf

Stabile ID pz-b5e2302bf71445c09caac76bbc2a7075, Paket r06, Kategorie saeuger.
Standardauftrag 1 / reveal_review nach PUZZLE_AUTHORING 0.5.0, Dokumentrevision 14.
Der Nutzer möchte wegen unbefriedigender Rasterwirkung eine neue Kopfkomposition
testen. Die neuen Bilder sind eine freie Motivübertragung aus diesem Textauftrag,
keine nachträgliche Rechtfertigung oder Änderung des alten Lösungsrasters.

Nur der Kopf einschließlich vollständiger Ohren und Hörner; eine kleine natürliche
Kehlkontur darf den unteren Abschluss bilden. Keine Schultern, kein Rumpf, Beine,
Schwanz, Zubehör oder Landschaft. Charakteristisch: breites schweres Maul,
natürliche lange Büffelgesichtsform, breite Ohren und seitlich ausladende gebogene
Hörner. Ruhige farbige 2D-Illustration mit klaren Konturen, ausgearbeiteter
Binnenzeichnung und zurückhaltendem Hintergrund. Keine Rastergrafik.

Drei neu erzeugte Einzelbilder: A-r02 frontal, B-r02 Dreiviertel nach links,
C-r02 seitlich betont nach rechts. Namen unterscheiden sie eindeutig von A/B/C-r01.
Die konkrete Auswahl ist offen; erst ihre ausdrückliche Freigabe bindet die
neue Perspektive, Proportionen und wichtigen Negativräume für die Abstraktion.

Gewünscht bleiben ungefähr 40 × offen Zellen, mono. Höhe und konkreter Korridor
werden nach Abschlussbildfreigabe aus der gewählten Kopfkomposition empfohlen.
Das alte 40×24-Körperraster und der alte Crop gelten nicht automatisch weiter.
Die neue Konzentration auf den Kopf bietet mehr relativen Platz für Gesicht und
Horninnenräume; geeignete Zell-Lesbarkeit und Lösbarkeit sind noch nicht geprüft.

Bestehende Freigaben bleiben ausschließlich an ihren alten Dateien gültig.
Für A-r02/B-r02/C-r02 und die noch nicht erzeugte neue Motivvorlage gibt es
keine menschliche Freigabe. Frühere Pakete r01–r05 werden unverändert erhalten.
Keine alte technische Zertifizierung als fehlgeschlagen umetikettieren.
