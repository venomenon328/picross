# Carabao – Kopf: Abschlussbildauswahl r06

ID `pz-b5e2302bf71445c09caac76bbc2a7075` · Revision r06 · Status reveal_review · 2026-10-16T21:23:49.382298+00:00
Regelwerk 0.5.0 / Dokumentrevision 14; gelesener Repository-/Toolcommit `40484d5b59377f1c2830a5e999c4c28eb7ba8d5d`.

Auf Nutzerwunsch Rücksprung zu Standardauftrag 1. Drei neue farbige Kopfporträts
A-r02, B-r02 und C-r02; nur Kopf/Ohren/Hörner, kein Rumpf oder Zubehör.
Frontalansicht betont die ausgewogene Horn-/Gesichtsform, Dreiviertel die
räumliche Schnauze, die rechtsgewandte Ansicht die seitliche Kontur. Vergleich und fünf visuelle
Kriterien je Quelldatei: visual-review.json. Keine Auswahl vorweggenommen.

Gewünscht: ungefähr 40 × offen, mono. Konkrete Maße, Zellzahl, Matrixpalette,
verwendete Farben, logische Schwierigkeit und Lösungszeit sind unbestimmt.
Noch keine neue Motivvorlage oder Matrix. Alte Freigaben gelten nur für die
historischen Dateien; für die neuen Kopfentwürfe sind alle Freigaben offen.
Details zur Nutzungsgrundlage und den drei tatsächlichen Prompts: provenance.json
und prompts.json. Drei Bildaufrufe, keine Korrekturrunde; Menschenzeit unbekannt.

Neue Logik-, Randregel-, Hinweis-, Schwierigkeits-, Herkunftsrekonstruktions-
und Endmatrixprüfungen sind erst für spätere Phasen anwendbar. Kein Import,
Reparaturversuch, ZA-1-inspect, Spielstart oder Build für diese frühe Bildablage.
Keine technische Abwertung der früheren zertifizierten Raster behauptet;
der neue Versuch folgt dem redaktionellen Nutzerwunsch. r01–r05 und alle
Runtime-Inhalte bleiben unverändert. Ablage-/CI-/Mergebelege werden im PR geführt.

Nächster erlaubter Schritt: 2 · Bild freigeben & abstrahieren.
Der Mensch wählt A-r02, B-r02 oder C-r02 und gibt genau diese Dateirevision frei.
Erst danach Konfigurationsvergleich und daraus abgeleitete neue Motivvorlage.
