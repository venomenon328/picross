# Carabao – Abschlussbildauswahl r01

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.5.0 / Dokumentrevision 14.
Nutzer: Tobias. Textmotiv ohne Bildreferenz; Arbeitsweise `free` für die Auswahl.
Kategorie: `saeuger` / Säugetiere gemäß content/categories.json.
Gewünscht: ungefähr 40 Zellen Breite, Höhe offen; monochromes Rätsel.
Das Abschlussbild bleibt immer farbig. Maße sind Wunsch, kein bereits freigegebener Parameterkorridor.

Identitätskern: ein einzelner philippinischer Carabao mit kräftigem langem Rumpf,
breiter Schnauze, seitlich ausladenden gebogenen Hörnern, breiten Ohren,
vier plausiblen Beinen mit gespaltenen Hufen und Schwanzquaste.
Ruhiger warmer heller Hintergrund, keine zusätzliche Szene oder Requisiten.
Kopf, Hörner, Beine und Schwanz bleiben vollständig im Bild.

Drei getrennte farbige Illustrationen: A-r01 nach links stehend mit zum Betrachter
gewandtem Kopf; B-r01 nach rechts in Dreiviertelansicht; C-r01 nach rechts im Schritt.
Die unterschiedliche Kopf-/Hornstellung und die Pose werden erst durch die
spätere konkrete Auswahl verbindlich. Die gewählte Perspektive, Hauptproportionen
und charakteristischen Negativräume sind dann bei der Abstraktion zu bewahren.
Oberflächentextur und Schattierungen dürfen später motivgerecht reduziert werden.

Native ChatGPT-Bildgenerierung, keine externen Bilder oder Referenzassets.
Prompts und tatsächlich exponierte Einstellungen: prompts.json.
Originaldateien sind verlustfreie PNGs und werden unverändert gespeichert.
Keine Motivvorlage, Zellmatrix, Hinweise oder Lösbarkeitszusage in dieser Phase.
