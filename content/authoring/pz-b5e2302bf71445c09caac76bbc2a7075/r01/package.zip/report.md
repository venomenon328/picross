# Carabao – Auftrag 1

ID: `pz-b5e2302bf71445c09caac76bbc2a7075` · Paket `r01` · Status `reveal_review` · 2026-10-16T19:50:23.815847+00:00
Regelwerk 0.5.0 / Dokumentrevision 14; gelesener Repository-/Toolcommit `d419c9b2eedfbd7a05cd6747f327937551be8e7f`.

Drei native farbige Abschlussbilddateien A-r01, B-r01 und C-r01 liegen unter reveal/.
A: stehende breite Ansicht nach links; B: Dreiviertelansicht nach rechts;
C: ruhiger Schritt nach rechts. Alle Varianten werden zur Auswahl erhalten.
Vorschlag: B für stärker sichtbare Kopf-/Hornformen; A für besonders breiten Rumpf;
C für die bewegte Pose. Keine menschliche Auswahl oder Freigabe vorhanden.

Fünf visuelle Kriterien je Datei im getrennten Selbstreview: visual-review.json.
Originalbytes und Nutzungsgrundlage: provenance.json; vollständige Prompts: prompts.json.
Gewünscht: ungefähr 40 × offen, mono. Konkrete Maße, Zellzahl, Matrixpalette,
Farbverwendung, Schwierigkeit und Lösungszeit sind noch nicht bestimmt.
Herkunft der Bilddateien und Hashbindungen sind dokumentiert; die spätere
Ableitungskette zum Raster existiert noch nicht. Keine Import-/Reparaturrunde:
in dieser Auswahlphase noch nicht anwendbar. Logik, Randregel, Hinweise,
Raster-/Abschlussbildkonsistenz und Zieladapterexport sind noch nicht anwendbar.
Spieltests und Spielerbuilds sind für reine Authoringablage nicht erforderlich.
Abschlussbildfreigabe, Motivfreigabe und Endabnahme bleiben ausdrücklich offen.

Nächster erlaubter Schritt: 2 · Bild freigeben & abstrahieren: Mensch wählt und gibt A-r01, B-r01 oder C-r01 ausdrücklich frei; erst danach Konfigurationsvergleich und Motivvorlage.
Repositoryablage und bedingter Ablage-PR-Merge sind beauftragt; der Ablagemerge
ist keine Freigabe und keine Spielintegration. Prüf-/Mergebelege stehen außen im PR.
