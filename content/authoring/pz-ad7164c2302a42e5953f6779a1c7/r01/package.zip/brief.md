# Glas Bier mit Schaumkrone · Abschlussbildauswahl

Standardauftrag 1; Paket r01; Produktions-ID pz-ad7164c2302a42e5953f6779a1c7.

Auftrag: Drei farbige, detaillierte Abschlussbilder nach PUZZLE_AUTHORING 0.4.1, Dokumentrevision 5. Späterer Rätselmodus: monochrom (mono). Rastermaße, Crop und Importparameter bleiben offen. Kategorie: suesses-getraenke (Süßes & Getränke), prägender Hauptgegenstand ist das Getränk.

Ausgangsquelle ist der Motivtext des Nutzers, kein Fremdbild. Arbeitsweise für die Bildauswahl: free; Glasform und Perspektive dürfen zwischen den Vorschlägen variieren. Hauptmotiv: ein einzelnes Glas mit goldenem Bier und klar erkennbarer heller Schaumkrone. Kein Etikett, Text, Logo, Gesicht, Hintergrundmotiv oder zusätzliche Requisite.

Serienstil: warme, ruhige handgezeichnete 2D-Illustration, saubere Konturen, kräftige zusammenhängende Farbflächen, motivgerechte Binnenzeichnung, Glasreflexe, Bläschen und zurückhaltende Schattierung. Alle drei Originaldateien bleiben unverändert erhalten.

Vorgeschlagene Invarianten nach Wahl: aufrechte Glasform, konkrete gewählte Perspektive und Hauptproportionen; Schaumkrone mit organischem oberen Umriss; erkennbare Trennung zwischen Bier, Schaum und Glasboden. Bei B außerdem kurzer Stiel und Fuß; bei C rechter Henkel samt leerem Innenraum und links überhängendem Schaum. Kleine Bläschen, Kondensation und feine Lichtreflexe dürfen bei späterer Abstraktion reduziert werden. Dies ist noch keine menschliche Freigabe.

Befugnis: Repositoryablage nach §6, Commit/Push/Draft-PR; kein Merge. Aktueller Stopp: reveal_review. Nächster Schritt erst nach ausdrücklicher Freigabe einer konkreten Variante: Standardauftrag 2 mit Bindung der Freigabe, Konfigurationsvergleich und gezielter Motivabstraktion.
