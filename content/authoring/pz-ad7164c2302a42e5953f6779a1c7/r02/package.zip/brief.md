# Glas Bier mit Schaumkrone · Motivvorlage

pz-ad7164c2302a42e5953f6779a1c7 · Paket r02 · Status motif_review · Kategorie suesses-getraenke.

Textauftrag und verbindlicher Rätselmodus: monochrom. C-r01 ist ausdrücklich freigegeben; die tatsächliche Erklärung und der Zeitstempel stehen unter approvals/. Die Originalbytes von reveal/C-r01.png (54d053af4c1022dade010581b5b70823f4acc9a406057221ef638fc9f1a1c804) werden aus r01 unverändert übernommen. Herkunft r01: a3fad9647f77af5d3c522063977ee1f629084e13, content/authoring/pz-ad7164c2302a42e5953f6779a1c7/r01/package.zip. Der aktuelle Werkzeug-/Regelwerksstand ist main@f666f87d36a0ea7fa3740202d08706f2215bc303.

MA-r01 ist eine native Bildbearbeitung der gespeicherten C-r01-Datei, Arbeitsweise faithful. Sie erhält Identität, Blickwinkel, Hauptproportionen, Schaumkrone/ linken Schaumüberlauf, Bodenform sowie rechten Henkel und dessen Leerraum. Feinere Glasfacetten, Bläschen, Kondenswasser, Farben und Schattierungen entfallen. Zwei breite weiße Reflexflächen bleiben. Der Boden ist mit dem Körper verbunden; keine neue horizontale Leerlinie.

Vorgeschlagene Konfiguration: 28 × 32 Mono; größere Alternative im Freigabekorridor 35 × 40. Einheitlicher Crop [170,10,1206,1194], Fit exact, area, Weiß als Leer, Schwarz/ink als einzige Vordergrundfarbe; je Maß zunächst Schwellen 128 und 160. Details und Alternativen: configuration.json. Dies sind Vorschläge für die spätere Motivfreigabe, keine bereits erteilte Parameterfreigabe.

Für jedes spätere Raster: alle Invarianten und Negativflächen prüfen. Bei untragfähiger Ausgangsform zuerst Vorlage/Parameter korrigieren. Keine motivfremden Randpixel oder stillen Geometrieänderungen. Keine Lösbarkeitszusage vor vollständigem deduktivem Nachweis.

Aktueller Auftrag endet bei Vorlage, Konfiguration und Dateiübergabe. Autorisiert sind neue Revision, Commit/Push und Fortschreibung von Draft-PR #107; kein Merge. Nächster erlaubter Schritt: Standardauftrag 3 erst mit ausdrücklicher Freigabe der tatsächlichen MA-r01 samt Korridor. Codex-Übergabe: codex-handoff.md.
