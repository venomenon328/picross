# Ho Chi Minh – Produktionsstand r03

ID `pz-023b50b44d1c4698a6e17e65b6ea4337`, Kategorie `menschen-berufe`. Auftrag: Standardauftrag 3 und Repositoryablage samt bedingtem Merge.
A-r02 bleibt bytegleich und menschlich freigegeben. MA-r01 samt exakt vorgeschlagenem Korridor wurde in diesem Auftrag freigegeben; Wortlaut und Dateibindung in `motif-approval.json` und `production-request.json`.
Invarianten und Konfiguration unverändert in `configuration.json`: frontaler Blick und leichtes geschlossenes Lächeln, hohe Stirn, schmales Gesicht, Ohren, helles Seitenhaar, heller schmaler Schnurrbart, langer spitzer Kinnbart, olivgrüne geschlossene Jacke mit Kragen und zentraler Knopfleiste, 3:4-Komposition.
Erlaubt: 30×40, 33×44 oder 36×48, vier feste Vordergrundfarben plus Weiß, area/exact, Vollbildcrop 1086×1448, Alpha128. Alle drei Importe technisch zertifiziert, aber gestalterisch abgelehnt.
Status `blocked`: keine freigabefähige Endauswahl. Keine Endabnahme, kein Export und keine Registrierung. A-r02 bleibt verbindlich; nächster Schritt ist eine neu vorzulegende und freizugebende Motivkorrektur. Die Ablage dieses Fehlversuchs ist beauftragt und von der Inhaltsfreigabe getrennt.
