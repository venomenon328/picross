# Ho Chi Minh – Detailüberarbeitung MA-r02

ID `pz-023b50b44d1c4698a6e17e65b6ea4337`, Paket r04, Kategorie `menschen-berufe`, Phase `motif_review`.
Der Nutzer beauftragt ein neues Raster mit vorlagentreueren Haaren, mehr Gesichts- und Hemddetails und bei Bedarf mehr Farben. Die bisherige Rasterproduktion r03 scheiterte an geschützten Details. Deshalb wurde MA-r02 unmittelbar aus den gespeicherten freigegebenen A-r02-Bytes abgeleitet; A-r02 selbst bleibt unverändert.
Haarführung, Gesicht, Kragen, Knopfleiste, Taschen und Stofffalten sind überarbeitet. MA-r02 und der neue Vier-Ansätze-Korridor sind Vorschläge, noch keine freigegebene Rasterquelle. Empfehlung: 36×48 und vier Vordergrundfarben; Vergleich 33×44 und ursprüngliches/mittleres Konturbraun. Konkrete Werte, Grenzen und Invarianten in configuration.json.
Neue Motivfreigabe gemäß PUZZLE_AUTHORING §2.4 und §4.4 vor Rasterproduktion erforderlich. B-PZ-01/B-PZ-02 bleiben für die alte Revision aktiv; ihre Behebung im neuen Raster muss nachgewiesen werden.
