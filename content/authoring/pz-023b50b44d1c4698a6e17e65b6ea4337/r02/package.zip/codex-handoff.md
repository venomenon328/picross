# Codex-Übergabe · Standardauftrag 3

Status: Vorbereitete Dateiübergabe; Produktionsstart wartet auf menschliche
Freigabe von MA-r01 mit configuration.json. Bevorzugter Weg: Codex gemäß
Standardarbeitsteilung, für deterministische Import-/Proof-/Reparaturschleifen.
Keine Modellverfügbarkeit oder nachträgliche Motivfreigabe behaupten.

Repository venomenon328/picross, Ziel main, Einstieg AGENTS.md und
docs/ai-workflows/PUZZLE_AUTHORING.md. Paket über content/authoring/index.json
für ID pz-023b50b44d1c4698a6e17e65b6ea4337, r02 laden. MA-r01 motifs/MA-r01.png (SHA-256 93f69db43b8d6afbd18a18d07e9a6fdb57a55e8fa7769775c2e23d256f38bc1a),
Reveal A-r02 reveals/A-r02.png (SHA-256 4a192182d637c185d46f4128640200c68c663639e0e30a477363677c1e5eebe1), Freigabe gespeichert.

Nach tatsächlicher Motivfreigabe deren Wortlaut, Akteur, Zeit und Korridor binden.
30 × 40 empfohlen; 33 × 44 und 36 × 48 erlaubt nur bei Annahme des vorgeschlagenen
Korridors. Vier Vordergrundfarben plus Leer; area, exact, Vollbildcrop.
config/design-30x40-proposed.json ist ein gültiger Designentwurf, kein freigegebener Import.
Vier gezielte Rasterhypothesen vorab begründen; Farb-area-Schwellenwertvarianten
sind identisch und dürfen nicht als getrennte Kandidaten gezählt werden.
Wenn ein Motivkonflikt neue Palette/Crop/Identität benötigt, zuerst Rücksprung gemäß Workflow.
Schlanken Produktionsauftrag 3 vollständig bis Endraster, Nachweisen, Schwierigkeit,
Bericht und neuem geprüftem Paket durchführen. Keine Spielregistrierung, kein Merge
für den folgenden Produktions-PR aus der Freigabe des jetzigen Ablage-PRs ableiten.
