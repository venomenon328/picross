# Ho Chi Minh · Abschlussbildauswahl

Auftrag: Standardauftrag 1 gemäß PUZZLE_AUTHORING 0.4.1, Dokumentrevision 8.
Motiv: die historische Person Ho Chi Minh, als Personenporträt interpretiert.
Wunsch: ungefähr 30 Zellen breit × 40 hoch, farbig; Abschlussbild immer farbig.
Kategorie: menschen-berufe (Menschen & Berufe), prägender Hauptgegenstand Person.
Arbeitsweise: free, keine bindende Fremdbildreferenz; freie Komposition bei erhaltener Personenidentität.
Wiedererkennungskern: hohe zurückweichende Stirn, schmale längliche Gesichtszüge,
helle seitliche Haare, schmaler Schnurrbart, langer spitzer heller Kinnbart,
schlichte geschlossene Jacke. Ruhige warme 2D-Illustration mit klaren Konturen,
kräftigen Flächen, ausgearbeiteter Binnenzeichnung und zurückhaltender Schattierung.
Varianten dürfen Blickrichtung, Ausdruck, Jackenfarbe und Armhaltung verändern.
Kein Text, Wasserzeichen, dekorativer Rahmen oder überladener Hintergrund.
Haut-, Bart-, Kontur- und Kleidungsflächen später mit bis zu vier Vordergrundfarben
prüfen; die Rasterpalette ist noch nicht beschlossen. Kein Raster, keine Hinweise,
keine Motivvorlage und kein Lösbarkeits- oder Schwierigkeitsversprechen in dieser Phase.
Natürlicher Torsoanschnitt am unteren Bildrand; Kopf und bei C die Hand enthalten.
Nutzungsgrundlage: native KI-Bilder aus dem Textauftrag, keine Fremdbildbytes.
Die tatsächliche Bildfreigabe ist offen. Keine Freigabe aus dem Generierungsauftrag ableiten.
Repositoryablage §6, Commit/Push und Draft-PR beauftragt; kein Merge oder Spielimport.
