# Ho Chi Minh – MA-r03 nach konkret belegtem Farbmittelungsverlust

ID `pz-023b50b44d1c4698a6e17e65b6ea4337`, Revision r06, Kategorie `menschen-berufe`, Status motif_review.
Die beauftragte neue Rasterproduktion r05 hat vier zertifizierte Matrizen, aber weiterhin einen verlorenen hellen Schnurrbart geliefert. Der dort vorgelegte geänderte Plan wird in eine konkrete neue Motivdatei umgesetzt: zusammenhängende helle Schnurr-/Kinnbartflächen und kräftige Gesichts-/Hemdformen statt weiterer dünner Einzelstriche. Ein zweiter gezielter Bildaufruf gleicht die Haarführung an das unverändert freigegebene A-r02 an.
MA-r03 ist eine neue Datei und noch nicht freigegeben; die tatsächliche MA-r02-Freigabe wird ausschließlich als frühere Freigabe erhalten. Vorgeschlagen bleibt33×44/36×48, zwei Konturpaletten, area/exact, Vollbildcrop, vier Vordergrundfarben plus Leer. Empfehlung36×48 mit mittlerem Braun. Keine neue Matrix oder technische Zertifizierung vor MA-r03-Freigabe.
