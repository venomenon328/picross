# Ankh · Standardauftrag 1

ID `pz-b6f94e528b48444985d0561cb48a5bc7` · r01 · reveal_review · 2026-10-25. Regelwerk 0.5.0 / Dokumentrevision 23, Repository-/Toolstand `79e641543adf61e7a4629d13e07e4774c659cdd1`. Vollständige Dateibindungen in inventory.json; dieser Bericht ist selbst inventarisiert, daher kein zirkulärer Inventarhash im Bericht.

Drei tatsächliche farbige PNG-Einzeldateien: A-r01 klassisches Gold (empfohlen), B-r01 gealterte Bronze, C-r01 Gold/Türkis. Prompts und tatsächliche exponierte Einstellungen separat gespeichert. Keine Bildbearbeitung nach Erzeugung. Prüfbefunde und Papiervergleich in audit/visual-review.json und audit/paper-preview.png.

Wunsch: Breite offen, Höhe ungefähr 15, monochrom (eine Vordergrundfarbe). Tatsächliche Matrixfarben, Rastermaße, Schwierigkeitsgrad, Randregel, Hinweise und Logiknachweise sind noch nicht anwendbar. Es gibt noch keine Motivvorlage oder Rasterproduktion. Kein Import/Reparaturlauf, kein Zieladapterexport und keine Runtime-Registrierung; frühe Bildphase ist kein ZA-1-Eingang.

Alle Bildoptionen bleiben zur Auswahl erhalten. Die Empfehlung ist keine menschliche Freigabe. Abschlussbildfreigabe, Motivfreigabe und Endabnahme offen; kein Probespiel (optional). Keine technischen Blocker bei Paketerzeugung. Nächster erlaubter Schritt: 2 · Bild freigeben & abstrahieren. Erst die konkrete Abschlussbilddatei auswählen und ausdrücklich freigeben.

Nutzungsgrundlage und Motivinvarianten: brief.md. KI-Durchläufe: 3; aktive Menschenzeit nicht erfasst. Ablageprüfung prüft ZIP-Dateimenge, alle SHA-256/Bytezahlen, Regelwerksbindung und bytegleiche Handoffkopie. Pflicht-CI und getrennter Selbstreview werden am tatsächlich gesicherten PR-Head dokumentiert; das Paket behauptet deren zukünftigen Erfolg nicht.
