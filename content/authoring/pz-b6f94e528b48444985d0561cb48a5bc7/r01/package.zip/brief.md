# Ankh · Abschlussbildauswahl

Standardauftrag 1. Motiv: Ankh. Rasterbreite offen, Rasterhöhe ungefähr 15 Zellen; monochrom mit genau einer Vordergrundfarbe. Das Abschlussbild bleibt farbig.

Freie Motivübertragung (`free`) aus dem Textauftrag, ohne Fremdreferenz. Drei aufrechte frontale Darstellungen eines einzelnen Ankh. Zu bewahren: geschlossene hohe Schlaufe mit echtem offenen Innenraum, seitlich ausladender Querbalken, zusammenhängender langer Schaft; vollständige unbeschnittene Silhouette. Keine fremden Symbole, Rahmen oder Schrift. Warm gezeichnete 2D-Oberflächen und zurückhaltende Schattierung; echter transparenter Außenraum und Schlaufeninnenraum.

Kategorie `mythen-fantasie`: der prägende Hauptgegenstand ist das kulturell/religiöse Symbol. Die Amulettgestaltung ist keine Umdeutung zum Bekleidungsgegenstand. Keine neue Kategorie.

Breite, konkrete Abstraktion und Parameterkorridor erst nach tatsächlicher Bildauswahl. Keine Motivvorlage, Matrix, Hinweise, Lösbarkeitsbehauptung oder Schwierigkeitszahl in dieser Phase.

Herkunft: neue KI-Illustrationen über das eingebaute Bildwerkzeug image_gen, aus eigenen Textprompts im beauftragten Produktionskontext. Keine fremden Bildassets übernommen; keine direkte Modell-API. Nutzungsgrundlage: vom Nutzer beauftragte KI-Erzeugung zur Verwendung im Picross-Projekt; keine Exklusivität oder rechtliche Schutzfähigkeit behauptet.

Befugnis: Repositoryablage nach §6 samt Commit/Push/PR und Ablagemerge nach erfolgreichen Pflichtprüfungen ausdrücklich beauftragt. Menschliche Bild-, Motiv- und Endabnahme stehen aus.
