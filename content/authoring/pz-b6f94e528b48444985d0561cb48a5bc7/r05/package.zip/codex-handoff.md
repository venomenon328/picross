# Nächster Auftrag: 4 · Abnehmen & ins Spiel integrieren

r05 ist content_ready. Tatsächliche Freigaben für A-r01 und die neue Pixelvorlage MA-r02 sind gebunden. Aktueller Produktionsweg ist ein regulärer frischer RP-3-Import aus der bereits angenommenen MA-r02; die vorherige manuelle Entstehung bleibt ausschließlich Herkunftsbeleg. In r05 gibt es keine manuellen Edits nach dem Import und keine manuelle Adapterautorisierung zu erfinden.

Zur Endabnahme final/acceptance.png und report.md vorlegen. Original-ZIP/Handoff/Inventar danach nicht ändern. Die äußere end-approval-template.json enthält die endgültigen technischen Bindungen, aber null für Akteur/Zeit/Erklärung und ist keine menschliche Freigabe. Nach tatsächlicher Endabnahme und Integrationsauftrag nach PUZZLE_AUTHORING §§8–9 vorgehen.

analysis/checked.json und vollständiges Bundle aus r04 bleiben bytegleich, Quelle/ID/Mono/Matrix/Logik/Methodenfreeze stimmen. Nach echtem Export ausdrücklich rebind an die tatsächlich geschriebenen Definitionsbytes ausführen; keine erneute Analyse unveränderter Logik. Aktuelle ZIP-Inspektion und ihr Hash stehen im äußeren Record. Reine Ablage ist weder Spielregistrierung noch Produktionscleanup.
