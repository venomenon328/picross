# Ankh · Standardauftrag 2

ID pz-b6f94e528b48444985d0561cb48a5bc7 · r02 · motif_review · 2026-10-25. Regelwerk 0.5.0, Dokumentrevision 23. Quell-/Toolcommit 96c6795cdbd7143b42d0c9a51ce460c0895af374. Originalinventarhash wird in handoff.json und äußerem record.json geführt, ohne Selbstreferenz dieses inventarisierten Berichts.

A-r01 ist tatsächlich vom Nutzer freigegeben; Beleg approvals/reveal-A-r01.json, unveränderte Quelldatei und SHA-256 ae6a6719f21111c623a32130bd2e31ed44a61343ab95c90bc73052d64c336360. Aus genau diesen gespeicherten Bytes ist die separate Motivvorlage MA-r01 entstanden: SHA-256 3873e7b3732f3379de3e3f1038e5668ba86df90c2fdc9958b4a16063b4090368. Ihre menschliche Freigabe und die Bestätigung des Parameterkorridors stehen aus.

Empfehlung 9×15 Mono mit einer Vordergrundfarbe (Wunsch exakt eins ohne Leer), Vergleich 10×15 und 11×17 in configuration.json. Motivinvarianten, tatsächliche Detailverluste und Sichtprüfung: brief.md, decisions.json und audit/visual-review.json; A/MA in audit/comparison.png groß/klein nebeneinander. Gold-/Materialdetails entfernt; Band kräftiger, Kontur und Fuß konsolidiert. Keine zusätzliche Binnenzeichnung.

Keine Matrix, Hinweise, Importe, Solver-/Proof-/Randregel-/Schwierigkeitsanalyse in diesem Auftrag. Verwendete Matrixfarben daher unbekannt; keine Lösbarkeit oder Stufe behauptet. Keine Reparaturen: Produktion noch nicht begonnen. Keine Zielregistrierung/ZA-1-Inspektion: frühe Bildphase ist noch kein Adaptereingang. Probespiel nicht durchgeführt, optional. Keine technischen Blocker; regulärer Haltepunkt ist die ausdrückliche Motivfreigabe.

Herkunft/Nutzungsgrundlage in provenance.json; 1 nativer Edit dieser Phase, insgesamt 4 Bildaufrufe, Menschenzeit nicht erfasst. Originalbilddateien und r01 unverändert. Ungewählte B/C nur im genau referenzierten Vorgänger, kein ZIP im ZIP. Codex-Übergabe: codex-handoff.md. Pflicht-CI und getrennter Selbstreview werden außen im PR an den tatsächlichen Ablagehead gebunden; sie sind kein im Voraus behaupteter Paketerfolg.
