# Codex-Übergabe · nächster Auftrag nach menschlicher Motivfreigabe

Paket: content/authoring/pz-b6f94e528b48444985d0561cb48a5bc7/r02/package.zip · r02.
Regelwerks-/Quellstand: main / 96c6795cdbd7143b42d0c9a51ce460c0895af374; die spätere Repository-Sicherung im äußeren Übergabe-/PR-Stand nachlesen.

Erst fortsetzen, wenn der Nutzer MA-r01 und den in configuration.json vorgeschlagenen Parameterkorridor ausdrücklich freigibt. Keine Freigabe aus diesem Übergabedokument ableiten. Die Abschlussbildfreigabe A-r01 ist bereits tatsächlich erteilt und dateigebunden; sie nicht erneut anfordern.

Danach Standardauftrag 3 gemäß aktueller AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md ausführen. Über Arbeitsindex laden; ZIP-/Handoff-/Inventar-/Quell- und Bildbindungen prüfen. MA-r01: motifs/MA-r01.png, SHA-256 3873e7b3732f3379de3e3f1038e5668ba86df90c2fdc9958b4a16063b4090368; unverändertes Reveal A-r01: reveals/A-r01.png, SHA-256 ae6a6719f21111c623a32130bd2e31ed44a61343ab95c90bc73052d64c336360.

Empfehlung 9×15 Mono, genau eine Vordergrundfarbe; erlaubte vorgeschlagene Alternativen 10×15 und 11×17. Vollständige Crop-/Fit-/Alpha-/Schwellen- und Motivgrenzen in configuration.json. Eigene Designs je Größe, vier gezielte Kandidaten gemäß suggested_first_four; identische Matrizen erkennen und begründet ersetzen, nicht mehrfach zählen. Keine unbeschlossene Streckung oder neue Farbe.

Motiv schützen: Schlaufe sichtbar offen, Körper verbunden, Querarme und ausgestellter Fuß; keine künstlichen Ankerpixel. Produktionsprüfungen/Profilwahl, gegebenenfalls begrenzte Reparatur und aktuelle externe SD-0.3-Analyse gemäß geltendem Workflow ausführen. Bei nicht lösbarem Kandidaten keine Scheinerfolge, keine Bildänderung des Reveals. Tatsächliches Endraster samt Vergleich und geprüftem Paket zur redaktionellen Endabnahme vorlegen. Keine Spielintegration vor Auftrag 4. Keine rätselspezifischen Unit-Tests, keine Werkzeugänderung oder Bestands-Replays.

Repositoryablage ist beauftragt; zugehörigen Ablage-PR nach erfolgreichen Pflichtchecks mergen. Menschliche Motiv-/Parameterfreigabe bleibt Voraussetzung vor Produktionsbeginn; Endabnahme separat.
