# Ankh · Abstraktion nach freigegebenem A-r01

Ausgangspunkt ist ausschließlich die unveränderte farbige Abschlussbilddatei A-r01, SHA-256 ae6a6719f21111c623a32130bd2e31ed44a61343ab95c90bc73052d64c336360. Tatsächliche Freigabe in approvals/reveal-A-r01.json und evidence/user-request.md.

Ziel: monochromes Rätsel, genau eine Vordergrundfarbe ohne EMPTY. Breite offen, Höhe ungefähr 15. Empfehlung 9×15; Alternativen 10×15 und 11×17 sowie präziser vorgeschlagener Parameterkorridor in configuration.json. Noch keine Motiv-/Parameterfreigabe.

MA-r01 ist eine native Bildbearbeitung dieser gespeicherten Abschlussbildbytes. Frontansicht, tropfenförmige Schlaufe, offener Innenraum, breite leicht hochgezogene Arme und ausgestellter Fuß bleiben erkennbar. Entfernt: Goldfarben, Gravurrahmen, Kratzer, Glanz und Materialschattierung. Band und Außenkontur werden für die kleine Größe konsolidiert; die Schlaufenwand ist sichtbar kräftiger, der Fuß ruhiger/flächiger. Kein Raster wurde vorgezeichnet oder importiert. Diese konkrete Formänderung wird mit MA-r01 zur ausdrücklichen Motivfreigabe vorgelegt.

Kategorie mythen-fantasie bleibt unverändert. Die bestätigte A-r01-Datei bleibt das farbige Abschlussbild; sie wird nicht ersetzt. B/C werden nur über die vorherige gesicherte Revision referenziert.

Nächster Haltepunkt: MA-r01 samt configuration.json und Invarianten ausdrücklich freigeben. Erst danach Standardauftrag 3 mit Produktionsprüfungen und Endabnahmevorlage. Auftrag 2 erlaubt keinen vorgezogenen Rasterlauf.
