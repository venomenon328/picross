# Nächster Auftrag: 4 · Abnehmen & ins Spiel integrieren

Aktuellen Repositoryindex und äußeren Record r03 laden; ZIP/Handoff/Inventar prüfen. Der aktuelle Paketstand ist content_ready. Endkandidat imports/9x15/area-160, echte Ansicht final/acceptance.png, Matrix final/matrix.json; Details in report.md. Beide menschlichen Bildfreigaben liegen tatsächlich vor. Die menschliche Endabnahme ist offen.

Erst nach tatsächlicher Endabnahme diese separat an Originalhandoff, Inventar und Auswahl binden; das versiegelte ZIP nicht umschreiben. Die äußere end-approval-template.json enthält nur die vorbereiteten Bindungen und null für noch nicht erklärte menschliche Felder; sie ist keine Freigabe. Export/Registrierung nur im anschließend erteilten Auftrag gemäß PUZZLE_AUTHORING §§8–9. Prüfung des Pakets und Referenzen aus dem aktuellen äußeren Record verwenden.

analysis/checked.json ist vollständig geprüft, Methode 0.3, Mono, L3/medium. Nach dem echten Export per rebind an identische Matrix/Logik und tatsächliche Definitionsbytes binden; keine erneute Routineanalyse. difficulty.json ist separat die verlangte 0.1-Begleitform. Kein Spieltest/Build, kein neues Bestandsreplay. Reine Ablage dieses Pakets ist keine Registrierung oder Endabnahme.
