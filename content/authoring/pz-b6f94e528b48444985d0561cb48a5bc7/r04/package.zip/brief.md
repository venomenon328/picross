# Ankh · manuelle Rasterkorrektur r04

Der Nutzer verlangt einen 2 Zellen breiten Schaft mit symmetrischer Verbreiterung auf 4 Zellen und weiterhin symmetrischer Schlaufe. Tatsächlicher Auftrag in evidence/correction-request.md. Umsetzung: Mittelspalte 5 des gesicherten r03-Rasters einmal als neue Spalte 6 einfügen. Alle bisherigen Zellen bleiben in ihrer Reihenfolge erhalten; Breite 9→10, Höhe 15. Keine weitere Formänderung, keine Suche oder Logikanker.

Die neue diskrete Pixelvorlage motifs/MA-r02.png ist offen eine manuelle Ableitung. Der RP-3-Lauf importiert genau diese Pixeldatei, nicht die frühere Illustration MA-r01. Die neue konkrete Pixelvorlage ist noch nicht menschlich angenommen; alte MA-r01-Freigaben werden nicht auf MA-r02 übertragen. A-r01 und seine tatsächliche Bildfreigabe bleiben unverändert.
