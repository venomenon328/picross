# Silbermöwe · Standardauftrag 3 · lokale Prüfung (kein offizielles Content-ready-Paket)

**Bild-/Motivfreigabe:** A-r01 und MA-r01, jeweils exakte SHA-256 und menschliche Erklärung in `approvals/`.
**Korridor:** 40–44 × 30–34, nur Mono; bevorzugt 42×32.
**Ausgewählt:** `area-42x32-selected` · 42×32 · 401 Tintenfelder · 943 leere Felder · 29.84 % Belegung.
**Nachweis lokal:** vollständiger Linienfixpunkt ohne Suchraten; 1344 von 1344 Zellentscheidungen jeweils gegengeprüft durch getrennten NFA-Checker aus unbekanntem Start (Datei `preflight/area-42x32-selected/independent-verification.json`). Quellbezug, Design, Matrix, Hinweise und Proofspur dateigebunden.
**Explizite Grenze:** Diese lokalen Prüfprogramme sind NICHT die tatsächlich aus `venomenon328/picross` ausgeführten RP-3-Import-/Proof-/ZA-1- oder SD-0.3-Tools und behaupten nicht deren Zertifizierung. Kein endabnahmebereites `content_ready`; kein Edit in der Runtime-Registry.
**Motiv:** Profil, Kopf-Brustlinie, Flügel, beide Beine und Fels bleiben erhalten. Die Auflösung zeichnet Auge und winzige Flecken nicht zuverlässig eigenständig; das bleibt ein sichtbarer redaktioneller Befund, kein per Pixelzufall versteckter Detailbeweis.
**Offene Pflichtgates:** Native Import-/Replay-Zertifizierung; Difficulty 0.3; vollständiges standardkonformes Content-Handoff, technische Qualitätsprüfung; menschliche finale redaktionelle Annahme; Repositorytransport/CI. Falsche Erfüllungsangaben sind ausgeschlossen.
**Status:** raster_review / technisch vorläufig; keine Endabnahmefreigabe.
