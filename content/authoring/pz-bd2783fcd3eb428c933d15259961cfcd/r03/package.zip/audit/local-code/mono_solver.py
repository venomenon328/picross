"""Temporary independent offline line-propagation exploration, not RP-3 certificate."""
from functools import lru_cache
from hashlib import sha256
import json, time

E,F,B=1,2,3

def clues_of(bits):
    out=[];run=0
    for v in list(bits)+[0]:
        if v:run+=1
        elif run:out.append(run);run=0
    return tuple(out)

def line_support(clues,domains):
    N=len(domains);K=len(clues)
    canE=[(x&E)!=0 for x in domains];canF=[(x&F)!=0 for x in domains]
    notE=[0];notF=[0]
    for x,y in zip(canE,canF):notE.append(notE[-1]+(not x));notF.append(notF[-1]+(not y))
    def evalid(a,b):return notE[a]==notE[b]
    def fvalid(a,b):return notF[a]==notF[b]
    @lru_cache(None)
    def viable(i,pos):
        if i==K:return evalid(pos,N)
        length=clues[i]
        endmax=N-length
        for st in range(pos,endmax+1):
            en=st+length
            nextpos=en+1 if i+1<K else en
            if nextpos>N:break
            if evalid(pos,st) and fvalid(st,en) and (i+1==K or canE[en]) and viable(i+1,nextpos):return True
            if not evalid(pos,st+1):break
        return False
    if not viable(0,0):return None
    support=[0]*N;vis=set()
    def trace(i,pos):
        if (i,pos) in vis:return
        vis.add((i,pos))
        if i==K:
            for q in range(pos,N):support[q]|=E
            return
        length=clues[i]
        for st in range(pos,N-length+1):
            en=st+length;nextpos=en+1 if i+1<K else en
            if nextpos>N:break
            if evalid(pos,st) and fvalid(st,en) and (i+1==K or canE[en]) and viable(i+1,nextpos):
                for q in range(pos,st):support[q]|=E
                for q in range(st,en):support[q]|=F
                if i+1<K:support[en]|=E
                trace(i+1,nextpos)
            if not evalid(pos,st+1):break
    trace(0,0)
    assert all(x and x&y for x,y in zip(support,domains))
    return support

def solve(matrix,max_lines=100000,max_seconds=30):
    h=len(matrix);w=len(matrix[0]);assert all(len(r)==w for r in matrix)
    rh=[clues_of(r) for r in matrix];ch=[clues_of(matrix[y][x] for y in range(h)) for x in range(w)]
    state=[[B]*w for _ in range(h)];steps=[];checks=0
    started=time.monotonic()
    for it in range(1,max_lines+1):
        if time.monotonic()-started>max_seconds:return {'status':'aborted','why':'time','checks':checks}
        changes=0
        for axis,groups,n in [('row',rh,h),('col',ch,w)]:
            for idx in range(n):
                checks+=1
                ds=state[idx][:] if axis=='row' else [state[y][idx] for y in range(h)]
                sup=line_support(groups[idx],ds)
                if sup is None:return {'status':'contradiction','axis':axis,'idx':idx,'checks':checks}
                todo=[(i,d,sup[i]) for i,d in enumerate(ds) if d!=sup[i]]
                if todo:
                    for i,old,new in todo:
                        if axis=='row':state[idx][i]=new
                        else:state[i][idx]=new
                    steps.append({'axis':axis,'index':idx,'changes':[[i,old,new] for i,old,new in todo]});changes+=len(todo)
        if not changes:break
    unknown=sum(v==B for row in state for v in row)
    match=all(state[y][x]==(F if matrix[y][x] else E) for y in range(h) for x in range(w))
    result={'status':'solved' if unknown==0 and match else ('mismatch' if unknown==0 else 'stalled'), 'unknown':unknown,'checks':checks,'rounds':it,'steps':steps,'matrix_exact':match,'row_clues':rh,'col_clues':ch,'final_domains':state,'seconds':round(time.monotonic()-started,3)}
    return result

if __name__=='__main__':
    from pathlib import Path
    import sys
    p=Path(sys.argv[1]);obj=json.loads(p.read_text());a=solve(obj['matrix'])
    print(json.dumps({k:v for k,v in a.items() if k not in ('steps','row_clues','col_clues','final_domains')},ensure_ascii=False))
    if len(sys.argv)>2:Path(sys.argv[2]).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
