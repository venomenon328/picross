"""Independent finite-state proof verification for local feasibility (not repository verifier)."""
import json,sys,hashlib,time
from pathlib import Path
E,F,U=1,2,3

def states_after(domains,clues):
    """NFA over cells; no use of the generator's interval line-support routine."""
    m=len(clues)
    states={(0,0,0)} # (completed_run_count, remaining_active_cells, mandatory_gap)
    for mask in domains:
        nextstates=set()
        for completed,remain,gap in states:
            if remain:
                if mask & F:
                    if remain==1:
                        k=completed+1; nextstates.add((k,0,1 if k<m else 0))
                    else:nextstates.add((completed,remain-1,0))
                continue
            if gap:
                if mask&E:nextstates.add((completed,0,0))
                continue
            if mask&E:nextstates.add((completed,0,0))
            if mask&F and completed<m:
                length=clues[completed]
                if length==1:
                    k=completed+1;nextstates.add((k,0,1 if k<m else 0))
                else:nextstates.add((completed,length-1,0))
        states=nextstates
        if not states:return set()
    return states

def possible(domains,clues):
    return (len(clues),0,0) in states_after(domains,clues)

def verification(matrix,trace):
    H=len(matrix);W=len(matrix[0]);assert all(len(r)==W for r in matrix)
    state=[[U for x in range(W)] for y in range(H)]
    def cl(line):
        ans=[];length=0
        for b in list(line)+[0]:
            if b:length+=1
            elif length:ans.append(length);length=0
        return tuple(ans)
    rows=[cl(row) for row in matrix]
    cols=[cl(matrix[y][x] for y in range(H)) for x in range(W)]
    assert len(trace['row_clues'])==H and len(trace['col_clues'])==W
    assert all(tuple(v)==rows[i] for i,v in enumerate(trace['row_clues']))
    assert all(tuple(v)==cols[i] for i,v in enumerate(trace['col_clues']))
    count=0
    for stepnum,step in enumerate(trace['steps']):
        axis=step['axis'];idx=step['index']; assert axis in ('row','col')
        dims,clues=(W,rows[idx]) if axis=='row' else (H,cols[idx])
        line=state[idx][:] if axis=='row' else [state[y][idx] for y in range(H)]
        assert possible(line,clues),('line unsatisfiable',stepnum,axis,idx)
        for pos,old,new in step['changes']:
            assert pos in range(dims) and old==U and new in (E,F),('invalid mutation',stepnum,pos,old,new)
            assert line[pos]==old,('not current state',stepnum,pos,old,line[pos])
            wrong=line[:]; wrong[pos]=F if new==E else E
            assert not possible(wrong,clues),('unjustified inference',stepnum,axis,idx,pos)
        for pos,old,new in step['changes']:
            if axis=='row':state[idx][pos]=new
            else:state[pos][idx]=new
            count+=1
    expected=[[F if v else E for v in row] for row in matrix]
    assert state==expected and trace['status']=='solved' and trace['matrix_exact']
    # Validate the clues against exactly the intended matrix again
    assert all(possible([F if x else E for x in row],c) for row,c in zip(matrix,rows))
    assert all(possible([F if matrix[y][x] else E for y in range(H)],c) for x,c in enumerate(cols))
    return {'format':'silbermoewe-independent-fsa-v1','status':'verified','from_unknown':True,'no_guessing':True,'correct_end_matrix':True,'unique_by_complete_deduction':True,'width':W,'height':H,'checked_inferences':count,'checked_steps':len(trace['steps']),'verifier':'independent NFA state reachability, opposite-cell impossibility, not repository implementation'}

if __name__=='__main__':
    mx=json.loads(Path(sys.argv[1]).read_text())['matrix'];trace=json.loads(Path(sys.argv[2]).read_text());r=verification(mx,trace);print(json.dumps(r,indent=2))
