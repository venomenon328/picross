# Silbermöwe · Endabnahmevorlage (technisch vorläufig, nicht abnahmebereit)

## Bindung

- Puzzle-ID: `pz-bd2783fcd3eb428c933d15259961cfcd` · Arbeitsrevision `r03` · Regelwerk `0.5.0`, Dokumentrevision 23, `main@026b5568643e1bd80281720dddd87b682fc7d4df`.
- Abschlussbild: `reveals/A-r01.png` – **freigegeben**, SHA-256 `03211f56cc6070575b4c9be740eb739a039891664f00ed711c74a2ffad6d68c0`.
- Monochrome Motivvorlage: `motifs/MA-r01.png` – **freigegeben**, SHA-256 `3510c97274f4cb2d2025d1c52e95239b61a12ccd2e6a90d3d97f9ab9c3a112d0`.
- Gestattete Maße: Breite 40–44, Höhe 30–34, Seitenverhältnis 1,25–1,4; genau eine Vordergrundfarbe.
- Ausgewählter vorläufiger Kandidat: `area-42x32-selected` – **42 × 32**, Ink #272524, weißer/empty Hintergrund, 401/1344 gefüllte Zellen (29,84 %), 943 Leer.
- Source: genehmigte MA-r01-Bytes, crop 145,18,1447,1010; Pillow BOX; Alpha 1; Schwelle 241.

## Sichtprüfung (KI-Befund)

| Kriterium | Status / Begründung |
| --- | --- |
| Erkennbarkeit | Bedingt: Silhouette als Möwe erkennbar, Detailrückgewinn durch farbiges Reveal |
| Silhouette & Proportionen | Erfüllt: rechter Profilvogel, gefalteter Flügel, zwei Beine, Fels |
| Negative Räume | Erfüllt: helle Brust als ausgesparte Fläche, Tail-/Flügelspiegel in vereinfacht |
| Auge & Schnabel | Korrektur nötig / Abnahmerisiko: Auge in 42×32 nicht als eigenständiges Innenmerkmal lesbar; gebogener Schnabel grob |
| Palette | Erfüllt: exakt eine belegte Vordergrundfarbe |
| Randregel | Erfüllt: links, oben, unten gefüllt; rechts leer, trotzdem zulässig |
| Rasterdichte | 29,84 %: unauffällig; 1 vierfach isoliertes Tintenfeld als Prüfanlass |
| Unnötige Außenbereiche | 4 rechte äußere Spalten leer; nichts allein für Kantenregel hinzugefügt |
| Serienästhetik | Abnahmerisiko: Farbabschlussbild im naturkundlich-realistischen Stil |

## Technik und unabhängige Prüfung

- **Lokal PASS**: vollständige Deduktion vom unbekannten Start, 229 Schritte; 1.344/1.344 Zellwerte gegengeprüft per unabhängigem endlichem Zustandsautomaten (jede erzwungene Zuordnung gegen den Gegenwert geprüft).
- **Lokal PASS**: deterministische Hinweise aus exakt gespeicherter Matrix; valide Vorlagenmaße, tatsächliche Farbzahl, Randregel, exakte unveränderte SHA-256 der freigegebenen Dateien.
- **Offen**: tatsächlicher RP-3 `import-image`-Lauf auf gepinntem Toolstand, unabhängiger Projektverifier und Original-/Proof-Replay. Eigenimplementierte Vorprüfung ersetzt das nicht.
- **Offen**: SD-Methode `picross-difficulty-0.3`, geprüfte Stufe L1–L5 und Belege. Noch keine belastbare Spielzeit geschätzt.
- **Nicht durchgeführt, auch nicht nötig**: menschliches Probespiel, native Spieler-/PCK-/Chromium-Checks je Rätsel.

## Finale Gate-Tabelle

| Freigabe / Gate | Stand |
| --- | --- |
| Menschliche Abschlussbildfreigabe | PASS |
| Menschliche Motiv-/Parameterfreigabe | PASS |
| Herkunft / Standardimport | BLOCKIERT: native Projektprüfung nicht vorhanden |
| Deduktions-/Eindeutigkeitsnachweis | Lokaler zusätzlicher PASS, **Projektzertifikat offen** |
| Redaktionelle Raster-/Motivkonsistenz | **Offen**, Auge kann in kleinster Ansicht problematisch sein |
| Schwierigkeit 0.3 | OFFEN |
| Endabnahme durch Eigentümer | OFFEN – aus dieser Vorlage keine automatische Freigabe |
| `content_ready`, Katalogexport, Registrierung | NICHT ERREICHT |
| Repositoryablage, CI, Merge | NICHT ERREICHT: Binärtransport erforderlich |

**Nächste erlaubte Aktion:** Native RP-3-/ZA-1-/SD-Prüfstrecke im Repositorycheckout ausführen und die vier originalen Kandidaten bzw. den qualifizierten Endkandidaten mit tatsächlichen Source-/Proofdateien binden. Erst nach allen Inhaltsgates eine echte Endabnahmevorlage im `content_ready`-Status anbieten. Ohne Eigentümer-Endfreigabe keine Spielintegration und keine Freigabe fingieren.
