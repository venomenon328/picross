# Rätselbrief · Silbermöwe (Larus argentatus)

- Auftrag: Standardauftrag 1 (Abschlussbildauswahl), ohne vorhandene Benutzerbildvorlage.
- Rätselmodus: monochrom (1 Vordergrundfarbe plus Leer); **Abschlussbild bleibt farbig**.
- Maße: offen; keine feste Größe zugesagt. Reguläres späteres Raster höchstens 50 × 50.
- Kategorie: `voegel` (Vögel), aus dem aktuellen Katalogsystem.
- Bildmotiv: adulte Silbermöwe mit hellem Kopf/Brust, lichtgrauem Rücken/Schwingen, schwarzen Spitzen mit weißen Flecken, rosafarbenen Füßen, gelbem Schnabel und rotem Gonysfleck.
- Gestaltung: bildliche Ausarbeitung ohne Raster/Nonogramm, echte RGBA-Transparenz; weiße Motivfedern erhalten.
- Ursprung: neues KI-generiertes Bild, keine vom Benutzer übermittelte Vorlage. Zoologische Merkmale öffentlich gegengeprüft (RSPB; keine Fotoübernahme).
- Bildrechte/Nutzungsgrundlage: mittels OpenAI-Bildgenerierung erstellt, KI-Herkunft dokumentiert; kein fremdes Bildasset kopiert.
- Nachfolgende Grenzen: Bildfreigabe anhand konkreter SHA, danach separate daraus abgeleitete Motivvorlage und erneute Freigabe. Noch keine Raster-/Logikproduktion, Bewertung, Registrierung oder Endabnahme.

Hinweis: Variante B und C sind transparente Kompositionsbearbeitungen der **gleichen** nativen Bildgenerierung A. Sie sind keine eigenständigen nativen Neugenerierungen und unterschieden sich nicht durch frei erfundene neue Posen. Das ist eine Einschränkung der üblichen Variantenbreite.

## Fortschreibung r02 (22.10.2026)

Das originale farbige PNG `reveals/A-r01.png` ist ausdrücklich vom Eigentümer per „A-r01“ freigegeben. Die neue vereinfachte Datei `motifs/MA-r01.png` wurde ausschließlich aus diesen Bildbytes abgeleitet. Der Parameterkorridor ist vorgeschlagen und die separate Motivfreigabe steht aus. Keine Raster-/Solver-/Spielintegration in dieser Revision.
