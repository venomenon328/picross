# Pentagramm · Standardauftrag3 · blockierter Prüfstand

pz-1e9cdac1f83a49d5982f93ded09e58de · r04 · Basis/Toolcommit ee9d92164cf9ba0125c13fa98846e1af86ecf77a · Kategorie mythen-fantasie.
Tatsächliche Motivfreigabe MA-r02 und beide zulässigen Maße sind in approvals/motif-MA-r02.json protokolliert; Erklärung unter approvals/production-instruction.md. Keine Endabnahme liegt vor.

Geschützt: frontaler kreisförmiger Reif, fünf gekreuzte Stege, einzelne untere/two obere Spitzen, Verbindungen aller fünf Spitzen zum Reif, zentrales Fünfeck und fünf Dreiecksöffnungen sowie große Negativflächen. Bevorzugt20×20, alternativ22×22; mono, genau ink ohne Leer; area/exact; Crop[32,33,1216,1217]. Original B-r02 und MA-r02 bleiben bytegleich.

Vier vorgeschlagene Erstkandidaten und zwei gezielte dünnere Kandidaten sind geprüft. Alle sechs unterschiedlich, alle Randregel und Farbzahl1. Vollständige Linienlogik stagniert bei allen; Paarprofil löst nur22×22/160 vollständig. Diese Fassung wird wegen verlorener unterer Dreiecksöffnung verworfen. Zwei gezielte RP-5-Runden (Ringglättung20×20, Wiederöffnung22×22) sind unabhängig replayt, ohne geeigneten Fund. Ein Budgetabbruch vor dem ersten Edit wird separat erhalten.

Dieser Stand ist blocked, kein content_ready und keine Endabnahmevorlage. Neuer gestalterischer Ansatz mit erneuter konkreter Motivfreigabe bzw.erweiterter Größenentscheidung nötig. Repositoryablage und bedingter Ablagemerge sind beauftragt; kein Spiel-/Registry-/Exportauftrag vor Endabnahme.
