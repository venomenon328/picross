# Pentagramm · Auswahlbericht

pz-1e9cdac1f83a49d5982f93ded09e58de · r01 · reveal_review · 2026-10-24 · Authoring 0.5.0 / Dokumentrevision 23 · Toolcommit 49f99cdad933d4ba8f802ad0595e54c538819c9e.
Inventarbindung: inventory.json und dessen SHA-256 im handoff.json (kein selbstreferenzieller Hash).

| Variante | Ergebnis | Abstraktionshinweis |
| --- | --- | --- |
| A-r01 | Kupferstern ohne Kreis | Empfehlung; der Stern erhält bei ungefähr 20 Zellen Höhe den meisten Raum. |
| B-r01 | Violettes Holz im Walnussreif | Kräftiger Materialkontrast; Kreis und Zwischenräume müssen später in Mono zusammen funktionieren. |
| C-r01 | Patiniertes Messing im Metallreif | Aufwendigeres Abschlussbild; Gravuren und Patina werden in Mono weitgehend entfallen. |

Alle drei Original-PNGs sind 1254×1254 RGBA. Volldekodierung und Alphakanal einschließlich transparenter Mitte geprüft. Große Ansicht und 140-px-Kataloggröße auf dem tatsächlichen Buchpapier geprüft: Außenflächen und Aussparungen transparent, klare Konturen, keine störenden Matten. Die fünf visuellen Pflichtkriterien sind je Variante mit Urteil in decisions.json dokumentiert; technische Bildwerte in image-checks.json.

Abschlussbildauswahl/-freigabe: offen. Motivvorlage/-freigabe und Endabnahme: offen. Rastermaße: Breite offen, Höhe ungefähr 20; Modus mono, eine Vordergrundfarbe plus Leer; keine Matrix vorhanden, tatsächlich verwendete Farben daher unbekannt. Logik, Hinweise, Randregel, unabhängiger Proof, Schwierigkeit und Export sind noch nicht anwendbar. Kein Import und keine Reparatur, da dies Auftrag 1 ist. Lösungszeit nicht geschätzt; Menschenzeit nicht erfasst; drei native Bildaufrufe.

Herkunft: eigenständig nativ erzeugte Bilder ohne externe Referenzen, Originalbytes erhalten, Nutzungsgrundlage in generation.json. Paketprüfung erfolgt auf dem geschriebenen ZIP: vollständige Dateimenge, sichere Pfade, Größen, SHA-256 und bytegleiche Handoffkopie. Kein ZA-1-inspect, Solverlauf, Spieltest oder Build für diese frühe Bildphase. CI-Pfad-/Modusprüfung und ci-required werden im Ablage-PR an den finalen Head gebunden.

Nächster Schritt: 2 · Bild freigeben & abstrahieren. Der Mensch gibt genau A-r01, B-r01 oder C-r01 aus diesem Paket frei; erst danach wird daraus eine monochrome Motivvorlage samt Konfiguration abgeleitet. Die Empfehlung ist keine Freigabe.
