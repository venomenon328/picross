# Endabnahmevorlage · Pentagramm r06

Zur Freigabe steht genau der Direktimport imports/a96 · area-160 aus der freigegebenen MA-r03:22×22, mono, eine Vordergrundfarbe, area/exact, Crop[18,22,1234,1238], Alpha96, Schwelle160. Keine Zellreparatur.

Tatsächliche Matrixdatei: imports/a96/area-160-raster.png (ein Bildpixel je Zelle). Vergrößerung mit Gitter: review/final-grid.png. Gemeinsamer Bildvergleich mit unverändertem B-r02 und MA-r03: review/final-comparison.png.

Matrixhash `27235c31d631e2e68bfaf60f09dab2c7075576fa8a5d1576130efb204ca65385`; Logikhash `275b15c4f5f4325d4607314ee67c2562215fb95552c249a8745dc28766dc4cf1`. Vollständiger unabhängiger Proof unter full-line-mono, Herkunft und Endmatrixgleichheit geprüft. Alle fünf Dreiecksöffnungen und das Fünfeck bleiben offen. Aktuelle Schwierigkeit L4/Schwer nach0.3, instrumented/medium; keine geschätzte Lösungszeit.

Die tatsächliche menschliche Endabnahme fehlt noch. Das Originalpaket wird dafür nicht umgeschrieben: spätere Erklärung außerhalb des versiegelten ZIP an ID/r06, äußeren Handoffhash, Inventarhash, diese Auswahl und B-r02 binden. Hashes stehen im äußeren record.json. Ein tatsächlicher Auftrag4 darf danach Export und Registrierung durchführen; der jetzige Ablagemerge ist keine Spielintegration.
