# Standardauftrag4 · Endabnahme und Integration

pz-1e9cdac1f83a49d5982f93ded09e58de · r06 · content_ready. Menschliche Endabnahme offen. Erst eine tatsächliche Endfreigabe dieses Pakets bindet Originalhandoff, Inventar, Auswahl und B-r02. Kein bestehendes Gateflag ist diese Erklärung.

Auswahl: imports/a96 · area-160; Matrixhash `27235c31d631e2e68bfaf60f09dab2c7075576fa8a5d1576130efb204ca65385`, Logikhash `275b15c4f5f4325d4607314ee67c2562215fb95552c249a8745dc28766dc4cf1`. Direktimport,22×22 mono, genau ink, Crop[18,22,1234,1238], area/exact, Alpha96, Schwelle160. Full-line-mono vollständig und unabhängig geprüft; keine Paarbindung oder Reparatur. Finale Endabnahmevorlage unter ENDABNAHME.md und review/final-comparison.png.

Nach tatsächlicher Endabnahme: aktuellen main/Index/Record und ZIP-/Handoff-/Inventarbindungen prüfen, aktuelle Pflichtquellen/ZA-1 lesen. Separate echte approval.json erstellen. Regulären kategorisierten Export für mythen-fantasie mit derselben Produktions-ID und expliziter Runtime-Revision1/Stem/Slot erstellen. Kein zusätzliches Routine-inspect, weil export selbst frisch prüft.

Geprüfte0.3-Hülle analysis/checked.json und vollständiges Bundle liegen vor. Nach Export bei identischer ID/Modus/Logik/Matrix explizit auf echte Definitionsbytes rebind; keine erneute Routineanalyse. Dann plan/register mit geprüftem Difficultyinput. Bestehende B-r02-/MA-r03-/Freigabebytes erhalten. Keine echten Saves. Pflicht-CI, getrennter Selbstreview, beauftragter Integrationsmerge und danach eigener geprüfter Cleanup nach §9; nichts davon ist durch die jetzige Paketablage vorweggenommen.
