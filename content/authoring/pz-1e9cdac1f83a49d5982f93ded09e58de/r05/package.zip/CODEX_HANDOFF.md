# Übergabe · MA-r03 zur Motivfreigabe

Status motif_review. Neue konkrete Freigabe für motifs/MA-r03.png · MA-r03 erforderlich; SHA-256 94a8e110819f145d8e9a11350ff32cea4dfad9198d3f372472c444f749c87a6e. Die Nutzerantwort zur neuen Gestaltungsrichtung ist keine Bildbytefreigabe. Alte MA-r02-Freigabe gilt ausschließlich für die alte Datei.

Paket r05 und äußeren Record über den Authoringindex auflösen; ZIP/Handoff/Inventar/Dateien prüfen. Aktuellen main und Pflichtquellen prüfen. Freigegebenes B-r02 bleibt bytegleich; seine Freigabe und Herkunft sind enthalten. MA-r03-Provenienz/Prompt und der Vergleich belegen die konkrete neue Abstraktion.

Nach tatsächlicher MA-r03-Freigabe einschließlich configuration/proposal.json Standardauftrag3 vollständig ausführen:22×22, mono, genau eine Vordergrundfarbe, area/exact, Crop [18, 22, 1234, 1238]. Vier vorgeschlagene Kandidaten, Dubletten ehrlich erkennen, höchstens sechs je Runde unter begründeter Hypothese. Keine20×20- oder24×24-Ausweichgröße ohne neue Entscheidung.

Reif, fünf verbundene Spitzen, Orientierung, Fünfeck und alle fünf vergrößerten Dreiecksöffnungen schützen. Linienprofil und unabhängiger Herkunfts-/Endnachweis zuerst, bei geeignetem stalled-Kandidaten das zugelassene Paarprofil. Nötigenfalls begrenzte RP-5-Reparaturen nach §4.4. Nicht die vorigen Nichtfunde als Beweis einer unmöglichen neuen Produktion verwenden. Anschließend finale SD0.3-Bewertung, visueller Vergleich, Endabnahmevorlage und §6-Sicherung. Keine Spielregistrierung vor tatsächlicher Endabnahme.
