# Pentagramm · neue Motivvorlage MA-r03

pz-1e9cdac1f83a49d5982f93ded09e58de · r05 · motif_review · Basis 346fe214dcd563ed47150aa4af79611e2f25ec3a · Kategorie mythen-fantasie.

Nach dem blockierten r04-Prüfstand hat der Nutzer ausdrücklich den neuen22×22-Ansatz mit größeren Dreiecksöffnungen und kräftigerem Reif gewählt. Tatsächliche Erklärung unter approvals/revision-direction.md. Sie beauftragt die neue Vorlage, erteilt jedoch keine Freigabe ihrer erst danach erzeugten Bytes.

B-r02 bleibt das unveränderte freigegebene Abschlussbild. MA-r03 ist eine native Bildbearbeitung von MA-r02 mit B-r02 als Identitätsreferenz. Geschützt bleiben Reif, fünf gekreuzte Stege mit fünf verbundenen Spitzen, eine untere und zwei obere Spitzen, Querbalken unterhalb der Mitte, Fünfeck und alle fünf Dreiecksöffnungen sowie die fünf äußeren Freiräume. Reif und Dreiecke sind sichtbar verstärkt beziehungsweise geöffnet. Kein anderes Motiv, keine Perspektivänderung und kein neuer Reveal.

Vorgeschlagen:22×22 fest, monochrom, genau eine Vordergrundfarbe ink ohne Leer; area/exact; neuer quadratischer Crop [18, 22, 1234, 1238]. Schwelle112–176, Alpha96–160; vier gezielte Anfangskandidaten in configuration/proposal.json. Beide Designs sind nur schema-validiert. Keine Matrix, Hinweise, Logikprüfung oder Lösbarkeitszusage vor tatsächlicher neuer MA-r03-Freigabe.

§6-Ablage und bedingter Ablagemerge bleiben beauftragt. Originale r01–r04 und frühere Freigaben bleiben unverändert. Der nächste Schritt ist3 · Motiv freigeben & produzieren; Endabnahme und Spielregistrierung folgen separat.
