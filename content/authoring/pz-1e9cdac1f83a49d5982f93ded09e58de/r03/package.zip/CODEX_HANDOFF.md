# Codex-Übergabe · Standardauftrag 3

GATE: MA-r02 ist noch nicht menschlich freigegeben. Dieses Dokument erteilt keine Freigabe. Nach tatsächlicher Nutzerfreigabe von MA-r02 und dem vorgeschlagenen Parameterkorridor:

```text
Arbeite in venomenon328/picross am aktuellen main nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Paket über content/authoring/index.json auflösen: pz-1e9cdac1f83a49d5982f93ded09e58de, r03. Paket-, Handoff-, Inventar- und Quelldateihashes prüfen.
Tatsächliche menschliche Motivfreigabe für motifs/MA-r02.png (SHA-256 fdf0a90bf4b373059b5ea7c158131ae9e1e9ea6439746d23b478f2062034c20b) protokollieren; nicht aus der gespeicherten B-r02-Freigabe ableiten. Reveal unverändert: reveals/B-r02.png (SHA-256 d98d365128e3146657440f35645fea55d95aa23bd74efd7038d240e1026db12d).
Standardauftrag 3 vollständig ausführen. Vorgeschlagener Korridor: bevorzugt 20×20, alternativ 22×22; mono, genau eine Vordergrundfarbe ink ohne Leer. configuration/proposal.json und beide gültigen design-Dateien lesen; keine Größe 24 ohne Entscheidung. Crop/Proportionen und geschützte Innenräume erhalten.
Vier gezielte Startkandidaten gemäß initial_candidates, Dubletten ehrlich erkennen; nötige Ersatzhypothesen nur im freigegebenen Korridor, max. sechs/Runde. Vollständige Linienlogik und unabhängigen Proof/Herkunft prüfen. Bei passendem Linienfixpunkt Profilwahl gemäß §4.2.1; bei Bedarf bis zwei motivgeschützte Reparaturrunden nach §4.4, keine Material-/Identitätsänderung ohne erneute Freigabe.
Tatsächliche Matrix, Hinweis-/Rand-/Palettenregeln, Motivtreue und unveränderten Reveal prüfen; Schwierigkeit nach §5.2 mit gebundenem aktuellen SD-Verfahren außerhalb der CI. Bis content_ready samt echtem Raster, Qualitätsbericht und Endabnahmevorlage arbeiten, §6 sichern. Keine Spielregistrierung vor menschlicher Endabnahme/Standardauftrag 4. Bereits beauftragte Ablage-PRs nach erfolgreichen Pflichtchecks mergen.
```

Die Nutzerfreigabe muss zusätzlich den tatsächlich gelieferten neuen Paketstand binden. Hashes der geschlossenen Lieferung stehen in record.json/handoff.json; kein Platzhalter gilt als Nachweis. Paketbasis und späterer Ablage-Merge werden außerhalb versiegelter Pakete im PR/Chat genannt.
