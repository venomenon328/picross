# Pentagramm · Motivvorlage zur Freigabe

pz-1e9cdac1f83a49d5982f93ded09e58de · r03 · motif_review · 2026-10-24 · Authoring 0.5.0 / Dokumentrevision 23 · Toolcommit 14b09b9228a221d22667f918e307961c5f2cd04f. Inventarhash ist ohne Selbstreferenz im Handoff gebunden.

Freigegebenes Abschlussbild: B-r02 (d98d365128e3146657440f35645fea55d95aa23bd74efd7038d240e1026db12d), Originalbytes unverändert. Erklärung, Akteur, protokollierter UTC-Zeitpunkt und Herkunftspaket in approvals/reveal-B-r02.json; genaue Nachrichtenzeit ist nicht exponiert und wird nicht erfunden. Neue Motivvorlage: MA-r02 (fdf0a90bf4b373059b5ea7c158131ae9e1e9ea6439746d23b478f2062034c20b); menschliche Motivfreigabe und Endabnahme offen.

Empfehlung 20×20 mono (400 Zellen), eine Vordergrundfarbe ink plus Leer. 22×22 (484) bietet etwas mehr Raum für kleine Innenöffnungen; 24×24 (576) ist nur Vergleich, nicht vorgeschlagen. Motivtreue, Darstellbarkeit, ungeprüftes Lösbarkeitsrisiko und Umfang stehen getrennt in configuration/proposal.json. Keine Lösungszeit geschätzt, tatsächlich verwendete Matrixfarben unbekannt.

Holzmaserung, Violett-/Brauntrennung, Abplatzer und Überlagerungsschatten entfallen. Reif, fünf Sternstege, einzelne untere Spitze, Fünfeckzentrum und charakteristische offene Dreiecke bleiben. MA-r01 hatte fünf unerwünschte Kontaktschlitze; eine gezielte Korrektur ergibt die durchgehende MA-r02. Keine Rasterreparatur. Visuelle Pflichtkriterien für Reveal/Motiv dokumentiert; Papiervergleich groß/140px, PNG-Alpha/Dateidekodierung und Cropgrenzen geprüft. Bildvergleich unter review/reveal-motif.png.

Zwei vorgeschlagene picross-image-design-v1-Dateien mit area/128/160, alpha_below 128 und festem quadratischen Crop sind schema-validiert. Noch kein Import, Raster, Hinweis, Randtest, Logik-/Prooflauf, Schwierigkeitsbericht oder Zieladapterexport; diese Nachweise folgen erst nach Motivfreigabe. Kein ZA-1-inspect oder Spieltest für diese frühe Phase. Geschriebenes ZIP wird auf sichere vollständige Dateimenge, CRC, Größen, sämtliche SHA-256 und bytegleiche Handoffkopie geprüft; CI-Pfadprüfung und ci-required werden im Ablage-PR am finalen Head/Test-Merge gebunden.

Herkunft/Nutzungsgrundlage: projektbeauftragte native Bearbeitungen der freigegebenen B-r02; keine fremden Bildassets. Zwei Bildaufrufe/92,2 s in dieser Phase; Menschenzeit nicht erfasst. Nächster Schritt: 3 · Motiv freigeben & produzieren. Vollständige beauftragte Codex-Übergabe liegt in CODEX_HANDOFF.md; einziges aktuelles menschliches Gate ist MA-r02 samt vorgeschlagenem Parameterkorridor.
