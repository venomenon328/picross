# Stirnlappenbasilisk · Korrekturrunde r04

`pz-c71563f1b8c940de998afdd62f09`. Tatsächlicher aktueller Auftrag in [change-request.json](change-request.json): erneut50×25, keine nur einmal verwendete Vordergrundfarbe. Fortgesetzte Repositoryablage und Draft-PR109, kein Merge/keine Registrierung.

Unverändertes freigegebenes [A-r01](reveals/A-r01.png) bleibt verbindlich; bisher freigegebene [MA-r01](motifs/MA-r01.png) und ihre tatsächlichen bisherigen Freigaben bleiben erhalten. Vier neue Rasterimports aus MA-r01 wurden vollständig mit source-bound Designs und Proofs erzeugt. Alle scheitern an der Randregel und bleiben logisch unvollständig; dadurch Rücksprung zur Abstraktionsphase.

Neue vorgeschlagene [MA-r02](motifs/MA-r02.png), SHA-256 `9468fb1b5a883bd550026c08f718732a44c7fbf8d9b2cd006a08e348cc7d9928`, nativ anhand A-r01 und MA-r01 abgeleitet. Drei Vordergrundfarben vorgesehen, Körper höher auf2:1-Fläche, unveränderte Blickrichtung/Pose und vollständiger Schwanzbogen. [Konfiguration](configuration.json) enthält exakt50×25 und vier background-only2:1-Crops; keine Streckung. Noch nicht vom Menschen freigegeben, daher noch kein Rasterimport aus MA-r02.

Geschützt: Artenidentität, zwei Kopfkämme, Rücken-/Schwanzsegel, anatomische Hauptproportionen, ruhende Vierbeinpose, vollständiger langer Schwanz und wichtige Bein-/Schwanzzwischenräume. Neue Vorlage und sichtbare Detailänderungen müssen konkret freigegeben werden. Herkunft/Prompt und beide früheren Originalbilder erhalten.
