# Stirnlappenbasilisk · Produktion r03

Standardauftrag 3, 13.10.2026, `pz-c71563f1b8c940de998afdd62f09`, Kategorie `insekten-kleine-tiere`.
Verbindliche technische Quellen: main `f666f87d36a0ea7fa3740202d08706f2215bc303`; Ausgangsrecord r02 bei `1d71e8a888da63a6d97fa0627345ded782a11f3c`.
Aktueller Auftrag/Freigabe wörtlich in [motif-approval.json](motif-approval.json).
„Motivvorlage r02“ bezeichnet die einzige Vorlage im eindeutigen Paketrecord r02: MA-r01.
Freigegeben: exakt 46 × 20, color, vier feste Vordergrundfarben plus Leer; area/contain und die beiden angebotenen äußeren Hintergrund-Crops. 50 × 22 ist durch die feste Nutzerwahl ausgeschlossen.

Hauptmotiv: nach links blickender männlicher Stirnlappenbasilisk in ruhiger Vierbeinpose, zwei Kopfkämme, Rücken-/proximales Schwanzsegel, vollständiger sehr langer Schwanzbogen. Identität, Blickrichtung, Proportionen, Pose und wichtige Bein-/Schwanzzwischenräume erhalten. Keine Streckung, gekappte Körperteile oder künstliche Randpixel. Rasterdetails dürfen bei 20 Zellen Höhe zusammenfallen; sichtbare Verluste werden im [Bildreview](visual-review.json) offengelegt.

Abschlussbild A-r01 ist tatsächlich freigegeben und bleibt bytegleich. MA-r01 ist die gespeicherte native Abstraktion genau dieses Bilds; Prompt, Provenienz und Originalbildbytes bleiben erhalten. Keine neuen Bildaufrufe und keine Fremdbildassets. Nutzungsgrundlage in den beiden Provenienzdateien; keine exklusive Schutzfähigkeit zugesagt.

Auftrag umfasst Produktion, technische/visuelle Prüfung, Schwierigkeit, §6-Ablage und Fortführung Draft-PR109. Keine Endabnahme selbst erteilen, keine Spielregistrierung, kein Merge, Build oder Release. Nur Authoring-Index und dieses Paket ändern.
