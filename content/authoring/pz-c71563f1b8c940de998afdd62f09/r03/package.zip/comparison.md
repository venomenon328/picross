# Bild- und Reparaturvergleich

[Direkter Vergleich](views/final-comparison.png): unverändertes freigegebenes A-r01, unveränderte freigegebene MA-r01 und tatsächliches Endraster. [Raster](views/final-raster.png), [ohne Glättung vergrößert](views/final-large.png), [Gitter](views/final-grid.png), [Reparaturdiff und Schutz](production/repair-tail/view.png).

Echsenprofil, hohe Kopf-/Rückensegel, lange Proportion und großer offener Schwanzbogen bleiben erhalten; vier Beine sind stark zu zwei Beinpaaren zusammengefasst. Der kleine vordere Kopflappen wird zur flachen Stufe, sein Ansatz verschmilzt mit dem großen Kamm. Auge/Pupille, Mundlinie, feine dunkle Konturen, Schuppen, Segelrippen und Krallen sind bei46×20 nicht einzeln dargestellt. Diese sichtbaren Detailverluste sind Gegenstand der abschließenden redaktionellen Annahme; keine neue Perspektive/Pose oder veränderte Kerngeometrie.

Reparatur: nullbasiert (y17,x43), also Zeile18/Spalte44, `empty`→`dark`. Sie sitzt am unteren rechten Schwanzknick und berührt zwei andere gefüllte Zellen. Ursprüngliche dunkle Außenkontur wird lokal verdickt; weder ein isolierter Dekorpunkt noch ein Randregeltrick. Alle anderen919 Zellen sind unverändert und außerhalb der vier zugelassenen Schwanzzellen hart geschützt. Der ohnehin erfüllte Randvertrag bleibt links/top erfüllt.

Knapper Crop verworfen: mehr unbestimmte Zellen und abgelöster Schwanzspitzenpixel. Großzügiger Crop bewahrt einen einzigen zusammenhängenden Vordergrund und den offenen Bogen; dessen kleine Farblogik-Mehrdeutigkeit wird durch die begrenzte Konturreparatur beseitigt. Beide vollständigen Importbündel und das vollständige Reparaturbundle bleiben erhalten.
