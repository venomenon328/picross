# Stirnlappenbasilisk · Motivvorlage MA-r01

Standardauftrag 2, 13.10.2026, `pz-c71563f1b8c940de998afdd62f09` / r02. Aktuelle main-Quellen `f666f87d36a0ea7fa3740202d08706f2215bc303`, Weiterarbeit im vorhandenen Draft-PR #109 auf `content/stirnlappenbasilisk-reveal-r01`, Vorpaket r01 bei `ee2f2d0844ad63e6542c855f76b86c7c09e7502f`.

Tobias hat A-r01 am 13.10.2026 um 13:46:07 UTC ausdrücklich freigegeben; Erklärung und Originalbildhash sind in reveal-approval.json / approvals/user-statement.json gebunden. A-r01 bleibt unverändert und ist die verbindliche gestalterische Referenz. Motivableitung `faithful` aus den tatsächlichen Bildbytes; keine neue freie Motivwahl.

MA-r01 bewahrt Identität, links gerichtetes Profil, Proportionen, beide Kopflappen, Rücken-/Schwanzsegel, Vierbeinpose, vollständigen langen Schwanzbogen und wichtige Bein-/Schwanzzwischenräume. Erlaubte Detailverluste: Schuppen/Rippen, kleine Flecken, feine Lichtführung und Krallendetails zusammenfassen. Keine motivfremden Randpunkte, Poseänderung, Schwanzverkürzung oder Streckung.

Empfehlung: 50×22, farbig, vier Vordergrundfarben plus Leer. Vorgeschlagener Produktionskorridor: 50×22 oder 46×20, feste Vierfarbenpalette, area/contain, ausschließlich die beiden hintergrundbeschränkten Crops aus configuration.json. Vier verschiedene Designhypothesen vorbereiten; noch keine Raster erzeugt. Die Betrachtung 40×18 mit drei Farben ist nur eine verworfene Konfigurationsalternative, nicht Teil des Korridors.

Kategorie `insekten-kleine-tiere` bleibt unverändert. Repositoryablage nach §6, Commit/Push und Draft-PR beauftragt; kein Merge. Menschliche Motivfreigabe fehlt und blockiert die Rasterproduktion. Kein Solverlauf, keine Reparatur und keine Spielregistrierung in Auftrag 2.
