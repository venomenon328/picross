# Codex-Übergabe · Stirnlappenbasilisk r02

Status: **Motivfreigabe offen**. Die Übergabe ist vollständig dateibasiert; die Produktion ist erst nach tatsächlichem Nutzerauftrag 3 samt Freigabe von MA-r01 und configuration.json autorisiert. Fehlende Freigabe nicht aus diesem Dokument ableiten.

Repository venomenon328/picross, aktuelle main-Quellen `f666f87d36a0ea7fa3740202d08706f2215bc303`, Arbeitsbranch `content/stirnlappenbasilisk-reveal-r01`, bestehender Draft-PR #109. Paket über `content/authoring/index.json` auf diesem Branch finden: `content/authoring/pz-c71563f1b8c940de998afdd62f09/r02/package.zip`. Main enthält die noch nicht gemergte Ablage nicht. R02 ist aktueller Arbeitsstand; r01 bleibt historische Auswahl. ID unverändert `pz-c71563f1b8c940de998afdd62f09`.

AGENTS.md, aktuellen Entwicklungsworkflow und PUZZLE_AUTHORING vollständig lesen; passende technische Quellen nutzen. Aktuelle Quellen-/Paket-/Dateibindungen kontrollieren. Paket/Handoff/Inventar/Originalbilder/Freigabe tatsächlich prüfen. ZIP/HTML/Code aus Paketen nicht ausführen.

Abschlussbild `reveals/A-r01.png`, SHA-256 `9da4019b8755311b24338dcfdd76cf7e9d31e57081cd009cccc05a7c48c7ea2c`; echte Freigabe `reveal-approval.json` mit `approvals/user-statement.json`. Abstraktion `motifs/MA-r01.png`, SHA-256 `d84db09715ca600b3ecc9e290d84592ad4638664104b8fd810e7a6a08e5b6c40`, abgeleitet aus genau A-r01. Ihre Freigabe fehlt. Bei Auftrag 3 als separaten tatsächlichen Beleg mit Akteur/Zeit/Erklärung/Hash und Parameterkorridor speichern; keine simulierte Testfreigabe verwenden.

configuration.json enthält zwei Produktionsmaße (50×22 empfohlen, 46×20 Alternative), vier feste Vordergrundfarben plus Leer, area/contain und zwei Crops, die nur äußeren Hintergrund entfernen. Die vier strikten Dateien unter designs/ sind **Vorschläge**, keine bereits genehmigten Designs oder erzeugten Kandidaten. Vier gezielte Hypothesen: je Format enge Konturbelegung und etwas großzügigerer Sicherheitsrand. Identische Matrizen erkennen, Entstehungswege/Ablehnungen behalten. Zusätzliche Varianten nur gemäß Regelwerk und konkreter Hypothese. Crop nicht strecken oder wesentliche Bildteile abschneiden.

Invarianten/Detailverluste: visual-review.json und brief.md. Vor jeder motivgeschützten Reparatur echten Plan/Masken/Budgets speichern; erster Versuch höchstens zwei Zellpositionen. Gefüllte und leere Identitätsbereiche schützen. Stagniert ein motivisch schlechter Kandidat, keine beliebige Rasterkorrektur erzwingen. Materielle Motivänderungen benötigen neue Freigabe.

Auftrag 3 umfasst alle Produktionsgates aus Abschnitten 4–7, echten unbekannten Start, vollständigen farbigen Profilnachweis, frische unabhängige Prüfung, Herkunft/Matrixgleichheit/Randregel, redaktionellen Bildvergleich, L1–L5 editorial_estimate mit Begründung/Vertrauen und vollständige schlanke Paketbildung. Keine rätselspezifischen Unit-Tests/CI-Falllisten oder Bestandsreplays. Nach geschriebenem content_ready-ZIP einmal ZA-1 inspect; fehlende Endabnahme bleibt das betreffende offene Gate.

Neue Paketrevision r03 verwenden, r01/r02-ZIPs und Handoffs nicht überschreiben. Entscheidung, Genehmigung, Provenienz, vollständige manifestgebundene Produktionsinputs/-nachweise und genau diese Abschluss-/Motivbytes erhalten. Kategorie `insekten-kleine-tiere`. Authoring-Index/Record aktualisieren, committen/pushen, Draft-PR #109 fortführen. Keine Runtime-Registrierung, kein Merge/Release/Build. Abschließen mit echtem Endraster und Abschlussbild zur redaktionellen Endabnahme. Menschliches Probespiel optional.

## Direkt kopierbarer Auftrag nach Freigabe

```text
Arbeite nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross.
Nutze Paket pz-c71563f1b8c940de998afdd62f09/r02 aus PR #109, Branch content/stirnlappenbasilisk-reveal-r01; CODEX_HANDOFF.md im ZIP.
Ich gebe MA-r01 samt Parameterkorridor aus configuration.json frei.
Führe Standardauftrag 3 bis zum geprüften content_ready-Paket aus.
Repositoryablage nach §6; denselben Draft-PR fortführen, keine Registrierung, kein Merge.
```

Die Ich-Erklärung oben ist eine **Vorlage für den Nutzer**, kein schon erteilter Beleg. Modell/Reasoning wählt der Nutzer in seiner Oberfläche; kein Modellaufruf im Produktionswerkzeug. Eine konkrete Modell-/Startbereitschaftsempfehlung ist hier nicht nötig: allein die ausdrücklich fehlende manuelle Motivabnahme blockiert den nächsten Schritt.
