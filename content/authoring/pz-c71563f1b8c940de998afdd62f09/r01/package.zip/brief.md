# Stirnlappenbasilisk · Abschlussbildauswahl

Auftrag vom 13.10.2026: Standardauftrag 1 nach PUZZLE_AUTHORING 0.4.1 / Dokumentrevision 5 auf `f666f87d36a0ea7fa3740202d08706f2215bc303`. Farbiger Rätselmodus; Abschlussbild immer farbig. Repositoryablage, Commit/Push und Draft-PR beauftragt, kein Merge.

Hauptmotiv: ein erwachsenes männliches Exemplar von Basiliscus plumifrons. Freie Motivübertragung (`free`), da nur Motivtext und keine bindende Bildquelle vorliegen. Drei Varianten mit unterschiedlicher Pose und Komposition; gleiche Serienästhetik.

Identitätskern: grüne schlanke Echse, charakteristische Stirn-/Kopflappen, deutliches Rücken- und proximales Schwanzsegel, sehr langer auslaufender Schwanz, lange Zehen und kräftige Hinterbeine; gelbes Auge und türkisblaue Flecken unterstützen die Erkennung. Hauptproportionen und wichtige Bein-/Schwanzzwischenräume sind nach der Bildwahl zu bewahren. Keine Drachenhörner, Flügel oder anthropomorphe Mimik.

Zuordnung: `insekten-kleine-tiere` (Insekten & kleine Tiere), bestehende redaktionelle Motivgruppe. Die Kategorien sind laut KAT-1 keine biologische Taxonomie. Keine neue Reptilienkategorie ohne eigenen Auftrag erzeugt.

Rastermaße, Crop und Rasterpalette offen. Beide Rasterachsen später höchstens 50, gewöhnlich 2–4 Vordergrundfarben plus Leer. Detailreduktion erst nach ausdrücklicher Abschlussbildfreigabe. Noch keine Motivvorlage, Matrix, Hinweise, Logikzertifizierung oder Spielintegration.

Freigabegegenstand: eine exakt vorgelegte Datei A-r01, B-r01 oder C-r01, gebunden in variants.json und inventory.json. Keine Freigabe aus Auswahlinteresse oder Schweigen ableiten. Nach Freigabe Standardauftrag 2: Dateifreigabe binden, 2–3 geeignete Konfigurationen vergleichen, eine empfehlen und daraus die Motivvorlage erstellen.
