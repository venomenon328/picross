# Abschlussbildauswahl · Stirnlappenbasilisk

ID `pz-c71563f1b8c940de998afdd62f09`, Paket r01, Status `reveal_review`, 13.10.2026. Regelwerk 0.4.1, Dokumentrevision 5; Repository-/Toolquellen `f666f87d36a0ea7fa3740202d08706f2215bc303`. Inventarhash im gebundenen handoff.json und äußeren record.json; Inventar ohne Selbstreferenz.

| Variante | Bild | Beurteilung |
| --- | --- | --- |
| A-r01 | [Seitenprofil](reveals/A-r01.png) | Empfehlung: übersichtlicher Körperaufbau ohne Nebenobjekt; sehr breiter Schwanzbogen. |
| B-r01 | [Astpose](reveals/B-r01.png) | Kompaktere Diagonale; Ast und überlagerte Füße erhöhen Abstraktionsaufwand. |
| C-r01 | [Wasserlauf](reveals/C-r01.png) | Ausdrucksstarke Bewegung; Wasser und schmale Zehen brauchen gezielte Vereinfachung. |

Alle fünf Styleguidekriterien bei allen drei Bildern erfüllt; Begründungen und Dateihashes in variants.json. Natürliche Verdeckung einzelner ferner Gliedmaßen bei B ist bewusst vermerkt. Kein Detailverlust durch Bearbeitung: Originalbytes unverändert; keine Reparatur. Surface-Details sind für Abschlussbilder passend und werden später abstrahiert. Keine Lösbarkeits- oder Schwierigkeitszusage aus Bildqualität.

Abschlussbildfreigabe **offen**, Abstraktionsfreigabe **offen**, Endabnahme **offen**. Keine Variante ausgewählt oder verworfen. Farbmodus angefragt; Rastermaße, Zellzahl, Rasterpalette, Randregel, Hinweise, Logiknachweis/Profil, unabhängige technische Prüfung, Matrixgleichheit, Schwierigkeit, Export und Registrierung: noch nicht anwendbar. Lösungszeit nicht geschätzt, Probespiel nicht durchgeführt (optional).

Herkunft: neue native KI-Erzeugung aus Text, keine fremden Bildassets; tatsächliche Prompts/Einstellungen in prompts.json, nicht exponierte Einstellungen entsprechend markiert. Drei Bildaufrufe, keine Korrektur-, Import- oder Reparaturversuche. Aktive Menschenzeit nicht erfasst. Fachliche Recherche ausschließlich zur Artenidentität; Quellen in sources.json / Provenienzdateien.

Dateiprüfung: alle PNGs dekodiert, Maße/Modus und unveränderte Originalbytes geprüft. Sicheres ZIP, exakte Dateimenge, alle Inventarhashes, Regelwerksbindung und bytegleiche äußere Handoffkopie werden beim Packen geprüft; Beleg validation.json außen. Frühphase ist kein ZA-1-Adaptereingang. CI nur schlanker Inhaltspfad (docs und ci-required), keine Rätsel-/Spieltests.

Nächster erlaubter Schritt: ausdrückliche Freigabe von A-r01, B-r01 oder C-r01 und Standardauftrag 2. Repositoryablage auf `content/stirnlappenbasilisk-reveal-r01` als Draft-PR; keine Ablage auf main behauptet, kein Merge/Release.
