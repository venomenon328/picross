# José Rizal · Abschlussbildauswahl r01

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.5.0, Dokumentrevision 23.
Motiv: José Rizal. Rätselmodus: farbig; Abschlussbilder immer farbig.
Breite, Höhe und Vordergrundfarbzahl sind offen; Größenobergrenze später 50 je Achse.
Kategorie: menschen-berufe / Menschen & Berufe, nach prägendem Hauptgegenstand.

Freie illustrative Interpretation (`free`) einer historischen Person ohne bindende Bildvorlage.
Zu bewahren: erkennbarer schlanker Porträtkopf, dunkler Seitenscheitel mit geschwungener Stirnlocke,
schmaler gepflegter Schnurrbart ohne Vollbart, charakteristische Augen-/Nasen-/Kinnpartie,
weißer hoher Hemdkragen und dunkler historischer Anzug. Keine Schrift, Flagge oder Dekoration.
Gestalterische Farbgebung ist keine belegte historische Farbrekonstruktion.

A-r01: Dreiviertelporträt mit anthrazitblauem Anzug, braunem Binder.
B-r01: frontaler Blick, warmer brauner Anzug, bordeauxroter Binder.
C-r01: starkes linkes Seitenprofil, anthrazitfarbener Anzug, gedeckt petrolfarbener Binder.
Alle Bilder sind eigenständige native KI-Illustrationen mit echtem Alphakanal.
Keine fremden Bildbytes als Quelle oder Referenzeingang übernommen. Nutzungsgrundlage:
im Auftrag des Repositoryeigentümers in ChatGPT nativ erzeugte Illustrationen;
keine Behauptung exklusiver Rechte oder fotografischer Authentizität.

Erlaubt ist die beauftragte Ablage samt Index, Commit/Push, PR und bedingtem Merge nach Pflichtprüfungen.
Es liegen keine menschliche Abschlussbildfreigabe, Motivfreigabe oder Endabnahme vor.
Noch keine Abstraktion, Zellmatrix, Hinweise, Logikprüfung oder Spielregistrierung.
Nächster Schritt: 2 · Bild freigeben & abstrahieren, nach ausdrücklicher Dateiauswahl/Freigabe.
