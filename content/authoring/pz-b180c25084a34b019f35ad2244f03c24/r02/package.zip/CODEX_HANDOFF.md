# Codex-Übergabe · Standardauftrag 3, erst nach Motivfreigabe

Repository venomenon328/picross, Einstieg aktuelle AGENTS.md auf main.
Paket: content/authoring/pz-b180c25084a34b019f35ad2244f03c24/r02/package.zip; ID pz-b180c25084a34b019f35ad2244f03c24, r02.
Paketfundort über index.json und record.json auflösen, Inventar/Handoff/Bildhashes prüfen.
Freigegebenes Abschlussbild A-r01: ca042226c76c485abd2e89aae1fed574787e393a5faf69e058bd3fca223f911d; MA-r01: 61ba88451c3987ee8300b1f7cced2adf69336fa0a1a8dd6e8858a864fd3527b1.

Motivfreigabe ist ausdrücklich noch offen. Vorliegende Abschlussbildfreigabe wiederverwenden;
keine menschliche Motiv- oder Endfreigabe erfinden. Sobald der Nutzer MA-r01 samt Korridor
tatsächlich freigibt, diese Erklärung binden und Standardauftrag 3 gemäß PUZZLE_AUTHORING ausführen.

Empfehlung 44×48/Farbe/4 Vordergrundfarben; vorgeschlagene Maße ausschließlich
40×44, 42×46, 44×48. Palette, Crop, Fit und Invarianten verbindlich aus parameters.json.
Zunächst vier gezielte Eingänge: 44×48/42×46 jeweils alpha_below 96/192, echte config-Dateien.
Area-threshold ist bei Farbe wirkungslos: keine bloßen Threshold-Dubletten als neue Kandidaten zählen.
Gleiche Matrizen erkennen; Lesbarkeit und Identitätskern vor Solvererfolg bewerten.
Zwischentöne der PNG-Vorlage werden beim Import auf die vorgeschlagene Vierfarbpalette abgebildet.

Aktuelle Pflichtquellen und Werkzeugbudgets lesen; unabhängiger Proof, Herkunft,
Randregel, Endmatrix, motivgeschützte begrenzte Reparatur und Difficulty gemäß Workflow.
Die drei Rasterfarben wurden nur als schlechtere Alternative verglichen, nicht in den Korridor aufgenommen.
Keine eigenmächtige fünfte Farbe, neue Pose, motivische Randpunkte oder manuelle Matrixmanipulation.
Ohne tragfähigen Kandidaten die zulässigen Schritte des Workflows ausschöpfen und konkreten Blocker melden.
Bis content_ready und echter Endabnahmevorlage arbeiten; keine Spielregistrierung vor Standardauftrag 4.
Repositoryablage/PR/Merge nur gemäß dem tatsächlich nachfolgenden Nutzerauftrag fortführen.
