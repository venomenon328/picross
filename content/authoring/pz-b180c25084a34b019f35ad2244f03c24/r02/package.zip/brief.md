# José Rizal · r02 · Motivfreigabevorlage

Regelwerk 0.5.0, Dokumentrevision 23; Quellen-/Toolstand `68fd36e5cd6642d3f75ee22ebb695b91ba56cec0`.
Standardauftrag 2: tatsächliche Freigabe von A-r01 binden, Konfiguration empfehlen,
Motivvorlage aus genau dessen gespeicherten Bytes ableiten und an Codex übergeben.
Kategorie: menschen-berufe / Menschen & Berufe. Nutzerwunsch: farbig; Maße/Farbzahl offen.

Abschlussbild: `reveals/A-r01.png` · A-r01, SHA-256 `ca042226c76c485abd2e89aae1fed574787e393a5faf69e058bd3fca223f911d`; Originalbytes unverändert.
Motivvorlage: `motifs/MA-r01.png` · MA-r01, SHA-256 `61ba88451c3987ee8300b1f7cced2adf69336fa0a1a8dd6e8858a864fd3527b1`; vorlagentreue native Ableitung.
Empfehlung: 44×48, vier Vordergrundfarben plus Leer. Exakter vorgeschlagener Korridor
und drei Konfigurationsvergleiche: `parameters.json`; vier echte Design-JSONs in `config/`.
Noch keine menschliche Motivfreigabe oder Produktionsautorisierung; approved_parameters bleibt leer.

Geschützte Merkmale: Dreiviertelpose/Blick, beide Augen, Seitenscheitel/Stirnlocke,
Nasen-/Kinnform, schmaler Schnurrbart, hoher heller Kragen, brauner Binder und Brustbildform.
Details gezielt vereinfacht; keine Neupose oder neue Gegenstände. Quellen-/Bildprovenienz siehe Sidecars.
Freigabebeleg: `approvals/reveal-A-r01.json` mit tatsächlicher Nutzererklärung.
Die Uhrzeit bezeichnet die Erfassung dieser Erklärung, nicht einen erfundenen exakten Nachrichtenzeitstempel.

Repositoryablage und bedingter Ablagemerge sind beauftragt. Kein Raster, keine Hinweise,
keine Logik-/Schwierigkeitsanalyse, keine Spielintegration in Auftrag 2.
Nächster Schritt: 3 · Motiv freigeben & produzieren, nach menschlicher Freigabe
von MA-r01 mitsamt parameters.json. Inhaltsgates und Endabnahme bleiben später erforderlich.
