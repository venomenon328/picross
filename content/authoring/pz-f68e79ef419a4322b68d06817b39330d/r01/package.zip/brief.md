# Torii · Abschlussbildauswahl

## Tatsächlicher Nutzerauftrag

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Starte Standardauftrag 1: Abschlussbildauswahl.
Motiv: Torii
Rasterbreite × Rasterhöhe: offen × 15 Zellen (ungefähr).
Rätselmodus (Abschlussbild immer farbig): monochrom.
Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.

## Erfasste Auslegung und Invarianten

Ein einzelnes japanisches Torii als prägender Hauptgegenstand; keine konkrete reale Sehenswürdigkeit und keine externe Bildvorlage. Freie Motivinterpretation (`free`) bis zur menschlichen Auswahl. Kategorie `gebaeude-bauwerke` / Gebäude & Bauwerke. Zwei kräftige tragende Pfosten, oberer Querbalken und klar getrennter unterer Querbalken, offener Durchgang und klare Aussparungen zwischen den Balken. Vollständige architektonisch zusammenhängende Torform, keine Türen oder Gitter im Durchgang. Keine Landschaft, Schreinbauten, Schrift, Seile oder dekorativen Nebenobjekte.

Abschlussbilder als detaillierte farbige warme 2D-Illustrationen mit klaren Konturen, ausgearbeiteter Holz-/Lackoberfläche und zurückhaltender Schattierung; Außenraum und Durchblicke echt transparent. A und C besitzen geschwungenen dunklen oberen Abschluss, roten Lack, mittige kurze Strebe und dunkle Fußhülsen; B besitzt gerade honigbraune Holzbalken ohne diese mittige Strebe. Diese Unterschiede sind angebotene Alternativen und noch keine freigegebenen Invarianten eines ausgewählten Bilds.

Späteres Raster: monochrom, genau eine Vordergrundfarbe plus Leer; Höhe ungefähr 15, Breite offen. Keine konkreten Istmaße oder freigegebener Größenkorridor. Die dominante Silhouette und großen Negativräume sollen die kleine Mono-Abstraktion tragen; Holzmaserung, Farbtrennung und Glanz bleiben Details des Abschlussbilds. Keine Lösbarkeit, Schwierigkeit oder Erkennbarkeit einer noch nicht erzeugten Matrix zugesagt. Auftrag 1 endet vor Abstraktion und Rasterproduktion.

## Herkunft und Nutzungsgrundlage

Alle drei tatsächlichen Bilddateien wurden separat mit nativer ChatGPT-Bildgenerierung aus den beigelegten Prompts erzeugt. Keine externen Referenzbilder oder Fremdassets verwendet. Projektbezogene Erzeugung gemäß Nutzerauftrag; keine Behauptung exklusiver Urheberrechte oder einer freien Fremdlizenz. Die unveränderte vorhandene Buchillustration wird ausschließlich für den statischen Sichtbeleg verwendet; ihr Repositorypfad, Quellcommit und Hash sind gebunden.
