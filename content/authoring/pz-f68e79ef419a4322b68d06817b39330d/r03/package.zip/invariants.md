# Motivschutz

- Frontale Ansicht und breite Hauptproportionen des freigegebenen A-r01.
- Breiter oberer Querbalken mit sanft nach oben gezogenen Enden.
- Zwei kräftige nach unten auseinanderlaufende Pfosten mit leicht breiteren Füßen.
- Tiefer liegender durchgesteckter Querbalken mit seitlichem Überstand.
- Kurze mittige vertikale Strebe zwischen den Querbalken.
- Zwei getrennte offene obere Zwischenräume und großer offener Durchgang ohne unteren Abschlussbalken.
- Vollständige Torform, keine zusätzlichen Objekte oder geschlossenen Durchblicke.

Erlaubte Reduktion: Materialmaserung, Glanz, feine Beschläge, innere Schattierung und Trennung der roten/schwarzen Flächen entfallen. Obere Balkenschichten verschmelzen zu einer gefüllten Form; Fußhülsen werden zu verbreiterten Pfostenenden. Kleine Kontur-/Negativraumkorrekturen in der späteren motivgeschützten Produktion nur innerhalb dieser Invarianten und des tatsächlich freigegebenen Korridors. Keine neue Bildperspektive oder Architektur. Ein Farbwechsel würde eine neue Vorgabe benötigen.
