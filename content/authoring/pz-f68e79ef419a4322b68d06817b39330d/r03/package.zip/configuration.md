# Torii · Konfigurationsvergleich

Alle Optionen sind monochrom mit genau einer Vordergrundfarbe plus Leer. Die sichtbare native Motivkontur hat ungefähr 1,325:1 Seitenverhältnis. `contain` erhält dieses Verhältnis ohne Strecken; geringe geometrische Quantisierung erfolgt erst bei der späteren Zellabbildung.

| Größe | Motivtreue und Darstellbarkeit | Erwartetes Lösbarkeitsrisiko | Spielgefühl / Eingabeumfang |
| --- | --- | --- | --- |
| 18 × 14 · 252 Zellen | Kompakt; die obere Balkenlücke und Mittelstrebe stehen enger, die Endkrümmung muss stärker zusammengefasst werden. | Dünne Zwischenräume können beim Import schließen. Keine Logik geprüft. | Kurzer Bearbeitungsumfang, aber unnötiger Detaildruck. Nicht empfohlen und außerhalb des vorgeschlagenen Freigabekorridors. |
| 20 × 15 · 300 Zellen · Empfehlung | Liegt an der gewünschten Höhe; breites Querformat passt zur Torform, ausreichend kräftige Pfosten und klarer Durchgang. | Symmetrie und wiederholte Pfosten sind ein Prüfanlass. Ein guter Umriss garantiert keinen vollständigen Deduktionsnachweis. | Kleines kompaktes Bildrätsel; keine feste Schwierigkeit oder Lösungszeit behauptet. |
| 22 × 17 · 374 Zellen | Etwas mehr Platz für Bogenenden, Pfostenneigung und getrennte obere Aussparungen bei sehr ähnlichem Verhältnis. | Zusätzliche Linien können helfen oder kompliziertere Hinweise erzeugen; größer ist keine Erfolgsgarantie. | Etwas mehr Zeichnen/Zählen; Alternative für tragfähigere Details. |

Vorgeschlagener Korridor: genau 20×15 oder 22×17, jeweils monochrom, genau `ink` plus `empty`. Empfehlung 20×15. Keine freie Kreuzkombination der Achsen. Nur vollständig transparenter Außenraum und schwache native Antialiasingrestpixel dürfen beim dokumentierten Crop entfallen; charakteristische Torform, drei große Negativräume und offener Boden bleiben erhalten.

Feste Nutzervorgabe: eine Vordergrundfarbe, deshalb keine Farbpalettenalternative. Die Farbe trägt das gesamte Tor. Die fehlende Material-/Farbtrennung ist die beabsichtigte Mono-Reduktion; das Abschlussbild bleibt unverändert farbig.

`configuration.json` bindet Quelle/Hash, Crop [33,65,1369,1073], Fit `contain`, weißen Importhintergrund, `alpha_below=1` und die `area`-Hypothesen. Start in Auftrag 3: vier gezielte Kandidaten, 20×15 und 22×17 mit je Schwelle 128/176. Die Schwelle steuert die Flächendeckung an schrägen Konturen; andere native Farbtöne sind keine zusätzlichen Rasterfarben. Maße benötigen getrennte Designs, gleiche Matrizen werden exakt erkannt. Diese Vorschläge sind keine bereits ausgeführten Importe und kein Logiknachweis.
