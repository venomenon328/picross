# Torii · Standardauftrag 2

pz-f68e79ef419a4322b68d06817b39330d · r02 · Quell-/Toolstand ddd88aca4d91541c9f7cc8be5c285590a6b83ffe.
Der tatsächliche Nutzerauftrag steht vollständig in evidence/user-instructions.md. A-r01 wurde ausdrücklich freigegeben und bleibt bytegleich; MA-r01 ist daraus nativ und vorlagentreu abgeleitet. Kategorie gebaeude-bauwerke. Wunsch: Breite offen, Höhe ungefähr 15, monochrom mit genau einer Vordergrundfarbe plus Leer.

Die native Abstraktion erhält Blickwinkel, breite Torform, Pfostenneigung, geschwungenen oberen Querbalken, unteren Querbalken, Mittelstrebe, zwei obere Zwischenräume und offenen großen Durchgang. Einzelheiten stehen in invariants.md. Oberflächen- und Farbdifferenzen entfallen gezielt; weder Bild noch Motiv werden als bereits geprüftes Raster ausgegeben.

Empfehlung 20×15, erlaubte vorgeschlagene Alternative 22×17. Die bereits vorgelegte Bildfreigabe bindet keine noch unbekannte Matrix. Motiv-/Parameterfreigabe bleibt offen. Paket dient der menschlichen Motiventscheidung und vollständigen dateibasierten Übergabe an Auftrag 3; keine Rasterproduktion oder Spielregistrierung in Auftrag 2.
