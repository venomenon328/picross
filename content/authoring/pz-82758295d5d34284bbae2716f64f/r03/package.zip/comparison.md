# Tatsächlicher Bildvergleich

Unveränderte freigegebene Dateien: [Abschlussbild A-r01](reveal/A-r01.png), [Motivvorlage MA-r01](motif/MA-r01.png). Die Sockelzwischenräume und getrennten Ohrspitzen sind im Bild deutlich, im Raster nicht ausreichend erhalten.

| Schwelle | Echtes Raster · 1 Pixel/Zelle | Gitter · 12 Pixel/Zelle | Offene Zellen | Randregel |
| --- | --- | --- | ---: | --- |
| area-112 | [PNG](production/import/area-112-raster.png) | [PNG](views/area-112-grid.png) | 137 | verfehlt |
| area-144 | [PNG](production/import/area-144-raster.png) | [PNG](views/area-144-grid.png) | 58 | erfüllt |
| area-160 | [PNG](production/refinement/area-160-raster.png) | [PNG](views/area-160-grid.png) | 45 | erfüllt |
| area-176 | [PNG](production/import/area-176-raster.png) | [PNG](views/area-176-grid.png) | 29 | erfüllt |
| area-192 | [PNG](production/refinement/area-192-raster.png) | [PNG](views/area-192-grid.png) | 21 | erfüllt |
| area-208 | [PNG](production/import/area-208-raster.png) | [PNG](views/area-208-grid.png) | 10 | erfüllt |

Die 12-fache Ansicht entstand ausschließlich mit NEAREST-Vergrößerung der tatsächlichen Matrixvorschau; Gitter/Fünferlinien darüber. Kein generiertes Zahlenbild, keine nachträgliche Rasterretusche. Alle sechs sind verschieden nach Maßen/Palette/Zellwerten. Einzelbefunde: [Sichtprüfung](audit/visual-review.json). Kein Endkandidat ausgewählt.
