# A-r01 und MA-r01

| A-r01 · freigegebenes farbiges Abschlussbild | MA-r01 · monochrome Motivvorlage, Freigabe offen |
| --- | --- |
| ![A-r01](reveal/A-r01.png) | ![MA-r01](motif/MA-r01.png) |

Entfallen: Farbe, Holzmaserung, feine Schattierungen und Bodenschatten. Mähnengrooves und kleine Gesichtshighlights sind in größere Schwarz-Weiß-Formen zusammengefasst. Blickrichtung, Hauptsilhouette, Ohren, Schnauzenform, Halsbogen, Sockelproportionen und die große freie Fläche unter der Schnauze bleiben erhalten. Keine Zellansicht oder Rasterzertifizierung.
