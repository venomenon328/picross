# Schachspringer · Abstraktionsvorlage

pz-82758295d5d34284bbae2716f64f · r02 · `motif_review` · 12.10.2026 · Regelwerk 0.4.1 / Dokumentrevision 4 · Tool-/Maincommit `ee6179f6f7b6bc53f6953e2220eeeb01f060ea11`.

A-r01 ausdrücklich menschlich freigegeben, Beleg `approvals/reveal-A-r01.json`; SHA-256 `cc126391c1835f9eba7721d09bee3a3a86abfc0582785ddd75ceef170605ff89`. Originalfarbe, Details und Bytes unverändert. MA-r01 SHA-256 `21847d0e6bb804a2d3eafc5a1fc783d21166d68195cdcc11e7e9b1548c5832b0`, getrennte native Ableitung aus genau dieser Datei, tatsächlicher Aufruf in `provenance/MA-r01.json`. MA-r01-Freigabe und Endabnahme offen.

Vergleich `comparison.md`, begründete Sichturteile `visual-review.json`. Identität und wichtige Negativflächen bleiben erkennbar; Farbig-/Holzmaterialdetails, Maserung, kleine Schatten/Highlights und Groundshadow entfallen. Mähnendetails werden zusammengeführt. Beide Bilder sind quadratisch 1254×1254, keine Streckung oder nachträgliche Retusche. Schwarze/weiße Motivzeichnung, noch keine diskreten Zellwerte.

Konfigurationen `parameters.json`: 24×36 (864 Zellen, stärkste Detailreduktion), 28×42 (1176, kompakter Kompromiss), empfohlen 32×48 (1536, beste Reserve für Augen-/Ohr-/Mund- und Sockelformen), jeweils mono. Maße und späterer motivpassender Hintergrundcrop sind Vorschläge zur separaten Freigabe. Alle innerhalb 50 je Achse; keine Lösbarkeit zugesagt. Dünne Sockeltrennungen und Gesichtskonturen müssen später am echten Raster erneut beurteilt werden.

Kein gewählter Rasterkandidat, Logik-/Frame-/Proofnachweis, Schwierigkeit oder Zeitprognose. Vollständige Herkunft der Bilddateien und echte menschliche Revealfreigabe vorhanden; gesamte technische Herkunftskette erst in Produktion prüfbar. Kein ZA-1-inspect für `motif_review`, Export/Registry/Runtime unberührt. Nutzungsgrundlage: eigens beauftragte native Bildableitung ohne Fremdreferenz. Ein nativer Bildaufruf in dieser Phase, insgesamt vier; aktive Menschenzeit nicht erfasst, Probespiel optional und nicht durchgeführt.

ZIP-Inventar bindet alle Nutzdateien ohne Selbstreferenz; Inventarhash im Handoff/äußeren Record. Original-r01-ZIP/-Handoff bleiben bytegleich; Auswahlfreigabe und Fortschritt dort außen. Unausgewählte B/C nur im exakt benannten r01-Commit/ZIP belassen, keine alte ZIP eingebettet. Neues Phasenpaket mit Original-A und neuer MA-Datei, keine umetikettierte Ableitung des alten Gesamtarchivs.

Nächster erlaubter Schritt: beide tatsächlichen Bilder und den vorgeschlagenen 32×48-mono-Korridor gemeinsam vorlegen; separate ausdrückliche menschliche Motivfreigabe abwarten. Bedingter Archivmerge nach Selbstreview/ausgewählter CI erlaubt, aber keine Rasterproduktion.
