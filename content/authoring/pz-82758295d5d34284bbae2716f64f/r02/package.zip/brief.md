# Schachspringer · Abstraktion aus freigegebenem A-r01

ID `pz-82758295d5d34284bbae2716f64f`, Paket r02. Aktuelle Produkt-/Werkzeugbasis main@ee6179f6f7b6bc53f6953e2220eeeb01f060ea11; bereits geprüfte vorgelagerte Ablage PR #93@a57b2c2083cad0b782e928752b3fade8c07f337c. Main enthält noch kein Springerpaket; vorhandenen PR aktualisieren, keine Fremdarbeit übernehmen.

Der Nutzer hat am 12.10.2026 20:48:01 UTC die tatsächliche A-r01-Datei ausdrücklich freigegeben. Die Quelle wurde aus dem gespeicherten r01-ZIP geladen und mit dem angebotenen SHA-256 geprüft. Unverändertes farbiges detailliertes Abschlussbild im Paket. Menschlichen Beleg vor dem Bildaufruf zugeordnet, jetzt mit Dateihash gebunden in `approvals/reveal-A-r01.json` und außen an r01.

Auftrag: 2–3 passende Rasterkonfigurationen empfehlen, dann eine gezielte getrennte monochrome Motivvorlage aus genau A-r01 ableiten und beide nebeneinander samt Detailverlusten vorlegen. Zu bewahren: Identität, Perspektive, Bildaufbau, Hauptproportionen und wichtige Negativflächen. Links blickender Springer, beide Ohrspitzen, Schnauze/Backe, Halsbogen, Außenmähne und gestufter Sockel bleiben maßgeblich.

Empfohlen 32×48 mono; Alternativen 24×36 / 28×42. Ein schwarzer Vordergrund plus Leer. Maße/Crop und MA-r01 sind noch nicht menschlich freigegeben. Keine Rastermatrix, Hinweise, Solver-/Frameprüfung oder Schwierigkeitsschätzung. Kategorie `sport-spiele`, kein neuer Spielkatalogeintrag.

Autorisiert: Repositoryablage, Commit/Push, Draft-PR und ausdrücklich bedingter Merge nach vollständigem Diff/Selbstreview und ausgewählten Pflichtprüfungen; Main danach verifizieren. Keine Werkzeuge, Release/Deployment, Rasterproduktion. Vor jedem Rasterauftrag separate Abstraktionsfreigabe abwarten.
