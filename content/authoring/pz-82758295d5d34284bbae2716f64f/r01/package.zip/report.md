# Abschlussbildauswahl · r01

pz-82758295d5d34284bbae2716f64f · 12.10.2026 · `reveal_review` · Regelwerk 0.4.1 / Dokumentrevision 4 · Tool-/Quellcommit `ee6179f6f7b6bc53f6953e2220eeeb01f060ea11`.

| Revision | Vergleich | PNG-SHA-256 |
| --- | --- | --- |
| A-r01 | Klassisches helles Holz | `cc126391c1835f9eba7721d09bee3a3a86abfc0582785ddd75ceef170605ff89` |
| B-r01 | Kräftiges dunkles Holz | `bba5def050b224e4b11530279a78400b4028ce6ffe1728590f02be752ee4498d` |
| C-r01 | Elegante elfenbeinfarbene Figur | `a1b4326a99fc776cd304d9bdd23cb544cd2c8759885dab39f27406cb2a299b67` |

Alle drei tatsächlichen PNGs sind farbig, RGB, 1254×1254. A: klassisch und warm; B: markant und kantiger; C: heller und geschwungener. Empfehlung A für eine kompakte klassische Springerform. Alle Varianten bleiben angeboten, keine Auswahl übernommen. Native Bildgenerierung mit drei unabhängigen Aufrufen ohne Bildreferenz; tatsächliche Prompts/Einstellungen und Herkunft in `provenance/`. Keine direkten Modell-API-Aufrufe. Sichturteile je Kriterium in `visual-review.json`.

Maße/Zellzahl/Rasterpalette/Schwierigkeit/Lösungszeit offen; Rätselmodus mono, Reveal farbig. Abschlussbildfreigabe, Motivfreigabe und Endabnahme ausdrücklich offen. Kein Endkandidat, keine Matrix, Hinweise, Logik-/Rand-/Proofprüfung, Reparatur, Export oder Integration vorhanden. Für diese frühe Bildphase kein ZA-1-inspect und keine Adapterzertifizierung. Paket-Sicherheits-/Inventar-/Dateibindungsprüfung wird nach dem Schreiben des ZIPs außen dokumentiert. Das versiegelte Inventar bindet alle Nutzdateien, ohne sich oder den Handoff selbst zu hashen.

Nutzungsgrundlage: eigens beauftragte native KI-Bilder aus generischem Schachfigurenmotiv ohne Fremdbild oder Markenreferenz. Drei KI-Bildaufrufe, keine Korrekturrunde; aktive Menschenzeit nicht erfasst. Persönliches Probespielen nicht durchgeführt und optional.

Nächster erlaubter Schritt: konkrete Abschlussbildrevision mit Dateihash zur ausdrücklichen menschlichen Freigabe vorlegen und darauf warten. Anschließend Rasterkonfigurationen vergleichen; keine Abstraktion vor Freigabe. Repository-Sicherung ist keine Spielkatalogaufnahme und keine Mergefreigabe.
