# Pferd (Schachfigur) · Abschlussbildauswahl

ID `pz-82758295d5d34284bbae2716f64f`, Paket r01, Quelle main@ee6179f6f7b6bc53f6953e2220eeeb01f060ea11.
Auftrag: drei unterschiedliche farbige detaillierte Abschlussbilder eines Schachspringers im verbindlichen warmen ruhigen 2D-Illustrationsstil. Rätselmodus monochrom (`mono`); Rastermaße offen. Keine Referenzbilddatei mitgegeben. Freie Ausarbeitung der Textidee, keine vorbestehende Bildfreigabe.

Unverzichtbar: deutlich als Schachfigur lesbarer Pferdekopf mit Mähne, Ohr/Auge/Schnauze, gebogener Hals und gedrehter gestufter Sockel. Alle Teile vollständig sichtbar; ruhiger Hintergrund, klare Konturen und zusammenhängende Farbflächen. Keine Zellgrafik, Hinweise, abstrahierte Motivvorlage oder Rasterproduktion.

Kategorie: `sport-spiele` (Sport & Spiele), weil der Hauptgegenstand eine Spielfigur ist; keine Tierkategorie nur wegen Pferdeform.

Nach ausdrücklicher Freigabe genau einer konkreten Abschlussbildrevision werden passende Rasterkonfigurationen empfohlen. Erst ein weiterer passender Auftrag erlaubt die daraus abgeleitete Motivvorlage; vor eigentlicher Rasterproduktion separate menschliche Motivfreigabe. Regulär höchstens 50 je Achse. Keine Lösbarkeit oder Schwierigkeit behauptet.

Autorisiert: schlanke Repositoryablage, Commit/Push und Draft-PR. Kein Spielkatalogeintrag, Werkzeugänderungen, Merge, Release oder Deployment. Alle Freigaben bleiben offen. Fortschritt und spätere Erklärungen ausschließlich außerhalb des versiegelten ZIPs führen.
