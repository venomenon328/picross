# Tatsächlicher Bild- und Rastervergleich

[A-r01](reveal/A-r01.png) bleibt unveränderte Referenz; [MA-r02](motif/MA-r02.png) bleibt die freigegebene vereinfachte Quelldatei. [Direkter Dreifachvergleich](views/reveal-motif-raster-comparison.png), [erste vier Raster](views/candidate-comparison.png), [zwei begründete Ergänzungen](views/additional-comparison.png).

Endauswahl [area-160 in Zellauflösung](production/import/area-160-raster.png), [16-fach ohne Glättung](views/area-160-nearest.png), [mit Gitter](views/area-160-grid.png). Alle Bilder stammen aus tatsächlichen Matrizen; keine generierten Rätselzahlen oder Bildattrappen. Die Kontaktansicht skaliert nur zur Betrachtung; Originaldateien und ihre Hashes bleiben erhalten.

Die sechs Raster bewahren Kopfneigung, Schnauzenöffnung, Halsbogen, Außenmähne und gegliederten Sockel. area-160 erhält den oberen Konturpunkt und ausgewogene Breite besser als 96/128; 192 wirkt voller, die zwei Cropverschiebungen lösen die Ohrtrennung nicht. Die Zusammenführung der Ohrspitzen ist eine materielle Abstraktion: vor Freigabe als Korrekturbedarf behandelt, dann tatsächlich für exakt area-160 menschlich freigegeben. Keine neue Zelländerung, Motivdatei oder Abschlussbildrevision.

Alle fünf Stylekriterien je Darstellung in [Sichtprüfung](visual-review.json), Auswahlgründe/Matrixvergleiche in [Kandidatenübersicht](audit/candidate-summary.json). Endabnahme wird damit nicht vorweggenommen.
