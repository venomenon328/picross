# Schachspringer – Produktionsauftrag r05

ID `pz-82758295d5d34284bbae2716f64f`, Quelle `main@542ba6237a8a962774b23abb195b000b079199a7`, Kategorie `sport-spiele`. Aktuelles Regelwerk 0.4.1 / Dokumentrevision 4. Über den Index eindeutig r04 geladen. A-r01 bleibt bytegleich freigegebene farbige Referenz; MA-r02 bleibt bytegleich native Silhouettenableitung.

Aktueller Produktionsauftrag umfasst deterministischen Import, vier gezielte Kandidaten und höchstens zwei begründete Ergänzungen, Herkunft, Hinweise, vollständige deduktive Lösung, unabhängige Nachweisprüfung, echte Rasteransichten, Motivvergleich, L1–L5-Schätzung und schlanke Ablage zur Endabnahme. Reine Inhalts-CI; keine Werkzeuge/Unit-Tests/Replayfälle ergänzen. Archivmerge ausdrücklich nach vollständigem Diff/Selbstreview und allen ausgewählten Pflichtchecks beauftragt. Kein Spielkatalogeintrag, Release oder Deployment.

Tatsächliche neue MA-r02-Freigabe für 24×36 mono und unverzerrten Leerraum-Crop: `approvals/motif-statement.json`. Unverändert zu bewahren: Identität, linke Perspektive, Hauptproportionen, Schnauzenfreiraum, Halsbogen und gestufter Sockel. Binnenzeichnung darf entfallen. Nach Vergleich aller sechs echten Raster akzeptiert der Mensch die zusammenlaufenden Ohrspitzen **ausschließlich für area-160** mit Matrixhash `6322a2e0a2b55b4fdde62b0bb9256acf6235b5d581d120b13113d9e89c96878f`; Beleg `approvals/ear-contour-statement.json`. Keine stillschweigende Lockerung auf andere Varianten.

Maße 24×36 (864 Zellen), eine Vordergrundfarbe plus Leer. Gewählter Crop `[215,11,1021,1220]` enthält die gesamte dunkle Silhouette, 806×1209 = 2:3, kein Strecken oder motivfremdes Randpixel. Exakte Koordinaten sind KI-Umsetzung der tatsächlich freigegebenen Leerraum-Cropklasse, kein erfundenes menschliches Koordinatenzitat. Zwei Zusatzcropps ebenso nur Außenhintergrund. Keine Reparatur erforderlich.

Endabnahme bleibt gesondert offen. Originalpakete r01–r04 nicht ändern oder neu packen; Fortschritt/Freigaben außerhalb versiegelter ZIPs. Neues Paket r05 bindet alle erforderlichen neuen Bündel vollständig.
