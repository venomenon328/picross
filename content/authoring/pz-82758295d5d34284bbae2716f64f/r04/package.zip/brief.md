# Schachspringer · Silhouettenkorrektur

ID `pz-82758295d5d34284bbae2716f64f`, Paket r04, neue Motivdatei MA-r02. Quelle `main@bc3286050a35cdbdd3b5fe5e6274255228517aaa`. Aktuelles Regelwerk 0.4.1 / Dokumentrevision 4 und schlanke Inhalts-CI vorhanden. Vorhandenes Produktionspaket r03 über den Mainindex aufgelöst, vollständige tatsächliche ZIP-/Handoff-/Inventar-/Bildbindungen geprüft. Keine Bestands-Proof-Replays, keine Produktionsrunde fortgesetzt.

Menschlicher Korrekturauftrag vom 12.10.2026 22:54:08 UTC: Gesichtsdetails müssen nicht erhalten bleiben, Silhouette steht im Vordergrund. Direkt aus genau dem farbigen freigegebenen A-r01 ableiten; Original nicht ändern. Neues MA-r02 braucht ausdrückliche neue menschliche Motivfreigabe, alte MA-r01-Freigabe darf nicht übertragen werden. Modus monochrom; zuvor freigegebener Rasterkorridor 24×36 bleibt unverändert, jetzt keine Rasterproduktion.

Zu erhalten: Identität der Schachfigur, linke Seitenperspektive, Bildaufbau, Hauptproportionen, beide Ohrspitzen und ihre äußere Trennung, große freie Fläche unter der Schnauze, Halsbogen und gestufter Sockel. Erlaubt: Auge/Nüster/innere Mundzeichnung, Ohrinnenflächen, innere Mähnen-/Hals-/Sockellinien vollständig zugunsten einer geschlossenen schwarzen Silhouette entfernen. Keine motivfremden Randpixel, kein Raster, keine Hinweise.

Kategorie `sport-spiele`. Autorisiert: schlanke Ablage, Commit/Push, Draft-PR und bedingter Merge nach vollständigem Diff/Selbstreview und allen ausgewählten Pflichtchecks; main danach tatsächlich verifizieren. Keine Werkzeugänderungen, Spielkatalogaufnahme, Release oder Deployment.
