# A-r01 und MA-r02

| A-r01 · freigegebenes unverändertes Abschlussbild | MA-r02 · neue Silhouettenvorlage, Freigabe offen |
| --- | --- |
| ![A-r01](reveal/A-r01.png) | ![MA-r02](motif/MA-r02.png) |

MA-r02 fasst die Schachfigur zu einer geschlossenen schwarzen Silhouette zusammen. Auge, Nüster und innere Mundzeichnung, Ohr-/Mähnen-/Hals-/Sockel-Binnenlinien entfallen. Erhalten bleiben linke Perspektive, beide Ohrspitzen und ihre äußere Trennung, freie Fläche unter der Schnauze, Halsbogen und die Außenform des gestuften Sockels. Kein Raster, keine Hinweise oder Lösbarkeitszusage.
