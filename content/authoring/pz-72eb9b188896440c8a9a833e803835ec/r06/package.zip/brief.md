# Koboldmaki · Farbkorrektur MA-r03 · Paket r06

Neue tatsächliche Nutzerentscheidung: zurück zu Schritt3, mehr Farben als r05 und klare Trennung von Ast und Tier, Farben für Spieler deutlich unterscheidbar. Beleg: color-correction-decision.json.
Vorschlag vier Rollen: warmes orangebraunes Tier, dunkleres blaugraues Astobjekt, hellcreme Innenflächen, fastschwarze Konturen/Pupillen. Keine zusätzliche nahe Irisfarbe.
MA-r03 ist die konkrete neue Motivdatei. Pose/Perspektive/Silhouette/Greiflage/Freiräume bleiben; B-r01 bytegleich. Astfarbe in der Abstraktion bewusst kühler als natürliche Revealfarbe.
Empfehlung26×38, Alternative24×35. Neue Vierfarbrollen/Kandidaten vollständig in parameterkorridor.json. Keine alte Freigabe auf neue Bildbytes übertragen; vor neuem Import ist MA-r03 konkret freizugeben.
Alte r05-Originale und Proofs bleiben unverändert unter main@8577f707038d410672032765fa09b711b5b5b5a2; keine Wiederholung alter Rätselprüfungen oder eingebetteten alten ZIPs.
