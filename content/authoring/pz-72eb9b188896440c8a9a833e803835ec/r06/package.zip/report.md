# Koboldmaki · r06 · neue Motivfreigabe erforderlich

16.10.2026 · ID `pz-72eb9b188896440c8a9a833e803835ec` · `motif_review` · Regelwerk0.5.0/rev14 · Toolcommit `8577f707038d410672032765fa09b711b5b5b5a2`. Inventarhash im Handoff/äußeren Record.

**Neue Vorgabe:** Der Nutzer verlangt Rückkehr zu Schritt3, mehr Farben zur klaren Differenzierung von Ast/Körper und deutlich unterscheidbare Endfarben. [Tatsächliche Erklärung](color-correction-decision.json). r05 ist damit keine aktuelle Endabnahmevorlage; Originale bleiben unverändert erhalten.

**Konkrete Farbkorrektur:** [MA-r03](MA-r03.png), per eingebauter nativer Bildbearbeitung aus MA-r02 und unverändertem [freigegebenem B-r01](B-r01.png). Pose, Kopfneigung, Augen/Pupillen, große Ohren, Oberschenkelbogen, offene Greifräume, derselbe diagonal steigende Ast und S-Schwanz erhalten. Körper/Hände/Füße/Schwanz warm orangebraun, Ast durchgehend dunkleres Blaugrau; Gesicht/Bauch/Ohrinneres hellcreme, Konturen/Pupillen fastschwarz. Iris teilt Fellfarbe. Kühler Ast in der Abstraktion ist eine explizite Objekttrennung; im detaillierten Reveal bleibt er natürlich braun. [Originalprompt](motif-color-prompt.txt), [Provenienz](MA-r03.provenance.json), [Bildreview](visual-review.json).

**Vier statt drei geplante Farben:** Keine fünfte nahe Iris-/Schattenfarbe. Farbton und Zielhelligkeit unterscheiden die vier Rollen. [Farbprüfung](color-review.json) führt die sRGB-Zielhelligkeiten und die visuelle Prüfung, ohne erfundene Pflichtgrenze oder Barrierefreiheitszusage. Keine Farbsinnsimulation/Menschenprobe. Die tatsächliche Farbenverwendung und Unterscheidbarkeit im Zellraster müssen nach Freigabe geprüft werden; die generierte Quelle enthält leichte Tonvariation/Kantenglättung und ist keine diskrete Vierfarbenmatrix.

**Parameter/Prüfplan:** Empfehlung26×38, zulässige kompaktere Alternative24×35; vier Vordergrundrollen, Vollcrop1024×1536/contain/area. [Korridor](parameterkorridor.json) mit vier formal validierten, noch nicht importierten Designs: zwei Größen×direkte bzw. leicht versetzte Palettenanker. Kein Raster/Proof/Schwierigkeitsgrad für MA-r03 erzeugt oder behauptet. Keine Wiederverwendung der alten L5-Zertifizierung für neue Farben. Nach echter Motivfreigabe vollständige neue Herkunfts-/Hinweis-/Proof-/Endmatrix-/Farb-/Rand-/Gestaltungsprüfung.

**Freigaben/Zielstatus:** B-r01 weiterhin gültig freigegeben. Der Korrekturauftrag autorisiert die konkrete Überarbeitung, erteilt aber keine vorweggenommene Freigabe unbekannter MA-r03-Bytes. Neue Motivfreigabe und Endabnahme offen. Kein ZA-1-inspect in dieser frühen Bildphase, kein Export/Registrierung/Spieltest/Build. Nur beauftragte Repositoryablage samt Pflichtchecks/bedingtem Merge. Eigene KI-Projektbilder, keine Fremdbildbytes. Ein neuer Bildaufruf, insgesamt6; aktive Menschenzeit nicht erfasst.

**Nächster Schritt:3 · Motiv freigeben & produzieren** – MA-r03 samt diesem vorgeschlagenen Vierfarbkorridor konkret freigeben; erst dann neue Rasterproduktion. Regelwerksgrund:§2.4 „Vor jeder eigentlichen Rasterproduktion MUSS die konkrete abstrahierte Motivdatei freigegeben sein“.

