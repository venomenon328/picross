# Koboldmaki · Korrekturvorlage MA-r02 · Paket r04

Standardauftrag3 auf main@7910f4cdcaf904e7c28395dc2e61e5f3ebe76035 lieferte in r03 technische Zertifizierung, aber B-PZ72-V01: geschützte Greif-Freiräume/Oberschenkelkontur gingen in allen vier Rastern verloren. Die tatsächliche Endabnahmevorlage blieb dadurch unerreicht.
MA-r02 ist die konkrete neue Korrekturvorlage. Gleiche Pose, Perspektive, Ast, S-Schwanz und Größen-/Palettenplanung; verstärkte dunkle Konturen und vergrößerte bestehende Freiräume. Keine Rasterproduktion aus dieser unfreigegebenen Datei. r03 bleibt unverändert unter Commit51bf7ce3bb654f72207a5aa50be40c79ba87a282 und im selben Ablage-PR erhalten.
Nötig: menschliche Freigabe von MA-r02 samt parameterkorridor.json, danach vollständige Neuimporte/-nachweise. Keine alte MA-r01-Freigabe auf neue Bildbytes übertragen.
