# Codex-Übergabe · Standardauftrag 3

Status: durch noch ausstehende ausdrückliche Motivfreigabe blockiert.
Dieser Datensatz ist keine solche Freigabe und startet keine Rasterproduktion.
Nach menschlicher Freigabe von MA-r01 samt parameterkorridor.json ist folgendes
zusammenhängende Produktionspaket vorgesehen. Bevorzugter Ausführungsweg: Codex.
Die aktuelle Umgebung besitzt Bild-, Datei-, Werkzeug-, Commit- und GitHub-CI-Zugriff;
eine Modell-/Reasoning-Empfehlung wird nicht allein wegen offener manueller Abnahme erzeugt.

```text
Arbeite in venomenon328/picross@main, zuerst AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Lade pz-72eb9b188896440c8a9a833e803835ec/r02 über content/authoring/index.json und prüfe die Dateibindungen.
Nur nach tatsächlicher Nutzerfreigabe: MA-r01.png samt parameterkorridor.json binden und Standardauftrag 3 bis Endraster, Pflichtprüfungen, Schwierigkeit und content_ready-Paket zur Endabnahme ausführen.
B-r01 ist ausdrücklich freigegeben; Originalbytes und Herkunft erhalten. Vier Kandidaten gemäß Designs: 24×35 und 26×38, jeweils 3/4 Farben, vorlagentreu und ohne Streckung.
Repositoryablage nach §6 sowie Ablagemerge nach erfolgreichen Pflichtchecks sind beauftragt. Endabnahme und Spielintegration bleiben Standardauftrag 4 vorbehalten.
```

Keine neue Konfigurationsrunde nötig, falls genau der vorgelegte Korridor freigegeben wird.
Unabhängige Proofprüfung und gezielte Reparatur folgen dem aktuellen Regelwerk, keine
rätselspezifischen Unit-Tests oder Bestandsreplays. Keine alten Pakete umschreiben.
