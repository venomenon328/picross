# Koboldmaki · Motivvorlage MA-r01 · Paket r02

Nutzer wählte und gab B-r01 am 16.10.2026 ausdrücklich frei. Originalbytes bleiben unverändert.
Freigabe: reveal-approval.json, Erklärung: user-reveal-approval.md, Originalhash 38ae36da53346a92ef6d9bccb1146ccf8a152593594405ce28d0a7d1d40322ea.
Quell-/Werkzeugstand 15e54e3e35794edd1d34b18fbdaab17ccea780a3, Regelwerk 0.5.0 Dokumentrevision 14.
Kategorie saeuger. Gewünscht offene Breite × ungefähr 35 Zellen, farbig, Farbzahl offen.

MA-r01 wurde per nativer Bildbearbeitung mit genau B-r01 als gespeicherter Referenz abgeleitet.
Empfehlung 24×35 mit vier Vordergrundfarben; zweite mögliche Größe 26×38.
Dreifarbige Alternative wird im selben Vierer-Vergleich statt zusätzlicher Matrixsuche geprüft.
Konkrete Vorgaben, unverzichtbare Merkmale und Grenzen: parameterkorridor.json.
Nach Bildauswahl gilt vorlagentreue Ableitung (`faithful`); kein Wechsel der Pose oder Perspektive.

Noch keine Motivfreigabe. Vier vorbereitete Designs wurden nur formal validiert, nicht importiert.
Keine Raster-, Hinweis-, Proof-, Schwierigkeits- oder Zielintegrationsergebnisse vorhanden.
Die Bildquelldatei ist kein diskretes Lösungsraster und kein Farbzahlnachweis.
Vollständige Codex-Übergabe: CODEX_HANDOFF.md, Bildvergleich: comparison.html.
