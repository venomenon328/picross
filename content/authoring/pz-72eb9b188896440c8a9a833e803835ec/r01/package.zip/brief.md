# Koboldmaki · Abschlussbildauswahl r01

Auftrag: Standardauftrag 1 nach docs/ai-workflows/PUZZLE_AUTHORING.md auf main.
Motivtext: Koboldmaki. Freie Motivübertragung (`free`), keine Bildreferenz vorgegeben.
Rasterbreite offen, Rasterhöhe ungefähr 35 Zellen. Farbig; Vordergrundfarbzahl offen.
Kategorie: saeuger (Säugetiere), prägender Hauptgegenstand ist das Tier.

Identitätsmerkmale: zwei sehr große runde Augen mit dunklen Pupillen, große dünne Ohren,
kurze Schnauze, kleiner Körper, lange Greiffinger/-zehen und langer schlanker Schwanz.
Einzelnes Tier mit tragendem Ast/Stamm vor ruhigem hellem Hintergrund.
Warme handgezeichnete 2D-Illustration, eigenständige Farbflächen und Binnenzeichnung.
Pose, Proportionen, Astgeometrie und Schwanzführung der später ausgewählten Datei
werden zur Bindung der Abstraktion. Keine Abstraktion oder Rasterproduktion vor Bildfreigabe.
Feine Fellstriche, Fingerfalten und Rindendetails dürfen später zusammengefasst werden.
Höhenwunsch und offene Breite sind keine bereits genehmigte konkrete Konfiguration.

Quelle: native image_gen.imagegen, drei getrennte Aufrufe; keine Fremdbildbytes verwendet.
Prompts und tatsächlich sichtbare Einstellungen: prompts.json. Weitere Modell-/Seedparameter nicht offengelegt.
Nutzungsgrundlage: im Nutzerauftrag KI-erzeugte Originalbilder für dieses Projekt;
keine Fremdassets, Zeichen oder Künstlerreferenzen eingebunden. Keine menschliche Endfreigabe behauptet.

Autorisierung: Repositoryablage nach §6 einschließlich Commit/Push/PR und bedingtem
Merge nach Pflichtchecks ist ausdrücklich beauftragt. Keine Bild-, Motiv- oder Endfreigabe erteilt.
Eine spätere Spielintegration bleibt an Standardauftrag 4 und tatsächliche Endabnahme gebunden.
