# Koboldmaki · Produktionspaket r05

Standardauftrag3 aus r04@8dfe9665acf877e84f36ca8e09393eb1113fbd8a. Tatsächliche Freigabe von MA-r02 samt Parameterkorridor im Nutzerauftrag; Beleg motif-approval.json. B-r01 bleibt freigegeben und bytegleich. Kategorie saeuger.
Freigegeben sind24×35 oder26×38, jeweils3/4 Farben, vollständiger Crop/contain, keine Pose-/Motivänderung. Palette besitzt bevorzugte RGB-Werte und Rollen, keine exakte RGB-Zwangsvorgabe; die zwei begründeten Zusatzvarianten bleiben innerhalb derselben Dimensionen/Farbrollen.
Sechs gezielte Rasterhypothesen, keine blinde Suche. Auswahl26×38/3 tatsächlich verwendete Farben, unbenutzte amber-ID vor Versiegelung entfernt und vollständig neu importiert/geprüft. Keine Reparatur und keine handgeänderte Matrix.
Alle technischen/visuellen Inhaltsgates bestanden, content_ready; menschliche Endabnahme separat offen. Keine Spielregistrierung durch diesen Ablageauftrag.
