# Klauenhammer · Produktionsprüfung r03

pz-22969714393847e697e8169a8b688efd · 2026-10-29T15:24:03Z · **blocked / VIS-01** · Authoring 0.5.0/rev25 · Toolcommit `d0929cf44ba0f67ff138d020d4a864de583d6266`. Inventarhash: handoff.json/record.json.

A-r01 ist weiterhin freigegeben und unverändert; M-r02 samt parameters.json ist durch die tatsächliche Nutzererklärung in approvals/motif.json freigegeben. Endauswahl/Endabnahme offen. **Keine Endabnahmevorlage möglich:** In allen vier zulässigen Direktimporten fehlt der geschützte offene Spalt zwischen zwei Klauen. Kein freigabefähiges Rasterangebot; siehe comparison/candidates.png und decisions.json.

| Kandidat | Zellen / gefüllt | Logik | Visuelle Entscheidung |
| --- | --- | --- | --- |
| 9×16 / area-128 | 144 / 34 | solved, 30 Schritte | Verworfen: diagonale Einzelklaue, dünner Griff |
| 9×16 / area-176 | 144 / 48 | solved, 32 Schritte | Verworfen: gemeinsamer Haken, kein Klauenspalt |
| 10×18 / area-128 | 180 / 45 | solved, 30 Schritte | Verworfen: gebogene Klauenform verschwindet weitgehend |
| 10×18 / area-176 | 180 / 53 | solved, 32 Schritte | Verworfen: gemeinsamer Block am rechten Kopfauslauf |

Alle vier Matrizen sind verschieden. Maße, Palette, Quelle, Crop und Importparameter entsprechen exakt der Motivfreigabe. Wunsch/Ist: Mono, genau **1** Vordergrundfarbe (ink, Schwarz) ohne Leer. Flächenanteile 23,6/33,3/25,0/29,4 %. Rechte Leerspalte ist durch proportionale Einpassung begründet; kein Anlass zu Fremdpixeln. Alle vier erfüllen die Randformel: links, oben und unten belegt, rechts leer. Einzelne diagonale Klauenpixel sind visuell problematisch, keine weiche Ausnahme zugunsten der Logik.

checks/09x16.json und checks/10x18.json belegen in frischen Prüferprozessen vollständige Quellen-/Normalisierungsrekonstruktion, alle Manifestdateien, exakt neu abgeleitete Hinweise und Rasterpixel, unabhängigen **full-line-mono**-Proof vom unbekannten Start und identische Singleton-Endmatrix. Dies beweist jeweils auch Eindeutigkeit. Kein Raten, keine Startfelder. Budgets vorab 120 s / 100000 Linien je Kandidat und Prüfer; kein Abbruch. Kein Paar-/Diagnosesuchlauf nötig.

Sichtprüfung groß mit Gitter, ungeglättet und als echte Zellvorschau: Hammergrundform und ruhige Mono-Lesbarkeit bleiben; Kopf-/Klauendetail **verfehlt**, Silhouette/Erkennbarkeit **Korrektur nötig**. A-r01 und M-r02 selbst erfüllen Erkennbarkeit, Proportionen, Details/Negativräume, Palette und Serienästhetik unverändert; tatsächlicher Bildvergleich comparison/reveal-motif.png. Ausführliche Einzelurteile: decisions.json. Materialzeichnung/Farben bleiben ausschließlich im unveränderten farbigen Reveal. Nutzungsgrundlage und native Prompts liegen unter images/ und prompts/; Ursprungskette zusätzlich checks/source-chain.json.

**Reparaturentfall:** Kein visuell tragfähiger Kandidat mit dem geschützten Identitätskern. Nach §4.4 zuerst Abstraktion/Größe korrigieren; keine Motivänderung oder neue Rasterparameter erfinden. Alle vier sind bereits logisch gelöst. Keine Suchrunde, keine Zelländerung, kein Reparaturdiff. Schwierigkeit nicht erzeugt: es gibt keine geeignete finale Matrix für §5.2; keine Ersatznote/Empfehlung. Bearbeitungsumfang 144 oder 180 Zellen; menschliche Zeit nicht erfasst, Lösungszeit nicht geschätzt, Probespiel optional/nicht durchgeführt.

Keine technische ZA-1-Inspektion als content_ready-Eingang: blockierter Produktionsstand ohne Endkandidat. ZIP-/Inventar-/Handoff-/Pfadprüfung erfolgt auf geschriebenen Bytes; Beleg im Ablage-PR. Kein Export, keine Registrierung, keine native Spielprobe erforderlich. Repositoryablage ist keine Produktabnahme; der Ablagemerge behebt VIS-01 nicht. Ursprüngliche r01/r02-Pakete bleiben unangetastet.

Nächster erlaubter Schritt: **Korrigieren oder Fehler beheben** – M-r02 mit deutlich breiterem offenem Klauenspalt überarbeiten und die konkrete neue Motivdatei freigeben lassen; falls nötig größeren konkreten Größenkorridor entscheiden. A-r01 erhalten.
