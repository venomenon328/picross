# Klauenhammer · Korrektur VIS-01

pz-22969714393847e697e8169a8b688efd · r04 · Kategorie werkzeuge-handwerk.

Quelle r03 auf main@7ea5d00699471b4486a1ab859bb3b8fec1ca87c1 ist geprüft. Tatsächlicher Korrekturauftrag samt Klärung: approvals/correction-evidence.txt. Beauftragt ist breiterer offener Klauenspalt; bei Bedarf größeren Korridor vorschlagen. Keine Freigabe der geänderten Fassung. A-r01 bleibt unverändert und verbindlich. M-r04 ist eine neue direkte Mono-Ableitung mit breiterer Öffnung; 20×36 empfohlen, 22×40 Reserve. Nur diese konkreten neuen Kombinationen sind vorgeschlagen, keine freie Intervallfreigabe. Invarianten und technische Parameter in parameters.json.

Nächste notwendige menschliche Entscheidung: Motivdatei M-r04 samt neuem Korridor freigeben. Vorher keine Raster-/Hinweisproduktion, kein Solver, keine Schwierigkeit oder Integration. Repositoryablage samt bedingtem Ablagemerge ist beauftragt.
