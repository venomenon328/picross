# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: b27970bb05c8970b54ab95dd210b25bd64a9c16d468f07e67b5f060062ab3661
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 141/68 |
| search | 5437/5104 |
| workload | 1/4 |

Score: 294037/86768; level: 4 / 5.
Without workload: 272345/86768; level: 4.
Lower boundary: 3; distance: 33733/86768.
Upper boundary: 4; distance: 53035/86768.
Nearest boundary distance: 33733/86768.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
