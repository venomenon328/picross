# Klauenhammer · Standardauftrag 1

Datum 2026-10-29T09:50:27Z · ID `pz-22969714393847e697e8169a8b688efd` · r01 · Status `reveal_review` · Regelwerk 0.5.0, Dokumentrevision 23 · Quellen-/Toolcommit `5c56b2add52c993ee3e07e9d84b22818bf6ca4ee`. Inventar und seine Bindung stehen in inventory.json / handoff.json.

| Variante | Ausführung | Vergleich |
| --- | --- | --- |
| A-r01 | Klassischer Holzstiel, nahezu aufrecht | Empfohlen: wenig diagonaler Platzverbrauch und klarer Kopf-Stiel-Aufbau für etwa 10 × 15 Mono. |
| B-r01 | Moderner roter Griff, geneigt | Klarer Farbakzent im Reveal; die spätere Mono-Abstraktion muss ohne die Farbtrennung auskommen. |
| C-r01 | Dunkler Holzstiel, Gegenrichtung | Charaktervoll; Schräglage beansprucht bei nur zehn Spalten mehr Breite als A. |

Empfehlung **A-r01**, keine Auswahl/Freigabe durch den Agenten. Alle drei Einzeldateien liegen unverändert unter images/. paper-review.png ist ausschließlich die statische Auswahl-/Transparenzhilfe auf dem vorhandenen Projektpapier, groß sowie in 112/140 Pixel hohen Bildräumen (UI100/125).

| Bild | Erkennbarkeit | Silhouette/Proportionen | Details/Negativräume | Palette/Mono-Lesbarkeit | Serienästhetik |
| --- | --- | --- | --- | --- | --- |
| A-r01 | erfüllt: vollständiger Klauenhammer | erfüllt: Kopf, Klaue und langer Stiel klar | erfüllt: zwei Klauen und offener Spalt | erfüllt: Stahl und Griff klar getrennt; Mono-Raster noch offen | erfüllt: gezeichnete Kontur, ruhige Farbflächen, Materialdetails |
| B-r01 | erfüllt: vollständiger Klauenhammer | erfüllt: Kopf, Klaue und langer Stiel klar | erfüllt: zwei Klauen und offener Spalt | erfüllt: Stahl und Griff klar getrennt; Mono-Raster noch offen | erfüllt: gezeichnete Kontur, ruhige Farbflächen, Materialdetails |
| C-r01 | erfüllt: vollständiger Klauenhammer | erfüllt: Kopf, Klaue und langer Stiel klar | erfüllt: zwei Klauen und offener Spalt | erfüllt: Stahl und Griff klar getrennt; Mono-Raster noch offen | erfüllt: gezeichnete Kontur, ruhige Farbflächen, Materialdetails |

PNG-Dekodierung, Ressourcengrenzen, Alpha-Außenflächen und sichtbarer Klauenspalt sind geprüft (image-checks.json). Statische Papiersichtung: vollständige Motive, erhaltene helle Stahlreflexe, keine auffälligen Säume. Dies ist keine native Spiel-, Katalog- oder Überblendungsprüfung. Sehr feine Textur und Klauenspalt werden bei 10 × 15 Zellen eine gezielte spätere Vereinfachung benötigen; Größe und Lösebarkeitsrisiko werden nach der gewählten Vorlage beurteilt.

Gewünschtes Raster: ungefähr 10 × 15 = 150 Zellen, Mono mit genau einer Vordergrundfarbe plus Leer. Tatsächliche Matrixmaße, verwendete Rasterfarben, Randregel, Hinweise, Logik-/Eindeutigkeitsnachweis, unabhängiger Proof, Herkunftsrekonstruktion bis zur Matrix und Schwierigkeit: **noch nicht vorhanden**, in Auftrag 1 nicht prüfbar. Keine Lösbarkeitszusage. Keine Import-/Reparaturversuche; keine Rasterproduktion in dieser Phase. Lösungszeit nicht geschätzt, menschliches Probespiel nicht durchgeführt (optional).

Herkunft/Nutzungsgrundlage: provenance.json; tatsächliche Prompts/Einstellungen: prompts.json (nicht sichtbare Parameter als not_exposed). Drei native Bildaufrufe in einer Runde; keine Korrektur, keine Fremdbildreferenz, Menschenzeit nicht erfasst.

Abschlussbildfreigabe, Motivfreigabe, Endabnahme und Zielintegration sind offen. ZIP-/Inventar-/Handoffprüfung erfolgt nach dem Schreiben; Repository-/CI-/Mergebelege werden im Ablage-PR geführt. Diese frühe Bildphase ist kein ZA-1-Adaptereingang und behauptet keine Adapterzertifizierung. Pflicht-CI nutzt ausschließlich den schlanken Inhaltspfad, keine rätselspezifischen Tests oder Spielerbuilds.

Nächster erlaubter Schritt: **2 · Bild freigeben & abstrahieren**. Nutzer gibt eine konkrete Variante A-r01, B-r01 oder C-r01 frei; Originaldatei und SHA-256 stehen in decisions.json und handoff.json. Danach Standardauftrag 2 nach aktuellem Workflow ausführen.
