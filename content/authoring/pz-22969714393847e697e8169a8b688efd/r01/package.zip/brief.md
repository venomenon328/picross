# Klauenhammer · Abschlussbildauswahl

ID `pz-22969714393847e697e8169a8b688efd` · r01 · Standardauftrag 1 · `reveal_review`.

Auftrag und Wortlaut stehen in request.txt. Gewünscht sind ungefähr 10 × 15 Zellen, monochrom; Mono bedeutet genau eine Vordergrundfarbe plus Leer. Die Abschlussbilder sind unabhängig davon farbig. Kategorie: `werkzeuge-handwerk` (Werkzeuge & Handwerk), nach dem prägenden Hauptgegenstand.

## Motivkern und Gestaltungsrahmen

Ein einzelner vollständiger Klauenhammer mit einer flachen runden Schlagfläche, kurzem Stahlkopf, deutlich rückwärts gebogener gespaltener Nagelklaue und langem verbundenem Stiel. Der freie Spalt zwischen beiden Klauen ist ein charakteristischer Negativraum. Keine Hände, Nägel, zusätzliche Werkzeuge, Schrift, Marken oder Umgebung. Freie Interpretation (`free`) ohne bindende Fremdreferenz.

Warme ruhige ausgearbeitete 2D-Illustration mit klarer dunkler Kontur, Materialzeichnung und zurückhaltender Schattierung. Neutrale Außenflächen und der tatsächliche Klauenspalt sind transparent. Lichtreflexe auf Stahl bleiben Motivbestandteile.

Die drei Kompositionen berücksichtigen die kleine Zielgröße; noch keine Motivabstraktion oder Zellmatrix. Nach einer konkreten Bildfreigabe darf die gewählte Darstellung motivtreu vereinfacht werden. Orientierung, Hauptproportionen, Kopf-Stiel-Verbindung und Klauenöffnung bleiben für die weitere Ableitung maßgeblich. Der genaue Parameterkorridor wird erst mit der Motivvorlage vorgeschlagen.

## Befugnis und Halt

Beauftragt: drei Abschlussbilder, Paket-/Indexsicherung nach §6, Commit/Push, Ablage-PR und dessen bedingter Merge nach Pflichtprüfungen. Offen: tatsächliche Auswahl und menschliche Freigabe des konkreten Abschlussbilds. Keine Bildfreigabe aus dem Ablageauftrag ableiten. Standardauftrag 2 beginnt erst mit dieser Freigabe. Logik, Eindeutigkeit, Randregel, Schwierigkeit und Spielintegration sind in dieser Phase noch nicht geprüft.
