# Klauenhammer · Standardauftrag 2

2026-10-29T14:12:02Z · `pz-22969714393847e697e8169a8b688efd` · r02 · `motif_review` · Authoring 0.5.0 / Dokumentrevision 24 · Quellen-/Toolcommit `47155d998e3592414ad67f9d5066820ca6b2251d`. Inventarhash steht in handoff.json/record.json.

**A-r01 ist ausdrücklich menschlich freigegeben**, exakt gebunden an das unveränderte Originalpaket und Bild (approvals/reveal.json). Daraus entstand in einem nativen Editaufruf **M-r02**, eine schwarze transparente Silhouette. Beide Dateien und Vergleich: images/ und comparison/reveal-motif.png. Keine Rasterproduktion.

**Empfehlung 9 × 16**, Reserve **10 × 18**. Wunsch war ungefähr 10 × 15. Der vollständige Alpha-Crop [109, 56, 882, 1475] ist proportional schmaler: contain ergibt bei 10 × 15 eine Bildfläche 8 × 15 und zwei leere Außenspalten, daher ungeeignet für die Randregel. Bei 9 × 16 ergibt die reine Einpassgeometrie 8 × 16 mit nur einer rechten Leerspalte, bei 10 × 18 entsprechend 9 × 18. Das ist keine Behauptung bereits belegter gefüllter Rasterränder. 144 Zellen bleiben nahe am 150-Zellen-Wunsch. Genau Mono/1 plus Leer; verwendete Matrixfarben erst in Auftrag 3 zählen.

| Darstellung | Erkennbarkeit | Silhouette/Proportionen | Details/Negativräume | Palette/Mono-Lesbarkeit | Serienästhetik |
| --- | --- | --- | --- | --- | --- |
| A-r01 | erfüllt: Klauenhammer | erfüllt: unverändertes freigegebenes Original | erfüllt: runde Schlagfläche, zwei Klauen | erfüllt: farbiges Reveal | erfüllt: ruhige Kontur und Materialzeichnung |
| M-r02 | erfüllt: markanter Hammerkopf mit langem Griff | erfüllt: Richtung und Hauptproportionen bewahrt, Kontur verdichtet | erfüllt: zwei gebogene Klauen und offener Spalt zeichnerisch erhalten | erfüllt: schwarze Positivform und transparente Leerfläche | erfüllt: klare ruhige Vereinfachung desselben Motivs |

Verluste: Holzmaserung, Farbtrennung, Metallreflexe, Binnenellipse und feine Stahlzeichnung entfallen. Der Klauenspalt bleibt in der Vorlage sichtbar, sein Erhalt im kleinen Raster muss noch geprüft werden; bei Detailverlust ist 10 × 18 innerhalb des vorgeschlagenen Korridors die Reserve. Keine zweite Abstraktion nötig, da kein ungelöster Vorlagenkonflikt gesehen wurde.

Sichtprüfung groß sowie statisch bei 112/140 px Höhe auf tatsächlichem Projektpapier: Silhouetten zusammengehörig, Außen-/Klauenflächen transparent, keine auffälligen Säume. PNG-Dekodierung/Ressourcengrenzen und Ableitungsinputhash geprüft. Designschemata/Einpassgeometrie dürfen geprüft werden, es wurden keine Zellwerte oder Hinweise berechnet. Keine native Spiel-, Solver-, Proof-, Schwierigkeits- oder Adapterprüfung; diese ist in Auftrag 2 noch nicht anwendbar. Keine Lösbarkeits- oder Schwierigkeitszusage, Lösungszeit nicht geschätzt. Probespiel optional und nicht durchgeführt.

Freigaben: Reveal vorhanden; **Motiv M-r02 samt vorgeschlagenem Korridor offen**; Endabnahme/Integration offen. Gatepass ausschließlich für die belegte Revealfreigabe und dateigebundene Provenienz; spätere Gates bleiben pending. Herkunft/Nutzungsgrundlage und tatsächliche Prompts sind gespeichert. Ein Bildaufruf in dieser Phase, keine Nachbearbeitung/Import-/Reparaturrunde, aktive Menschenzeit nicht erfasst.

ZIP-/Inventar-/Handoffprüfung am geschriebenen Paket und getrennter Selbstreview/CI werden im Ablage-PR belegt; keine Adapterzertifizierung der frühen Bildphase. Der reine Ablagemerge ändert keine Runtime-Inhalte und nimmt die Motivvorlage nicht menschlich ab. Nächster Schritt: **3 · Motiv freigeben & produzieren**; kompakte Freigabe-/Codexvorlage in codex-handoff.md.
