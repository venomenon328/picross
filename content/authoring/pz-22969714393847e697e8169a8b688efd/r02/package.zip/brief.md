# Klauenhammer · Motivvorlage M-r02

`pz-22969714393847e697e8169a8b688efd` · r02 · Standardauftrag 2 · `motif_review`.

Tatsächlicher Auftrag/Wortlaut: approvals/reveal-evidence.txt. A-r01 ist nach Datei, SHA-256, ursprünglichem r01-Paket und Quellcommit `ac2e1f85e29f0dffd06a3d84d6a70e09af8a6d7a` ausdrücklich freigegeben (approvals/reveal.json). Die Quelle und alle ursprünglichen r01-Bytes bleiben unverändert; frühere B-/C-Varianten stehen nur im quellcommitgebundenen r01-Paket.

Gewünscht: ungefähr 10 × 15, monochrom, genau eine Vordergrundfarbe ohne Leer mitzuzählen. Zuordnung `werkzeuge-handwerk`. Aus dem freigegebenen Reveal wurde eine eigene gespeicherte schwarze Motivvorlage abgeleitet, keine Zellmatrix.

## Empfehlung und vorgeschlagener Korridor

**9 × 16 (144 Zellen)** empfohlen, **10 × 18 (180 Zellen)** als Detailreserve. 10 × 15 würde bei unverzerrtem contain-Import der Motiv-Boundingbox nur 8 × 15 Bildzellen mit je einer leeren Außenspalte links/rechts ergeben und damit die Randregel verletzen. Die Empfehlung bleibt nahe am ungefähren Zellumfang und erhält die tatsächlichen Proportionen. Diese begründete Größenanpassung ist Bestandteil der nun vorzulegenden Motivfreigabe, noch keine eigenmächtige Rasterproduktion.

Genau diese beiden Maßpaare; Mono/1, area, contain, schwarzes ink, weißer Leergrund, Alpha-Untergrenze 64, Schwellen 128/176. Tatsächlicher Crop [109, 56, 882, 1475] ist die vollständige Alpha-Boundingbox. Genaue technisch passende Entwürfe unter designs/; vollständiger Vorschlag und geschützte Merkmale in parameters.json. Keine zusätzlichen Crops, Rotation, Spiegelung oder Dehnung freigegeben. Schwellenvergleich 128 gegen 176 prüft normale Flächenabdeckung gegen stärkeren Konturerhalt, ohne zusätzliche Farben oder contour-Rahmenfehler.

## Zu bewahrende Merkmale

- Ein einzelner vollständiger nahezu aufrechter Klauenhammer.
- Breiter kurzer Kopf; runde/flache Schlagfläche links, rückwärts nach rechts unten gebogene, gespaltene Klaue.
- Der offene Spalt zwischen beiden Klauen und der Leerraum unter der Klaue bleiben erkennbar; keine Fusion zu einer geschlossenen Hakenspitze.
- Langer mit dem Kopf verbundener Stiel mit leicht ausgestelltem gerundetem Griffende; Hauptproportionen und Orientierung des Reveals erhalten.
- Mono genau eine Vordergrundfarbe plus Leer; keine Rahmen- oder Fremdpixel zur Logikstütze.

## Befugnis und Halt

Standardauftrag 2 samt Repositoryablage, Commit/Push, PR und bedingtem Ablagemerge ist beauftragt. Nur das Abschlussbild ist menschlich freigegeben. **M-r02 samt vorgeschlagenem Größen-/Parameterkorridor benötigt die tatsächliche menschliche Motivfreigabe.** Rasterproduktion, neue Bildfreigabe, Endabnahme und Spielintegration werden nicht aus dem Ablagemerge abgeleitet. Der Übergabeprompt für Auftrag 3 ist erst nach dieser Freigabe auszuführen.
