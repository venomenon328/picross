# Codex-Übergabe für den nächsten Auftrag

**Vorbereitung vollständig; Ausführung erst nach tatsächlicher Motivfreigabe.** Aktueller beauftragter Endzustand ist motif_review, keine Rasterproduktion.

Bevorzugter Weg: **Codex**. Selbst umsetzbar: **Ja**, sofern die nächste Ausführungsumgebung die gebundenen Produktionswerkzeuge und Pillow exakt 12.3.0 bereitstellt; ChatGPT kann hier Dateien, GitHub und CI bedienen. Codex ist für die anstehende zusammenhängende Import-/Proof-/Reparatur-/Bewertungsschleife der vorgesehene Ausführungsweg, keine Aufforderung zu parallelen Unteragenten.

**Codex: GPT-6.1 Sol — Reasoning: High.** Die vier begründeten Importkandidaten, getrennte visuelle Beurteilung und unabhängige Nachweisbindung verlangen sorgfältige mehrstufige Arbeit; High folgt der Projekt-Heuristik. Kein Anlass für Max/Ultra. Offiziell geprüft am 2026-10-29T14:12:02Z: [Modell](https://developers.openai.com/api/docs/models/gpt-6.1-sol), [Codex/Work-Modelle](https://learn.chatgpt.com/docs/models). Konto-/Clientauswahl ist nicht geprüft; API-Verfügbarkeit wird nicht mit persönlicher Verfügbarkeit gleichgesetzt.

## Übergabeinhalt

Originalreveal, bytegebundene tatsächliche Bildfreigabe samt Wortlaut, eigene Motivdatei und deren Ableitungsprovenienz, geschützte Formen, vorgeschlagene Parameter sowie zwei schemafähige Entwürfe liegen vor. Der Crop ist reine Entfernung vollständig transparenter Außenfläche bei unveränderter PNG-Quelle. 9 × 16 ist empfohlen; 10 × 18 ist Detailreserve. Erst menschliche Motivfreigabe macht diese Kombinationen verbindlich.

Nach Freigabe die vorhandenen vier Ansätze (zwei Maße × area-128/area-176, alpha_below 64) gemäß aktuellem Workflow prüfen. Keine Matrix oder Solverausgabe wird hier vorweggenommen. §4.5 verlangt vorzugsweise zwei bis drei verschiedene vollständig freigabefähige Raster mit je eigener Paketrevision, soweit die bestehenden Kandidaten-/Reparaturbudgets solche liefern. Weniger geeignete Ergebnisse begründet melden. Der Klauenspalt darf nicht für einen Logikerfolg zugeschlossen werden. Stärkere Profilprüfung und Reparatur richten sich unverändert nach §4.2.1/§4.4. Neue Bewertungsintegration folgt dem dann aktiven Methodenstand (aktuell 0.4); dafür die gerouteten Quellen vor Ausführung lesen. Keine neue Testfamilie oder Bestandsreplays.

## Kopiervorlage für den Nutzer

Der folgende Text ist **eine noch nicht erteilte Freigabevorlage**. Erst tatsächliches Absenden durch den Nutzer erteilt die Motivfreigabe und Standardauftrag 3:

```text
Arbeite in venomenon328/picross nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md auf feat/468-authoring-options.
Ich gebe die Motivvorlage M-r02 (images/motif-m-r02.png, SHA-256 a902d98469f741dc049f2f4456d64767eb25cb4034231ee36260aa0503695578) samt parameters.json mit genau 9 × 16 oder 10 × 18, Mono/1, frei. Führe Standardauftrag 3 bis zur geprüften Rasterauswahl aus.
Paket: content/authoring/pz-22969714393847e697e8169a8b688efd/r02/package.zip · r02. Lade Record und Paket selbst; die gespeicherte A-r01-Freigabe bleibt gültig. Der Paketstand ist über den Authoringindex/Quellcommit der Chatübergabe erreichbar.
Repositoryablage nach §6 samt Ablage-PR und Merge nach erfolgreichen Pflichtprüfungen ist beauftragt. Keine Spielintegration; Standardauftrag 4 bleibt separat.
```
