# Fortsetzung nach tatsächlicher Endabnahme

Paket r03 ist content_ready, Endabnahme noch offen. Über aktuellen Arbeitsindex laden; ZIP/Inventar/Handoff/Dateien prüfen. A-r01 und MA-r01 sind tatsächlich freigegeben. Geprüfter Endkandidat imports/31x40-alpha96, Variante area; aktuelle 0.3-Bewertung analysis/checked.json.

Erst nach gesonderter redaktioneller Endabnahme Auftrag 4 ausführen: tatsächliche Freigabe extern an Originalhandoff/Inventar/Auswahl/Reveal binden, regulären kategorisierten Export erstellen und vorhandene Bewertung bei identischer Logik/Matrix neu binden. Keine neue Rasterproduktion oder Routine-Reanalyse. Integrationsbefugnis dann anhand des tatsächlichen Folgeauftrags prüfen. §9-Cleanup gilt erst nach nachgewiesener Runtimeintegration auf main.
