# Chupacabra · Standardauftrag 3

Nutzer gibt MA-r01 und parameters.json/r02 frei; tatsächlicher Wortlaut in approvals/motif-evidence.md. Vier Vordergrundfarben, 28–33 × 36–42, area/contain, Alpha 96 oder 128; nur vollständig transparente Außenstreifen beschneiden.

A-r01 und MA-r01 bleiben bytegleich. Identität, gebeugte Dreiviertelpose nach links, Ohren, rote Augenmarke, Stachelreihe, Arm-/Beinräume und offene rechte Schwanzschleife bewahren. Vier erste Konfigurationen geprüft, 31×40/Alpha96 gewählt. Keine manuelle Zelländerung.

Beauftragt: Produktion bis Endabnahmevorlage, §6-Ablage, Commit/Push/PR und Ablagemerge nach Pflichtchecks. Gesonderte menschliche Endabnahme für Auftrag 4 steht aus.
