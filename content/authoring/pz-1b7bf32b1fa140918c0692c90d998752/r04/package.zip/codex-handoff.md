# r04 · Fortsetzung nach Endabnahme

Feste Farbkorrektur unter bereits freigegebenem Motiv; state=raster_review, source_type=manual, repair.type=fixed_color_editorial_redraw. Alle acht Inhaltsgates technisch/redaktionell im Produktionsumfang belegt; Nutzerendabnahme offen.

Nach tatsächlicher Endabnahme r04 und seinen unveränderten Handoff/Inventar/ZIP/Auswahlhash binden. Den bestehenden externen ZA-1-v4-Autorisierungsvertrag samt owner-override-v4 und tatsächlichem Endfreigabehash verwenden. Nutzerkorrekturauftrag in edits/owner-request.json; niemals eine Freigabe erfinden. Die v4-Hülle muss den ursprünglichen genehmigten Motiv-/Parameterdatensatz, base imports/31x40-alpha96 und genau eine steps-Zeile für edits/second-eye-plan.json / edits/second-eye-record.json → imports/second-eye/area binden; Schutzmaske aus dem Plan.

ZA-1-v4 verlangt die echte Endabnahme auch vor inspect. Deshalb kein Adapter-inspect dieses Reviewpakets vorgetäuscht; origin-checks.json belegt die vorhandenen Replay-/Import-/Proof-APIs. Anschließend regulärer kategorisierter Export mit --manual-authorization, vorhandene analysis/checked.json bei identischen ID/Logik/Matrix rebind; danach Plan/Register nur mit entsprechendem Integrationsauftrag.
