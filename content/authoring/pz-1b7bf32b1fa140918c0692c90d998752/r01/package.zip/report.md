# Chupacabra · r01 · reveal_review

Regelwerk 0.5.0, Dokumentrevision 22. Basis/Toolcommit: 0297f539e702a2632aec3b07c86c265e8a9695d7.
Die drei farbigen Einzeldateien sind in decisions.json einschließlich SHA-256
gebunden. Keine Auswahl oder menschliche Freigabe liegt vor.

| Kriterium | A-r01 | B-r01 | C-r01 |
| --- | --- | --- | --- |
| Erkennbarkeit | erfüllt: stacheliger aufrechter Kryptid | erfüllt: schleichender Kryptid | erfüllt: hockender Kryptid |
| Silhouette/Proportionen | erfüllt: klare Kopf-/Rumpf-/Beinaufteilung | erfüllt: vollständiges breites Tier, bewusst lange Arme | erfüllt: kompakte breitbeinige Figur |
| Details/Negativräume | erfüllt: Augen, Zähne, Klauen, Arm-/Beinräume | erfüllt: auffällige Rückenreihe, freie Gliedmaßen | erfüllt: Gesicht, Klauen, Arm-/Beinräume |
| Palette/Lesbarkeit | erfüllt: Grün/Ocker/Rot | erfüllt: Blaugrau/Ocker/Rot | erfüllt: Rotbraun/Sand/Rot |
| Serienästhetik | erfüllt: konturierte ausgearbeitete 2D-Zeichnung | erfüllt: detailreiche 2D-Zeichnung, düsterere Palette | erfüllt: konturierte 2D-Zeichnung, warme Palette |

Die Oberflächen sind bewusst ausgearbeitet; Schuppen und feine Krallen müssen
bei späterer Abstraktion zusammengefasst werden. B verlangt voraussichtlich
mehr horizontale Auflösung. Dies ist eine Gestaltungsbeobachtung, kein Logiktest.
Empfehlung: A-r01 wegen der gut gegliederten kompakten Haltung.

PNG-Dekodierung, RGBA, Alpha, Dateimaße, Bytes und Hashes geprüft. Auf dem
tatsächlichen Papierasset game/art/book/bp2-a-inventarband.png groß und in
kleiner Karten-Bildfläche visuell verglichen: neutrale Außenflächen und echte
Zwischenräume transparent; helle Motivflächen erhalten, keine störenden Matten.
Diese statische Assetkontrolle ist kein Spielstart oder nativer Renderingtest.

Maße/Modus/Palette eines Rasters: offen. Keine Motivvorlage, Matrix, Hinweise,
Deduktions-/Eindeutigkeits-/Randprüfung, Reparatur, Schwierigkeit oder Endmatrix
vorhanden; in dieser Bildphase noch nicht fällig. Lösungszeit nicht geschätzt.
Menschliches Probespielen nicht durchgeführt, optional. Zieladapter/Runtime:
nicht aufgerufen; dies ist ausschließlich die Authoringablage.

Vor Sicherung: ZIP sicher geöffnet; Dateimenge, CRC, Pfade, reguläre Modi,
Inventargrößen/-hashes und bytegleiche äußere Handoffkopie kontrolliert.
Frühe Bildphase ist kein ZA-1-Inspektionseingang; keine Adapterzertifizierung.
CI und separater vollständiger Diff-Selbstreview werden im Ablage-PR gebunden.

Nächster erlaubter Schritt: 2 · Bild freigeben & abstrahieren. Der Eigentümer
wählt A-r01, B-r01 oder C-r01 und gibt genau diese Datei frei oder fordert
eine konkrete Korrektur. Vor dieser Freigabe keine Abstraktion.
