# Chupacabra · Abschlussbildauswahl

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING in venomenon328/picross@main.
Motiv: Chupacabra. Freie Interpretation (`free`), keine bindende Bildreferenz.
Kategorie: mythen-fantasie · Mythen & Fantasie.

Unverzichtbarer Kern: ein einzelnes vollständiges kryptides Wesen; markante
Rückenstacheln, rote Augen, Fangzähne, gekrümmte kräftige Hinterbeine und Krallen.
Pose, Proportionen und Farbgebung dürfen zwischen den drei Angeboten variieren.
Keine Schrift, Raster, Kleidung, Blut oder Nebenfiguren. Detaillierte farbige
2D-Illustration mit klarer Silhouette und echter PNG-Transparenz.

Rasterbreite, Rasterhöhe, Modus und Vordergrundfarbzahl sind offen. Regulär gilt
höchstens 50 je Achse; eine Lösbarkeit oder Schwierigkeit wird nicht behauptet.
Konfiguration und Ableitung folgen erst nach der konkreten Abschlussbildfreigabe.

Repositoryablage nach §6 sowie Merge des Ablage-PR nach erfolgreichen
Pflichtprüfungen sind ausdrücklich beauftragt. Das ist keine Bildfreigabe,
Motivfreigabe oder redaktionelle Endabnahme. Kein Export/Spielregistrierung.

Herkunft: drei eigens für diesen Auftrag nativ in ChatGPT erzeugte Bilder,
ohne fremde Bildvorlage. Nutzungsgrundlage: beauftragte KI-Neuschöpfung für
dieses Projekt; keine zugesicherte Exklusivität oder fremde Assetlizenz behauptet.
Originale Bildbytes und tatsächliche Prompts sind erhalten.
