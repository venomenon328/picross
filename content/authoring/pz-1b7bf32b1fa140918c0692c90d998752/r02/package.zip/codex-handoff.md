# Codex-Übergabe · Start erst nach Motivfreigabe

Paket r02 ist vorbereitet; noch kein Auftrag zur Rasterproduktion.
Bevorzugter Folgeweg: Codex für die längeren lokalen Produktions-/Prüfschleifen.
Diese Umgebung könnte sie grundsätzlich ebenfalls ausführen; sie ersetzen weder
die konkrete menschliche Motivfreigabe noch die spätere Endabnahme.
Eine Modell-/Reasoningfestlegung wird vor der tatsächlichen Folgeausführung nach
den aktuellen Projektregeln getroffen; keine ungeprüfte Verfügbarkeitsbehauptung.

Nach tatsächlicher Freigabe von motifs/MA-r01.png und parameters.json kopierbar:

```text
Arbeite in venomenon328/picross@main. Lies die aktuelle AGENTS.md und
docs/ai-workflows/PUZZLE_AUTHORING.md samt Pflichtquellen.
Starte Standardauftrag 3 für pz-1b7bf32b1fa140918c0692c90d998752 aus
content/authoring/pz-1b7bf32b1fa140918c0692c90d998752/r02/package.zip.
Prüfe Index, Record und Originalinventar; binde meine tatsächliche Freigabe
von MA-r01 samt parameters.json. A-r01 und seine bereits gebundene Freigabe erhalten.
Produziere innerhalb des bestätigten Korridors bis zur redaktionellen Endabnahmevorlage,
mit den vier begründeten Ausgangsdesigns. Führe Pflichtprüfungen, gegebenenfalls
Profilprüfung und motivgeschützte Reparaturen sowie aktuelle Schwierigkeitsanalyse
nach Workflow aus; sichere die neue Paketrevision samt Draft-PR.
Keine Spielregistrierung vor gesonderter Endabnahme. Kein Release/Deployment.
```
