# Chupacabra · r02 · motif_review

Regelwerk 0.5.0 / Dokumentrevision 22. Quellen-/Toolcommit: f58fe5a22601aa2052fc48a9f19750e743a15108.
Abschlussbild A-r01 ist hashgebunden tatsächlich freigegeben. Motivvorlage MA-r01
und Parameterkorridor sind vorgelegt, aber noch nicht menschlich freigegeben.
Endabnahme offen. Kein Raster und kein Zieladapterexport vorhanden.

| Kriterium | A-r01 | MA-r01 |
| --- | --- | --- |
| Erkennbarkeit | erfüllt: Chupacabra mit Rückenstacheln | erfüllt: Stacheln, Ohren, rote Augen und gebeugte Haltung bleiben |
| Silhouette/Proportionen | erfüllt: unveränderte Originalbytes | erfüllt: gleiche Kopf-/Rumpf-/Gliedmaßenanordnung, organisch vereinfachte Kontur |
| Details/Negativräume | erfüllt: detailreiches Ausgangsbild | erfüllt: Textur entfernt; Arm-/Beinräume und Schwanzöffnung erkennbar |
| Palette/Lesbarkeit | erfüllt: farbiges detailliertes Reveal | erfüllt: vier dominante Flächenrollen; Randglättung/leichte Generatorfarbvariation sind keine Matrixfarben |
| Serienästhetik | erfüllt: konturierte 2D-Illustration | erfüllt: ruhige flächige Abstraktion für die nachfolgende Rasterproduktion |

Die Abstraktion verliert einzelne Schuppen, Hautfalten, Glanz, Schattierungen
und feine Krallenglieder. Blick, Haltung, Proportionen, helle Bauch-/Schnauzenfläche,
rote Augen und die offene Schwanzschleife bleiben. Keine Änderung am Abschlussbild.

Empfehlung und zwei reduzierte Alternativen stehen in config-comparison.json;
parameters.json bindet Größen, vier Farbrollen, Crops und vier konkrete erste
Designs. MA-r01 ist kein auf exakte vier RGB-Werte quantisiertes Lösungsraster.
Die tatsächliche Vordergrundfarbzahl wird erst an der späteren Matrix gezählt.
Lösbarkeit, Randregel, Eindeutigkeit, Endmatrix, Schwierigkeit und Lösungszeit
sind in dieser Phase noch ungeprüft beziehungsweise nicht geschätzt.

Assetprüfung: Originalbytes/Hashes, native Ableitung, PNG/RGBA/Alpha, Ressourcen-
und Designschema mit Pillow 12.3.0 und bestehendem Reader geprüft (asset-checks.json).
Großansicht und 112/140px-Vorschauen auf tatsächlichem Papier statisch gesichtet:
helle Motivflächen erhalten, Außen-/Innenräume transparent, keine störende Matte.
Dies ist kein Spielstart, kein Import-/Solverlauf und keine ZA-1-Zertifizierung.

Vor Ablage: ZIP frisch sicher geöffnet, CRC/Dateimenge/Hashes/Modi und äußere
Handoff-/Freigabekopien geprüft. Getrennter Diff-Selbstreview und Pflicht-CI
werden im Ablage-PR an Head/Basis/Test-Merge gebunden. Menschliches Probespiel
optional und nicht durchgeführt. Nachfolgearbeit wartet auf die Motivfreigabe.
