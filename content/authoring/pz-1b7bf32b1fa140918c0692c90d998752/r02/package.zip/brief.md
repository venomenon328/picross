# Chupacabra · Standardauftrag 2

A-r01 ist durch den aktuellen Nutzerauftrag ausdrücklich freigegeben.
Die tatsächliche Erklärung und alte Paket-/Bildhashbindung stehen unter approvals/.
Motiv-ID: pz-1b7bf32b1fa140918c0692c90d998752; Kategorie mythen-fantasie.

MA-r01 ist nativ aus den gespeicherten Bytes von A-r01 abgeleitet, vorlagentreu.
Haltung, Blickrichtung, Proportionen, Ohren, rote Augen, Rückenstachelreihe,
Arm-/Beinräume und offene rechte Schwanzschleife bewahren.
Schuppen, Hautfalten, Schattierung und dünne Finger-/Krallendetails wurden
zusammengefasst. Die Motivdatei ist eine Illustration, keine Zellmatrix.

Empfehlung: 31×40, farbig, vier Vordergrundfarben ohne Leer. parameters.json
enthält den vorgeschlagenen Korridor (28–33 ×36–42), vier konkrete erste Designs,
zulässige Alpha-/Cropvarianten und die Motivinvarianten. Vergleich zweier
reduzierter Konfigurationen in config-comparison.json. Keine feste Größenvorgabe.
Wunschfarbzahl bleibt offen; die Viererpalette ist eine begründete Empfehlung.

Bildfreigabe erfolgt, Motiv-/Parameterfreigabe steht aus. Kein Import, Raster,
Hinweis, Solver, Proof, Reparaturlauf oder Schwierigkeitsurteil in dieser Phase.
Repositoryablage und deren Merge nach Pflichtprüfungen sind ausdrücklich beauftragt.
