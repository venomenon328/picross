# Nächster erlaubter Auftrag

Zur Entscheidung vorgelegt: Giraffe `pz-dbbebc72556d4f0c9a37ab69275480e9/r03`, finales Raster 24×36,
Reparaturkandidat candidate-001, unverändertes Abschlussbild A-r01.
Die Detailreduktion an Kopfanhängen und diagonale Verbindungen sind im Bericht offengelegt.
Paket-/Inventar-/Handoffhashes stehen im äußeren record.json und in inspection.json.

Nach tatsächlicher Endabnahme kann der Nutzer beauftragen:

> Ich nehme Giraffe pz-dbbebc72556d4f0c9a37ab69275480e9/r03 mit dem dort gebundenen Endraster,
> Abschlussbild und Paketinventar redaktionell ab. Führe Standardauftrag 4 samt
> Integration aus. Repositoryablage, Draft-PR #118 fortführen; kein Merge.

Dies ist nur eine Vorlage; keine bereits erteilte Endabnahme oder Integrationserlaubnis.
