# Giraffe · Produktion r03

Standardauftrag 3 nach ausdrücklicher MA-r01- und Parameterfreigabe im aktuellen Chat.
Kategorie saeuger. Vorlagentreu: Ganzkörper-Seitenprofil nach links, aufrechter langer
Hals, Kopf-/Ohren-/Stirnzapfenkontur, abfallender Rücken, vier Beine und vorhandene
Standpose, Bauchraum und Beinzwischenräume sowie rechter Schwanz mit Quaste.
Keine neuen Motive, Pose oder Perspektive. Ursprüngliche Flecken-/Gesichts-/Hufdetails
bleiben im unveränderten farbigen Abschlussbild, nicht in der Mono-Silhouette.

Freigegebener Korridor: genau 20×30 oder 24×36, mono, ink/#000000 und Leer weiß;
area mit Schwelle 96 oder 160, fit=exact, Crop [16,8,1016,1508], alpha_below=128.
configuration.json bleibt als bytegleicher r02-Vorschlag; seine nun tatsächliche
Annahme ist getrennt in motif-approval-*.json und motif-approval-evidence.md gebunden.
Die zwei Freigabedatensätze dokumentieren dieselbe tatsächliche Erklärung und die
beiden erlaubten Größen; die Adapterauswahl bindet die tatsächlich verwendete Größe.

Repositoryablage und Fortführung Draft-PR #118 sind beauftragt. Kein Merge.
Endabnahme und anschließende Spielintegration gehören zu Standardauftrag 4.
