# Giraffe · Endabnahmevorlage

`pz-dbbebc72556d4f0c9a37ab69275480e9` · **r03 / content_ready** · 14.10.2026 · Kategorie Säugetiere.
Regelwerk 0.4.1, Dokumentrevision 8; Tool-/Quellencommit `6de29292d966ecf0348f42508354bcba7a7ed07e`,
Main-Basis `62e290bfce56071b6870f2ed2896fce776c7ae03`. Inventar-Dateihash im bytegebundenen `handoff.json`/äußeren Record
(keine Selbstreferenz des Berichts).

**Freigaben:** A-r01 unverändert freigegeben (`reveal-approval.json`);
MA-r01 samt genau vorgeschlagenem Korridor durch aktuelle Nutzererklärung angenommen
(`motif-approval-24x36.json`, tatsächlicher Wortlaut/Erfassungszeit im Beleg).
**Redaktionelle Endabnahme offen.** Probespiel nicht durchgeführt, optional.

**Auswahl:** 24×36, 864 Zellen, mono ink/#000000 + Leer weiß, area-160,
Crop [16,8,1016,1508], exact. 252 Füllzellen (29,17 %), 612 Leerzellen.
Echtes Raster: `final-raster.png`, `final-raster-enlarged.png`, `final-raster-grid.png`;
Abschlussbild: `reveals/A-r01.png`. Vergleich: `candidate-comparison.png`.
Vier unterschiedliche Originalimporte: 20×30/96 und 24×36/96 verfehlen Randregel
und zerlegen Beine; 20×30/160 ist gröber und bleibt mit acht offenen Zellen stehen.
24×36/160 hat die beste Form, vier offene Zellen und gültigen Rand.

**Reparatur:** vorab maximal zwei Positionen erlaubt, alle übrigen Füllungen und
Leerstellen hart geschützt. Tatsächlich genau **Spalte 13, Zeile 34: ink → empty**;
Knöchelkontur geglättet, Beinsäule/Hufbasis/Standpose erhalten. Ein Vorschlag,
zwei Kandidaten inklusive Referenz. Vollständige RP-5-Dateien, Plan und Diff in `repair/`;
unabhängiger frischer Replay `repair-replay.json`: accepted/certified.

**Pflichtprüfungen erfüllt:** Produktmaße; Rand rechts/oben/unten belegt (links leer);
Herkunft und alle Original-/Normalisierungs-/Parameterbindungen; exakt neu abgeleitete
Hinweise; `full-line-mono` v1 ohne Suche/Startfelder; vollständiger gespeicherter Proof
mit 155 Schritten, unabhängiger Blockintervallprüfer und identische Endmatrix.
Belege: `audit/candidates.json`, `origin-verification.json`, `audit/technical.json`,
`repair/final-proof.json`, `repair-replay.json`.

**Gestaltung:** Hauptpose, langer Hals, Rücken, vier Beine und Freiräume erhalten.
Offengelegte Auflösungsgrenzen: Stirnzapfen/Ohren nur als gemeinsame Kopfkontur;
Schwanzansatz und schräge Beinabschnitte teils diagonal verbunden. Keine isolierten
Einzelzellen oder leeren Innenlinien. Farbige Details bleiben im Abschlussbild.
Eigener Sichtvergleich erfüllt, keine unabhängige Zweitprüfung (`raster-visual-review.json`).

**Schwierigkeit L2**, plausibel L2–L4, `editorial_estimate`, Vertrauen low.
Überlappungen/Verlängerungen dominieren; Mehrfachblockzuordnung kann R2 benötigen,
R3-Notwendigkeit nicht bewiesen. Vor Restaufräumen mindestens sechs produktive Linien;
keine beobachtete definierte Engstelle. Belege und Technikbegründung in `difficulty.json`
und `audit/difficulty-*.json`. Umfang 864 Zellen separat; Lösungszeit nicht geschätzt.

**Herkunft/Nutzung:** eigene native KI-Generierung im beauftragten Projekt, keine
Fremdassets; unveränderte Provenienz/Prompts erhalten. Vier Bildaufrufe insgesamt,
kein neuer Bildaufruf, zwei Importe/vier Raster, ein Reparaturlauf; Menschenzeit nicht erfasst.
ZA-1-Diagnose erfolgt am geschriebenen ZIP und liegt außen in `inspection.json`;
Export/Registrierung folgen erst Auftrag 4 mit echter Endabnahme. Kein Merge.
Nächster Schritt: r03 anhand Raster, A-r01 und Paketinventar redaktionell abnehmen.
