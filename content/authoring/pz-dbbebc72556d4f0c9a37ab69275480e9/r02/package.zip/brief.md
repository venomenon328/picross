# Giraffe · Motivvorlage MA-r01

ID pz-dbbebc72556d4f0c9a37ab69275480e9, Paket r02. Kategorie saeuger / Säugetiere.
Nutzerfreigabe von A-r01 am 14.10.2026 um 13:18:47 UTC; tatsächlicher Beleg
in user-approval-evidence.md. Abschlussbild unverändert farbig erhalten.
Standardauftrag 2, Ablage nach §6, Draft-PR #118 fortführen; kein Merge.

Neuer Wunsch ungefähr 30 breit × 20 hoch, monochrom. Empfehlung gemäß §2.1:
20 × 30, alternativ 24 × 36. 30 × 20 würde viel leeren Seitenraum erzeugen
oder die freigegebene aufrechte Form verzerren. Pose oder Perspektive nicht ändern.

Vorlagentreue Abstraktion: Schwarze Silhouette; Kopfprofil, langer Hals,
Stirnzapfen/Ohren, vier Beine, Freiräume und rechter Schwanz erhalten.
Fellflecken, Gesicht, Hufdetails und einzelne Haare entfallen ausdrücklich.
Vorgeschlagener Parameterkorridor und zwei gültig formatierte, noch ungenutzte
Importdesigns in configuration.json und config/. Diese sind noch keine Freigabe.

Nach MA-r01-Freigabe vier gezielte Rasterkandidaten im festgelegten Korridor,
danach sämtliche Produktionsprüfungen aus §§4–7. Keine Spielregistrierung.
