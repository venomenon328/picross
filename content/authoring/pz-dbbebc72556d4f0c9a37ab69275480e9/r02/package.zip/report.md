# Giraffe · Standardauftrag 2

ID `pz-dbbebc72556d4f0c9a37ab69275480e9` · Paket r02 · Status `motif_review` · 14.10.2026.
Regelwerk 0.4.1 / Dokumentrevision 7, Quellen-/Toolcommit `5209d30c48957318412adfce98999e78487dc18c`;
aktueller main `b57d8da3dd8c0965727759eb027c10686abb3630`. Inventarhash steht ohne Selbstreferenz im Handoff/Record.

A-r01 ausdrücklich menschlich freigegeben, unveränderte farbige Originalbytes
gebunden. MA-r01 aus genau dieser Datei nativ abgeleitet; noch nicht freigegeben.
Bilddateien in reveals/ und motifs/. Sichtprüfung mit fünf Kriterien erfüllt;
Beleg visual-review.json. Keine unabhängige Zweitprüfung.

| Konfiguration | Motivtreue / Darstellbarkeit | Logik / Spielgefühl |
| --- | --- | --- |
| 30 × 20, gewünscht | Querformat unpassend; ungefähr 13 × 20 Motivzellen bei unverzerrtem Contain. | Nicht geprüft; viel Leerraum, horizontale Randregel gefährdet. |
| 20 × 30, Empfehlung | Erhält Profil und Ganzkörperpose; Silhouette ohne Binnenflecken. | 600 Zellen, kompakt; Lösbarkeit offen. |
| 24 × 36, Alternative | Mehr Detailraum für Stirnzapfen und Beinzwischenräume. | 864 Zellen, mehr Arbeit; nicht automatisch schwieriger. |

Vorgeschlagener Korridor: genau 20 × 30 oder 24 × 36, mono, eine Vordergrundfarbe
ink/#000000, Leer weiß, area mit 96/160, fit=exact, Crop [16,8,1016,1508].
Noch keine Parameterfreigabe. Verlust: Flecken, Felltextur, Gesicht, Huf-/Gelenk-
details und einzelne Haare. Erhalten: Kopfprofil, Hals, Hörner/Ohren, Rücken/Rumpf,
vier Beine, Negativräume, rechter Schwanz. Keine Pose-/Perspektivänderung.

Vier Bildaufrufe insgesamt, einer in dieser Phase; keine Import-/Reparaturversuche.
Menschenzeit nicht erfasst. Schwierigkeit und Lösungszeit nicht geschätzt.
Matrix/Hinweise, Randregel, Deduktionsproof, unabhängige Prüfung, Endmatrixgleichheit,
Reparatur und Zieladapter/Export sind für diese Bildphase noch nicht anwendbar.
Probespiel nicht durchgeführt, optional. Endabnahme und Katalogfreigabe offen.

Nutzungsgrundlage/Herkunft in den beiden Provenienzdateien; keine Fremdreferenz.
B-r01/C-r01 bleiben ausschließlich im unveränderten Paket r01 mit festen Commit-
und Hashverweisen. Nächster erlaubter Schritt: ausdrückliche Freigabe von MA-r01
samt Konfiguration, danach Standardauftrag 3; Vorlage in codex-handoff.md.
