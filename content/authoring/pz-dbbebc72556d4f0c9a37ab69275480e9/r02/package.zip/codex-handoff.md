# Kopierbarer Folgeauftrag nach Motivfreigabe

Dies ist eine Vorlage für den nächsten Nutzerauftrag, keine bereits erteilte Motivfreigabe.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.

Ich gebe die Motivvorlage MA-r01 aus Paket pz-dbbebc72556d4f0c9a37ab69275480e9/r02 samt vorgeschlagenem Parameterkorridor in configuration.json frei.
Quellpaket: content/giraffe-reveal, Draft-PR #118; über content/authoring/index.json laden. Die Abschlussbildfreigabe A-r01 ist im Paket gebunden.
Führe Standardauftrag 3 vollständig bis zum geprüften Endraster und Übergabepaket aus.
Repositoryablage nach §6 ist beauftragt. Draft-PR #118 fortführen; keine Spielintegration und kein Merge.
```
