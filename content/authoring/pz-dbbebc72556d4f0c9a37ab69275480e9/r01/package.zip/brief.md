# Giraffe · Abschlussbildauswahl

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING auf venomenon328/picross@main.
Motiv: Giraffe. Größenwunsch ungefähr 20 breit × 30 hoch, Rätselmodus monochrom;
das Abschlussbild bleibt farbig. Kategorie saeuger / Säugetiere.
Repositoryablage nach §6, Commit, Push und Draft-PR beauftragt; kein Merge.

Arbeitsweise free: keine bindende Bildreferenz. Drei unterschiedliche Ganzkörperposen
mit ruhigem elfenbeinfarbenem Hintergrund. Wesentliche Merkmale: langer Hals,
kleiner Kopf, zwei Stirnzapfen, Ohren, Mähne, geflecktes Fell, vier lange Beine
mit Hufen, Schwanzquaste. Keine zusätzlichen Szenenobjekte oder Landschaft.
Warme handgezeichnete 2D-Binnenzeichnung, kräftige Flächen und saubere Konturen.

Noch keine Motivvorlage, Matrix, Hinweise, Importkonfiguration oder Lösbarkeitszusage.
Nach Bildfreigabe genaue Pose und Hauptproportionen erhalten; feine Felltextur und
Flecken werden für Mono gezielt reduziert. Wunschmaße sind keine feste Grenze.
Vor Rasterproduktion braucht die daraus abgeleitete Motivdatei eine eigene Freigabe.
