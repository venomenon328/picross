# Entscheidungen · pz-erdbeere/r01

Die Nutzererklärung beauftragt ein neues Erdbeermotiv, Schritt 1 nach Authoring 0.8.0, drei echte detaillierte farbige Abschlussbilder und die vollständige Gitablage samt automatisch geprüfter workspace.json. Erst im Produktionsauftrag wurde die kollisionsfreie ID pz-erdbeere vergeben; ein einziger Branch content/pw/pz-erdbeere wurde von aktuellem main erstellt. Keine Eingangsbilddatei vorhanden. Freie Textinterpretation; spätere Fassung nach menschlicher Auswahl vorlagentreu ableiten.

Die Rasterwünsche sind ungefähr 18 × 18 Zellen (Breite × Höhe), farbig, ungefähr drei Vordergrundfarben ohne Leer. Kein davon abweichender Parameterkorridor ist bereits freigegeben. Kategorie obst-nuesse folgt dem prägenden Fruchtgegenstand.

Commit, Push und Draft-PR sind im Scope autorisiert; Merge ist ausgeschlossen. Technische lokale Arbeitsdaten werden erst nach geprüfter Sicherung bereinigt. Menschliche Bild-/Motiv-/Raster-/Endfreigaben sind nicht erklärt. E-C-r01 ist nur die Empfehlung des Produktionsakteurs.
