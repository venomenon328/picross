# Auswahl- und Qualitätsprotokoll · pz-erdbeere/r01

Prüfer: ChatGPT/Codex (Produktionsakteur, Selbstprüfung). Zeitpunkt der protokollierten Sichtung: 2026-11-11T20:34:31.728009Z. Zustand: reveal_review. Keine menschliche Bildfreigabe erklärt.

Norm: docs/PUZZLE_QUALITY.md, Vertrag 1.0 / Dokumentrevision 9, Quellcommit 307e87099ff462150779b030fbffbe2001d6238e, SHA-256 7589c0e9784cd0492440cd08ea9b167d65277492aed6410bd44c2e0f13f1993f. Authoring 0.8.0 / Dokumentrevision 1 als bytegleicher Snapshot rulebook.md im Paket. Die Bildbindungen unten gelten jeweils für die unveränderten Originalbytes.

Methode: alle drei nativen farbigen Originalausgaben tatsächlich angesehen; gespeicherte Dateien mit Pillow 12.3.0 vollständig dekodiert, Maße, Bytezahlen, Dateihashes und echte Alpha-Verteilung geprüft. Zusätzliche statische Sichtkompositionen mit game/book/paper.png am Quellcommit (SHA-256 1af9f61957619d7cea98b69021688b0b78997d84baf93698c9f02dcbb866362f): große Ansicht bis 550 × 680 px und kleine Bildflächen 112 × 112 sowie 140 × 140 px, entsprechend catalog_card.gd bei UI100/125. Die Prüfkompositionen sind temporäre Ansichten, keine neuen Bildoriginale. Kein Engine-/Katalogstart, keine Animation oder Interaktion behauptet.

### E-A-r01 · images/reveal-A.png
SHA-256 `cc202e928cc2f64a8c78a02e56fac3c9e61103c1973ebae64c98d16ffbac1809` · 1666798 Bytes · 1254 × 1254 RGBA.
- Q-B01: erfüllt. Reife Einzelerdbeere mit deutlichem Kelch und länglicher Spitze, stimmiger frontnaher Perspektive; Frucht und Stiel sichtbar erhalten.
- Q-B02: erfüllt. Samenvertiefungen, Blattadern und modellierte rote Fläche bleiben in Großansicht deutlich; die Form liest sich auch klein. Saubere gezeichnete Kontur, warme Farbflächen und Oberflächendetails; keine Schrift, Wasserzeichen oder Zellgrafik.
- Q-B03: erfüllt. Die freigestellte Außenfläche und Blattzwischenräume lassen das aktuelle Papier durchscheinen. Kein weißer Bildkasten und bei der statischen Sichtung keine störenden hellen Säume oder sichtbare Beschneidung. Sehr schwache Randpixel sind in der separaten Alphadiagnose gezählt; die Diagnose allein ist kein Sichturteil.

### E-B-r01 · images/reveal-B.png
SHA-256 `7fc51220a2ecd037c3b24e1de20c703ac22f3f1ad8e550161b714b61b8cf2243` · 1764774 Bytes · 1254 × 1254 RGBA.
- Q-B01: erfüllt. Eigenständige diagonale Seitenlage mit nachvollziehbarer Fruchtform, Kelch links oben, Spitze rechts unten und geschwungenem Stiel.
- Q-B02: erfüllt. Die abgeschattete Unterseite und gezielt gesetzten Nüsschen unterstützen das Volumen; keine zusätzliche Kulisse oder Kleinstobjekte. Saubere gezeichnete Kontur, warme Farbflächen und Oberflächendetails; keine Schrift, Wasserzeichen oder Zellgrafik.
- Q-B03: erfüllt. Die freigestellte Außenfläche und Blattzwischenräume lassen das aktuelle Papier durchscheinen. Kein weißer Bildkasten und bei der statischen Sichtung keine störenden hellen Säume oder sichtbare Beschneidung. Sehr schwache Randpixel sind in der separaten Alphadiagnose gezählt; die Diagnose allein ist kein Sichturteil.

### E-C-r01 · images/reveal-C.png
SHA-256 `78423fae1090641fcb1a0352baa8f18905eb34c44d7d2b2b5b3513c82243b141` · 1980673 Bytes · 1254 × 1254 RGBA.
- Q-B01: erfüllt. Breite rundliche Frucht mit erkennbaren Schultern und leicht erhöhter Ansicht auf den sternförmigen Kelch; natürliche asymmetrische Proportionen.
- Q-B02: erfüllt. Ausgearbeitete Blattfaltungen, Nüsschen und rote Binnenmodellierung bei ruhiger zusammenhängender Hauptform; in beiden kleinen Größen erkennbar. Saubere gezeichnete Kontur, warme Farbflächen und Oberflächendetails; keine Schrift, Wasserzeichen oder Zellgrafik.
- Q-B03: erfüllt. Die freigestellte Außenfläche und Blattzwischenräume lassen das aktuelle Papier durchscheinen. Kein weißer Bildkasten und bei der statischen Sichtung keine störenden hellen Säume oder sichtbare Beschneidung. Sehr schwache Randpixel sind in der separaten Alphadiagnose gezählt; die Diagnose allein ist kein Sichturteil.

## Nachgelagerte Kriterien

Q-M01, Q-M02, Q-M03: jeweils nicht geprüft; erst nach tatsächlicher Abschlussbildfreigabe an Motivvorlage und vorgeschlagenem Parameterkorridor fällig.

Q-R01, Q-R02, Q-R03, Q-R04: jeweils nicht geprüft; noch kein Lösungsraster produziert. Die zahlreichen gemalten Farbtöne sind keine Rasterpalette.

Q-H01, Q-H02, Q-H03: jeweils nicht geprüft; noch keine Raster-/Hinweisansicht oder Lösungsspur vorhanden.

H-01, H-02, H-06: jeweils nicht geprüft; Maße/Istpalette, Logik/Proof und Schwierigkeit gehören zur späteren Rasterproduktion. H-03: Bildherkunft und Dateihashes in den drei Provenienzen aufgezeichnet; spätere Rasterrekonstruktion nicht geprüft. H-04: ausstehende menschliche Bildfreigabe; keine Abstraktion oder Rasterproduktion autorisiert. H-05: Builder prüft die Ablagebindungen; spätere Endabnahme und Integration bleiben offen. Kein positives Inhaltszertifikat aus der frühen Dateiprüfung ableiten.

## Entscheidung

Drei verschiedene tatsächliche Abschlussbildangebote. Empfehlung E-C-r01 wegen der kompakten Form im ungefähren quadratischen Rasterziel; keine automatische Auswahl. Nutzerziele ungefähr 18 × 18, farbig, ungefähr drei Vordergrundfarben ohne Leer sind im Briefing für den Folgeauftrag erhalten. Kein freigegebener Parameterkorridor und keine Lösbarkeitszusage. Nächster Schritt: konkrete menschliche Bildwahl/-freigabe, danach Motivvorlage erstellen.
