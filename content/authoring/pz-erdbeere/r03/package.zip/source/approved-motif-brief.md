# Erdbeere · Motivvorlage M-A-r02 zur Freigabe

Originalbriefing vollständig und bytegleich: source/original-brief.md. Der dortige alternative Konturwunsch „weich zulaufend oder rundlich herzförmig“ wurde in Schritt 1 durch drei Angebote ausgeführt. Die tatsächliche Nutzerwahl E-A-r01 bindet jetzt die aufrechte weich zulaufende Form; es wurde keine erste Option still gewählt. Die frühere KI-Empfehlung E-C-r01 ist keine Freigabe und wird nicht weiterverfolgt.

Verbindliche Ableitung: E-A-r01, r01, cc202e928cc2f64a8c78a02e56fac3c9e61103c1973ebae64c98d16ffbac1809 → M-A-r02, r02, 21c6dd76bce0220f3061849f969d93c990716da247dc0162eadd37b8b706228f. Das detaillierte Reveal bleibt unverändert. Kategorie obst-nuesse. Nach der anfänglichen freien Motividee ist diese Ableitung vorlagentreu: Identität, Pose, Perspektive, Frucht-/Kelchproportionen, rechts gebogener Stiel und wichtige Blattzwischenräume erhalten.

Die vielen feinen Nüsschen werden zu 16 größeren goldfarbenen Zeichen zusammengefasst; in der späteren Matrix darf deren exakte Zahl und Lage motivtreu variieren. Blattadern, Glanzlichter, einzelne Vertiefungen und Schattierungen entfallen. Kelchblätter bilden kräftige zusammenhängende Flächen, ihre oberen Einschnitte bleiben erkennbar. Die Illustration hat geglättete Kanten und ist noch keine diskrete Matrix.

## Empfehlung und vollständiger vorgeschlagener Korridor

Überliefertes Nutzerziel: ungefähr 18 × 18 Zellen, farbig, ungefähr drei Vordergrundfarben ohne Leer. Noch keine Parameterfreigabe.

| Option | Format Breite × Höhe | Motivtreue und Darstellbarkeit | Erwartetes Logikrisiko und Spielgefühl |
| --- | --- | --- | --- |
| P-A-r02 · empfohlen | 18 × 20, Farbe, genau 3 Vordergrundfarben | Zwei zusätzliche Reihen gegenüber dem Ziel geben der langen Frucht und dem Kelch mehr Platz, ohne die Vorlage zu strecken. Kompakt mit wenigen großen Binnenformen. | 360 Zellen; überschaubarer Umfang. Einzelne Nüsschen können kurze Hinweisfolgen und Mehrdeutigkeiten erzeugen; noch ungeprüft. |
| P-B-r02 · kompakter | 18 × 18, Farbe, genau 3 Vordergrundfarben | Hält den ursprünglichen Größenwunsch exakt; proportionaler Fit macht die Frucht etwas schmaler im verfügbaren Raster. Kelcheinschnitte und Nüsschen stärker zusammenfassen. | 324 Zellen; kürzerer Arbeitsumfang, höhere Detailkollisionen möglich. Keine Leichtigkeitszusage. |
| P-C-r02 · Detailreserve | 20 × 22, Farbe, genau 3 Vordergrundfarben | Größere Reserve für Blattabstände und Nüsschen; 440 statt 324 Zellen, daher bewusst nur Alternative zum ungefähren Größenwunsch. | Mehr Eingaben und potenziell längere Hinweisfolgen; mehr Größe garantiert weder Lösbarkeit noch höhere Schwierigkeit. |

Vorgeschlagener Korridor ausschließlich diese drei Maßpaare, Modus color, genau drei tatsächlich genutzte Vordergrund-IDs. Kein freier Bereich aller Kombinationen. Priorität P-A-r02, dann bei begründetem Darstellungs-/Logikkonflikt P-B oder P-C; Empfehlung ist keine spätere Rasterwahl. Voraussetzung bleibt menschliche Freigabe dieses Korridors und genau M-A-r02.

Farbrollen: Rot = zusammenhängende Frucht; mitteldunkles Grün = Kelch und Stiel; kräftiges Goldgelb = Nüsschen. Entwurfswerte für spätere Palettenprüfung: #df302d, #37733d, #d7a221. Dies sind noch keine gemessenen Matrixfarben. Keine vierte Kontur-/Schattenfarbe. Eine reduzierte Zweifarbenalternative Rot/Grün würde goldene Nüsschen in Leerstellen oder umgedeutete grüne Binnenzeichen verwandeln und die überlieferte Identität schwächen. Deshalb nicht empfohlen und nicht Teil des Korridors. Drei Farben haben jeweils eine eigene Motivfunktion.

Crop: proportionaler contain-Fit; nur vollständig transparente äußere Sicherheitsränder dürfen eng beschnitten werden. Kein Motivanschnitt, Spiegeln, Drehen oder Strecken. Zusammenfassen kleiner Blattzacken und motivtreues Verschieben/Zusammenlegen einzelner Nüsschen sind vorgeschlagen; charakteristische Hauptformen und sichtbare Negativräume bleiben geschützt. Kein Fremdpixel oder Rahmen als Logikanker. Technische Randregel und tatsächliche Palette erst an einer später freigegeben produzierten Matrix prüfen.

## Erreichter Stand

motif_review. Revealfreigabe tatsächlich erfasst; Motiv- und Parameterfreigabe offen. Kein Raster, keine Hinweise, kein Solver/Proof, keine Difficulty und keine Integration erzeugt. Nächster Auftrag: genau M-A-r02 mit dem vorgeschlagenen Korridor freigeben oder konkret korrigieren.
