# Motivbriefing · Erdbeere · pz-erdbeere/r01

Auftrag: neue Produktion nach Authoring 0.8.0, Schritt 1. Kategorie: obst-nuesse (Obst & Nüsse). Textidee ohne beigegebene Bildreferenz; freie Interpretation (free) innerhalb dieses Briefings. Arbeitsbranch: content/pw/pz-erdbeere. Basis- und Werkzeugcommit: 307e87099ff462150779b030fbffbe2001d6238e.

Hauptmotiv: genau eine reife Erdbeere. Unverzichtbar: roter zusammenhängender Fruchtkörper, klar abgesetzter grüner Blattkelch mit kurzem Stiel, goldgelbe Nüsschen in erkennbaren kleinen Vertiefungen und eine charakteristische weich zulaufende oder rundlich herzförmige Kontur. Keine Gesichter, Schrift, Wasserzeichen oder zusätzlichen Gegenstände. Ruhige warme handgezeichnete 2D-Illustration mit sauberer Binnenzeichnung, Blattadern, motivgerechter Oberflächendetailierung und zurückhaltender Schattierung. Außenfläche und echte Blattzwischenräume transparent. Das Abschlussbild bleibt detailliert und vollfarbig.

## Verbindlich überlieferte Nutzerziele für den Folgeauftrag

- Rastergröße: ungefähr 18 × 18 Zellen (Breite × Höhe).
- Rastermodus: farbig.
- Farbzahl: ungefähr 3 tatsächlich verwendete Vordergrundfarben; Leerfelder zählen nicht mit.
- Die Rasterfarbzahl begrenzt weder die Farbtöne noch den Detailgrad des Abschlussbilds.

Mögliche spätere Farbrollen: Rot = Fruchtkörper, Grün = Kelch/Stiel, Goldgelb = Nüsschen. Dies ist noch kein freigegebener Parameterkorridor und keine Zusage zur Lösbarkeit. Im Folgeauftrag sinnvolle Maße/Palette am tatsächlich freigegebenen Original konkretisieren. Details wie Blattadern, einzelne Vertiefungen und Schattierungen dürfen dann kontrolliert zusammengefasst werden; Identität, Pose und Hauptproportionen der gewählten Fassung bewahren. Materielle Änderungen erfordern ihre konkrete neue Freigabe.

## Tatsächliche Bildangebote

- E-A-r01: aufrechte, länglich zugespitzte Frucht; breit aufgefächerter Kelch, Stiel nach rechts gebogen.
- E-B-r01: diagonal liegende Frucht; Kelch links oben, runde Spitze rechts unten, geschwungener Stiel.
- E-C-r01: breitere, rundliche Herzform; leicht erhöhte Ansicht auf den ausgebreiteten Kelch, Stiel nach links gebogen.

Empfehlung: E-C-r01 für eine kompakte spätere Abstraktion. Empfehlung ist keine Auswahl. Alle drei Bilder sind gespeicherte native ImageGen-Originale, keine Raster oder Motivvorlagen. Die Originalbytes werden nicht verändert.

## Offene Entscheidung und nächster Auftrag

Zustand reveal_review. Der Mensch wählt und gibt genau E-A-r01, E-B-r01 oder E-C-r01 an den veröffentlichten PNG-Bytes/Hashwerten frei oder benennt eine gezielte Korrektur. Erst danach folgt Schritt 2: aus den gespeicherten Bytes der freigegebenen Fassung eine eigene Motivvorlage ableiten und den Größen-/Modus-/Farbenkorridor zur Freigabe vorlegen.
