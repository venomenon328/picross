# Om · Übergabe Standardauftrag 1

pz-87bf2975c82540a399a3d0c7fa180a25 · r01 · reveal_review · 2026-10-21T13:36:17.798624Z
Regelwerk 0.5.0 / Dokumentrevision 22; Quellen- und Werkzeugcommit eed5ba4eaa06b51a92c7b05fa141704fcbaabd5e.

Die Referenzbytes wurden gegen den Nutzerhash geprüft. Drei farbige, native Einzelbilder mit echter Transparenz liegen unter reveals/. A-r01: Safran/Terrakotta (Empfehlung); B-r01: Zinnoberrot/Gold; C-r01: Türkis/Jade/Gold. Hashes und Begründung: decisions.json; tatsächliche Prompts und Einstellungen: prompts.json. Keine weitere Bildbearbeitung.

Sichtprüfung: Erkennbarkeit, Silhouette/Proportionen, wichtige Details/Negativräume, Farb-/Formlesbarkeit und Serienästhetik für alle drei erfüllt; genaue Bewertung in review/visual-assessment.json. Große und kleine statische Papieransichten: review/paper-review.png. Alphamessung: review/image-metrics.json. Das ist keine native Katalog-/Abschlussprüfung. Rasterdarstellbarkeit und Lösbarkeit sind noch nicht geprüft.

Bild-, Motiv- und Endfreigabe: offen. Maße: offen. Rätselmodus: mono; eine Vordergrundfarbe ohne Leer. Matrix, Deduktionsnachweis, Randregel, Schwierigkeit, Reparatur und Zieladapter: in dieser frühen Bildphase noch nicht anwendbar. Keine ZA-1-Zertifizierung, Spielregistrierung oder Probespiele.

Referenzherkunft: Nutzerupload; konkrete Urheber-/Lizenzangaben unbekannt. Repositoryablage beauftragt; spätere Katalogfreigabe bleibt bei ungeklärter Nutzungsgrundlage blockiert. Details in provenance.json. Aufwand: drei Bildaufrufe, aktive Menschenzeit nicht erfasst.

Nächster Schritt: 2 · Bild freigeben & abstrahieren. Nutzer wählt A-r01, B-r01 oder C-r01 und gibt genau diese Datei samt den gebundenen Merkmalen ausdrücklich frei. Danach Konfigurationen vergleichen und Motivvorlage ableiten. Vorher keine Abstraktion oder Rasterproduktion.
