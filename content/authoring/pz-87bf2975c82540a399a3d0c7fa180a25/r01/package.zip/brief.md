# Om · Abschlussbildauswahl

ID: pz-87bf2975c82540a399a3d0c7fa180a25 · Paket r01 · Zustand reveal_review · 2026-10-21T13:36:17.798624Z

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.5.0, Dokumentrevision 22.
Referenz: source/reference.png, SHA-256 fe8a562508c88f9a11db997c9248a4e5336586e5726b48ad868864118fd6c35f; vom Nutzer als Om_symbol.png bereitgestellt.
Arbeitsweise: faithful. Hauptmotiv ist allein das Om-Symbol in der Form der Referenz.
Zu bewahren: Aufrechte, ungespiegelte Form der Referenz; Zwei charakteristische linke Bögen und zentrale Verbindung; Große rechte Schleife mit offenem Innenraum; Getrennte obere Sichel und darüber stehende Raute; Proportionen, charakteristische Freiräume und Strichgewicht erhalten; keine Zusatzobjekte.
Erlaubt: ausgearbeitete handgemalte Binnenzeichnung, Farbgebung, zurückhaltende Schattierung und saubere Konturen. Keine Neufassung des Zeichens, Spiegelung, Perspektivänderung oder Zusatzdekoration.
Rätselmodus monochrom, daher genau eine Vordergrundfarbe plus Leer. Abschlussbild bleibt farbig.
Rastermaße offen; noch kein Parameterkorridor, keine Abstraktion, Matrix oder Hinweise.
Kategorie mythen-fantasie (Mythen & Fantasie), entsprechend der vorhandenen Zuordnung symbolischer Motive wie Yin-Yang. Keine neue Kategorie angelegt.

Der Nutzer hat die Referenz zur Bearbeitung und die Repositoryablage einschließlich bedingtem Ablagemerge beauftragt. Urheber/Lizenz der konkreten Quelldatei wurden nicht genannt; kommerzielle Nutzungsgrundlage bleibt vor späterer Katalogfreigabe zu klären. Keine Lizenz oder Urheberschaft erfunden.
Alle drei neuen Bilder sind native KI-Ausgaben unter diesem Auftrag. Ihre generierten Bytes bleiben unverändert, einschließlich Alphakanal.
