# Rasterkonfigurationen · vorläufige Gestaltungseinschätzung

Alle Varianten: monochrom, genau eine Vordergrundfarbe ohne Leer. Keine Matrix oder Logikprüfung erzeugt.

| Größe | Motivtreue und Darstellbarkeit | Erwartetes Lösbarkeitsrisiko | Spielgefühl / Umfang |
| --- | --- | --- | --- |
| 24 × 24 | Charakteristische Grundform wahrscheinlich lesbar; getrennte obere Elemente, spitze Enden und schmale Abstände anfälliger für Zusammenfallen. | Nicht geprüft; dünne Trennungen können verschwinden, geometrische Rundungen müssen stärker vereinfacht werden. | Kurzes kompaktes Zeichenmotiv, 576 Positionen; keine Schwierigkeitsbehauptung. |
| 30 × 30 · Empfehlung | Ausgewogenes Verhältnis aus kräftigen Strichen, offenen Innenräumen und den drei getrennten Motivteilen. | Nicht geprüft; geschwungene Konturen bleiben ein möglicher Profilengpass. Keine Lösbarkeitszusage. | Mittleres Format mit 900 Positionen; Formaufbau ist wichtiger als Binnenzeichnung. |
| 35 × 35 | Mehr Konturauflösung, aber keine zusätzlichen identitätsprägenden Motivdetails. | Nicht automatisch geringer; mehr kleine Konturstufen können zusätzliche Abhängigkeiten erzeugen. | 1.225 Positionen und mehr Bearbeitungsumfang bei gleichem Informationsgehalt. |

Vorschlag: 30 × 30, zulässiger späterer Produktionskorridor 28–32 je Achse bei unverzerrten Formproportionen. Geringe Rechteckabweichungen sind allein durch Entfernen vollständig leerer Außenlinien zulässig. Die 24er-/35er-Vergleichsoptionen sind nicht Teil des vorgeschlagenen Korridors. Detaillierte Grenzen und vier geplante Erstkandidaten in configuration.json. Bestätigung erst mit tatsächlicher Motivfreigabe.
