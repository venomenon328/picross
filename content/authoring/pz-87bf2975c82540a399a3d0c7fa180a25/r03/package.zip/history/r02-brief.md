# Om · Motivvorlage MA-r01

pz-87bf2975c82540a399a3d0c7fa180a25 · Paket r02 · motif_review. Quelle/Toolstand: 4ef5c39e5a27b1e3d649c545f1e7025a0fdbe262.
Verbindliche Richtung: Nutzerreferenz → ausdrücklich freigegebenes Abschlussbild A-r01 → daraus nativ erzeugte MA-r01 → erst nach Motivfreigabe Rasterproduktion.
A-r01 SHA-256: 3ce9799443da21c46dc63754670f3fb89ec3822ca267c26c27d1e4cb4ce3387e; tatsächliche Freigabe in approvals/reveal-A-r01.json und approvals/user-statement.txt.
MA-r01 SHA-256: 48dcb9d42f579288f057f29e94c8f278a05d4f0dd312b86507103256294e3f17; noch nicht freigegeben.
Modus monochrom, genau eine Vordergrundfarbe ink (#202020) plus Leer. Größenempfehlung 30 × 30, Vorschlag 28–32 je Achse gemäß configuration.json. Formproportionen bewahren, keine Streckung; nur leere Außenflächen beschneiden. Die dortige Konfiguration ist noch nicht menschlich bestätigt.
Zu bewahren: Aufrechter, ungespiegelter Om-Aufbau; Beide linken Bögen und zentrale Verbindung; Große rechte Schleife samt offenem Innenraum; Getrennte Sichel und Raute oberhalb; Charakteristische Proportionen und Freiräume.
Erlaubte Detailverluste: Farbe, Pinselstruktur, Oberflächenschattierung und separate Konturlinie. Keine wichtigen Innenräume schließen, keine Teile verschmelzen oder entfernen, kein neuer Om-Schriftstil, keine motivfremden Logikanker.
Kategorie bleibt mythen-fantasie. Nutzerreferenz unverändert unter source/reference.png; Urheber/Lizenz unbekannt, Nutzungsgrundlage vor späterer Katalogfreigabe klären. Neue Bildfreigabe ist keine Lizenzbestätigung.
