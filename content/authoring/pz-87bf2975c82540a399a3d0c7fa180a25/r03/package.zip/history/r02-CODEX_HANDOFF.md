# Codex-Übergabe · Standardauftrag 3, noch nicht gestartet

Startvoraussetzung ist die tatsächliche neue menschliche Freigabe von motifs/MA-r01.png (SHA-256 48dcb9d42f579288f057f29e94c8f278a05d4f0dd312b86507103256294e3f17) samt configuration.json und Invarianten. Diese liegt noch nicht vor. A-r01 ist bereits freigegeben; diese Entscheidung nicht erneut einholen.

Repository venomenon328/picross, Ziel main. Aktuelle AGENTS.md und Pflichtquellen zuerst lesen; dann Index für pz-87bf2975c82540a399a3d0c7fa180a25/r02 und Paketbindungen auflösen. Produktionsbranch vom dann aktuellen main; keine fremden Änderungen übernehmen. Gesicherte Ausgangsbasis dieses Pakets: 4ef5c39e5a27b1e3d649c545f1e7025a0fdbe262.

Nach tatsächlicher Motivfreigabe Standardauftrag 3 gemäß docs/ai-workflows/PUZZLE_AUTHORING.md ausführen: Empfehlung 30 × 30, freizugebender Korridor 28–32 je Achse, mono mit genau einer Vordergrundfarbe ohne Leer. configuration.json ist eine redaktionelle Vorlage, kein direktes Werkzeugdesign. Formproportionen, drei getrennte Teile, Innenräume und Bezug zu A-r01 bewahren; keine Streckung. Erst dann streng gebundene Designs und vier gezielte Erstkandidaten herstellen, erforderliche unabhängige Produktionsnachweise und begrenzte Reparatur nach Workflow ausführen, Schwierigkeit nach aktuellem Standard bestimmen und bis content_ready zur Endabnahme liefern.

Keine Spielregistrierung, keine Endabnahme, kein Release oder Deployment aus diesem Paket ableiten. Die ungeklärte konkrete Referenznutzungsgrundlage bleibt vor Katalogfreigabe offen. Neue Produktionsunterlagen nach §6 sichern; ausdrücklich beauftragten passenden Ablagemerge nach erfolgreichen Pflichtprüfungen beachten. Keine alten ZIPs neu versiegeln und keine echten Bestandsrätsel replayen.
