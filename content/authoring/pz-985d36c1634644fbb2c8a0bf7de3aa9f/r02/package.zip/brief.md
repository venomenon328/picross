# Ingwer – Motivvorlage MA-r01

ID `pz-985d36c1634644fbb2c8a0bf7de3aa9f`, Paket r02. Standardauftrag 2 nach Authoring 0.4.1 / Dokumentrevision 8.
Ausdrücklich freigegeben: B-r01; Erklärung und Dateihash in approvals/reveal-approval.json.
Kategorie Gemüse, Pilze & Kräuter. Maße exakt **20 breit × 25 hoch**, 500 Zellen; mono.
Die farbigen freigegebenen Originalbytes werden als Reveal unverändert mitgeführt.

MA-r01 entstand durch native Bildbearbeitung genau dieser B-r01-Datei. Sie ist eine
Illustration, keine Zellmatrix. Diagonale Lage, Knollenenden, drei obere Äste und beide
Astzwischenräume sind erhalten. Farbe, feine Oberflächentextur und kleine Knubbel wurden
reduziert; weiße Gelenkeinschnitte ersetzen einen Teil der Binnenzeichnung.
Invarianten, erlaubte Detailreduktion, tatsächlicher Crop und enger Parameterkorridor:
configuration.json. Das bestehende technische Design steht in design.json.

Maße/Modus sind vom Nutzer fest bestellt; die Motivdatei und der gesamte vorgeschlagene
Korridor sind noch nicht menschlich freigegeben. Deshalb approved_parameters bleibt leer.
Kein Import, Raster, Solver, Proof, Reparatur, Schwierigkeitsurteil oder Export in dieser Phase.
Nach ausdrücklicher MA-r01-Freigabe folgt Standardauftrag 3 bis zur Endabnahmevorlage,
ohne Spielregistrierung. Aktueller Main-/Toolstand `835c102ba76f26683b4dc42a8077b650e1725303`; Arbeitsstand `3584353cc44249b0c481a2b30a3dccb32734ab5c`.
Quellen seit Auftrag 1 gegen main verglichen: Fach-/Workflowdokumente unverändert.
Aktuelle AGENTS.md, Index/Kategorien/Registry und PR #121 geprüft. MODEL_SELECTION und
MODEL_CATALOG zusätzlich gelesen. Allgemeine Quellen commitgebunden; Regelwerks-Snapshot im Paket.
