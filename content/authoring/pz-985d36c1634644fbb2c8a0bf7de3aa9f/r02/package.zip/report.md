# Ingwer – Motivfreigabevorlage

`pz-985d36c1634644fbb2c8a0bf7de3aa9f` / r02 · Status motif_review · 14.10.2026.
Authoring 0.4.1 / Dokumentrevision 8; Main-/Toolcommit `835c102ba76f26683b4dc42a8077b650e1725303`.
Inventarhash: siehe handoff.json/äußeren record.json.

B-r01 ist durch Tobias Schröder am 14.10.2026 um 15:06:48 UTC ausdrücklich freigegeben.
Bytebindung `f67bb2fc2e200fb68acfb0c0324520249b532419047cd645c94ce326018a3471`; Beleg approvals/reveal-approval.json.
MA-r01 ist nativ aus diesen Originalbytes abgeleitet, Hash `974bda0232439ecc4d9acc3c7f43cf5d79ce193ffce9f758c9d5882fff6170eb`.
Hauptachse, Proportionen, große Knollenenden und Astzwischenräume erhalten;
Farbe, Hauttextur und kleine Knubbel reduziert. Bildkriterien/Ableitung: derivation.json.
A/C bleiben nur in der unveränderten Vorgängerrevision r01; genaue Verweise/Hashes in decisions.json.

Konfiguration: exakt 20 × 25 / 500 Zellen / mono / ein schwarzer Vordergrund.
Area-Import, proportional contain, Crop [21,22,1101,1354], Schwellen 96/128/160/192.
Diese vorgeschlagenen Parameter und MA-r01 warten noch auf menschliche Motivfreigabe.
Keine Raster-/Logik-/Randregel-/Endmatrix-/Schwierigkeitsprüfung, keine Lösbarkeitszusage.
Schwierigkeit/Lösungszeit nicht geschätzt. Probespiel nicht durchgeführt und optional.

Dateibindungen, PNGs, ZIP-Dateimenge/sichere Pfade, bytegleiche Handoffkopie und
Designsyntax werden vor Ablage geprüft; frühe Motivphase ist kein ZA-1-inspect-Eingang.
Eine native Bearbeitung, keine Korrekturrunde oder Import-/Reparaturversuche; Menschenzeit null.
Codex-Übergabe: codex-handoff.md / codex-prompt.txt.
Nächster Schritt: Ausdrückliche menschliche Motivfreigabe MA-r01 samt configuration.json für exakt 20 × 25 mono; danach Standardauftrag 3 bis content_ready/Endabnahmevorlage, keine Registrierung.
Repositoryablage/CI ersetzt weder Motiv- noch Endfreigabe. Kein Merge.
