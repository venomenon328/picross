# Codex-Übergabe – Standardauftrag 3

Stand: vorbereitet, durch die noch offene Motiv-/Parameterfreigabe bedingt.
Nicht vor der tatsächlichen Freigabe des Menschen importieren. Der folgende Prompt
enthält diese Freigabe als Vorlage für die nächste Nutzernachricht, nicht als bereits
erteilte Erklärung. Einstieg über Paket `pz-985d36c1634644fbb2c8a0bf7de3aa9f` / r02, PR #121 / `chore/ingwer-reveal-r01`.
Beide Bilddateien, Revealfreigabe, Herkunft, Invarianten, Design und Konfiguration sind im Paket.

Bevorzugter Weg: Codex. Selbst umsetzbar: Ja – Bild-, Datei-, Werkzeug- und Repositorywege
sind vorhanden; Codex ist für die folgende zusammenhängende Raster-/Proof-/Kurationsschleife vorgesehen.
Codex: GPT-5.6 Sol — Reasoning: High (lokaler Katalogstartpunkt für differenzierte
Kuratierung und logische Prüf-/Reparaturschleifen; Auswahl in der konkreten Nutzeroberfläche
nicht überprüft). Kein automatischer Mehragentenmodus und keine Modell-API.

```text
Arbeite in venomenon328/picross nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Quellstand: aktueller main; bestehender Arbeitsbranch chore/ingwer-reveal-r01, Draft-PR #121.
Paket pz-985d36c1634644fbb2c8a0bf7de3aa9f / r02 über content/authoring/index.json laden und Dateibindungen prüfen.
Ich gebe die vorgelegte Motivvorlage MA-r01 samt configuration.json frei: exakt 20 breit × 25 hoch, monochrom.
Führe Standardauftrag 3 bis zur Endabnahmevorlage samt geprüftem Paket aus.
Repositoryablage nach §6 ist beauftragt. Draft-PR fortführen; keine Registrierung, kein Merge.
```

Die vier area-Schwellen vergleichen exakt dieselben 20 × 25 Zellen; keine Größenvarianten.
Echte Duplikate erkennen; falls nötig nur begründete weitere Varianten im freigegebenen
Korridor. Keine Contour-Umstellung. Vor Reparatur Schutzmaske/Budget nach Workflow
festlegen, wichtige Astzwischenräume bewahren. Wenn Darstellbarkeit/Logik scheitert,
keinen größeren Rasterstand oder neue Geometrie eigenmächtig herstellen.
