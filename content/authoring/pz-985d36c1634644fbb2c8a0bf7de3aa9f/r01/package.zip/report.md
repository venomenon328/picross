# Ingwer – Übergabe r01

ID `pz-985d36c1634644fbb2c8a0bf7de3aa9f` · Status `reveal_review` · 14.10.2026.
Regelwerk 0.4.1 / Dokumentrevision 8; Tool-/Quellcommit `62e290bfce56071b6870f2ed2896fce776c7ae03`.

| Datei | Vergleich |
| --- | --- |
| A-r01 | Aufrecht, klare Seitenäste; empfohlen für die feste Hochformatabstraktion. |
| B-r01 | Diagonal, etwas bewegter; andere Astzwischenräume. |
| C-r01 | Kompakte Knolle mit heller Schnittfläche; in Mono zusätzliche Binnenform nötig. |

Alle drei nativen farbigen PNG-Originale sind visuell geprüft; Kriterien und
Dateibindungen: visual-review.json. Prompts/Einstellungen: generation.json.
20 × 25 Zellen / 500 Zellen / mono sind fest bestellt; Rasterpalette noch nicht erstellt.
Bild-, Motiv- und Endfreigabe offen. Kein ausgewählter Kandidat, keine Ablehnung,
keine Reparatur und keine Rasterproduktion. Herkunft: beauftragte eigenständige KI-Generierung.

ZIP-Dateimenge, Hashes, sichere Pfade und bytegleiche äußere Handoffkopie werden vor
Ablage geprüft. Inventarhash steht im handoff.json und äußeren record.json.
Keine ZA-1-inspect-Zertifizierung: frühe Bildphase, noch kein content_ready-Eingang.
Randregel, Hinweise, vollständiger Proof, unabhängige Prüfung und Endmatrixgleichheit:
noch nicht anwendbar. Schwierigkeit, Aufwand des Lösens und Lösungszeit: nicht geschätzt.
Drei Bildaufrufe, keine Korrekturrunde; aktive Menschenzeit nicht erfasst.
Export/Registrierung nicht beauftragt. Keine rätselspezifischen Tests oder CI-Replays.

Nächster erlaubter Schritt: ausdrückliche menschliche Freigabe A-r01, B-r01 oder C-r01,
danach Standardauftrag 2. Repositoryablage ist keine Inhaltsfreigabe.
