# Ingwer – Abschlussbildauswahl

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.4.1, Dokumentrevision 8.
Motiv Ingwer; feste Maße **20 breit × 25 hoch**, 500 Zellen; Modus **mono**.
Abschlussbilder bleiben farbig. Maße dürfen nicht eigenmächtig geändert oder vertauscht werden.
Kategorie: Gemüse, Pilze & Kräuter (`gemuese-pilze-kraeuter`). Freie Interpretation des Motivtexts ohne Fremdbild.

## Motivkern und Gestaltung

Erkennbare knollige Ingwer-Rhizome mit kräftigen fingerartigen Verzweigungen, Gelenkringen,
charakteristischen Knubbeln und offen lesbaren Zwischenräumen. Warme 2D-Illustration,
saubere braune Konturen, kräftige goldbraune Flächen, motivgerechte Hautdetails, ruhiger
elfenbeinfarbiger Hintergrund. Keine Umgebung oder Zusatzdekoration.
A und B zeigen ganze Knollen; C zeigt einen angeschnittenen oberen Ast.
Alle Bilder haben 1122 × 1402 Pixel; das annähernde 4:5-Bildformat ist keine Zellmatrix.

## Grenzen und nächste Phase

Noch keine ausgewählte oder freigegebene Bilddatei, Motivvorlage, Matrix, Hinweise,
Logik- oder Schwierigkeitsprüfung. Keine Lösbarkeitszusage. Nach ausdrücklicher
Abschlussbildfreigabe Standardauftrag 2: gewählte Originalbytes binden, daraus eine
monochrome Motivvorlage für exakt 20 × 25 ableiten und zur Motivfreigabe vorlegen.
Feine Oberflächentextur wird später zusammengefasst; wichtige Verzweigungen und
Zwischenräume sowie bei C die Schnittfläche sollen erhalten bleiben.

## Auftrag und Quellen

Nutzerauftrag vom 14.10.2026: Repositoryablage nach §6, Draft-PR, kein Merge.
Arbeitsumfang umfasst Auswahlpaket, Index, Commit und Push; keine Spielintegration.
Quell- und Toolcommit: `62e290bfce56071b6870f2ed2896fce776c7ae03`. Aktuelle AGENTS.md, Workflow, Projektprofil,
Produktdefinition, Gestaltungskonzept, Produktionsvertrag, Werkzeuganleitung,
Authoring, Kategorienvertrag, ZA-1, CI-Policy und Bestandsinventar tatsächlich gelesen.
Die allgemeinen Dokumente sind commitgebunden; nur der verpflichtende Regelwerks-Snapshot
liegt im Paket. Herkunft und tatsächliche Bildprompts stehen in generation.json.
