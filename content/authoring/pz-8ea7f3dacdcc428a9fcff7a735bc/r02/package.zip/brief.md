# Efeutute · Motivvorlage

Standardauftrag 2 nach Regelwerk 0.4.1, Dokumentrevision 5.
ID pz-8ea7f3dacdcc428a9fcff7a735bc, Paket r02, Kategorie `blumen-pflanzen`, Rätselmodus farbig.
Quellstand main f666f87d36a0ea7fa3740202d08706f2215bc303; gespeicherte Bildauswahl im Branch authoring/efeutute-selection,
Commit 30cd3179d2a245d7c01b3d0e448ad759eda0365d. Aktuelle Pflichtquellen sind gegenüber main unverändert.
Tobias gibt A-r01 ausdrücklich frei. Freigabe bindet Datei/Revision/SHA-256;
kein Wechsel zur anderen Bildvariante. Abstraktion erfolgt vorlagentreu (`faithful`).
Motivdatei MA-r01 ist separate Bilddatei; Reveal bleibt bytegleich.
Konfiguration, Invarianten und Detailverluste: `configuration.json`, `visual-review.json`.
Autorisierung: Standardauftrag 2, Paketsicherung, Commit/Push und Fortführung
des Draft-PR #108. Kein Raster, keine Integration, kein Merge.
