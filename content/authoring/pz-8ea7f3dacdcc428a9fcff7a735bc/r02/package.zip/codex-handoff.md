# Codex-Übergabe · Efeutute r02

Standardauftrag 2 endet mit `motif_review`; keine Rasterproduktion beauftragt.
Abschlussbild A-r01 ist ausdrücklich durch Tobias freigegeben; tatsächlicher
Beleg `approvals/reveal-A-r01.json`, Originalbytes `reveal/A-r01.png`.
Motiv MA-r01 (`motif/MA-r01.png`) ist daraus abgeleitet; Freigabe noch offen.
Beide Dateien, getrennte Herkunft und Hashes sind enthalten; keine erneuten Uploads verlangen.
`configuration.json` führt Größenvergleich, Empfehlung und exakten vorgeschlagenen Korridor.

Bevorzugter Weg: Codex. Selbst umsetzbar: Ja, Werkzeuge vorhanden; Standardarbeitsteilung
für die zusammenhängende Produktions-/Proof-/Kurationsschleife.
Codex: GPT-6 Astra — Reasoning: High. Kontospezifische Verfügbarkeit nicht verifiziert;
Auswahl in der Oberfläche, keine Modell-API, keine Parallelisierung.
Offizielle Modellquellen mit Datum in `execution-choice.json`.

Nach menschlicher Freigabe von MA-r01 und Korridor ist dieser Auftrag kopierbar:

```text
Arbeite in venomenon328/picross, PR #108, Branch authoring/efeutute-selection; Ziel main.
Lies AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md samt Pflichtquellen.
Paket pz-8ea7f3dacdcc428a9fcff7a735bc/r02 über content/authoring/index.json laden und Dateibindungen prüfen.
Ich gebe Motivvorlage MA-r01 und den Parameterkorridor in configuration.json frei.
Verbindliche Referenz bleibt das freigegebene Abschlussbild A-r01.
Führe Standardauftrag 3 bis content_ready samt Endraster, Bericht und Freigabepaket aus.
Repositoryablage nach §6, denselben Draft-PR fortführen; keine Integration, kein Merge.
```

Nicht vor tatsächlicher Freigabe ausführen. Die Promptvorlage ist keine Freigabe.
Maße 40×40 empfohlen, zusätzlich 48×48; vier Vordergrundfarben, `area`,
quadratischer unverzerrter enger Crop ohne Motivverlust; zwei konkrete Paletten.
Invarianten: Blattpositionen/-proportionen, Topfumriss/-lage, rechte Seitenranke,
Panaschierung und wichtige Zwischenräume. Feine Marmorierung/Adern/Texturen entfallen.
Keine Lösbarkeits-/Schwierigkeitszusage; sämtlicher Nachweis entsteht in Auftrag 3.
