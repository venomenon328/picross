# Nächster Auftrag · 4 · Abnehmen & ins Spiel integrieren

Dieses content_ready-Paket enthält die Endabnahmevorlage. Keine Endabnahme erfunden.
Vor Integration tatsächliche menschliche Endfreigabe separat an das unveränderte
r03-Handoff, Inventar, Auswahl/Matrix-/Logikhash und A-r01 binden.
Danach PUZZLE_AUTHORING §§8–9 mit aktuellen Pflichtquellen ausführen.
Die vollständige geprüfte 0.3-Analyse unter analysis/checked.json wiederverwenden und
nach tatsächlichem Export bei identischer ID/Modus/Logik/Matrix ausdrücklich neu binden.
Keine erneute Routineanalyse, kein Routinepaarlauf oder Probespielgate.
Ablage-Merge ist keine Registrierung. Die tatsächliche Endabnahme bleibt erforderlich,
auch wenn der Eigentümer den späteren Integrationsmerge bereits bedingt beauftragt hat.
