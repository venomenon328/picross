# Sonnenblume · r03 · content_ready · 21.10.2026

ID `pz-a13368590b744814915eb722f5b2c5f2`; Regelwerk 0.5.0 / Revision 22;
Quell-/Toolcommit `c941f95b4aecd0f14ff93209fa1900147c87b011`.
Inventarhash im bytegebundenen [Handoff](handoff.json); Dateiliste im [Inventar](inventory.json).

[Endabnahmeansicht](review/final-comparison.png) · [Endraster ohne Glättung](review/final-raster.png) ·
[Raster mit Gitter](review/final-grid.png) · [1 Pixel je Zelle](imports/color-32x40-4colors/area-raster.png) ·
[Abschlussbild A-r01](reveals/A-r01.png) · [Motiv MA-r01](motifs/MA-r01.png).

**Auswahl:** 32×40 = 1280 Zellen, farbig, tatsächlich vier Farben; 629 gefüllt/651 leer.
Gold #e8ae28: Blütenkranz (285); Braun #684323: Mitte/kleine Grenzen (107);
Dunkelgrün #29452e: Stängel/Blattstiele und punktuelle Hauptader (23);
Blattgrün #638449: Blattflächen (214). Keine genaue Wunschfarbzahl vorgegeben.
Vier [Kandidaten](review/candidates.png) vollständig gelöst; kompakte 28×35-Fassung gröber,
Dreifarbenfassungen ohne Binnenstruktur und mit gelblichen Blattrandfragmenten verworfen.
Keine zusätzlichen Varianten, keine Rasteredits, kein Reparaturdiff; geeigneter Direktimport,
daher keine Reparaturrunden, Paar- oder Eindeutigkeitssuchläufe erforderlich.

**Gestaltung:** Alle fünf Kriterien [erfüllt](review/visual-review.json). Kopf, Proportionen,
Blattversatz und Zwischenräume bleiben. Feine Samen, Adern, Blattzähne und einzelne
Blütentrennungen sind abstrahiert; die Hauptader wird nur punktuell dargestellt.
49,14 % Füllung; keine isolierten Füllzellen oder leeren Innenstreifen. Letzte Zeile/Spalte
bleiben durch contain leer; Randregel besteht über links/oben, keine künstlichen Randpixel.

**Pflichtprüfung bestanden:** Maße/Palette/Randregel [Statistik](review/raster-statistics.json);
Quelle→Normalisierung→Matrix→Hinweise [frisch rekonstruiert](review/provenance-verification.json).
`full-line-color` vollständig, 209 Schritte; [frischer unabhängiger Prüferprozess](review/final-proof-verification.json).
Enddomains exakt gleich der Matrix; deduktive Vollständigkeit beweist auch Eindeutigkeit.
Keine Vorbelegungen, Suchannahmen oder Motivprämissen. Geschriebenes ZIP wird zusätzlich
frisch mit ZA-1 inspect geprüft; dessen äußerer Bericht und Pflicht-CI stehen am Repositoryrecord/PR.

**Aktuelle Schwierigkeit:** [0.3, vollständig geprüft](analysis/checked.json): L3 – Mittel,
instrumented/medium, Basis 3 + Größe 0; R2 notwendig, 23 Wellen (R0:6/R1:11/R2:6),
keine Engstellenwelle, Enge 1/6. Kein R3/R4 nötig; synthetisch gebundene Modellbewertung,
keine menschliche Kalibrierung oder Lösungszeit. 0.1-[Kompatibilitätsmetadaten](difficulty.json)
bleiben davon ausdrücklich getrennte redaktionelle Produktionsschätzung L3 (L2–L4/low).

A-r01-[Bildfreigabe](approvals/reveal-approval.json) und MA-r01-[Motivfreigabe](approvals/motif-approval.json)
liegen tatsächlich vor; **Endabnahme offen**. Herkunft/Nutzungsgrundlage: beauftragte native
KI-Neuschöpfung und vorlagentreue Ableitung, keine fremde Bildvorlage oder Exklusivitätsbehauptung.
In dieser Phase 4 Importe/1 Analyse/0 Bildaufrufe; [Aufwand](effort.json), Menschenzeit nicht erfasst.
Probespiel optional/nicht durchgeführt; native Spielprüfung nicht erforderlich: reine Authoringproduktion.
Kein Zieladapterexport, keine Runtime-Registrierung oder Veröffentlichung.
**Nächster Schritt: 4 · Abnehmen & ins Spiel integrieren**, nach tatsächlicher Endfreigabe.
