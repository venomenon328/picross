# Sonnenblume · Standardauftrag 3

Rätsel-ID pz-a13368590b744814915eb722f5b2c5f2, Kategorie blumen-pflanzen.
A-r01 und MA-r01 bleiben bytegleich. Tatsächliche Motiv-/Parameterfreigabe sowie
Produktions- und Ablageauftrag liegen unter approvals/motif-approval.json.
Gewählter Direktraster: 32×40, Farbe, vier Vordergrundfarben; innerhalb des genehmigten
Korridors 28×35/30×38/32×40 mit 3–4 Farben. Die Nutzerwünsche zu exakten Maßen und
Farbzahl bleiben offen; dies ist die freigegebene Empfehlung, keine erfundene Festvorgabe.
Goldkranz, große braune Mitte, frontaler Kopf, gebogener Stängel, genau zwei
versetzte breite Blätter und die Zwischenräume erhalten. Keine neue Bildproduktion.
Vier Anfangsdesigns, keine Reparatur nötig; vollständige technische Prüfung und
separate instrumentierte Schwierigkeit 0.3. Endabnahme offen, keine Spielregistrierung.
Repositoryablage samt Merge nach Pflichtprüfungen ist beauftragt.
