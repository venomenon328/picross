# Fortsetzung nach tatsächlicher Endfreigabe · ZA-1 v4

Paket unverändert lassen. Die konkrete menschliche Endabnahme muss r04, die Auswahl,
Matrix-/Logikhash, Inventar/Handoff und A-r01 sowie die festen 27 Zellkorrekturen annehmen.
Dann die tatsächliche Erklärung separat als Endfreigabe und `picross-owner-override-v4`
mit `permissions={fixed_color_edits:true}` aufzeichnen; niemals jetzt ein pass-Flag erfinden.
Externe `picross-manual-authorization-v4` aus diesen tatsächlichen Bindungen erzeugen.
`approved_motif` bindet die ursprüngliche inventarisierte MA-r01-Freigabe und den
ursprünglichen 32×40/4-Farben-/Crop-Parametersatz. `base` ist der vollständige
Direktimport `imports/color-32x40-4colors`, Variante `area`; `steps` enthält genau
`edits/veins-plan.json`, `edits/veins-record.json`, deren Dateihashes und exakte Maske
sowie Ausgabe `production/veins-r04`, Variante `area`. `superseded_content_blockers=[]`.
Paket-ZIP-, Handoff- und Inventarhash selbst aus den Originaldateien berechnen.
Die Besitzererklärung muss den tatsächlichen Endfreigabe-Dateihash binden.
Danach regulärer `target_adapter export --manual-authorization ...` mit echter
Endfreigabe und Kategorie `blumen-pflanzen`; keine synthetische Freigabe verwenden.
Die neue vollständige 0.3-Analyse `analysis/checked.json` wiederverwenden und nach
Export bei gleicher ID/Modus/Logik/Matrix neu binden. §8–9 und geltende Mergebefugnis
beachten. Keine technische Werkzeugänderung nötig; keine echten Saves.
