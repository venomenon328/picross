# Sonnenblume · Abschlussbildauswahl

Standardauftrag 1 nach PUZZLE_AUTHORING, venomenon328/picross@main.
Motiv: Sonnenblume. Rätselmodus: farbig (feste Nutzervorgabe).
Rasterbreite, Rasterhöhe und gewünschte Vordergrundfarbzahl sind offen.
Regulär höchstens 50 Zellen je Achse. Abschlussbilder bleiben detailliert farbig.
Kategorie: blumen-pflanzen · Blumen & Pflanzen.

Freie Interpretation (free), keine bindende Bildreferenz. Identitätskern:
goldgelber Strahlenblütenkranz, deutlich braune runde/ovale Samenmitte,
grüner Stängel und charakteristische breite Blätter. Varianten dürfen
Ansicht, Neigung, Stängellänge und Gewichtung von Blüte/Blättern variieren.
Keine Schrift, Raster, Rahmen, Töpfe oder motivfremde Nebenobjekte.
Warme konturierte 2D-Illustration, ausgearbeitete Binnenzeichnung,
echte PNG-Transparenz außen und in Zwischenräumen.

Die drei Varianten sind Angebote ohne menschliche Bildfreigabe.
Keine Abstraktion, Matrix oder Hinweise vor Auswahl und ausdrücklicher
Freigabe einer konkreten Dateirevision. Größe und Rasterpalette werden danach
im Standardauftrag 2 verglichen und empfohlen; noch keine Lösbarkeitszusage.

Repositoryablage nach §6 samt Merge nach erfolgreichen Pflichtprüfungen ist
beauftragt. Keine Bild-/Motiv-/Endfreigabe und keine Runtime-Registrierung.
Herkunft: drei nativ in ChatGPT für diesen Auftrag erzeugte Einzelbilder,
ohne fremde Bildvorlage. Nutzungsgrundlage: beauftragte KI-Neuschöpfung für
dieses Projekt; keine Exklusivität oder fremde Assetlizenz behauptet.
Originalbytes und tatsächliche Bildprompts bleiben erhalten.
