# Codex-Übergabe · erst nach Motivfreigabe

Status: vollständig vorbereitet bis zur Motiv-/Parameterfreigabe, noch kein
startfreier Produktionsauftrag. Bevorzugter Folgeweg: Codex für die längeren
lokalen Produktions-, Profil- und motivgeschützten Reparaturschleifen.
Selbst umsetzbar: Ja, Werkzeuge, Quell-/Schreibzugriff und lesbare CI sind
vorhanden; eine menschliche Motiv- oder Endabnahme kann keine Umgebung ersetzen.
Eine konkrete Modell-/Reasoningempfehlung wird erst bei tatsächlicher
Umsetzungsvorbereitung des freigegebenen Produktionsauftrags aktuell geprüft;
keine ungeprüfte Verfügbarkeitsbehauptung aus dem datierten Modellkatalog.

Nach tatsächlicher Freigabe von MA-r01 und parameters.json kopierbar:

```text
Arbeite in venomenon328/picross@main. Lies die aktuelle AGENTS.md und
docs/ai-workflows/PUZZLE_AUTHORING.md samt Pflichtquellen.
Ich gebe motifs/MA-r01.png · MA-r01 und den Korridor aus parameters.json
im Paket content/authoring/pz-a13368590b744814915eb722f5b2c5f2/r02/package.zip · r02 frei.
Starte Standardauftrag 3 für pz-a13368590b744814915eb722f5b2c5f2. Prüfe aktuellen Index,
Record und Inventar und binde diese tatsächliche Freigabe. A-r01 samt
bereits gebundener Abschlussbildfreigabe unverändert erhalten.
Produziere innerhalb des Korridors bis zur redaktionellen Endabnahmevorlage;
die vier Anfangsdesigns vergleichen zwei Größen und drei/vier Farben.
Führe die vorgeschriebenen Prüfungen, Profilwahl und nötige motivgeschützte
Reparaturen sowie die aktuelle Schwierigkeitsanalyse aus. Sichere die neue
Paketrevision nach §6 samt PR; Ablage-PR nach erfolgreichen Pflichtchecks mergen.
Keine Spielregistrierung vor gesonderter Endabnahme, kein Release/Deployment.
```

Der kopierte und tatsächlich gesendete Folgeauftrag erteilt die Freigabe;
dieser vorbereitete Text allein ist kein Freigabebeleg.
