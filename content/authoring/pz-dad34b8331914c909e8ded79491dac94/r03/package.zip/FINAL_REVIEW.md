# Menschliche Endabnahme · Vorlage, noch keine Freigabe

Bitte das finale Raster, sein Gitter und das unveränderte A-r01 im Bildvergleich prüfen.
Die technische Prüfung und Schwierigkeit sind belegt; menschliches Probespiel ist optional.
Die sieben festen Randfarbkorrekturen sind bereits tatsächlich autorisiert, die abschließende
redaktionelle Abnahme ist davon getrennt. Nach dieser Erklärung werden echte Freigabedateien
außerhalb des unveränderlichen ZIPs erzeugt.

Vorschlag für den nächsten Auftrag (nur nach eigener Endabnahme verwenden):

> Ich nehme Regenbogen r03 mit dem vorgelegten finalen 50×30-Raster, sieben Farben,
> dem unveränderten Abschlussbild A-r01 und der dokumentierten festen Ableitung ab.
> Ich autorisiere für genau dieses Paket den ZA-1-v5-Weg aus dem bestätigten stalled-
> Originalimport samt den acht dokumentierten Edits. Führe Standardauftrag 4 aus und
> merge den Integrations-PR nach erfolgreichen Pflichtprüfungen; anschließend §9-Cleanup.

Datei- und Inventarhashes stehen neben dem ZIP in record.json; sie werden aus den
tatsächlich gesicherten Dateien übernommen und müssen nicht abgetippt werden.
