# Konfigurationsvergleich · Vorschlag, noch keine Freigabe

| Konfiguration | Motivtreue und Darstellung | Lösbarkeitsrisiko | Spielgefühl |
| --- | --- | --- | --- |
| **50×30 · 7 Farben – empfohlen** | Sechs Bänder und weiße Wolken getrennt; Breite nutzt die reguläre Achsgrenze und erhält den breiten Bogen ohne Strecken. | Geschwungene Randtreppen und Wolken können Engstellen erzeugen; noch ungeprüft. | 1500 Zellen, mehr Farbwechsel, klare bandweise Orientierung. |
| **48×29 · 7 Farben** | Nahezu gleiche Proportionen, etwas gröber und kompakter. | Weniger Platz für Band-/Wolkenränder; weder leichter noch schlechter bewiesen. | 1392 Zellen, etwas weniger Eingaben. |
| **50×30 · 6 Farben** | Blau/Violett gemeinsam blauviolett; innere Spektraltrennung sichtbar reduziert. | Weniger Farbinformation kann Ableitungen schwächen; kein sicherer Vereinfachungseffekt. | 1500 Zellen, weniger Farbwerkzeuge, schwächere visuelle Differenzierung. |

Als vierte gezielte Produktionshypothese ist 48×29 mit derselben 6-Farben-Palette enthalten. 48×30 war vor dem fertigen Bild eine vorläufige Empfehlung: Der tatsächliche inhaltliche Crop ist etwas breiter und würde dort beim dokumentierten contain-Fit zwei Polsterzeilen erzeugen. Deshalb jetzt 50×30 als begründete Empfehlung innerhalb der ungefähren Höhenvorgabe. Alle Maße ≤50.

Sieben Vordergrundfarben sind hier motivisch begründet: sechs sichtbare Spektralbänder, jede weitere Zusammenlegung entfernt eine benannte Farbtrennung, plus das eigenständige Wolkenweiß. Sechs ist die bewusst reduzierte Alternative, acht wird nicht benötigt. Bitmap-Antialiasing/-Farbschwankungen sind keine zusätzlichen Rasterfarben. Keine Istfarbzahl, Schwierigkeit, Lösbarkeit oder Lösungszeit ohne Matrix/Nachweis angeben.
