# Codex-Übergabe · Standardauftrag 3

**Status:** Paket technisch vorbereitet. Die ausdrückliche Freigabe von `motifs/MA-r01.png` samt vorgeschlagenem Korridor fehlt noch; vorher keine Rasterproduktion. Diese Übergabe ist keine erfundene Freigabe.

Bevorzugter Weg: Codex. Selbst umsetzbar: Ja; Datei-/Repository-/Werkzeug-/CI-Zugriff vorhanden. Codex wird für die angeforderte längere Produktionsstrecke bevorzugt. Codex: **GPT-6 Astra — Reasoning: High**. Prüfung und Begründung in `codex-execution.json`; keine Modell-API einbauen.

Nach tatsächlicher Freigabe im nächsten Auftrag verwenden:

```text
Arbeite in venomenon328/picross@main ab der aktuellen AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Führe Standardauftrag 3 für pz-dad34b8331914c909e8ded79491dac94 aus; lade r02 über content/authoring/index.json und prüfe die gebundenen Dateien.
Die neue Auftragsnachricht muss die tatsächliche Freigabe von motifs/MA-r01.png (3ac159441bdcaa3e790ef4c880f3bbd49a960c44b28b345b940baca617e55313) und configuration/corridor.json enthalten; protokolliere genau diese Erklärung, keine vorweggenommene Zustimmung.
Abschlussbild reveals/A-r01.png bleibt bytegleich. Nutze die vier gespeicherten Designhypothesen aus configuration/corridor.json; empfohlen 50×30, farbig, 7 Vordergrundfarben, Alternative 6 nur mit Blau/Violett-Zusammenlegung.
Arbeite auf einem neuen isolierten Arbeitsbranch bis zum geprüften content_ready-Paket und der Endabnahmevorlage nach §§4–7 einschließlich §6-Ablage; keine Runtime-Registrierung. Produktions-/Proof-/Reparaturregeln stehen im gebundenen Regelwerk und aktuellen Pflichtquellen. Befugnisse zum Ablagemerge aus der tatsächlichen neuen Auftragsnachricht übernehmen; keine zusätzliche Integrationsfreigabe erfinden.
```

Index/Originalpaket: `content/authoring/pz-dad34b8331914c909e8ded79491dac94/r02/package.zip`. ID bleibt unverändert. Paketrevision ist nicht Runtime-Revision. Sämtliche r01-Bytes bleiben in Git erhalten. Modelleinstellung in der Oberfläche, kein automatischer Modellaufruf. Nach Freigabe `approved_parameters` mit dem tatsächlich freigegebenen Korridor füllen und `motif.approval` an den neuen Originalbeleg binden; die konkrete Exportauswahl muss im heutigen ZA-1-Format exakt gebunden werden. Der vorgeschlagene Korridor erteilt bis dahin keine Zustimmung.
