# Regenbogen · r01 · reveal_review

pz-dad34b8331914c909e8ded79491dac94 · 2026-10-21T15:38:40.603750+00:00 · Authoring 0.5.0 / Dokumentrevision 22 · Quell-/Toolcommit `054a4a6496cf75fc77fb431966c65416fd18546d`.

Drei echte transparente PNG-Einzeldateien stehen unter `reveals/`: A-r01 breiter klassischer Bogen, B-r01 höherer Bogen, C-r01 asymmetrische Wolkenkomposition. Empfehlung A-r01; alle Varianten bleiben zur Auswahl erhalten. Keine Variante ausgewählt oder verworfen, keine Freigabe erfunden. Prompt-/Einstellungsbelege in `prompts.json`, Herkunft je Bild daneben, Varianten und Hashes in `decisions.json`, Quellen in `source-bindings.json`.

Wunsch: Breite offen, Höhe ungefähr 30, farbig, Farbzahl offen. Istmaße der Raster, Zellzahl, tatsächlich verwendete Vordergrundfarben, Schwierigkeit und Lösungszeit: noch nicht bestimmt. Sechs Spektralbänder der Illustration legen die Rasterpalette nicht fest. Kategorie `landschaften-natur`.

Bildkriterien einschließlich Silhouette, charakteristische Details/Innenräume, Farbe und Serienästhetik: je Variante erfüllt; `visual-review.json` bindet die konkreten Beobachtungen und Papierquelle. Original-RGBA sowie große und kleine statische Papierkompositionen (112/140 px Bildhöhe) gesichtet; saubere transparente Außen- und Innenräume bei erhaltenem Wolkenweiß. Keine native Spiel-/Renderingprüfung behauptet.

Frühe Bildphase: noch keine Motivvorlage, Matrix, Hinweise, Reparatur, Logik-/Rand-/Proof-/Schwierigkeitsprüfung oder Adapterzertifizierung entstanden. Keine Bestandsrätsel geprüft. Bild-, Motiv- und Endfreigabe stehen aus. 3 native Bildaufrufe, eine Runde; aktive Menschenzeit nicht erfasst. Technische Ablageprüfung validiert ZIP-Pfade, Dateimenge/-hashes, Inventar und identische Handoffkopie außerhalb der CI; Ergebnis liegt neben dem ZIP. Reiner Inhalts-PR benötigt `docs` und `ci-required`, keine Spiele-/Exporttests.

Nächster erlaubter Auftrag: **2 · Bild freigeben & abstrahieren**. Erst nach expliziter Freigabe einer konkreten A/B/C-r01-Datei deren Hash/Akteur/tatsächliche Erklärung binden und Konfiguration plus Motivvorlage aus genau diesen gespeicherten Bildbytes ableiten. Keine Abstraktion vorher.
