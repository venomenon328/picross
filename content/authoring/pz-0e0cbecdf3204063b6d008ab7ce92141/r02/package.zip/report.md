# Balut · r02 · motif_review

28.10.2026 · `pz-0e0cbecdf3204063b6d008ab7ce92141` · Regelwerk 0.5.0 / Dokumentrevision 23.
Technischer Quellstand `879874d12c3e8d7bded486c6cba15279ec0d805f`. Abschlussbild A-r01 ist tatsächlich freigegeben;
Beleg approvals/reveal-approval.json. M-r02 und Parameter sind noch offen.

Eine getreue native Abstraktion aus den freigegebenen A-Bytes ist erstellt.
Kopf rechts oben, Schnabel nach rechts unten, Dotter links, eingerollter Körper
und Schalenöffnung bleiben erhalten. Schalenflecken, Feintextur, Glanz und
Schraffuren entfallen. Helle Schale/Eiweiß teilen eine Farbrolle.
Groß- und Kleinvergleich auf dem echten Projektpapier: fünf Kriterien erfüllt,
siehe review/visual-review.json. Dies ist Selbstprüfung, keine Motivfreigabe.

Verglichen: 24×28/672 Zellen, 26×32/832, 30×36/1080. Empfehlung 26×32 mit vier
Vordergrundfarben: helles Ei, Dotter, Embryo, dunkle Kontur. Gemessene schlanke
Eiform begründet 26 statt der vorläufigen 28 Spalten. Drei Farben fassen Embryo
und Kontur zusammen; kleinere Augen-/Körperdetails können verloren gehen.
Vier konkrete Kandidaten mit beiden Größen und Paletten sind vorgeschlagen,
keiner bereits erzeugt. Korridor/Crop/Fit: configuration.json, Invarianten separat.

Zellmatrix, tatsächliche Farb-IDs, Hinweise, Randregel, deduktiver Proof,
unabhängige Verifikation, Schwierigkeit und Export: in Auftrag 2 noch nicht
anwendbar. Keine Lösbarkeits-, Zeit- oder Schwierigkeitszusage. Kein Reparaturlauf,
da keine Rasterproduktion stattgefunden hat. Wunschfarbzahl weiterhin offen;
vier ist Empfehlung, keine erfundene Nutzervorgabe.

Zwei native Bildaufrufe in Auftrag 2: Abstraktion und eine gezielte Korrektur.
Die größere helle Eiweißfläche in der unteren Mitte wurde nach Sichtvergleich
wiederhergestellt; Kopf, Blickwinkel und Silhouette bleiben erhalten. Aktive Menschenzeit
nicht erfasst. Nutzungsgrundlage: Auftragsgenerierung und Abstraktion aus A-r01,
beide Originaldateien samt Provenienz enthalten. B/C bleiben nur in r01 erhalten.
Kein altes ZIP eingebettet und keine versiegelte Originalrevision umgeschrieben.

Geschriebenes ZIP, vollständige sichere Dateimenge, Größen/SHA-256, Bild- und
Freigabebindungen, Regelwerk und Handoffkopie werden vor Ablage separat geprüft;
der äußere Record führt das Ergebnis. ZA-1 ist für motif_review noch nicht anwendbar.
Keine Solver-, Spiel- oder Buildtests erforderlich. CI: schlanker Inhaltspfad.

Nächster Schritt: 3 · Motiv freigeben & produzieren. Tatsächliche Freigabe von
M-r02 und Parameterkorridor erforderlich. CODEX_HANDOFF.md ist direkt nutzbar.
