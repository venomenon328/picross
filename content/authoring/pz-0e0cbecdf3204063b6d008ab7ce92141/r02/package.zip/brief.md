# Balut · Auftrag 2

ID `pz-0e0cbecdf3204063b6d008ab7ce92141` · Paketrevision r02 · Rätselmodus farbig.
Der Nutzer hat A-r01 aus r01 ausdrücklich freigegeben. Die unveränderten
Abschlussbildbytes sind nun bindende Referenz. Beleg: approvals/reveal-approval.json.
Auftrag: getreue Abstraktion, Konfiguration und gesicherte Codex-Übergabe.
Kategorie `gerichte-herzhaftes`; keine neue Motivinterpretation oder Spielregistrierung.

Empfehlung: 26×32, vier Vordergrundfarben plus Leer. Größere Alternative: 30×36.
Die vier konkret vorgeschlagenen Kandidaten kombinieren diese beiden Größen mit
vier und drei Farben; feste Grenzen, Palette, Crop und Fit stehen in configuration.json.
Freigegebene Parameter sind noch leer: Die tatsächliche Motivfreigabe folgt separat.

Hauptmerkmale und zulässige Verluste: invariants.json.
Die native Abstraktion bewahrt Dotter links, Kopf rechts oben, Schnabelrichtung,
eingerollten Körper und Schalenöffnung. Sie entfernt Oberflächentextur und Glanz.
Keine Zellmatrix oder Hinweise erzeugt; Lösbarkeit und Schwierigkeit sind ungetestet.
