# Auftrag und Befugnisse

Der Nutzer beauftragt nach PUZZLE_AUTHORING auf main:
„Ich gebe das Abschlussbild A-r01 frei. Führe Standardauftrag 2 bis zur Motivvorlage samt Konfiguration und Codex-Übergabe aus.“
Paket r01, Rätsel-ID pz-0e0cbecdf3204063b6d008ab7ce92141, farbiger Rätselmodus,
Quellstand main / 879874d12c3e8d7bded486c6cba15279ec0d805f.
„Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.“

Dies autorisiert A-r01-Freigabeprotokoll, Standardauftrag 2, Paketablage und
bedingten Ablagemerge. Die noch nicht vorgelegte Motivdatei, Parameter und ein
Endraster werden durch diese Erklärung nicht automatisch freigegeben.
