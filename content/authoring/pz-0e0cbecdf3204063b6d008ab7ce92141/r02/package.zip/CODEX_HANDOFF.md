# Codex-Übergabe · Balut r02

## Kopierbarer Folgeauftrag

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Lade content/authoring/pz-0e0cbecdf3204063b6d008ab7ce92141/r02/package.zip über den aktuellen Authoringindex;
prüfe zuerst AGENTS.md, Pflichtquellen sowie Paket-/Handoff-/Inventarbindungen.
Status motif_review. Abschlussbild A-r01 ist tatsächlich freigegeben, Beleg
approvals/reveal-approval.json; seine unveränderte Datei ist images/reveal-a-r01.png, SHA-256 f157ea64818caf859ad50cbf5ede92e0c7091f1f57ab1c7f1f7dbdb108025669.
Vorgelegte Motivdatei: images/motif-m-r02.png, M-r02, SHA-256 1ca8a80dffbf288eb350931ac94764e4508d191296653191c7f6b99f75a5a5e0.

**Noch benötigte Nutzerentscheidung:** ausdrückliche Freigabe genau dieser Motivdatei
und des Parameterkorridors in configuration.json. Keine Freigabe aus diesem Dokument ableiten.
Erst nach dieser tatsächlichen Erklärung Standardauftrag 3 ausführen.

Empfehlung 26×32, farbig, vier Vordergrundfarben plus Leer. Korridor: exakt
26×32 oder 30×36 mit vier oder drei Farben; vier gezielte Kandidaten gemäß
candidate_plan. Crop [54, 29, 1120, 1316], area, threshold 128 (im Farbmodus wirkungslos),
fit contain, alpha_below 128, Hintergrund #ffffff, explizite Paletten in configuration.json.
Bei drei Farben die dunkle Zusammenlegung nur bei erhaltener Motivtreue übernehmen.
Invarianten in invariants.json sind hart. Keine neue Pose, kein anderes Abschlussbild.

Nach Motivfreigabe alle erforderlichen Produktionsschritte des aktuellen Workflows
autonom bis content_ready ausführen: vier Kandidaten, Form-/Paletteprüfung,
passende Linienlogik, ggf. ausdrücklich gebundenes Paarprofil vor logikbedingten
Rasteränderungen, unabhängiger Verifier, Randregel, Herkunft und Endmatrixvergleich,
bei Bedarf die begrenzten Reparaturrunden. Aktuelle Schwierigkeit nach dem
aktiven Produktionsstandard erzeugen; keine Lösbarkeit/Stufe vor Nachweis zusagen.
Neue Produktion bleibt außerhalb von CI; keine rätselspezifischen Tests anlegen.
Keine Spielregistrierung vor tatsächlicher Endabnahme und Integrationsauftrag.

Repositoryablage und Merge richten sich nach dem tatsächlichen Folgeauftrag;
die vorliegende Freigabe erlaubt nur den Auftrag-2-Ablagemerge. Original r01/r02
nicht überschreiben, nächste Änderungen in neuer Revision ablegen.
