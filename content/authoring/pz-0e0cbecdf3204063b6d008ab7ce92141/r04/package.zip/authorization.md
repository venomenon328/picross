# Befugnis und Grenze r04

Der tatsächliche Nutzerauftrag in correction/request.md beauftragt die vier konkreten redaktionellen Rasterkorrekturen. Er autorisiert deren Ausarbeitung und erneute vollständige Prüfung einschließlich Ablage. Die feste Änderungsliste ist vor Import/Logikprüfung gespeichert; keine Suche oder eigenmächtige Spielregistrierung.

Originalabschlussbild A-r01 und Motivvorlage M-r02 bleiben unverändert; r03 bleibt historisch erhalten. Die neue feste Zellableitung ist ausdrücklich als manual gekennzeichnet. Vor ZA-1-Export ist die tatsächliche Endabnahme samt konkreter Autorisierung der festen Zellfassung nach ZA-1-v4 erforderlich. Kein owner-override, keine Endfreigabe und keine manuelle Exportautorisierung werden erfunden.
