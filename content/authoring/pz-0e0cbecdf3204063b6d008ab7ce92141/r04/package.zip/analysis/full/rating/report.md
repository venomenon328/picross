# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: e0b7d7933dfcddb2940e2731eb3599a25d4e7d58604664241c35f868a0e8e55f
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 407/188 |
| search | 183/160 |
| workload | 1/4 |

Score: 26761/7520; level: 4 / 5.
Without workload: 24881/7520; level: 4.
Lower boundary: 3; distance: 4201/7520.
Upper boundary: 4; distance: 3319/7520.
Nearest boundary distance: 3319/7520.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
