# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: e9aab5358867fb2d866349d721838642a23293b67c74ec672e38982df0ccd772
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 163/76 |
| search | 216/391 |
| workload | 8999/59432 |

Score: 169297/59432; level: 3 / 5.
Without workload: 80149/29716; level: 3.
Lower boundary: 2; distance: 50433/59432.
Upper boundary: 3; distance: 8999/59432.
Nearest boundary distance: 8999/59432.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
