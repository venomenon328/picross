# Balut · Produktion r03

ID `pz-0e0cbecdf3204063b6d008ab7ce92141` · Kategorie `gerichte-herzhaftes` · Tool-/Quellcommit `ebe587f79d18177056f25e7b220320081609a492`.
Tatsächlich freigegeben: Abschlussbild A-r01 und Motivvorlage M-r02 samt den vier Varianten in der unveränderten `configuration.json`; Belege unter approvals/. Invarianten in invariants.json bleiben hart.

Gewählt: 30×36, farbig, vier Vordergrundfarben plus Leer, Crop [54,29,1120,1316], area/contain/Alpha128. 26×32/4 war bevorzugt, verwendet aber nur drei Farben und verliert Gesichtszeichnung. Keine neue Quelle, Pose, Palette oder Rasterkorrektur. Oberfläche, Feinstriche und Binnenzeichnung sind stark reduziert, besonders die Kopf-/Körperkontur; zur tatsächlichen Endabnahme offengelegt.
