# Tatsächlicher Nutzerauftrag

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.

Starte Standardauftrag 1: Abschlussbildauswahl.
Motiv: Balut
Rätselmodus (Abschlussbild immer farbig): farbig.

Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.

Dieser Auftrag autorisiert Standardauftrag 1 einschließlich Ablage und
bedingtem Ablagemerge. Eine konkrete Bildauswahl oder Bildfreigabe liegt noch
nicht vor. Weitere Phasen benötigen ihre jeweiligen tatsächlichen Freigaben.
