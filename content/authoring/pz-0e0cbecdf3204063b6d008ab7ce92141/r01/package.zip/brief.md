# Balut · Abschlussbildauswahl

Standardauftrag 1 vom 28.10.2026. Rätselmodus: farbig. Abschlussbild immer farbig.
Größe und Vordergrundfarbzahl sind offen. Freie Motivübertragung (`free`) aus
dem Textauftrag, ohne bindendes Ausgangsbild. Kategorie: `gerichte-herzhaftes`
(Gerichte & Herzhaftes), weil die zubereitete Speise der Hauptgegenstand ist.

Identitätskern: geöffnetes Entenei als Speise, sichtbarer goldener Dotter,
helles Eiweiß, kompakt eingerollter graubrauner Embryo mit kleinem Schnabel,
abgebrochener heller Schalenrand. Kein lebendes schlüpfendes Küken.
Ruhige warme 2D-Illustration mit klarer Kontur, ausgearbeiteter Binnenzeichnung
und echter transparenter Außenfläche. Die Hauptflächen sollen später
abstrahierbar sein. Keine Matrix, Hinweise oder Motivvorlage in Auftrag 1.

Variation: A aufrecht und konzentriert; B breite Eihälfte; C kompakte Gruppe
aus einem geöffneten und einem geschlossenen Ei. Empfehlung A wegen klarer
Einzelsilhouette und geringerer späterer Detailkonkurrenz. Die Empfehlung ist
keine Auswahl. Erst die menschliche Freigabe bindet die konkrete Datei und
ihre zu bewahrenden Merkmale. Weitere Konfigurationen folgen in Auftrag 2.

Sachliche Textreferenz, keine Bildübernahme:
https://ijpsjournal.org/index.php/ijps/article/view/2704
Die Recherche bestätigt nur den motivischen Kern aus Embryo, Dotter, Eiweiß
und Schale. Die Bilder sind eigene Auftragsgenerierungen und keine medizinisch
oder zoologisch exakten Schnittzeichnungen.

Regelwerk und technischer Quellstand: `a7278092f98e30b46df769bfdde6b77b869604b2`. Ablage nach §6 ist beauftragt;
nach erfolgreichen Pflichtchecks ist der zugehörige Ablage-PR zu mergen.
Die Ablage erteilt keine Bild-/Motiv-/Endfreigabe und keine Spielregistrierung.
