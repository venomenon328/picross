# Balut · r01 · reveal_review

28.10.2026 · ID `pz-0e0cbecdf3204063b6d008ab7ce92141` · Regelwerk 0.5.0 / Dokumentrevision 23.
Technischer Quellstand: `a7278092f98e30b46df769bfdde6b77b869604b2`. Drei angebotene farbige PNGs: A-r01, B-r02,
C-r01. A ist empfohlen; Auswahl und sämtliche menschlichen Freigaben sind offen.

A bietet die konzentrierteste aufrechte Einzelsilhouette. B legt Dotter und
Embryo breit nebeneinander. C ergänzt ein geschlossenes Ei und benötigt später
mehr Raum für die zwei Eiformen. B-r01 bleibt nur als Quelle der Freistellrevision
erhalten; angeboten wird B-r02. Prompts, unbekannte Einstellungen, Herkunft und
alle Datei-/Revisionsbindungen stehen in den JSON-Belegen.

Alle drei sind auf dem tatsächlichen Projektpapier groß und bei 180×144 sowie
225×180 geprüft. Die fünf redaktionellen Kriterien sind jeweils erfüllt;
die protokollierte Selbstprüfung ersetzt keine menschliche Bildfreigabe.
Die Originalbilder werden für die statische Prüftafel nur proportional verkleinert
und mit ihrem Alpha komponiert; ihre gespeicherten Bytes bleiben unverändert.

Maße, Zellzahl, Matrixpalette, tatsächlich verwendete Vordergrundfarben,
Randregel, Hinweise, deduktiver Proof, unabhängiger Verifier, Reparatur und
Schwierigkeit: noch nicht anwendbar, weil Standardauftrag 1 endet.
Gewünschter Rätselmodus: farbig; Wunschgröße/Farbzahl offen. Kein Lösbarkeitsversprechen.
Keine Motivdatei, kein Export, keine Katalogregistrierung und kein Spieltest.
ZA-1-Inspektion ist für diese frühe Bildphase nicht anwendbar.

Vier native Bildaufrufe, davon eine Freistellrevision. Aktive Menschenzeit nicht
erfasst; Probespielen nicht durchgeführt und optional. Nutzungsgrundlage:
Auftragsgenerierung ohne fremde Referenzbilder, siehe Provenienzdateien.

Geschriebenes ZIP, vollständige sichere Dateimenge, CRC, Inventar, Bildbindungen,
Regelwerksnapshot und bytegleiche Handoffkopie werden vor Ablage geprüft.
Der äußere Record hält das tatsächliche Prüfergebnis und den ZIP-/Inventarhash.
Pflicht-CI des reinen Inhaltspfads: docs (Pfad-/Dateimodus) und ci-required.

Nächster Schritt: 2 · Bild freigeben & abstrahieren. Der Mensch wählt eine konkrete
Dateirevision aus und gibt sie ausdrücklich frei; danach Konfigurationsempfehlung
und Abstraktion nach dem Regelwerk.
