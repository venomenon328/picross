# Kolibri · Motivvergleich und Übergabe r02

ID pz-25d245061b0c49c190788de8e5d0e45b; Status motif_review. UTC 2026-10-16T23:51:53.699386+00:00.
Regelwerk 0.5.0 / Dokumentrevision 14; Quell-/Toolcommit b395abd0881a3a4e68576d583f3f6fcbb92cc9fb.

Abschlussbild A-r01 unverändert und ausdrücklich freigegeben. Motivvorlage
MA-r01 direkt aus dieser Datei abgeleitet; genaue Hashes und Herkunft im Handoff.
Die sichtbare Pose bleibt erhalten; Farben, Feinfedern und Füße entfallen,
Bauch wird gefüllt, Flügelkeile und Auge bleiben als vereinfachte Innenräume.
Detaillierter visueller Vergleich: visual-review.json.

Konfigurationsvergleich 38/40/42 × 30, Empfehlung 40 × 30 aufgrund des 4:3-Formats.
Vorgeschlagener Korridor nur 40 × 30 Mono, eine Vordergrundfarbe plus Leer.
Alle Alternativen respektieren die feste Höhe, sie werden nicht zur Produktion
freigegeben. Palette: ink #202020; Quelle schwarz/weiß; Reveal weiterhin farbig.
Validiertes Werkzeugdesign, proportionaler Crop und vier gezielte Schwellen liegen
unter config/. Das Design ist syntaktisch geprüft, noch nicht importiert.

Prüfungen dieser Phase: alter ZIP-/Handoff-/Inventar-/Bildhash, neue PNG-Dekodierung,
1:1-Revealbytes, Motivableitungsbezug, visuelle Merkmale, exaktes Crop-Verhältnis,
Designschema, neue ZIP-Sicherheit/Hashes/Handoffkopie und UTF-8/LF vor Commit.
Keine Matrix, Hinweise, Logik-/Randprüfung, Schwierigkeit oder Export entstanden.
Zieladapter-inspect ist für diese frühe Phase nicht anwendbar. Keine Solver-/
Spiel-/Render-/Windows-/Webtests; keine wiederholten Bestandsprüfungen.

Abschlussbildfreigabe belegt; Motivfreigabe und Endabnahme ausdrücklich offen.
Der nächste Schritt ist 3 · Motiv freigeben & produzieren. Vorbereitete,
noch nicht erteilte Eigentümerfreigabe und Codex-Auftrag: CODEX_HANDOFF.md.
