# Kolibri · Motivvorlage r02

ID pz-25d245061b0c49c190788de8e5d0e45b; Kategorie voegel / Vögel. Regelwerk 0.5.0, Dokumentrevision 14.
Aktuelle Quellbasis b395abd0881a3a4e68576d583f3f6fcbb92cc9fb; ursprüngliche Ablage PR #210, Main-Commit
60f091852615cb8aaed93b088b9f69db639cc1da. R01 bleibt unverändert.

## Freigabe und Ableitung

A-r01 ist durch die Eigentümernachricht vom 16.10.2026, 23:46:46 UTC freigegeben.
Die echte Erklärung und Datei-/Hashbindung liegen unter approvals/.
Die ausgewählte Reveal-Datei ist bytegleich zum Eingang; B/C nur historisch referenziert.
MA-r01 ist eine native, vorlagentreue Bildbearbeitung aus genau diesen Bytes.
Noch keine Motivfreigabe, Matrix, Hinweise oder Endabnahme.

## Zu bewahrende Merkmale

Rechte Seitenansicht im Schwirrflug; langer spitzer fast waagerechter Schnabel;
kleiner Kopf mit Auge; großer linker und kleiner aufgerichteter Flügel;
Negativräume zwischen den Flügeln und zwischen kleinem Flügel und Kopf;
schräg kompakter Körper; mehrzipfliger Schwanz links unten.
Nicht spiegeln, Pose oder relative Hauptproportionen ändern, Flügel zusammenziehen,
Schnabel kürzen oder neue Objekte ergänzen. Federtexturen und kleine Füße entfallen;
weiße Federkeile sind vereinfachte Innenzeichnung, keine zusätzlichen Gliedmaßen.
Die helle Bauchfarbe der Vorlage wird als Teil des gefüllten Körpers zusammengefasst.

## Vorgeschlagene Konfiguration

40 × 30 Zellen, monochrom, eine Vordergrundfarbe ink plus Leer; Höhe zwingend 30.
Die offene Breite wird mit 40 konkretisiert. 38/42 sind nur verglichene Alternativen,
nicht Teil des vorgeschlagenen Freigabekorridors. Exakter proportionaler Crop und
vier begründete Area-Schwellen stehen in config/parameters.json und im gültigen
Werkzeugdesign. Keine Höhenänderung, kein Contour-Import mit leerem Außenrahmen.
Kein Parameter ist allein durch diese Datei menschlich freigegeben.

## Nächster erlaubter Schritt

Mensch gibt MA-r01 samt config/parameters.json ausdrücklich frei. Erst dann
Standardauftrag 3; Details und kompakter vorbereiteter Auftrag in CODEX_HANDOFF.md.
Repositoryablage samt bedingtem Merge ist beauftragt, keine Rasterproduktion in Auftrag 2.
