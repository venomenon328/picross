# Codex-Übergabe · Kolibri r02

Status: **durch die noch ausstehende menschliche Motivfreigabe blockiert**.
Diese Datei und der vorbereitete Prompt sind keine tatsächliche Freigabe.
Das erforderliche Paket, beide Bilder, Bildfreigabe, Herkunft, Invarianten,
Konfigurationsvergleich und validiertes Design liegen vollständig vor.

Motivvorlage: motif/MA-r01.png · SHA-256 ef408ac399ea684f6253912c32d88410a2adc8032784c9861854dd841125b94e.
Reveal: reveal/A-r01.png · SHA-256 9b4fa04b16efebcd19d350e347d54537f992ea4e340766623aec05d5abe09dbe; bereits ausdrücklich freigegeben.
Parameter: config/parameters.json, Korridor ausschließlich 40 × 30 Mono,
eine Vordergrundfarbe, Area, exact, actual_crop=[49,27,1417,1053].
Die Nutzerhöhe bleibt exakt 30. Approved_parameters bleibt bis zur echten
Motivfreigabe leer; danach neue Paketrevision erstellen, r02 nicht umschreiben.

## Vorbereiteter nächster Auftrag für die Eigentümerfreigabe

Nur durch eine tatsächliche Eigentümernachricht mit diesem Inhalt auslösen:

```text
Arbeite nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Ich gebe MA-r01 aus Paket pz-25d245061b0c49c190788de8e5d0e45b/r02 samt vorgeschlagenem Parameterkorridor 40 × 30, monochrom, in config/parameters.json frei.
Führe Standardauftrag 3 bis zum geprüften Endraster und Paket zur redaktionellen Endabnahme aus.
Paket: content/authoring/pz-25d245061b0c49c190788de8e5d0e45b/r02/package.zip. Repositoryablage nach §6 samt Merge nach erfolgreichen Pflichtprüfungen ist beauftragt.
```

## Fortsetzung nach tatsächlicher Freigabe

Über aktuellen Arbeitsindex laden; ZIP/Handoff/Inventar und beide Bildbindungen
prüfen. Pflichtquellen aus AGENTS/Profil/Authoring lesen; für Paarprofile zusätzlich
PAIRED_LINES. Der aktuelle geprüfte Toolstand ist im Handoff gebunden.
Motivfreigabe mit Akteur, UTC-Zeit, tatsächlicher Erklärung, Bildhash,
Revealableitung und exakten Parametern protokollieren.

Vier gezielte Area-Kandidaten aus config/design-40x30.json, Schwellen
112/144/176/208, gemäß ihren gespeicherten Hypothesen erzeugen. Gleiche Matrizen
explizit erkennen. Keine bloße Zufallssuche; keine Lösbarkeitszusage.
Erst passende vollständige Linienlogik; bei visuell tragfähigem, unabhängig
bestätigtem stalled nach Authoring §4.2.1 das erlaubte Paarprofil erwägen und vorab
binden. Konkrete Budgetverträge der Werkzeuganleitung verwenden.
Schnabel, Auge, Flügelzwischenräume und Schwanz am echten Raster vergleichen;
Randregel und unabhängigen vollständigen Proof frisch prüfen. Falls erforderlich
gezielte Reparaturen innerhalb des freigegebenen Motivschutzes gemäß §4.4.
Keine neue Pose, Höhenänderung, künstlichen Randpixel oder freie Matrixkorrekturen.
Schwierigkeit, Arbeitsumfang und Zeit getrennt; fehlendes Probespiel ist kein Gate.

Die Bildphase behauptet weder Lösbarkeit noch ZA-1-Freigabe. Keine Registrierung
vor gesonderter Endabnahme. Reine Inhalte verwenden content_only; keine zusätzlichen
Rätseltests/Spielerbuilds. Repositorymerge bezieht sich auf die jeweilige Ablage,
nicht auf automatische Motiv- oder redaktionelle Endfreigabe.

Der noch nicht freigegebene Auftrag erhält hier keine rückblickende Modellwahl.
Ausführungs-/Modellentscheidung bei Startbereitschaft nach MODEL_SELECTION;
eine offene menschliche Freigabe ist kein Implementierungsfehler.
