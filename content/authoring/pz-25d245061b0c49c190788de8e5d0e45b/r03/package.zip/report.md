# Kolibri · Endabnahmevorlage r03

17.10.2026 · pz-25d245061b0c49c190788de8e5d0e45b · content_ready · Authoring 0.5.0/Revision14.
Toolcommit: f5f18819604167c8640c02d488ae95d3c646bb3f. Inventarhash: äußeres record.json und report.md
neben dem ZIP (Vermeidung einer Inventar-Selbstreferenz).

Auswahl **paired/area-80**, 40 × 30 = 1200 Zellen, Mono, eine gewünschte und
tatsächlich verwendete Farbe ink (#202020); 359 gefüllt, 841 leer (29,92 %).
Echte Bilder: [Raster](preview/final-large.png), [Gitter](preview/final-grid.png),
[Abschlussbild](reveal/A-r01.png), [Variantenvergleich](preview/comparison.png).
Bildfreigabe [A-r01](approvals/reveal.json), Motivfreigabe [MA-r01](approvals/motif.json)
samt genauem Parameterkorridor belegt. Redaktionelle Endabnahme ausdrücklich offen.

Vier Startkandidaten verlieren das Auge. Zusatzschwelle64 verliert den Schnabel;
80 erhält Auge, lange Schnabelform und wichtige Zwischenräume. Schwanzspitzen
sind grob gestuft, das Auge ist eine Leerzelle; Gefieder/Füße/Farben entfallen.
[Visuelle Kriterien](visual-review.json) erfüllt. Rechte Leerlinien bleiben wegen
des festen Formats; keine isolierten Füllzellen oder leeren Innenzeilen.
Keine Zellkorrektur; Reparaturdiff0. Geeigneter zertifizierter Kandidat macht
Reparaturrunden entbehrlich ([Entscheidungen](decisions.json)).

[Technische Prüfung](candidate-audit.json): sechs verschiedene Matrizen,
Produktmaße und tatsächliche Farbzahl gültig; Hinweise separat durch Runextraktion
bestätigt. Rand: links/oben belegt, rechts/unten leer; Formel erfüllt.
Quelle→Normalisierung→Matrix→Hinweise werden bei ZIP-Inspektion frisch rekonstruiert.
[Unabhängiger frischer Prüferprozess](verification.json): full-line-mono stalled
mit785 offenen Zellen; paired-lines-mono solved, 211 Schritte; Endmatrix exakt gleich.
Vollständige Deduktion belegt zugleich Eindeutigkeit, keine Suchdiagnose nötig.

[Schwierigkeit](difficulty.json): **L5**, Bereich L5–L5, Methode0.2 instrumented,
Vertrauen medium; R4-Notwendigkeit aus Baseline-/Paarvergleich belegt.
Keine R0–R3-Klassifikation oder menschliche Kalibrierung behauptet.
Bearbeitungsumfang1200 Zellen; Lösungszeit nicht geschätzt, aktive Menschenzeit
nicht erfasst. Probespiel nicht durchgeführt, optional. Drei Importaufrufe,
sechs Matrizen, ein unveränderter Profilvergleich; keine neuen Bildaufrufe.

Nutzungsgrundlage: originale beauftragte KI-Illustration ohne fremde Bildreferenz;
[Herkunft](motif/MA-r01.provenance.json) und Prompts erhalten.
ZA-1-ZIP-Inspektion separat neben dem ZIP; Ziel-/Spielerexport und Registrierung
nicht ausgeführt, benötigen Endabnahme. Keine Spiel-/Render-/PCK-Tests bei reiner
Inhaltsablage erforderlich. Nächster Schritt: **4 · Abnehmen & ins Spiel integrieren**.
