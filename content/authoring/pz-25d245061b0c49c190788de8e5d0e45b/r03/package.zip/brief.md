# Kolibri · Produktion r03

ID pz-25d245061b0c49c190788de8e5d0e45b; Kategorie voegel / Vögel. Quell-/Toolcommit f5f18819604167c8640c02d488ae95d3c646bb3f.
Standardauftrag 3 nach echter Motivfreigabe im aktuellen Chat. R02 bleibt unverändert.
Abschlussbild A-r01 und Motivvorlage MA-r01 sind bytegleich übernommen; Bildfreigabe
unter approvals/reveal.json, tatsächliche Motivfreigabe unter approvals/motif.json.

Geschützt: rechte Seitenansicht im Schwirrflug, langer fast waagerechter Schnabel,
kleiner Kopf mit Auge, großer linker und kleiner aufgerichteter Flügel, beide
wichtigen Zwischenräume, kompakter schräger Körper und Schwanz links unten.
Keine Spiegelung, neue Pose oder Objekte. Rasterbedingte Detailverluste stehen im
visuellen Review; farbiges Gefieder, Schattierung und Füße entfallen bei Mono.

Freigegeben: genau 40 × 30 Mono, eine Vordergrundfarbe, Area, exact,
Crop [49,27,1417,1053], keine Streckung. Vier Startschwellen und zwei gezielte
Augenhypothesen; Profilprüfung am unveränderten Raster. Keine manuelle Zellkorrektur.
Endabnahme separat offen; Repositoryablage und bedingter Ablagemerge sind beauftragt.
