# Endabnahmevorlage · Kolibri r04

Genau zwei neue Schnabelzellen, sonst unverändertes r03-Raster.
Preview: preview/final-large.png; markierter Diff: preview/cell-diff.png.
Farbige Referenz reveal/A-r01.png. Beide ursprünglichen Bildfreigaben erhalten;
konkreter Änderungsauftrag unter approvals/edit-request.json.

Neue vollständige Zertifizierung: fixed-import/fixed, eigene full-line-mono-
Baseline solved, paired-lines-mono solved ohne Paaroperation. R4 entfällt;
L2-Schätzung (L2–L4, low), keine Zeitprognose.

Der feste Editpfad verwendet picross-fixed-mono-import-plan-v2 und benötigt
vor ZA-1-Gesamtinspektion/-Export die externe picross-manual-authorization-v2
samt picross-owner-override-v2 und echter Endabnahme. Keine Randregel-Ausnahme:
frame_exception=false. Die konkrete feste Änderung ist bereits durch den
Eigentümerauftrag autorisiert; die Endabnahme muss die neue gebundene Auswahl
tatsächlich bestätigen. Keine zusätzliche technische Codeänderung erforderlich.

Nächster Schritt: 4 · Abnehmen & ins Spiel integrieren. Dann externe Endfreigabe
und Autorisierung an dieses versiegelte Paket/Handoff/Inventar binden; vorhandene
ZA-1-v2-/Paarverträge verwenden. Neue Metadaten außen führen; Originale unverändert.
