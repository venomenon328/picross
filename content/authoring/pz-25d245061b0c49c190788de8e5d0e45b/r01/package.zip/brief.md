# Kolibri · Abschlussbildauswahl r01

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.5.0, Dokumentrevision 14.
Motiv Kolibri; Rasterbreite offen, Rasterhöhe genau 30 Zellen; monochrom.
Das Abschlussbild bleibt immer farbig. Reguläre Breite höchstens 50 Zellen.
Kategorie: voegel / Vögel gemäß content/categories.json.

## Herkunft und Gestaltung

Freie Motivübertragung aus einem Textauftrag (working_mode=free), keine fremde
Bildreferenz. Drei farbige, detaillierte 2D-Abschlussbilder mit dunklen Konturen,
ruhigem warmem Grund und charakteristischen Federgruppen. Ganze Vögel ohne
Blüte, Zweig oder Umgebung; keine Artenbestimmung beauftragt oder behauptet.

Identitätskern für die spätere Ableitung: langer spitzer Schnabel, kleiner Kopf
mit Auge, kompakter Körper, zwei erkennbare Flügel, Schwanz und deutliche
Negativräume. Nach Bildfreigabe werden die konkrete Pose, Blickrichtung und
Proportionen dieser Datei verbindlich; freie Umstellung danach ist nicht erlaubt.
Feinfedern und zurückhaltende Schattierung dürfen später zusammengefasst werden.
Die feste Höhe darf nicht überschritten oder stillschweigend geändert werden.
Die spätere Randregel ist durch passenden Zuschnitt und Abstraktion zu erfüllen,
nicht durch einen dekorativen Rahmen. Noch keine Zellmatrix oder Hinweise.

## Befugnisse und Stopp

Repositoryablage nach §6 und Merge des Ablage-PRs nach erfolgreichen Pflichtchecks
sind ausdrücklich beauftragt. Dies ist keine Bild-, Motiv- oder Endfreigabe und
keine Runtime-Registrierung. Nächster Schritt erst nach tatsächlicher Auswahl und
Freigabe einer konkreten Bildrevision: Auftrag 2, Konfigurationsvergleich und
Ableitung der Motivvorlage. Keine weitere Konfigurationsfreigaberunde nötig,
solange die festen Vorgaben erhalten bleiben.
