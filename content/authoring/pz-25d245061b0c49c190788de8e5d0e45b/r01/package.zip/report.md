# Kolibri · Auswahlbericht r01

ID: pz-25d245061b0c49c190788de8e5d0e45b · Status: reveal_review · Regelwerk 0.5.0 / Dokumentrevision 14.
Quell-/Toolcommit: 8d2f6160895938ce2681349a13c40c93e79c1160. Datum UTC: 2026-10-16T23:40:26.596393+00:00.

Drei native farbige Einzelbilder: A-r01 seitlicher Schwirrflug, B-r01 breit
geöffnete Flügel, C-r01 steile Flugpose. Empfehlung A-r01 wegen klarer Profilform.
Alle Varianten sind angeboten, keine ist ausgewählt oder freigegeben.
Sichtprüfung: visual-review.json. Prompts/Einstellungen: prompts.json.
Herkunft: provenance.json; ausschließlich textbasierte KI-Erzeugung.

Rastervorgabe: Breite offen (höchstens 50), Höhe exakt 30; Mono.
Noch keine Motivvorlage, Matrix, Hinweise, Logikprüfung, Schwierigkeit oder
Zielintegration. Verwendete Rasterfarben und Lösungszeit sind unbekannt.
Bildfreigabe, Motivfreigabe und redaktionelle Endabnahme sind offen.
Menschliches Probespiel nicht durchgeführt und nicht erforderlich.

Paketinventar bindet alle Nutzdateien ohne Selbstreferenz; Handoff bindet Inventar,
äußerer Record bindet ZIP und bytegleiche Handoffkopie. Sicherheits-/Hashprüfung
des geschriebenen ZIPs erfolgt vor Commit; CI prüft nur Pfade/Dateimodi.
Kein ZA-1-inspect, Solver, Product-Harness oder Export in dieser Bildphase.

Nächster erlaubter Schritt: 2 · Bild freigeben & abstrahieren. Erforderlich ist
die ausdrückliche Freigabe genau einer Bildrevision; alle technischen
Bildparameter werden aus der gespeicherten Datei und ihrem Hash übernommen.
