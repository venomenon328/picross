# Regenwurm · Abschlussbildauswahl

**pz-eedd1fe72af54714908d5b5aff34 · r01 · reveal_review · 13.10.2026**  
Regelwerk 0.4.1, Dokumentrevision 5; Repository-/Toolstand `57c5ef4df44602d89d5679d744b7327deda7645f`.
Inventarhash: gebunden in [handoff.json](handoff.json), ohne zirkuläre Selbstbindung dieses Berichts.

| Variante | Vergleich |
| --- | --- |
| [A-r01](reveal/A-r01.png) | Breite S-Kurve; Empfehlung wegen natürlichem Verlauf und klaren Biegungszwischenräumen. |
| [B-r01](reveal/B-r01.png) | Aufgerichtete diagonale Vorderpartie; dynamischer, Perspektivwirkung in Mono schwächer. |
| [C-r01](reveal/C-r01.png) | Offene Schlaufe mit großem Innenraum; monochrom möglicherweise als C gelesen. |

Alle drei Einzelbilder: PNG, 1254 × 1254, RGB, unveränderte erzeugte Bytes.
Jede Bilddatei ist separat per SHA-256 in [variants.json](variants.json) gebunden.
Keine Auswahl/Ablehnung vorweggenommen; alle drei Angebote bleiben im Paket.
Eigene Sichtprüfung: fünf Styleguidekriterien je Bild erfüllt, begründet in
[visual-assessment.json](visual-assessment.json). Keine unabhängige oder menschliche Abnahme.

**Offen:** Abschlussbildfreigabe, Abstraktionsfreigabe und finale redaktionelle Abnahme.
Motivvorlage, Rastermaß, Zellzahl, Rasterpalette, Hinweise, Randregel, Solverprofil,
Proof, Endmatrixgleichheit, Schwierigkeit und Reparaturdiff: noch nicht vorhanden/nicht anwendbar.
Späterer Rätselmodus `mono`; Kategorie `insekten-kleine-tiere`. Lösungszeit nicht geschätzt.
Keine Lösbarkeit versprochen. Zieladapter/Export/Registrierung nicht ausgeführt.

Nutzungsgrundlage: neu mit nativer OpenAI-Bildgenerierung auf Nutzerauftrag erzeugt,
ohne externe Bildreferenzen; Originalprompts und exponierte Einstellungen stehen in den
drei [Provenienzdateien](provenance/A-r01.json). Drei Bildaufrufe, keine Überarbeitung,
kein Import/Reparaturversuch; aktive Menschenzeit nicht erfasst ([Aufwand](effort.json)).

Sicherung beauftragt auf `content/earthworm-reveal-r01`, Basis `main@57c5ef4df44602d89d5679d744b7327deda7645f`. Der tatsächliche
Sicherungscommit und Draft-PR werden außerhalb des versiegelten Pakets im PR nachgewiesen.
Noch keine Ablage auf main und kein Spieleintrag.

**Nächster Schritt:** Standardauftrag 2 mit ausdrücklicher Freigabe einer konkreten
Bildrevision. Identität, Perspektive, Proportionen und wichtige Negativflächen binden;
erst anschließend Konfigurationsempfehlung und Abstraktion erstellen.
