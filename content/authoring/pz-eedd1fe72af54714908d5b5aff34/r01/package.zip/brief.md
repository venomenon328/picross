# Regenwurm · Abschlussbildauswahl

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.4.1, Dokumentrevision 5.
Motiv: Regenwurm. Späterer Rätselmodus: monochrom (`mono`); Abschlussbilder immer farbig.
Repositoryablage nach §6, Commit/Push und Draft-PR sind ausdrücklich beauftragt; kein Merge.
Rastermaße sind offen (Produktgrenze: beide Achsen höchstens 50). Noch keine Rasterkonfiguration freigegeben.

Arbeitsweise `free`: freier Textauftrag ohne Ausgangsbild oder bindende Darstellung.
Zu erhalten: ein durchgehender gliedmaßenloser Ringelkörper mit zwei Enden, charakteristischen
Segmenten, deutlichem Gürtel und natürlicher Biegung. Ruhiger warmer handgezeichneter 2D-Stil;
keine Gesichter, Beine, Fühler, Fremdobjekte, Schrift oder Raster. Perspektive, Pose und Farbgebung
dürfen bei der jetzigen Auswahl variieren. Nach der Bildfreigabe sind die konkrete Identität,
Perspektive, Körperproportionen und wichtigen Zwischenräume dieser Datei verbindlich.

Kategorie: `insekten-kleine-tiere` / Insekten & kleine Tiere, nach dem prägenden Hauptgegenstand.
Dies ist eine Motivgruppe, keine Behauptung, ein Regenwurm sei ein Insekt.
Nutzungsgrundlage: auf Nutzerauftrag neu mit nativer OpenAI-Bildgenerierung erzeugt;
keine externen Bilder, Marken oder Fremdassets als Eingabe. Keine Exklusivrechte behauptet.

Freigabestopp: Alle drei Dateien sind Angebote, keine davon ist menschlich ausgewählt/freigegeben.
Keine Abstraktion, Zellmatrix, Hinweise, Logikprüfung oder Registrierung in diesem Auftrag.
