# Regenwurm · Motivvorlage

Standardauftrag 2: A-r01 ausdrücklich am 13.10.2026 um 10:31 UTC freigegeben.
Tatsächlicher Originalbildhash `585e51ace5904ad634f4ca3606b4a34aeff05759a1885927da8441f1d5afeef7`, Bindung in approvals/reveal-approval.json.
Modus monochrom; Abschlussbild bleibt farbig und bytegleich. Rastermaße bislang offen.
Kategorie `insekten-kleine-tiere`. Quellenregeln: aktueller main `57c5ef4df44602d89d5679d744b7327deda7645f`;
zugehörige Archive bisher nur auf `content/earthworm-reveal-r01` / PR #105, Quellcommit `63d7be780ff749b22f553c0bc61af420e375eb1a`.

Verbindliche Motiveigenschaften: ein Regenwurm, S-Haltung, gerundetes Vorderende oben rechts,
verjüngtes Ende unten links, charakteristische Körperproportionen und beide offenen Zwischenräume.
Keine Rotation, Spiegelung, neue Pose oder Zusatzobjekte. Der Gürtel bleibt an derselben Körperstelle.

Gezielte Abstraktion: schwarze tragende Körperfläche auf Weiß; viele feine Segmente werden
auf sieben kurze breite Binnenmarken reduziert. Farbe, Glanz, Schatten und Oberflächentextur entfallen.
Der breite farbige Gürtel wird nach zwei ungeeigneten Bandversuchen auf eine kleine vollständig
innenliegende helle Kapsel reduziert. Diese Detailreduktion wird offen zur Motivfreigabe vorgelegt.
MA-r01/MA-r02 sind verworfen; **nur MA-r03 ist zur Freigabe vorgeschlagen**.

Empfehlung 28 × 40. Vergleich 24 × 34; 32 × 46 nur bei konkretem Detailkonflikt.
Der genaue vorgeschlagene Korridor steht in parameters.json und ist noch nicht freigegeben.
Keine Zellmatrix, Hinweise, Solver-/Proofprüfung, Reparatur oder Registrierung in diesem Auftrag.
