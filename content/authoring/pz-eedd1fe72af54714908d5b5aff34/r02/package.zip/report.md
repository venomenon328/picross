# Regenwurm · Motivvorlage und Übergabe

**pz-eedd1fe72af54714908d5b5aff34 · r02 · motif_review · 13.10.2026**
Regelwerk 0.4.1 / Dokumentrevision 5, Tool-/Mainstand `57c5ef4df44602d89d5679d744b7327deda7645f`;
Inventarhash steht bindend in handoff.json (keine zirkuläre Selbstbindung dieses Berichts).

**Abschlussbild:** A-r01 unverändert, echte Freigabe in approvals/reveal-approval.json;
**Motivvorlage:** MA-r03 vorgeschlagen, Abstraktions- und Endfreigabe ausdrücklich offen.
Keine Zellmatrix, Kandidatenwahl, Hinweise, Rand-/Logik-/Proof- oder Endmatrixprüfung;
keine Schwierigkeiten L1–L5 und keine Lösungszeit geschätzt. Zieladapter/Export nicht ausgeführt.

| Konfiguration | Zweck |
| --- | --- |
| 24 × 34 / 816 Zellen | Kompakter Vergleich; höheres Risiko verlorener Binnenmarken |
| **28 × 40 / 1120 Zellen** | **Empfehlung:** Körperbreite und S-Zwischenräume im Hochformat |
| 32 × 46 / 1472 Zellen | Nur bei konkretem Detailkonflikt; mehr Arbeit, keine Lösbarkeitszusage |

Modus `mono`, ink schwarz, Leer weiß, Area/Contain und genau gebundener Crop;
Korridor in parameters.json ist vorgeschlagen, noch nicht freigegeben.
Eigene fünfteilige Sichtprüfung erfüllt mit begründeten Detailverlusten in visual-assessment.json.
Farbe, Schatten, Glanz und feine Ringtextur entfallen; sieben grobe Binnenmarken bleiben.
Die breite helle Binde wurde nach zwei dünnstegigen Versuchen auf eine kleine Innenkapsel
reduziert. S-Haltung, Orientierung, Hauptproportionen und wichtige Zwischenräume bleiben.
Native Zeichnungsableitung, keine behauptete pixelidentische Kontur oder deterministische Promptreproduktion.

Nutzungsgrundlage: projektbezogene native Bildgenerierung/-bearbeitung ohne Fremdassets.
Diese Phase drei Bildaufrufe, zwei Korrekturrunden; insgesamt sechs Bildaufrufe.
Keine Raster-/Reparaturversuche, aktive Menschenzeit nicht erfasst.
Vergleich: comparison.html; alle Originalprompts und Elternhashes: provenance/*.json.

Sicherung auf `content/earthworm-reveal-r01`, PR #105; tatsächlicher Sicherungshead/CI-Nachweis außen im PR.
**Nächster erlaubter Schritt:** ausdrückliche MA-r03-/Korridorfreigabe, dann Standardauftrag 3
nach codex-handoff.md. Kein Raster vor dieser Freigabe, keine Registrierung und kein Merge.
