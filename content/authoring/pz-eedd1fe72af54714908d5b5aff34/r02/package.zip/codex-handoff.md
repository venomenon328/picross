# Codex-Übergabe · Standardauftrag 3

Stand: `pz-eedd1fe72af54714908d5b5aff34` / `r02`, `motif_review`. Auftrag und aktuelle Quellenregeln auf
main `57c5ef4df44602d89d5679d744b7327deda7645f`; Paket nur auf Branch `content/earthworm-reveal-r01`, Draft-PR #105. Den konkreten
aktuellen Sicherungscommit nennt der PR-Nachweis. Kein Main-Merge und kein Runtimeinhalt.

Eingänge: farbiges `reveal/A-r01.png` (Hash `585e51ace5904ad634f4ca3606b4a34aeff05759a1885927da8441f1d5afeef7`), echte Abschlussbildfreigabe
`approvals/reveal-approval.json`, vorgeschlagene `motif/MA-r03.png` (Hash `d3a61b2eed25db159ff1225e08f334578474bbb17e31544ba90fb24c199f1b47`),
Ableitung in `provenance/MA-r03.json` samt vollständiger unmittelbarer Elternkette,
Invarianten und Konfiguration in `parameters.json`, Vergleich in `comparison.html`.
Alle Dateien liegen in dieser ZIP; Handoff und Inventar binden die exakten Bytes.
MA-r01/MA-r02 sind Diagnose-/Fehlversuche und keine freigegebenen Importe.

**Noch kein Produktionsauftrag:** Erst die tatsächliche menschliche Freigabe von MA-r03
und dem Parameterkorridor protokollieren. Die Abschlussbildfreigabe ist kein Ersatz.
Keine Abstraktion oder erneute Bildfreigabe aus bloßer Dateiverfügbarkeit erfinden.

Nach ausdrücklicher Motivfreigabe Standardauftrag 3 nach aktuellen AGENTS.md und
PUZZLE_AUTHORING §§4–7 ausführen. Brief, Entscheidungen und parameters.json sind die
konkreten Motivanweisungen; Regelwerk bleibt verbindlich. Vier gezielte Kandidaten innerhalb
des Korridors (keine Duplikate als Varianten zählen), anschließend einmalige technische
und redaktionelle Produktion inklusive unabhängigem Proof, Herkunft, Randregel,
Schwierigkeit, tatsächlicher Rasteransicht und schlankem Paket zur Endabnahme.
Noch keine Registrierung. Keine Tests oder Replay-Falllisten für dieses Rätsel anlegen;
reine Inhalte nur über schlanke CI. Keine Werkzeugänderungen, kein Build oder Merge.

## Kompakter Folgeauftrag (nur mit tatsächlicher Freigabe verwenden)

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Paket: pz-eedd1fe72af54714908d5b5aff34, r02, Branch content/earthworm-reveal-r01, Draft-PR #105.
Ich gebe MA-r03 samt dem in parameters.json vorgeschlagenen Korridor frei.
Führe Standardauftrag 3 bis zum geprüften Paket und Endraster zur Endabnahme aus.
Repositoryablage nach §6; denselben Draft-PR fortführen. Keine Integration, kein Merge.
```
