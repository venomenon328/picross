# Jinja · Standardauftrag 3

pz-d6cb06cb41854b1da84f0ba2f043aa14 · r03 · Ausgangs-/Toolcommit 1c05daad1e4bf20be36a78999894b82a45f81ba6.

MA-r01 ist mit der tatsächlichen Nutzererklärung in evidence/production-user-instructions.md freigegeben; Invarianten, feste Vierfarbenpalette und Größen 45×30/42×28/48×32 gelten. Die historische Offen-Formulierung bleibt in der wörtlichen Erklärung sichtbar. A-r01, seine Freigabe und sämtliche Bild-/Provenienzbytes sind unverändert. Das r02-Original bleibt in der Repositoryhistorie und aktuellen Ablage unverändert.

Autorisiert: Standardauftrag 3 und §6-Ablage samt Merge nach Pflichtchecks. Keine menschliche Endabnahme, Spielregistrierung oder festen manuellen Zellkorrekturen erteilt. Bestehende feste Ableitungsverträge erfordern eine separate konkrete Autorisierung. Keine Codeänderung.

12 gezielte unveränderte Motivimporte in zwei Runden. Der beste 45×30-Direktimport erfüllt technische Regeln, zeigt jedoch die vier geschützten Shide nicht ausreichend klar. Keine Endabnahmevorlage als freigabefähig ausgeben. Konkrete vierzellige Korrektur nur als ungeprüfter Vorschlag; kein Such- oder Korrekturlauf ausgeführt.
