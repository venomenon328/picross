# Tatsächliche Nutzerautorisierung

Frage:

Autorisierst du den gezeigten Korrekturvorschlag für 45×30: ausschließlich die vier Shide-Zellen in Zeile 17, Spalten 19, 22, 24 und 27 von „stone“ zu „cream“ ändern, alle übrigen Zellen schützen und danach Herkunft, Logik und Schwierigkeit vollständig neu prüfen? PUZZLE_AUTHORING §4.4 verlangt für feste manuelle Ableitungen eine gesonderte Autorisierung; die Endabnahme bleibt anschließend offen.

Antwort:

> Vier Farbkorrekturen autorisieren

Diese Erklärung autorisiert genau die vier vorgeschlagenen Farbkorrekturen und die Fortsetzung von Standardauftrag 3. Sie ist keine Endabnahme des danach neu zertifizierten Pakets. Die frühere Ablage-/Mergebefugnis gilt weiter.
