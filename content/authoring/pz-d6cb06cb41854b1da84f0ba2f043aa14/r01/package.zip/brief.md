# Jinja · Abschlussbildauswahl

## Tatsächlicher Auftrag

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Starte Standardauftrag 1: Abschlussbildauswahl.
Motiv: Jinja
Rasterbreite × Rasterhöhe: offen × 15 Zellen (ungefähr).
Rätselmodus (Abschlussbild immer farbig): monochrom.
Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.

## Erfasste Auslegung und Grenzen

Jinja wird als japanischer Shintō-Schrein verstanden, kein bestimmtes reales Bauwerk und kein Torii allein. Freie Motivinterpretation (`free`), ohne externe Bildvorlage. Hauptgegenstand ist ein einzelnes vollständiges Schreingebäude mit charakteristischem Dach, tragenden Pfosten, Eingang, Shimenawa und weißen Shide sowie kurzer Zugangstreppe. Keine Landschaft oder Nebenobjekte zum Füllen von Leerraum. Kategorie: `gebaeude-bauwerke` / Gebäude & Bauwerke.

Abschlussbilder immer detailliert und farbig, ruhige warme handgezeichnete 2D-Illustration, klarer Kontur-/Flächenstil. Echte PNG-Transparenz außen und in echten Durchblicken, helle Motivteile erhalten. Konkrete Farbfassung und Bauform werden erst durch die noch offene menschliche Bildauswahl verbindlich. Keine archäologisch exakte Rekonstruktion beansprucht.

Späteres Raster monochrom, eine Vordergrundfarbe plus Leer; Höhe ungefähr 15, Breite offen. Kein fester Größenkorridor beschlossen. Größen-/Detailkonflikte erst nach tatsächlicher Abschlussbildfreigabe anhand dieser gespeicherten Bytes behandeln. Keine Abstraktion, Matrix, Hinweise, Solverprüfung, Schwierigkeit oder Spielregistrierung in Auftrag 1.

## Herkunft und Nutzungsgrundlage

Die vier gespeicherten Bilddateien wurden mit nativer ChatGPT-Bildgenerierung aus den gespeicherten Prompts erzeugt. Keine Fremdassets oder externen Bildreferenzen verwendet. Die B-Korrektur verwendet ausschließlich die eigene gespeicherte B-r01 als Editquelle. Nutzung als projektbezogen generierte Illustration gemäß Nutzerauftrag; keine Behauptung exklusiver Urheberrechte oder einer freien Fremdlizenz.
