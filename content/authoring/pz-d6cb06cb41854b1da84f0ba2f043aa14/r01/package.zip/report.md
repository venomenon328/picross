# Jinja · Standardauftrag 1

pz-d6cb06cb41854b1da84f0ba2f043aa14 · r01 · reveal_review · 2026-10-24T09:30:58Z
Regelwerk 0.5.0 / Dokumentrevision 23 · Quell-/Toolcommit dbd728639071c43487395217bad95e51288b4dbb.

Drei ausgearbeitete farbige transparente Abschlussbilder angeboten: A-r01 (roter Schrein frontal), B-r02 (Holzschrein schräg), C-r01 (Reetdach und gekreuzte Dachhölzer frontal). Empfehlung A-r01 wegen der breit und klar gegliederten Frontalansicht für spätere ca. 15 Zellen Höhe. B-r01 wegen angeschnittenem Dachabschluss ersetzt; Original und tatsächlich verwendete Prompts bleiben nachvollziehbar erhalten.

Alle fünf Gestaltungskriterien je angebotener Datei samt Alpha-/Papierkontrolle in `review/visual-review.json`; Sichtbeleg `review/paper-context.png` mit großem Bild und 112/140-px-Höhen auf dem tatsächlichen unveränderten Buchpapier. Statische Montage, keine native Katalog-/Überblendungsprüfung. Bilder noch nicht menschlich freigegeben.

Wunsch: Breite offen, Höhe ungefähr 15, monochrom (eine Vordergrundfarbe plus Leer). Noch keine gewählten Rastermaße, Matrix oder verwendeten Rasterfarben. Motivvorlage, Randregel, Herkunftsrekonstruktion eines Imports, Hinweise, Deduktion/Proof, unabhängige Logikprüfung, Schwierigkeit und Zieladapter entfallen in dieser frühen Bildphase. Keine Lösbarkeit oder Schwierigkeit zugesagt, Lösungszeit nicht geschätzt. Abschlussbild-, Motiv- und Endfreigabe offen; kein Spielregistrierungs- oder Abnahmestatus.

Herkunft/Nutzungsgrundlage in `provenance.json`; vier native Bildaufrufe (drei Generierungen, ein Edit), aktive Menschenzeit nicht erfasst. Sämtliche tatsächlichen Bildbytes, Prompts, Vergleich und Regelwerk sind inventarisiert. ZIP/Inventar/Dateimenge und bytegleiche äußere Handoffkopie werden nach dem Schreiben kontrolliert; keine ZA-1-Zertifizierung für reveal_review behauptet.

Nächster Schritt: 2 · Bild freigeben & abstrahieren. Menschliche Freigabe einer der drei bezeichneten Dateien nötig. Danach erst die konkrete Bildfreigabe binden, 2–3 Größenkonfigurationen vergleichen und die gezielte Mono-Motivvorlage ableiten. Die Ablagefreigabe ist keine Bildfreigabe.
