# Zu bewahrende Merkmale und zulässige Vereinfachung

Vorlagentreu (`faithful`) zu A-r01. Frontale Sicht, breite Hauptproportionen, Hauptdach mit geschwungenen Ecken, mittiger vorgezogener Eingangsgiebel, rote Pfosten, dunkler mittiger Eingang, zwei offene seitliche Galerien, Shimenawa mit vier hellen Shide, Steinsockel und zentrale Treppe bleiben als Identitätskern geschützt. Insbesondere echte Durchblicke zwischen Pfosten und unter Geländern nicht schließen.

Die Motivvorlage MA-r01 fasst Dachziegel zu großen dunklen Flächen zusammen; entfernt Holz-/Steintextur, kleinteilige Schnitzereien, goldene Ornamente und Beschläge; vereinfacht Dachspitze, Geländer, Pfostenfüße, Seilzeichnung und Treppen. Stein und Seil teilen eine Rasterfarbrolle; Wandfelder und Shide teilen eine helle Rolle. Kleine Türenbeschläge und dünne interne Linien müssen im Raster entfallen. Die vier Shide dürfen kräftiger, kürzer und einfacher werden, ihre Anzahl und Position als Gruppe bleiben.

Keine Umstellung, Perspektivänderung, ergänzende Umgebung, Zusatzrahmen oder nur technisch motivierte Farbpixel. Zulässige Größenpaare und Farbrollen stehen in configuration.json. Eine tatsächliche Matrix, Randregel und Logikqualität sind erst in Standardauftrag 3 zu prüfen. Das Abschlussbild bleibt unverändert.
