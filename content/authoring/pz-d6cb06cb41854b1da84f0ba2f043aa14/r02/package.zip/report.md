# Jinja · Standardauftrag 2

pz-d6cb06cb41854b1da84f0ba2f043aa14 · r02 · motif_review · 2026-10-24T10:20:07Z
Regelwerk 0.5.0 / Dokumentrevision 23 · Quell-/Toolcommit d9216df52c335953ccbd4b0d7d35114f61ef0be9.

**Ergebnis:** A-r01 unverändert aus dem geprüften r01 geladen und tatsächliche menschliche Freigabe mit Dateihash gebunden. Größenvorgabe auf ungefähr 30 Zellen Höhe geändert; exakte Formularzahl 1 nach ausdrücklicher Klärung durch 4 ersetzt. Eine separate vorlagentreue Motivdatei MA-r01 mit Ableitungsbindung erzeugt. Empfehlung 45×30, Alternativen 42×28/48×32; alle vierfarbig, je ein Leerwert außerhalb der Palette.

Abschlussbild: reveals/A-r01.png, SHA-256 0154da8f3bbb63fb10b71b2181abd7e420204bfb548e643b2304341a10af661d. Motiv: motifs/MA-r01.png, SHA-256 b8510b323cd6324545b11bbc4136d524d37808d78036d1118630eed92b4de7d3. Vergleich comparison.png. Bildfreigabe approvals/reveal-A-r01.json; Motiv- und Parameterfreigabe ausdrücklich offen. Kein Lösungsraster, keine Hinweis-/Logikproduktion, keine Schwierigkeit und keine Endabnahme. Gates in dieser Phase nicht als technische Rasterprüfungen ausgegeben.

Fünf Gestaltungskriterien und Transparenz in visual-review.json bewertet. Frontalansicht, Dachsilhouette, Eingang, Galerien und vier Shide bleiben; Dach-/Materialtextur, Schnitzereien, Gold-/Beschlagdetails und kleinteilige Innenzeichnung entfallen. configuration.md trennt Motivtreue, Darstellbarkeit, erwartetes Nachweisrisiko und Eingabeumfang der drei Größen. configuration.json bindet vier Farbrollen und Crop/Fit/Methode. Native Bildnuancen und Antialiasing sind keine zusätzlichen freigegebenen Matrixfarben; tatsächliche Verwendung ist erst an der Endmatrix zu zählen. Lösbarkeit/Schwierigkeit nicht geprüft oder zugesagt; Lösungszeit nicht geschätzt, aktive Menschenzeit nicht erfasst.

Eine native Bildbearbeitung aus exakt A-r01; Herkunft und Prompt gespeichert. Groß- und 112/140-px-Kontext auf unverändertem Buchpapier statisch geprüft, kein Spieltest. Original-r01/ZIP/Handoff/Inventar bleiben erhalten; verworfene Bildbytes werden in r02 nicht dupliziert, sondern mit Hash und genauem früheren Paketstand referenziert.

ZIP nach Schreiben sicher geöffnet; CRC, vollständige Dateimenge, Datei-/Inventarhashes und äußere Handoff-/Freigabekopie geprüft. Frühe Bildphase, kein ZA-1-inspect oder Zertifizierungsanspruch. Nächster Schritt 3 · Motiv freigeben & produzieren: erst nach tatsächlicher MA-r01-/Parameterfreigabe. codex-handoff.txt ist eine kopierbare Freigabe-/Auftragsvorlage, keine bereits erteilte Motivfreigabe. Keine Rasterproduktion, Spielregistrierung, Endabnahme oder Produktionsbereinigung in diesem Auftrag.
