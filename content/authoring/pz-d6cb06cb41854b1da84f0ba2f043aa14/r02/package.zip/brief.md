# Jinja · Standardauftrag 2

ID pz-d6cb06cb41854b1da84f0ba2f043aa14; r02; Quellenstand main@d9216df52c335953ccbd4b0d7d35114f61ef0be9; Kategorie gebaeude-bauwerke.

Tatsächlicher Auftrag und nachfolgende Farbentscheidung: evidence/user-instructions.md. A-r01 ist ausdrücklich freigegeben und bytegleich aus r01 übernommen. Neue Richtung: farbig, Höhe ungefähr 30, Breite offen; Nutzer wählte nach Klärung vier Vordergrundfarben. Noch keine Motivfreigabe und keine Rasterproduktion autorisiert.

Ausgabe: eine vorlagentreue separate Motivdatei MA-r01, Vergleich, Konfiguration samt Detailverlusten, unveränderte Bildfreigabe und bedingte Codex-Übergabe. Die Ablage samt PR-Merge nach Pflichtprüfungen ist beauftragt. Keine Spielregistrierung, Endabnahme, Cleanup, Veröffentlichung oder Werkzeugänderung.
