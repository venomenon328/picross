# Konfigurationsvergleich

Alle Optionen verwenden vier Vordergrundfarben plus Leer und dasselbe freigegebene Abschlussbild A-r01. Neue Nutzervorgabe: Höhe ungefähr 30, Breite offen, farbig; die anfängliche Formularzahl 1 wurde ausdrücklich durch 4 ersetzt.

| Variante | Motivtreue und Darstellbarkeit | Erwartetes Lösbarkeitsrisiko | Spielgefühl / Bearbeitungsumfang |
| --- | --- | --- | --- |
| 42 × 28 · 1.176 Zellen | Kompakter; Dachgiebel, Geländer und Shide müssen kräftiger zusammengefasst werden. | Weniger Platz für Negativräume und einzelne Farbstreifen; keine Lösbarkeit geprüft. | Kompakte Alternative, geringerer Eingabeumfang. |
| 45 × 30 · 1.350 Zellen · Empfehlung | Passt zum breiten 3:2-Aufbau, lässt vier Shide und zwei Seitengalerien getrennt. | Repetitive Geländer, dünne Farbbänder und Symmetrie bleiben Prüfanlässe; keine Lösbarkeit zugesagt. | Ausgewogener Umfang nahe der gewünschten Höhe. |
| 48 × 32 · 1.536 Zellen | Zusätzlicher Platz für Dachbögen, Treppen und Innenräume; kein bloßes Hochskalieren. | Mehr Binnenlinien können den Logiknachweis verlängern; größer heißt nicht automatisch leichter oder schwerer. | Detailreichere Alternative mit mehr Eingaben; keine Zeitprognose. |

Vorgeschlagener Freigabekorridor: genau die drei Maßpaare 42×28, 45×30 und 48×32; jeweils Farbmodus mit genau vier Vordergrund-IDs. Empfehlung 45×30. Keine freie Kombination der Achsen. Geschützte Hauptformen und Negativräume bleiben bestehen. Keine feste Schwierigkeit und keine Lösungszeit geschätzt.

Palette: Dunkelblaugrün für Dach/Tür, Zinnoberrot für Tragwerk, Sand-/Steinton für Sockel/Seil, Cremeweiß für Wandfelder/Shide. Vier Farben trennen die tragenden Materialgruppen; die bereits angebotene Dreifarbenalternative würde helle Flächen mit Sockel/Seil vereinigen. Der Nutzer hat vier gewählt; drei ist daher keine still erlaubte Produktionsalternative. Farbbereiche müssen im tatsächlichen Raster verwendet und gezählt werden. Leer bleibt getrennt.

`configuration.json` führt Maße, Farbwerte, Methode, Fit und den pixelgebundenen Crop. Der Vorschlag ist noch keine Motiv-/Parameterfreigabe. `design-proposal.json` ist ein vorbereiteter RP-3-Entwurf für die Empfehlung und wurde nicht importiert oder zertifiziert.
