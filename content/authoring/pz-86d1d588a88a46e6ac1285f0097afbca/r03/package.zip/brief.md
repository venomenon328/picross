# Cầu Vàng · r03 · Produktion

ID `pz-86d1d588a88a46e6ac1285f0097afbca` · Kategorie `gebaeude-bauwerke`. Ausgangspaket r02 auf main@0ec44023978a6d03594c22b5cf32543fe88fa08f.
Ursprünglicher Wunsch ungefähr 40×30, farbig, Farbzahl offen. Tatsächlich freigegeben:
MA-r01 und genau 44×22/40×20 mit vier/drei Farben, area/contain, Crop [16,83,1692,896].
Die Erklärung und Dateibindungen stehen in motif-approval.json und evidence/motif-user-request.md.
A-r01-Abschlussbildfreigabe und Originalbytes bleiben unverändert erhalten.

Invarianten: genau zwei kohärente Steinhände mit Fingergruppen und Daumen,
linke größer/höher, rechte kleiner/tiefer; gleiche nahezu frontale Perspektive,
gemeinsamer gekrümmter goldener Steg und deutlicher zentraler Freiraum.
Vegetation und feine Binnenlinien dürfen wie in MA-r01 abstrahiert werden.
Kein Motivwechsel, keine neuen Logikanker oder Paletten außerhalb des Korridors.

Standardauftrag 3 umfasst vier Rasterkandidaten, Profilwahl, nötigenfalls begrenzte
Reparatur, unabhängige Prüfung, Schwierigkeit, Sichtprüfung und §6-Ablage samt
bedingtem Merge. Gewählt: 40×20/4 Farben als unveränderter Direktimport.
Keine Zellkorrektur erforderlich. Endabnahme und Auftrag 4 bleiben offen;
dieser Ablagemerge registriert kein Rätsel im Spiel.
