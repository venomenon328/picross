# Cầu Vàng · r03 · content_ready

25.10.2026 · `pz-86d1d588a88a46e6ac1285f0097afbca` · Authoring 0.5.0 / Dokumentrevision 23.
Quell-/Toolcommit `0ec44023978a6d03594c22b5cf32543fe88fa08f`. Inventarhash: im Handoff/äußeren Record;
das Inventar bindet diesen Bericht, deshalb keine Selbstreferenz.

**Auswahl:** unveränderter Direktimport **40×20, farbig, vier Vordergrundfarben**,
800 Zellen, 459 gefüllt/341 leer. Gold 61 (Brücke), Stein 138 (Hände/Felsen),
Grün 254 (Vegetation und quantisierte dunkle Teilflächen), Graphit 6 (strukturelle
Hand-/Felskanten). Ursprünglicher Farbwunsch offen, freigegeben 3/4, tatsächlich 4.
Die sechs Konturzellen sind keine Zusatzdekoration oder eingefügten Logikanker.
[Echtes Raster](final-raster.png), [groß](final-raster-large.png), [Gitter](final-grid.png),
[unverändertes Abschlussbild](reveals/A-r01.png), [Bildvergleich](audit/final-comparison.png).

**Gestaltung:** Beide Hände, größere linke, Stegkurve und zentrale Öffnung erhalten.
Finger-/Geländerfeinheiten und Vegetation bewusst zusammengefasst; grüne Flächen
greifen durch die direkte Quantisierung in dunkle Handkonturen. Die vier echten
Varianten wurden verglichen. 44×22 lässt 4/11 Zellen im Linienprofil offen;
der zusätzliche Vierfarb-Paarversuch ist am Verifier-Arbeitslimit abgebrochen,
kein Zertifikat/Mehrdeutigkeitsurteil. 40×20/3 ist zertifiziert, verliert aber die
neutrale Konturrolle. 40×20/4 bleibt innerhalb deiner Freigabe. Details und
[weiche Prüfanlässe](audit/final-quality.json), [Entscheidungen](decisions.json).
Keine Zellkorrektur; beide Reparaturrunden entfallen wegen geeignetem zertifiziertem Direktimport.

**Pflichtprüfung:** Produktmaße, echte Farbzahl, Randregel (links/rechts/oben belegt,
unten leer), Herkunft, deterministisch abgeleitete Hinweise, vollständige Deduktion
vom unbekannten Start ohne Raten, unabhängige frische Prüfung und exakte Endmatrix
bestanden. [Prüfbelege](audit/technical-checks.json), [Rekonstruktion/Proof](audit/verify-40x20-4c.json).
Vollständiger Nachweis mit **full-line-color** beweist zugleich Eindeutigkeit.
Keine zusätzliche Suchdiagnose. Sämtliche RP-3-Bündel unverändert erhalten.

**Schwierigkeit:** **L3 – Mittel**, Punktbereich L3–L3 der Methode
`picross-difficulty-0.3`, instrumentiert/medium; Basis 3 + Größe 0.
14 synchrone Wellen, R2 als höchste benötigte Familie, keine Engstellenwelle,
kein R3/R4. [Vollständig geprüfter Input](analysis/checked.json) und [voller Bericht](analysis/full/report.json).
Die Punktspanne ist kein menschliches Unsicherheitsintervall; keine menschliche
Kalibrierung oder Zeitprognose. Separate [0.1-Begleitschätzung](difficulty.json)
für ZA-1 mit low/L2–L4, nicht als 0.3 umetikettiert. 373 Hinweise, 112 Proofschritte;
Bearbeitungsumfang 800 Zellen, Lösungszeit nicht geschätzt.

**Freigaben/Status:** A-r01 und MA-r01 tatsächlich dateigebunden freigegeben.
Projektbezogene KI-Herkunft/Nutzungsgrundlage erhalten, keine fremden Bildbytes.
Vier historische Bildaufrufe, in dieser Phase kein Bildaufruf, vier Rasterimporte
plus ein Profilimport, eine Schwierigkeitsanalyse. Aktive Menschenzeit nicht erfasst.
**Menschliche Endabnahme offen**; keine weiteren Inhaltsblocker festgestellt.
ZA-1-Export/Spielregistrierung nicht ausgeführt; Probespiel optional und nicht erfolgt.
Nächster Schritt: **4 · Abnehmen & ins Spiel integrieren**, gebundene Endfreigabe.
