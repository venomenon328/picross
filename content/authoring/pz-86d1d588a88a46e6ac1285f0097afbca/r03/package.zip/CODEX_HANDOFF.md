# Codex-Übergabe · Standardauftrag 4

`pz-86d1d588a88a46e6ac1285f0097afbca` / r03 ist zur tatsächlichen Endabnahme vorgelegt.
Einstieg über content/authoring/index.json, Record und geschriebenes ZIP prüfen.
Regelwerk 0.5.0 / Dokumentrevision 23, Produktionscommit 0ec44023978a6d03594c22b5cf32543fe88fa08f.
Freigegebene A-r01-/MA-r01-Originalbytes bleiben unverändert. Tatsächliche
Motiv-/Korridorfreigabe in motif-approval.json; keine erfundene Endabnahme.

Auswahl: imports/40x20-4c, Variante area, full-line-color vollständig solved.
Matrixhash `b3a8f56f35b7c7a16fb00b475c4c8574c3561b1b61b51ca172ecac7e0e2839df`, Logikhash `daffdf02d36e4731ef802a9e08c140f361f282bd10739cbf6e17392dae02de48`.
Final-raster.png, final-grid.png und audit/final-comparison.png tatsächlich ansehen.
Technische Belege: audit/technical-checks.json, audit/verify-40x20-4c.json.
Aktueller vollständig geprüfter SD-Input analysis/checked.json: Methode 0.3,
L3, medium; vorläufige Definitionsbindung, nach tatsächlichem Export rebind nötig.
Separate ZA-1-Produktionsbegleitschätzung difficulty.json bleibt 0.1.

Nur nach tatsächlicher menschlicher Endabnahme den separaten ZA-1-Freigabedatensatz
an Originalhandoff, Inventar, Endauswahl und Reveal binden. ZIP/Handoff/Inventar
nicht für spätere Freigaben umschreiben. Keine zusätzliche routinemäßige
Produktionsanalyse oder Bestandsprüfung. Regulärer Auftrag 4 nach §§8–9:
export → difficulty rebind → plan/register → Dateiprüfung → Pflicht-CI/Selbstreview
und passender Mergeauftrag. Kategorie Gebäude & Bauwerke (`gebaeude-bauwerke`).
Nach tatsächlichem Spielintegrationsmerge gesonderten §9-Cleanup ausführen.
Aktuelle Ablage enthält keine Endabnahme, keinen Spieleintrag und keinen Export.
