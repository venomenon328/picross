# Codex-Übergabe · Standardauftrag 3

Eingang über `content/authoring/index.json`: `pz-86d1d588a88a46e6ac1285f0097afbca` / r02 / `package.zip`.
Vor Beginn aktuellen AGENTS-/Workflow-/Produktionsstand und Paketbindungen prüfen.
Das Paket steht in `motif_review`; Produktion ist bis zur echten menschlichen
Freigabe von `motifs/MA-r01.png` (SHA-256 `b9f71249b6b282592436cd2b0661fe18c188fd313817692279c2ac706b137311`) und des vorgeschlagenen
Korridors aus `configuration.json` gesperrt. Die A-r01-Freigabe bleibt gültig;
Datei-SHA-256 `b88c7dee737be9f5ee20c4793c6c47cb600dd9c9fa92f2eea599abdc93f93dbb`; keine erneute Bildauswahl.

Nach der tatsächlichen Freigabe: Erklärung/Akteur/UTC und Datei-/Korridorbindung
erfassen. Erst dann vier gezielte Importe aus der unveränderten MA-r01-Quelle:
44×22/40×20 mit 4/3 funktionalen Farben gemäß den vier gespeicherten Designs.
Ein expliziter Crop `[16, 83, 1692, 896]`, `area`, `contain`, Alpha 128; keine Streckung.
Für den ausgewählten Kandidaten die konkreten technischen Parameter in
`motif-approval.parameters` und `approved_parameters` aus der tatsächlich
freigegebenen Menge binden; keine neue Freigabe oder Auswahl erfinden.

Hände/Finger/Daumen, größere linke und kleinere rechte Hand, gemeinsame
Brückenkurve und zentralen Leerraum schützen. Drei Farben sind eine Reduktions-
alternative: dunkles Grün übernimmt Konturen und Vegetation; Verlust getrennt bewerten.
Vollständige Produktion nach §§4–7 inklusive Profilwahl, gegebenenfalls begrenzter
motivgeschützter Reparatur, unabhängigem Proof, Dateirekonstruktion, Randregel,
visueller Endmatrixprüfung, aktuellem SD-Analyseweg und kompaktem Bericht.
Keine Zusage aus Größen-/Farbwahl ableiten. Keine Bestandsreplays oder neuen
rätselspezifischen CI-Tests. Alle technischen Eingänge liegen im Paket.

Bis `content_ready` zur echten redaktionellen Endabnahme liefern; keine
Spielregistrierung ohne spätere Endabnahme. Neue §6-Revision sichern, Pflichtchecks,
getrenntes Selbstreview und beauftragten reinen Ablagemerge ausführen.
Diese Übergabe ist keine Motivfreigabe und startet Auftrag 3 nicht selbst.
