# Codex-Übergabe · Standardauftrag 4

`pz-86d1d588a88a46e6ac1285f0097afbca` / r04 ist der neue Vorschlag zur Endabnahme nach dem Folgeauftrag
für prägnantere Hände. Repositoryindex, Record, ZIP und Freigabebindungen lesen.
Produktionscommit bdf0080316296f5187767465cde62ec7aa722323; Regelwerk 0.5.0 / Dokumentrevision 23.
Auswahl `imports/40x20-5c-clear`, Variante area, 40×20/fünf Farben, full-line-color solved.
Matrixhash `7d3773858252934c9b3337f81da1641890fa2d2bc90bae85961753972a9edabf`, Logikhash `b28bbdb3b1bf35bed29a2682f61973d30e134eb5e4a746b6fed0417515df6ee5`.

A-r01/MA-r01 und ursprüngliche Freigaben bleiben unverändert; tatsächlicher
Folgeauftrag erlaubt zusätzliche Farben, in motif-approval.json gebunden.
Er erteilt keine Endabnahme. report.md, final-grid.png und Vorher/Nachher anschauen.
analysis/checked.json enthält vollständig geprüfte vorläufige 0.3-Bindung,
L3/medium; nach tatsächlichem Export identische ID/Logik/Matrix rebind verwenden.

Erst die echte menschliche Endabnahme separat an Originalhandoff, Inventar,
Auswahl und Reveal binden. Danach regulärer §8-/§9-Weg; kein routinemäßiger
Bestandsreplay oder Spielerbuild. Aktueller Zustand content_ready, keine
Registrierung, kein Produktionscleanup vor finalem Spielintegrationsmerge.
