# Cầu Vàng · Abschlussbildauswahl

ID `pz-86d1d588a88a46e6ac1285f0097afbca` · r01 · Kategorie `gebaeude-bauwerke` (Gebäude & Bauwerke).

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.5.0, Dokumentrevision 23.
Rasterwunsch ungefähr 40 × 30 Zellen, farbig; Vordergrundfarbzahl offen.
Das Abschlussbild bleibt eine detaillierte farbige Illustration, unabhängig von der späteren Rasterpalette.

Motivkern: der geschwungene goldene Fußgängersteg von Cầu Vàng mit genau zwei
monumentalen verwitterten steinartig gestalteten Händen. Hände/Finger und der
zusammenhängende Brückenverlauf müssen unterscheidbar bleiben. Goldener Steg,
grauer Stein und etwas Moos/Grün bilden klar getrennte Motivrollen.
Erlaubt ist eine freie illustrative Übertragung (`free`) aus dem Motivtext;
keine bindende Foto-/Geometrievorlage vorhanden. Kleine zusammenhängende
Wald-/Felsvignette unterstützt den Ort; Außenraum und echte Aussparungen sind transparent.
Keine Besucher, Schilder, fremden Assets oder zusätzlichen Bauwerke.

Drei Perspektiven A-r01/B-r01/C-r01, gespeicherte Original-PNGs im Paket.
Bildquellen: innerhalb dieses Auftrags nativ mit ChatGPT erzeugt; tatsächliche
Prompts und exponierte Einstellungen sind gebunden. Keine fremden Bildbytes verwendet.
Projektbezogene Nutzung durch den Auftrag beauftragt; keine fremden Lizenzen erfunden.
Die generierten Varianten werden erst durch die echte menschliche Dateiauswahl verbindlich.

Arbeitsumfang: Repositoryablage nach §6 samt Pflichtchecks und bedingtem Ablagemerge.
Noch keine Abschlussbildfreigabe, Motivabstraktion, Rasterproduktion oder Spielintegration.
Nächster Schritt: 2 · Bild freigeben & abstrahieren.
