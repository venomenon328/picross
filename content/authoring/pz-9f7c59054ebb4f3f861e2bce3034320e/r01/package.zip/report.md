# SEGA Game Gear · Standardauftrag 1

pz-9f7c59054ebb4f3f861e2bce3034320e / r01 · reveal_review · 20.10.2026 · Regelwerk 0.5.0 / Dokumentrevision 22.
Quell-/Toolstand: 7dab6c875e06d1e7c435df78c94e82e31a33543a.

Drei farbige transparente Einzelbilder A-r01/B-r01/C-r01 sind als unveränderte Originalbytes in reveals/ gespeichert. A ist wegen des klaren frontalen Aufbaus für die spätere monochrome Umsetzung empfohlen; B zeigt eine kühlere schräge Ansicht, C eine wärmere, stärkere Diagonale. Auswahl und alle Freigaben offen, keine Variante verworfen. Abweichung des C-Ergebnisses von der angefragten Blickrichtung ist in decisions.json dokumentiert.

Alle fünf Bildkriterien begründet erfüllt, siehe visual-review.json. PNGs vollständig dekodiert, Maße/Alpha und Originalhashes erfasst. Direkte Sichtung sowie große/kleine Papiermontagen mit echtem Spielpapier zeigen transparente Außenflächen und saubere Konturen. Keine Spieler-/Katalogabnahme behauptet. Prompts und tatsächliche bekannte Einstellungen: prompts.json. Herkunft/Nutzungsgrundlage: provenance.json. Drei Bildaufrufe, keine Korrekturrunde; Menschenzeit und Lösungszeit nicht erfasst.

Rastermaße noch offen; mono mit einer Vordergrundfarbe ohne Leer. Keine Motivvorlage, Zellmatrix, Hinweise oder tatsächliche Rasterpalette. Produktmaße, Randregel, Herkunftsrekonstruktion zum Raster, Logikproof, unabhängige Prüfung, Endmatrixvergleich, Schwierigkeit, Export und Registrierung: noch nicht anwendbar. Keine Reparatur, weil frühe Bildphase. Abschlussbildfreigabe, Motivfreigabe und Endabnahme bleiben menschliche Gates.

Das Originalinventar bindet sämtliche Paketdateien außer inventory.json/handoff.json; der Handoff bindet seinen Dateihash. Der äußere Record bindet das geschriebene ZIP und dessen bytegleiche Handoffkopie. Sicherer ZIP-/Dateimengen-/Hashcheck vor Ablage; bewusst kein ZA-1-inspect für diesen frühen Bildeingang. Allgemeine Pflichtquellen über Quellcommit referenziert, nur der verlangte Regelwerksnapshot mitgeführt.

Ablagemerge ist beauftragt und erfolgt erst nach Pflichtchecks plus getrenntem Selbstreview. Er ist keine Bildfreigabe oder Runtime-Integration. Nächster Schritt: 2 · Bild freigeben & abstrahieren: Nutzer wählt A-r01, B-r01 oder C-r01 und gibt die konkrete Datei ausdrücklich frei; erst danach Konfigurationen vergleichen und Motivvorlage ableiten.
