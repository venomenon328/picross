# Wiederaufnahme

Aktuelle Vorlage zur Freigabe: reveals/A-r02.png, SHA-256 e875ff4f7fd543a477e0269fe0d2ef0bd635fd3ac929e8363174edf47ec9ba4a.
Erst tatsächliche Nutzerfreigabe dieser neuen Revision binden, danach Standardauftrag 2 ausführen: Konfigurationen anhand der korrigierten Geometrie prüfen und neue Motivdatei aus genau A-r02 ableiten. Die alte MA-r01 und ihre Crops nicht als aktuelle freigegebene Eingänge übernehmen. Kein Produktionsstart, solange neue Bild-/Motivfreigabe fehlen.

Aktuelles Paket content/authoring/pz-9f7c59054ebb4f3f861e2bce3034320e/r03/package.zip; Quell-/Toolstand 7beffe2236e8f4bce88713f1b09ac77367d0090d. Tatsächlichen Ablagecommit aus PR/äußerer Übergabe lesen. Frühere Originalpakete r01/r02 bleiben unverändert erreichbar.
