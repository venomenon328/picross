# 4 · Abnehmen & ins Spiel integrieren

Zuerst die tatsächliche redaktionelle Endabnahme des neuen r06 mit der 52-Zellen-Auswahl erhalten. Dann gemäß resume.md und unveränderten ZA-1-v2-Verträgen externe Endfreigabe/Autorisierung binden; keine neuen Werkzeuge oder Formatlockerungen. Exakte Auswahl: fixed/import-separated, fixed; Proof fixed/import-separated/fixed-proof.json. Alle neuen technischen Belege und 0.3-Inputs vorhanden. Das frühere r05-Original bleibt unverändert erreichbar. Ohne echte Endabnahme/Integrationsauftrag kein Export/Register, keine Saves, kein Cleanup.
