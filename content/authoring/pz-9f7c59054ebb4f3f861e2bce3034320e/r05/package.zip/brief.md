# SEGA Game Gear · Produktionsbriefing r05

Fortsetzung aus r04 auf main@041ea7b455e132b5c1a637796062fc6405ca4c6e. Auftrag: freigegebene MA-r02 und parameter-corridor.json vollständig durch Standardauftrag 3 bis zur Endabnahmevorlage produzieren; Repositoryablage und Ablagemerge nach Pflichtchecks. Tatsächliche Erklärung unter approvals/motif-MA-r02-evidence.md. Keine Endabnahme oder Spielregistrierung in Auftrag 3.

A-r02 (farbig, transparent) und MA-r02 (monochrome kontinuierliche Quelle) bleiben unverändert. Breite frontale Hülle mit flacher Oberkante ohne Schulterbuttons, mittigem Display, linkem D-Pad, genau zwei diagonalen rechten Aktionstasten, Starttaste und linker Lautsprecherregion bewahren. Erlaubt: 44×20/Crop [24,48,1751,833] und 48×22/Crop [24,44,1752,836], exact, area, monochrom mit genau einer Vordergrundfarbe. Bereich 96–208, zunächst 112/160; höchstens sechs Kandidaten mit begründeter Zusatzhypothese. Alle Grenzen und historischen Herkunftsbindungen in der unveränderten parameter-corridor.json.

Vier Erstkandidaten plus zwei begründete 96-Varianten geliefert. Finale Wahl 48×22/96 wegen besserer Binnenräume. Erlaubte geometrische Diskretisierung; Lautsprecherschlitze vereinfacht, keine neue Ansicht, Farbe, Spiegelung oder materielle Motivkorrektur. Nachweise und konkrete Abweichungen im Bericht und checks/visual-review.json.
