# SEGA Game Gear · Motivvorlage

pz-9f7c59054ebb4f3f861e2bce3034320e / r02 · motif_review · Kategorie technik-erfindungen (Technik & Erfindungen) · Quelle/Tools e007ae76f59a5b1954da4fbb0b5d9950f2185e7e.

A-r01 ist am 20.10.2026 tatsächlich freigegeben; gespeicherte Originalbytes und Freigabebeleg sind gebunden. Nutzergrenze: monochromes Rätsel, Abschlussbild farbig. Keine festen Maße.

Motivvorlage: motifs/MA-r01.png; daraus erst nach Motivfreigabe produzieren. Das breite frontale Gehäuse, Display, linkes Steuerkreuz, zwei diagonale rechte Aktionstasten, Starttaste und Lautsprecherregion bleiben. Farben/Glanz/Powerlicht/Farbstreifen/Nähte entfallen; Bildschirmrahmen und -glas werden zusammengefasst, die Tasten durch helle Trennflächen freigestellt, Lautsprecher als zwei helle Schlitze. Schwarz und Weiß dienen als vorbereitete Flächenquelle, noch nicht als Zellmatrix. Der weiße Quellgrund ist expliziter Leergrund der Motivvorlage; das freigegebene farbige Reveal behält seine echte Transparenz.

Verglichen: 36×16, 44×20 und 48×22. Empfehlung 44×20 (880 Zellen), zugelassene Alternative 48×22 (1056). Nach Vermessung folgt die Empfehlung dem Gehäuse statt der ursprünglichen 40×20-Arbeitshypothese. Exakte größenbezogene Crops und sämtliche Grenzen in parameter-corridor.json; zwei technisch validierte Designvorschläge in designs/. Keine freien Größen-/Cropvarianten. Die Randregel ist erst am späteren Raster nachzuweisen.

Auftrag endet bei gesicherter Motiv-/Konfigurationsvorlage und Codex-Übergabe samt Ablagemerge. Menschliche Motivfreigabe und Endabnahme sind weiterhin offen. Keine Rasterproduktion, Logikprüfung, Schwierigkeit oder Registrierung in dieser Phase.
