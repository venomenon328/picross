# SEGA Game Gear · Standardauftrag 2

pz-9f7c59054ebb4f3f861e2bce3034320e / r02 · motif_review · 20.10.2026 · Regelwerk 0.5.0, Dokumentrevision 22 · Quelle/Tools e007ae76f59a5b1954da4fbb0b5d9950f2185e7e.

A-r01 (525b9fde7cddd7810b290fa612970b2b81b4c709f31c7fe43944d893a2e5d12f) ist ausdrücklich freigegeben und unverändert; echter Wortlaut und Zeitbeleg in approvals/. MA-r01 (80ce8977fcb4ad9dcd549b20dbd586f29d0e3b5234874a174bbd7260abf380ab) wurde in einem nativen referenzgebundenen Bildaufruf daraus abstrahiert und benötigt noch Motivfreigabe. Prompts, Provenienz und Invarianten sind gebunden; B/C nur über alte r01-Ablage referenziert, kein verschachteltes ZIP.

Empfehlung 44×20 (880 Zellen), erlaubte Alternative 48×22 (1056); 36×16 wegen kleiner Binnenfreiräume verworfen. Die erste 40×20-Arbeitshypothese wurde nach Vermessung durch proportional passende 44×20 ersetzt. Vier geplante Erstkandidaten aus zwei Größen mit je Area 112/160, exakte getrennte Crops, schwarz ink plus Leer; Details in parameter-corridor.json und validierten designs/. Wunschmodus mono; tatsächliche Matrixfarbzahl noch null.

Gehäuse, Frontalansicht, Display, D-Pad, zwei Aktionstasten und Starttaste erhalten. Farb-/Powerakzente, Glanz, Nähte und Texturen entfallen; Displaybezel vereinigt und Lautsprecher als zwei Schlitze. Direkter großer/kleiner Vergleich sowie fünf Bildkriterien in visual-review.json begründet erfüllt. Nutzungsgrundlage/Dateikette erhalten. Weißer Motivgrund ist expliziter Importleergrund, kein geändertes Abschlussbild.

Ein Bildaufruf, keine Korrekturrunde, keine Importe oder Reparaturen. Aktive Menschenzeit und Lösungszeit nicht erfasst. Alle tatsächlichen Bildfreigabe-/Provenienzbelege vorhanden; Motivfreigabe, Produktmaße am Raster, Randregel, Hinweise, vollständiger Logikproof, unabhängige Prüfung, Endmatrixgleichheit, Schwierigkeit, Endabnahme und Export bleiben offen beziehungsweise noch nicht entstanden. Kein ZA-1-inspect für die frühe Motivphase und keine Registrierung.

Geschriebenes ZIP sicher prüfen: Pfade/Modi, Inventarmenge, Größen/Hashes, Handoffkopie und Freigabe-/Ableitungsbindungen. Codex-Übergabe in codex-handoff.md ist vor Produktionsstart an die echte Motiv-/Parameterfreigabe gebunden. Nächster Schritt: 3 · Motiv freigeben & produzieren.
