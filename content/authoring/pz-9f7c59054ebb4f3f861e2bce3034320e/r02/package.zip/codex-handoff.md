# Codex-Übergabe · erst nach Motivfreigabe

Bevorzugter Weg: Codex. Selbst umsetzbar: Ja; Bild-/Datei-/Repository- und Prüffähigkeiten sind hier vorhanden. Für die anschließende zusammenhängende Raster-/Proof-/Reparatur-/Kurationsschleife folgt die Übergabe der Standardarbeitsteilung.
Codex: GPT-6 Astra — Reasoning: High. Empfohlen wegen interagierender Motivschutz-, Nachweis- und Reparaturschritte; keine Parallelagenten erforderlich. Verfügbarkeit im konkreten Client ist nicht verifiziert und vor Start in der Oberfläche zu prüfen. Offizielle Modell-/Reasoningangaben am 20.10.2026 unter https://learn.chatgpt.com/docs/models geprüft; High ist die aufgabenbezogene Wahl nach Repositoryheuristik, keine Erfolgszusage.

Die technische Vorbereitung ist vollständig; der Produktionsstart ist bis zur echten Motiv-/Parameterfreigabe gesperrt. Folgender Text erteilt sie nicht selbst:

```text
Arbeite in venomenon328/picross@main; lies aktuelle AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Setze Standardauftrag 3 für pz-9f7c59054ebb4f3f861e2bce3034320e aus content/authoring/pz-9f7c59054ebb4f3f861e2bce3034320e/r02/package.zip fort. Löse Paket/Hashes über den Arbeitsindex auf; verwende einen isolierten Arbeitsbranch.
Abschlussbild reveals/A-r01.png (525b9fde7cddd7810b290fa612970b2b81b4c709f31c7fe43944d893a2e5d12f) ist tatsächlich freigegeben; Motiv motifs/MA-r01.png (80ce8977fcb4ad9dcd549b20dbd586f29d0e3b5234874a174bbd7260abf380ab) und parameter-corridor.json benötigen zuerst meine ausdrückliche Freigabe. Protokolliere nur die tatsächlich erteilte Erklärung; vorher keine Rasterproduktion.
Nach Freigabe die beiden vorbereiteten Designs 44×20/48×22 mit je Area 112/160 vergleichen; exakte Crops, eine Vordergrundfarbe und Motivinvarianten aus dem Paket übernehmen. Weitere Schritte und begrenzte Reparatur nach Workflow; keine neue Ansicht oder freie Größen-/Cropänderung.
Bis zum geprüften Endraster samt aktueller Schwierigkeit und gesichertem Paket zur redaktionellen Endabnahme liefern. Keine Spielregistrierung. Repositoryablage und Ablagemerge nach erfolgreichen Pflichtprüfungen sind beauftragt; kein Deployment und keine Werkzeugänderungen.
```

Quell-/Toolstand der Vorbereitung: e007ae76f59a5b1954da4fbb0b5d9950f2185e7e. Tatsächlichen Sicherungs-/Maincommit aus äußerem Record/PR übernehmen; nicht diesen Quellstand als neuen Liefercommit ausgeben.
