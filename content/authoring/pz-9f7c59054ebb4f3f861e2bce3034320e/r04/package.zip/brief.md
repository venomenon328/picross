# SEGA Game Gear · Motivvorlage MA-r02

pz-9f7c59054ebb4f3f861e2bce3034320e / r04 · motif_review · Kategorie technik-erfindungen (Technik & Erfindungen) · Quelle/Tools dccb1722c871a2a19525312a13510172fd3856db.

A-r02 aus r03 ist tatsächlich freigegeben. Abschlussbildbytes bleiben unverändert und farbig mit echter Transparenz. Separate neue Motivvorlage MA-r02: schwarz gefüllte Hülle auf weißem Importleergrund, breite helle Binnenflächen. Nutzerwunsch mono, genau eine Vordergrundfarbe ohne Leer; Maße offen.

Verbindliche Merkmale: Breite dunkle Handheldkonsole in waagerechter Frontalansicht; vollständige Gehäusesilhouette und Hauptproportionen aus A-r02. Durchgehende flache Oberkante ohne Schulterbuttons, Trigger, seitliche Erhebungen oder zusätzliche Bedienelemente. Großer mittiger rechteckiger Bildschirmbereich und linkes kräftiges Steuerkreuz auf runder Basis. Genau zwei diagonal angeordnete rechte Aktionstasten und kleine Starttaste darüber. Lautsprecherregion links unten; getrennte wichtige Binnenfreiräume an Display, D-Pad und Tasten.

Entfallen: Farben/Farbakzente/Powerlicht, Glanz/Schattierung/Texturen und Nähte. Displayrahmen/Glas zusammengefasst, Lautsprecher zu zwei Schlitzen. Keine neue Geometrie an der Oberkante. Neuer direkter Vergleich groß/klein auf Spielpapier dokumentiert.

Verglichen 36×16, 44×20 und 48×22; Empfehlung 44×20, Alternative 48×22. Neu aus MA-r02 vermessene exakte Crops und Grenzen in parameter-corridor.json, technisch validierte Designvorschläge in designs/. Vier geplante Erstkandidaten; noch keine Matrix, Hinweise, Proofs oder Schwierigkeit.

Historische A-r01-Freigabe bleibt unverändert nur für die Herkunftskette. Frühere MA-r01-/Crop-Vorschläge sind superseded und nur in r02 referenziert. Aktuell zählen ausschließlich A-r02, MA-r02 und dieser neue Korridor. Auftrag endet bei gesicherter Vorlage und Codex-Übergabe mit Ablagemerge; Motivfreigabe und Endabnahme bleiben offen.
