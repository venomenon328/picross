# Codex-Übergabe · Produktionsstart nach Motivfreigabe

Bevorzugter Weg: Codex. Selbst umsetzbar: Ja; Bild-/Datei-/Repository- und Prüffähigkeiten sind hier vorhanden. Die Standardarbeitsteilung hält die zusammenhängende Raster-/Proof-/Reparatur-/Kurationsschleife in einem Auftrag.
Codex: GPT-6 Astra — Reasoning: High. Empfohlen wegen der interagierenden Motivschutz-, Nachweis- und Reparaturschritte; keine Parallelagenten erforderlich. Verfügbarkeit im konkreten Client nicht verifiziert; Auswahl in der Oberfläche vor Start prüfen. Offizielle Angaben am 20.10.2026 unter https://learn.chatgpt.com/docs/models geprüft; Zuordnung/High folgen der Repositoryheuristik, keine Erfolgs- oder Kostenersparniszusage.

Die Vorbereitung ist vollständig; echte Motiv-/Parameterfreigabe bleibt die notwendige menschliche Voraussetzung. Folgender Text erteilt sie nicht selbst:

```text
Arbeite in venomenon328/picross@main; lies aktuelle AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Setze Standardauftrag 3 für pz-9f7c59054ebb4f3f861e2bce3034320e aus content/authoring/pz-9f7c59054ebb4f3f861e2bce3034320e/r04/package.zip auf einem isolierten Arbeitsbranch fort. Index, Paket und Hashbindungen selbst laden.
A-r02 (e875ff4f7fd543a477e0269fe0d2ef0bd635fd3ac929e8363174edf47ec9ba4a) ist freigegeben. MA-r02 (cfec097e9d7550b4a4788e30534e527b1afa0e5d3e013717182ece2220fc12f9) und parameter-corridor.json benötigen zuerst meine ausdrückliche Motiv-/Parameterfreigabe; nur die tatsächlich erteilte Erklärung protokollieren. Vorher keine Rasterproduktion.
Nach Freigabe die vorbereiteten 44×20-/48×22-Designs mit je Area 112/160 im genauen Einfarbkorridor prüfen. Flache Oberkante ohne Schulterbuttons, Tastenanordnung, Proportionen und Binnenfreiräume schützen. Weitere Schritte gemäß Workflow.
Bis zum geprüften Endraster samt aktueller Schwierigkeit und gesichertem Paket zur redaktionellen Endabnahme liefern. Repositoryablage und Ablagemerge nach erfolgreichen Pflichtprüfungen beauftragt; keine Spielregistrierung, Veröffentlichung oder Werkzeugänderung.
```

Quell-/Toolstand der Vorbereitung: dccb1722c871a2a19525312a13510172fd3856db. Tatsächlichen Sicherungs-/Maincommit aus äußerem PR/Arbeitsindex übernehmen; Quellstand nicht als neuen Liefercommit ausgeben.
