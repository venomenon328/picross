# SEGA Game Gear · Standardauftrag 2

pz-9f7c59054ebb4f3f861e2bce3034320e / r04 · motif_review · 20.10.2026 · Regelwerk 0.5.0, Dokumentrevision 22 · Quelle/Tools dccb1722c871a2a19525312a13510172fd3856db. Inventarhash: siehe handoff.json → inventory.sha256 und äußeren record.json (kein Selbsthash im Inventarbericht).

A-r02 (e875ff4f7fd543a477e0269fe0d2ef0bd635fd3ac929e8363174edf47ec9ba4a) tatsächlich freigegeben, Originalbytes unverändert. Wortlaut/Zeit/Dateibindung in approvals/reveal-A-r02-approval.json und approvals/reveal-A-r02-evidence.md. Neue referenzgebundene MA-r02 (cfec097e9d7550b4a4788e30534e527b1afa0e5d3e013717182ece2220fc12f9) separat gespeichert; Motivfreigabe und Endabnahme offen. Prompts, Provenienz und historische Bearbeitungsquelle erhalten.

Vergleich 36×16 / 44×20 / 48×22: Empfehlung 44×20 (880 Zellen), Alternative 48×22 (1056). 36×16 gefährdet kleine Binnenfreiräume. Crops neu am Quellmotiv vermessen; vier geplante Area-Erstkandidaten 112/160, zwei technisch validierte Designvorschläge. Monochrom, genau 1 schwarze Vordergrundfarbe plus Leer gewünscht; tatsächliche Matrixfarbzahl noch null. Keine Lösbarkeitszusage.

Flache Oberkante ohne Schulterbuttons, Proportionen, Display, D-Pad, zwei Aktionstasten, Start und Lautsprecherregion erhalten. Farb-/Powerakzente, Glanz, Texturen, Nähte entfallen; Displayrahmen vereinigt, Lautsprecher als zwei Schlitze. Groß-/Kleinvergleich auf Spielpapier und fünf Bildkriterien mit Begründung in visual-review.json. Weißer Motivgrund ist Importleergrund; Reveal bleibt farbig transparent.

Ein nativer Bildaufruf, keine Korrekturrunde, keine Importe/Reparaturen; aktive Menschenzeit nicht erfasst, Lösungszeit nicht geschätzt. Bildfreigabe und Herkunft belegt. Produktmaße am Raster, Randregel, Hinweise, Profilproof, unabhängige Prüfung, Endmatrixgleichheit, Schwierigkeit und Export noch nicht entstanden; keine ZA-1-Zertifizierung oder Registrierung. Native Prüfungen nicht erforderlich: reine Authoringablage. Kein Probespiel; optional.

Geschriebenes ZIP auf sichere Pfade/Modi, Inventarmenge, Größen/Hashes, Handoffkopie, Freigabe-/Ableitungsbindungen und unveränderten Regelwerks-Snapshot prüfen. Codex-Übergabe in codex-handoff.md. Keine technischen Blocker; nächste menschliche Freigabe: 3 · Motiv freigeben & produzieren.
