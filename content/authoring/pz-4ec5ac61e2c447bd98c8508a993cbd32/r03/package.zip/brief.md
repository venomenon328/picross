# Briefing · Senf

- Hauptmotiv: Senf als würzige, goldgelbe Speisebegleitung; Motivfokus ist der Senf selbst, kein Gericht.
- Unverzichtbar: sofort lesbarer Senfbehälter bzw. Senf im geöffneten Gefäß, goldgelbe Senffarbe und handgezeichneter, sauber konturierter Stil.
- Zulässige Variation: Gefäßform, Material, Deckel und kleines Servierutensil.
- Rasterwunsch: ungefähr 15 × 15 Zellen; farbig.
- Kategorie: Gerichte & Herzhaftes (gerichte-herzhaftes), Zuordnung nach prägendem essbarem Hauptgegenstand; keine Nebenobjektzuordnung.
- Gestaltung: drei farbige, detaillierte quadratische Einzelbilder; transparente PNG-Umgebung, keine Schrift/Marken.
- Herkunft/Nutzungsgrundlage: neu generierte Illustrationen auf Grundlage dieses Nutzerauftrags; keine externen Bildquellen oder Markenassets verwendet. Tatsächliche Bildgenerierungsparameter außer den festgehaltenen Textprompts sind nicht offengelegt.

## Auftrag 3 · 23.10.2026

Motiv r02 und der vorgelegte Korridor 15×15/Farbe/4 Farben, alternativ 3 mit negativem Etikett, sind tatsächlich freigegeben (motif-approval.json). Unverzichtbar bleiben Glas, dunkelgrüner Deckel, Senfgold, Etikett und Holzlöffel mit Senfklecks. Nur transparente Außenränder dürfen zugeschnitten werden; keine Streckung, keine Motiv- oder Bildrevision. Standardauftrag 3 inklusive Prüfung, Schwierigkeit, §6-Ablage und bedingtem Ablagemerge; keine Endabnahme oder Spielregistrierung.
