# Produktionsbericht · Senf · r01

**Status:** reveal_review · **Nächster Schritt:** 2 · Bild freigeben & abstrahieren

Drei neu generierte, farbige und detaillierte Einzelbilder liegen zur Auswahl vor. Alle sind 1254 × 1254 RGBA-PNG mit echten transparenten und teiltransparenten Randpixeln. Noch kein Abschlussbild ist freigegeben; es wurde keine Motivvorlage oder Rastermatrix erstellt.

## Varianten

- **A-r01 · Glas, traditionell:** bauchiges klares Senfglas mit dunkelgrünem Metalldeckel und Holzlöffel; klassische, volle Silhouette.
- **B-r01 · Quetschflasche:** auf dem Kopf stehende, kräftig gelbe Quetschflasche mit grünem Klappverschluss; die prägnanteste, einfachste Außenform.
- **C-r01 · Steinguttopf:** offener ockerfarbener Senftopf mit grüner Haube und Löffel; stärker erzählerische Form, aber mehr Konturen und kleine Details.

Für ungefähr 15 × 15 farbige Zellen ist B-r01 voraussichtlich am robustesten zu abstrahieren: der Flaschenumriss ist bei kleiner Fläche sofort erkennbar. A-r01 ist die klassische Alternative mit klarer Gelb-Grün-Trennung; C-r01 trägt mehr Binnenformen und könnte bei 15 × 15 Details verlieren. Dies ist eine Empfehlung, keine Auswahl oder Freigabe.

## Gates

Abschlussbildfreigabe: pending. Motivvorlage, Logik-/Hinweisprüfung, Difficulty und Endabnahme: pending und in Auftrag 1 noch nicht fällig. Keine Bild- oder Rasterprüfungen außerhalb der hier festgehaltenen Dateiintegrität behauptet.
