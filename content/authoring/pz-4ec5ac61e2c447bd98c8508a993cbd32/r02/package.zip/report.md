# Produktionsbericht · Senf · r02

**Status:** motif_review · **Nächster Schritt:** 3 · Motiv freigeben & produzieren  
**Regelwerk:** 0.5.0 / Revision 23 · **Quellstand:** main / 1c5f40a7b48bbde0b4bfadbce34dd8fc57e791b1

## Freigaben und Ergebnis

Der Auftraggeber hat A-r01 ausdrücklich freigegeben. Der Beleg `approval.json` bindet die Aussage an `reveals/A-r01.png` und SHA-256 `05264b9ec2743a1812b52e6c11a2e61928a1ca810deca6b51ce15b5e69d29acf`. Freigegeben ist damit nur das detaillierte Abschlussbild. Die separate Motivfreigabe steht aus; es wurde kein Raster und keine Hinweismenge erzeugt.

Die abstrahierte Vorlage `motif/r02.png` (SHA-256 `83b1bb4990e0c0e09a973d3c814f6682895d7be8ca7b9792e97f4da4f5807fd4`) wurde aus den gespeicherten Bytes von A-r01 abgeleitet. Sie behält Glasgefäß, grünen Deckel, goldgelben Senf, cremefarbenes Etikett und Löffel mit Senfklecks. Weggelassen/vereinfacht wurden die Senfkorntextur, feine Glasreflexe, Papierfalten und Holzmaserung.

## Vorgeschlagener Parameterkorridor

Empfehlung: **15 × 15 Zellen, farbig, Zielpalette 4 Vordergrundfarben**: Senfgold (Senf), Dunkelgrün (Deckel), Warmbraun (Kontur/Löffel) und Creme (Etikett). Die vier Farben tragen jeweils eine klar unterscheidbare Motivfunktion. Sinnvolle reduzierte Alternative: **15 × 15, farbig, 3 Farben**, wobei das Etikett als Negativfläche/Leerfläche erscheint. Dabei verliert nur das Papierband eine eigene Flächenfarbe. Diese Konfiguration ist ein Vorschlag zur Motivfreigabe, noch keine Produktionsvorgabe.

## Beibehaltung und Herkunft

- Abschlussbild: `reveals/A-r01.png` · A-r01 · 05264b9ec2743a1812b52e6c11a2e61928a1ca810deca6b51ce15b5e69d29acf
- Motivvorlage: `motif/r02.png` · r02 · 83b1bb4990e0c0e09a973d3c814f6682895d7be8ca7b9792e97f4da4f5807fd4
- Abgeleitet von Abschlussbild-SHA-256: 05264b9ec2743a1812b52e6c11a2e61928a1ca810deca6b51ce15b5e69d29acf
- Vorlage stammt aus dem Nutzerauftrag; neu generierte Illustration, keine externen Bildquellen/Markenassets.
- Kategorie: `gerichte-herzhaftes` (Gerichte & Herzhaftes).
- Verworfen: B-r01 und C-r01; ihre Originale und Begründungen bleiben über r01 und `decisions.json` nachvollziehbar.

## Gates

Abschlussbildfreigabe: pass (`approval.json`). Motivfreigabe: pending. Herkunft/Technik, Raster, Logik, Difficulty, Endabnahme und Zieladapter: pending und in Auftrag 2 nicht fällig. Kein Raster, Solverlauf oder ZA-1-Prüfung behauptet.
