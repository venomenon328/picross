# Briefing · Senf

- Hauptmotiv: Senf als würzige, goldgelbe Speisebegleitung; Motivfokus ist der Senf selbst, kein Gericht.
- Unverzichtbar: sofort lesbarer Senfbehälter bzw. Senf im geöffneten Gefäß, goldgelbe Senffarbe und handgezeichneter, sauber konturierter Stil.
- Zulässige Variation: Gefäßform, Material, Deckel und kleines Servierutensil.
- Rasterwunsch: ungefähr 15 × 15 Zellen; farbig.
- Kategorie: Gerichte & Herzhaftes (gerichte-herzhaftes), Zuordnung nach prägendem essbarem Hauptgegenstand; keine Nebenobjektzuordnung.
- Gestaltung: drei farbige, detaillierte quadratische Einzelbilder; transparente PNG-Umgebung, keine Schrift/Marken.
- Herkunft/Nutzungsgrundlage: neu generierte Illustrationen auf Grundlage dieses Nutzerauftrags; keine externen Bildquellen oder Markenassets verwendet. Tatsächliche Bildgenerierungsparameter außer den festgehaltenen Textprompts sind nicht offengelegt.
