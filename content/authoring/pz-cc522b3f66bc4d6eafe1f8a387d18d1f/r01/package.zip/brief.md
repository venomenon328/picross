# Level 1-1 · Standardauftrag 1

Motiv: Stilisierte Darstellung des Beginns von Level 1-1 aus Super Mario Bros. (Original von 1985).
Größenwunsch: ungefähr 30 breit × 20 hoch; farbiges Rätsel; Abschlussbild immer farbig.
Kategorie: Sport & Spiele (sport-spiele); prägender Gegenstand ist ein Videospiel-Level.

Unbedingt bewahren: Erkennbarkeit des Levelanfangs. Seitenansicht, Mario links,
erster Gumba, einzelner Fragezeichenblock vor der ersten Fünferreihe
Ziegel/Fragezeichen/Ziegel/Fragezeichen/Ziegel, darüber ein weiterer Block,
erste kurze grüne Röhre rechts, durchgehender Ziegelboden, blauer Himmel,
weiße Wolken und grüne Hintergrundformen.

Arbeitsweise: faithful bezüglich der Szenenidentität, mit stilisierter Gewichtung
von Abständen/Proportionen für das ungefähre spätere Querformat. Keine vorliegende
Bilddatei als bindende geometrische Referenz; kein Screenshot übernommen.
Stil: warme ruhige handgezeichnete 2D-Illustration, saubere Konturen, kräftige
Farbflächen, ausgearbeitete Binnenzeichnung und zurückhaltende Schattierung.
Keine Pixelgrafik, Zellmatrix, Hinweise, HUD oder Punktestand.

Geplant waren drei Einzelbilder: ruhige Seitenansicht, Sprung zum ersten Block
und kompakter Levelauftakt. Nur A-r01 wurde aufgerufen; der Bilddienst lehnte ab.
Diese Bezeichnungen sind geplante Varianten, keine vorgelegten Dateirevisionen.
Keine Bild-, Motiv- oder Endfreigabe; kein Raster und keine Runtime-Integration.

Herkunft/Nutzungsgrundlage: Nutzer-Motivauftrag und eigener Generierungsprompt.
Es wurden keine fremden Assetbytes heruntergeladen oder in das Paket eingebracht.
Es liegt kein erzeugtes Bild vor. Eine Nutzungsberechtigung für Nintendo-Motive
im späteren Spiel ist nicht belegt; vor Katalogfreigabe separat zu klären.
Die textuelle Referenz ist keine Lizenz für das Spiel.
