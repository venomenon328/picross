# Wiederaufnahme · Standardauftrag 2, technisch blockiert

Repository venomenon328/picross, main; Einstieg aktuelle AGENTS.md und PUZZLE_AUTHORING.
Paket content/authoring/pz-6d980b0285604e22b8ecfce205aa008b/r02/package.zip, ID pz-6d980b0285604e22b8ecfce205aa008b, r02.
Fundort über index.json/record.json auflösen; ZIP/Handoff/Inventar und Bildbytes prüfen.
A-r01 ist bereits ausdrücklich freigegeben: 12f53a2adb863ccb0fe19445c50d603bbcff4ebb2dbeb64f30b6f36e5b1948e8.
Freigabe approvals/reveal-A-r01.json samt tatsächlichem Wortlaut und r01-Bindung wiederverwenden.

Auftrag 2 fortsetzen, sobald native Bildbearbeitung funktioniert. Geprüfter bisheriger Blocker:
generation-error.json, drei HTTP-400-Fehler Unknown parameter reasoning, keine Motivdatei.
Editprompt prompts/MA-r01.txt auf die gespeicherten Bytes reveals/A-r01.png anwenden.
Konfigurationen und zu bewahrende Merkmale in parameters-proposal.json; bevorzugt 25×15/Farbe/4.
Keine technische API- oder Vektorgrafik als stillen Ersatz nutzen. Falls native Bildfunktion
weiter fehlt, Blocker ehrlich führen; CLI/API nur nach ausdrücklichem gesonderten Nutzerauftrag.

Motivvorlage separat speichern, Hash/Provenienz binden, mit unverändertem A-r01 groß/klein
vergleichen und Detailverluste dokumentieren. Erst dann Crop/Fit/Palette und Größenkorridor
dateibasiert festlegen, konkrete Designs und vollständige Auftrag-3-Übergabe liefern.
Neue Paketrevision verwenden, r01/r02 und tatsächliche Freigaben niemals überschreiben.
Noch keine Motivfreigabe, Matrix oder Rasterproduktion. Bei Motivfreigabevorlage stoppen.
Repositoryablage samt bedingtem Merge gemäß tatsächlichem fortgeltendem Nutzerauftrag.
