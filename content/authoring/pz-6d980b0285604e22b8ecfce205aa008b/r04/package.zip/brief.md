# Webcam · Standardauftrag 2 · r04

Fortsetzung des gespeicherten Auftrags aus r02 unter Berücksichtigung des neueren r03 auf main.
A-r01 und seine tatsächliche menschliche Freigabe bleiben bytegleich. Quellenbasis: main@bbcb47222be2a2e33f2f881dfe3f750c7a7549eb.
Kategorie technik-erfindungen; Wunsch ungefähr 25×15, farbig, Farbanzahl offen; Ableitung faithful.
Der native Editaufruf war erfolgreich. MA-r01 ist als separate transparente Motivdatei gespeichert.
Unverzichtbar: breites türkises Gehäuse, dunkle Front, zentrale Rundlinse, mittiges Gelenk,
breite Monitor-Klemmhalterung und echter offener Zwischenraum; Ansicht/Proportionen erhalten.
Entfallen: Mikrofonperforationen, LED, Glanzreflexe und feine Texturen/Schattierung.
Empfehlung 25×15/vier Farben; 30×18/vier und 25×15/drei vergleichend begründet.
parameters-proposal.json bindet MA-r01 und vier zulässige, schema-validierte Importdesigns.
Motivfreigabe und sämtliche Raster-/Logik-/Endgates sind offen. Keine Produktion oder Registrierung.
