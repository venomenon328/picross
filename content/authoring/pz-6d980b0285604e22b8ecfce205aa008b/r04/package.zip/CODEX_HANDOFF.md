# Codex-Übergabe · Standardauftrag 3 erst nach Motivfreigabe

Repository venomenon328/picross, main. Aktuelle AGENTS.md, PUZZLE_AUTHORING und Pflichtquellen lesen.
Paket: content/authoring/pz-6d980b0285604e22b8ecfce205aa008b/r04/package.zip, r04. Paketstand über aktuellen Index auflösen.
Quellenbasis dieses Pakets: bbcb47222be2a2e33f2f881dfe3f750c7a7549eb. Vorgänger r03, keine alten ZIPs überschreiben.
Originalfreigabe A-r01 unverändert und gültig: reveals/A-r01.png, SHA-256 12f53a2adb863ccb0fe19445c50d603bbcff4ebb2dbeb64f30b6f36e5b1948e8.
Motivvorlage MA-r01: motifs/MA-r01.png, SHA-256 3d346ec40b4bb7942346135be46f09e0661e500455444e13dbf4092a20a06157.
parameters-proposal.json enthält den dateigebundenen Korridor, vier validierte Designs und Invarianten.

Vor Rasterproduktion tatsächliche menschliche Freigabe von MA-r01 UND Parameterkorridor an dieses
Paket/Inventar binden; aktuell keine Motivfreigabe behaupten. Abschlussfreigabe nicht erneut verlangen.
Empfehlung 25×15, farbig, vier funktionale Vordergrundfarben; zulässige zweite Größe 30×18.
Vier gezielte Kandidaten: zwei Größen × zwei begründete Crops aus den enthaltenen Designs.
Keine wirkungslosen Farbschwellenvarianten. Alpha/Fit erhalten, wichtigste Negativfläche schützen.
Dann Standardauftrag 3 gemäß §§4–7 vollständig ausführen: Import, Profilwahl, nötige begrenzte
motivgeschützte Reparatur, unabhängiger Proof/Herkunft/Endmatrixvergleich, visuelle Prüfung,
Randregel und zentrale Difficulty-0.3-Analyse. Paarlinien nur nach zugehöriger Quellenlektüre und
expliziter Produktionsbindung. A-r01 bleibt der bytegleiche Reveal.
Keine Solver-/Spiel-/Browser-/Exporttests in Inhalts-CI, keine rätselspezifischen Unit-Tests.
Am nächsten Freigabestopp vollständiges geprüftes Paket und echtes Endraster vorlegen.
Noch keine Spielintegration; diese benötigt menschliche Endabnahme und Standardauftrag 4.
Repositoryablage samt Merge nach erfolgreichen Pflichtprüfungen ist ausdrücklich gespeichert.
