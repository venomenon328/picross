# Codex-Übergabe · nach echter Motivfreigabe

Bevorzugter Weg für die noch ausstehende Produktion: Codex. Selbst umsetzbar: Ja, lokale Werkzeug-/Dateiprüfung und GitHub-Sicherung/CI sind vorhanden; Codex ist wegen der zusammenhängenden Import-, Schutzmasken-, Reparatur- und Kurationsschleife bevorzugt. Keine neue API oder Mehragentenarbeit.

Empfehlung: Codex: GPT-6 Astra — Reasoning: High. Erwarteter Nutzen: verlässliche Führung der begrenzten Reparatur- und Nachweisschritte bei Erhalt feiner Negativräume. Empfehlung gemäß lokaler Heuristik, keine Erfolgsgarantie. Modell und High in offizieller Quelle am 15.10.2026 geprüft: https://developers.openai.com/api/docs/models/gpt-6-astra. Konkrete Auswahlmöglichkeit im Nutzerclient nicht verifiziert, vom Nutzer in der Oberfläche auszuwählen.

Vorbereitungsstatus: wartet ausschließlich auf ausdrückliche Motiv-/Parameterfreigabe; kein startbereiter Rasterauftrag ohne sie. Der folgende Prompt darf erst als tatsächliche Nutzererklärung verwendet werden, wenn er dem gewünschten Freigabeumfang entspricht:

```text
Arbeite in venomenon328/picross@main nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md.
Ich gebe MA-r02 samt parameterkorridor.json aus content/authoring/pz-20219e14dbe242689b9ef06297828f34/r02/package.zip frei.
Führe Standardauftrag 3 bis zur geprüften Endabnahmevorlage aus. Höhe fest 30, mono; Empfehlung 14×30, zugelassene Alternative 15×30. Bewahre die gebundenen Motivinvarianten.
Repositoryablage nach §6 samt Merge nach erfolgreichen Pflichtprüfungen ist beauftragt. Noch keine Runtimeintegration.
```

Zielstand nach Auftrag 3: tatsächliches geprüftes Raster und content_ready-Paket oder konkreter, belegter Blocker nach den autorisierten Profil-/Reparaturschritten. Keine Inhaltsfreigabe aus dem Ablagemerge ableiten.
