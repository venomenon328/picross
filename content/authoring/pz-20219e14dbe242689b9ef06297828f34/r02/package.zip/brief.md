# Windspiel · Standardauftrag 2 · r02

Produktions-ID pz-20219e14dbe242689b9ef06297828f34; Quellen-/Toolcommit d3a7c22d3d161b219fc120dfbe3a2eda39158ddd. Alle seit Auftrag 1 gelesenen Pflichtquellen wurden gegen den aktuellen Mainstand abgeglichen und sind unverändert, AGENTS.md erneut tatsächlich abgerufen. Regelwerk 0.5.0, Dokumentrevision 14. Aktuelle Kategorien, Authoringindex und Registry gelesen, ohne Bestands-Replays.

Nutzer gibt C-r01 aus r01 ausdrücklich frei und beauftragt Motivvorlage, Konfiguration und Codex-Übergabe einschließlich Paketsicherung und bedingtem Ablagemerge. Kategorie musik-buehne; Interpretation weiterhin hängendes Klangspiel. Breite offen, Höhe fest 30, Modus mono, eine Vordergrundfarbe plus Leer aus Modus. Keine Motivfreigabe erteilt.

Die bytegleiche farbige Abschlussdatei bleibt Referenz. Native Bildbearbeitung erzeugte MA-r01 und die gezielt korrigierte MA-r02. Nur MA-r02 wird zur Motivfreigabe angeboten. Sie bewahrt Bogen, Ring, vier Röhren samt Längenfolge, Klöppel und ovales Segel, ist etwas schlanker; genaue Änderungen stehen in generation.json und visual-review.json. Die vorherige Zwischenfassung dient nur dem Ableitungsnachweis.

Empfehlung 14×30, zusätzliche zulässige Produktionskonfiguration 15×30. 16×30 wurde motivisch verglichen und nicht in den vorgeschlagenen Korridor übernommen. Die feste Höhe bleibt unverändert. Invarianten und exakte ungestreckte Crops stehen in parameterkorridor.json; vier spätere Area-Importkandidaten sind als zwei Designs mit je zwei Schwellen vorbereitet. Noch keine Matrix, Hinweise oder Logikprüfung.

Nach tatsächlicher menschlicher Freigabe von MA-r02 samt parameterkorridor.json führt Codex Standardauftrag 3 bis zum geprüften Endraster und zur Endabnahmevorlage aus. Keine Spielregistrierung vor gesonderter Endfreigabe. Bild-/Inhaltsfreigabe und Ablagemerge sind getrennt.
