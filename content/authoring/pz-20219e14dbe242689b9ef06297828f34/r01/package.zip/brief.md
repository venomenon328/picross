# Windspiel · Abschlussbildauswahl r01

## Auftrag und Grenzen
Nutzerauftrag vom 15.10.2026: Standardauftrag 1, Motiv Windspiel. Rasterbreite offen; Rasterhöhe genau 30 Zellen. Rätselmodus monochrom. Abschlussbild immer farbig. Repositoryablage nach §6 und Ablage-/Integrations-PR nach Pflichtprüfungen mergen.

Interpretation: hängendes Klangspiel; keine Tierdarstellung. Freie Motivübertragung (free) aus Text ohne Bildreferenz. Reversible Wahl von Material und Form über drei Varianten. Kategorie musik-buehne (Musik & Bühne), weil der prägende Gegenstand ein Klanginstrument ist.

## Gestalterische Merkmale
Erkennbarer hängender Träger mit Aufhängung, getrennte Klangröhren, Klöppel und unteres Windsegel. Charakteristische Negativräume zwischen Klangkörpern bewahren. Warme ruhige handgezeichnete 2D-Illustration, klare Konturen, ausgearbeitete Materialdetails und zurückhaltende Schattierung, ruhiger heller Hintergrund.

Nur die Höhe ist fest. Breite wird nach Bildfreigabe anhand von 2–3 geeigneten Konfigurationen empfohlen, höchstens 50 Zellen. Kein Vergrößern der Höhe zum Retten von Details. Das spätere Raster verwendet eine Vordergrundfarbe plus Leer; die Palette des Abschlussbilds ist davon unabhängig. Breite, Crop und konkrete Abstraktion sind noch nicht freigegeben. Dünne Schnüre müssen später kontrolliert vereinfacht werden.

## Herkunft und Nutzungsgrundlage
Drei neue Bilder mit dem nativen image_gen.imagegen auf den textlichen Nutzerauftrag erzeugt. Keine fremden Bilddateien oder Markenassets verwendet. KI-generierte Originale für diesen beauftragten Projektinhalt; keine Fremdlizenz oder Exklusivität behauptet. Gespeicherte Originalbytes bleiben unverändert. Prompts und tatsächlich exponierte Einstellungen in generation.json. Nicht exponierte Modell-/Qualitätsparameter sind als not_exposed erfasst.

## Befugnis und nächstes Gate
Die beauftragte Paketsicherung samt Merge ist autorisiert. Die konkrete Abschlussbilddatei A-r01, B-r01 oder C-r01 muss der Nutzer erst ausdrücklich freigeben. Anschließend Standardauftrag 2; bis dahin keine Abstraktion, Matrix, Hinweise, Solverläufe oder Spielregistrierung.
