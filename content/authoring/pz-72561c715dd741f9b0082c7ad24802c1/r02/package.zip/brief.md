# Pfirsich – Standardauftrag 2 (r02)

- **Ausgangsauftrag:** Motiv Pfirsich, Zielgröße ungefähr 30 × 30 Zellen, Modus/Farbanzahl zuvor offen.
- **Bestätigte Freigabe:** Nutzer wählte ausdrücklich Abschlussbild `B-r01`, als UTF-8-Beleg in `approvals/reveal-approval.json`, Datei `reveal/B-r01.png` SHA-256 `02805fd71b357341b2bd354d5ce9761b55a36cce3e90b6f36a4fc66e1fc1b4ab`.
- **Gestalterische Herkunft:** Original aus lokalem Authoring-Paket r01; deren Repositoryablage war noch nicht erfolgt. Der dazugehörige vorherige Dokument-/Quellstand war `main@199c75c219a56bd9e14ac3b2c6a163b2756eff79`.
- **Abgeleitetes Bild:** `motif/MA-r01.png`, SHA-256 `e016b71b81ad31376444ad139b803513a4f669e7ca0360cb32c71cc5f6ab2f73`; ein quellgebundenes, flächenreduziertes Stillbild und **keine** Zellmatrix. Details in `abstraction.json`.
- **Verbindlicher Identitätskern:** eine Pfirsichhälfte im Anschnitt; goldenes Fruchtfleisch, schräg-länglicher Kern, rot-orange Schale und gleichartiger Umriss inklusive oberer Einkerbung.
- **Gestalterische Reduktion:** feine Rippen, Lichtreflexe, Bodenschatten und Schraffuren weggelassen, weil sie in 30×30 eher isolierte Störzellen erzeugen.
- **Parameterentscheidung:** Empfehlung drei funktionale Vordergrundfarben in 30×30. Optionen und Vorschlagskorridor in `parameterkorridor.json`, vor Produktionsbeginn menschlich zu bestätigen.
- **Kategorie:** `obst-nuesse` (Obst & Nüsse).
- **Nutzungsgrundlage:** native, im Auftrag erzeugte Illustrator-Quelle; keine Fremdvorlage. Künftige Veröffentlichung ist nicht hiermit freigegeben.
- **Normative Quelle:** Regelwerk `0.5.0` Dokumentrevision `14` gemäß `docs/ai-workflows/PUZZLE_AUTHORING.md`, tatsächlich gelesen auf `main@112770455606f15c455ce784ffd0188c1d0f6c3b`. Der vollständige Rohsnapshot ist weiterhin vor Produktionszertifizierung aus dem Repo bytegebunden zu sichern (siehe Blocker).
- **Nicht geleistet:** Keine Motivfreigabe, keine Lösungsraster/Varianten, keine Solver-/Logik-, Schwierigkeit- oder Endabnahme und keine Runtime-Registrierung.
- **Ablage:** Für den neuen Stand ist ausschließlich ein lokales übertragbares Paket erstellt. Binärdatei-Push/CI/PR/Merge bleiben offen; frühere r01-Version wird nicht als Repositorystand ausgegeben.
