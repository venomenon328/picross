# Pfirsich — Briefing für die Abschlussbildauswahl

- Auftrag: Standardauftrag 1 · Abschlussbildauswahl.
- Motiv: Pfirsich; freie Illustration ohne bereitgestellte externe Bildreferenz.
- Wunschgröße: 30 × 30 Zellen, ungefähr (kein festes Raster).
- Rätselmodus: noch offen; durch KI erst in Auftrag 2 zu empfehlen.
- Farbanzahl: noch offen; keine Vorfestlegung oder tatsächlichen Rasterfarben.
- Kategorie: `obst-nuesse` (Obst & Nüsse), nach Hauptgegenstand.
- Bildstil: warme ruhige handgezeichnete 2D-Illustration, klare dunkle Konturen, kräftige Orange-/Rot-/Gelbtöne, stimmiges Grün, zurückhaltende Schattierung, neutraler Hintergrund.
- Unverzichtbar: charakteristische rundliche Pfirsichform, natürliche Fruchtteilung, eindeutiger Fruchtcharakter; je Variante Blatt/Stiel beziehungsweise Fruchtfleisch/Stein bewahren.
- Variationen: A ganzer Pfirsich mit großem Blatt, B Pfirsichhälfte mit Stein, C ganzer Pfirsich mit Spalte und Blättern. Keine weiteren Früchte, Schriften, komplexen Hintergründe.
- Keine Raster, Hinweise oder Motivabstraktionen in dieser Phase freigeben. Die nativen Kontaktübersichten enthielten Raster-Mockups; diese sind **kein** freigegebenes oder übergebenes Rätselraster.
- Herkunft: native KI-Bilderzeugung; Einzeldateien sind verlustfrei aus der Quelle `source/native_generation_sheet.png` ausgeschnitten. Keine Bilder Dritter eingebracht.
- Nutzungsgrundlage: von der anfragenden Person beauftragte Bildgenerierung; Veröffentlichung/Nutzungsrechte vor späterer Katalogfreigabe separat beurteilen.
- Normative Quelle: `venomenon328/picross@199c75c219a56bd9e14ac3b2c6a163b2756eff79`, `docs/ai-workflows/PUZZLE_AUTHORING.md` (Version 0.5.0, Dokumentrevision 14).
- Repositoryablage und Merge von Auftrag 1 beauftragt, aber mangels verfügbarer Binärdatei-Übertragung an den GitHub-Connector noch nicht umgesetzt.
