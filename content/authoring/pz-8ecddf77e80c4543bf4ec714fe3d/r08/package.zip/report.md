# Warnemünde r08 · Eindeutig und deduktiv lösbar

**Vollständiger unabhängig geprüfter Liniennachweis: solved/certified.**
[Raster](review/raster.png), [Vorher/Nachher](review/comparison.png),
[38 Änderungen](review/changes.png), [frischer Proof](proof-verification.json),
[Herkunft und Replay](origin-verification.json).

30×35,1050 Zellen,390 gefüllt/660 leer. Navy121,Gold70,Grün20,Blau34,
Beige145 (107 Strandzellen und38 Dachinnenzellen). Nur diese38 vormals leeren
Dachinnenzellen gegenüber r07 geändert. Konturen, beide Symmetrien, sämtliche
Turmzellen, Fenster, leerer Außenhimmel, Strandzeilen30–35, Gebäudefüße33 und
12-Zell-Sonne unverändert. Keine zusätzliche Farbe. Das helle Dach passt C-r02.

140 Linien-Deduktionsschritte vom unbekannten Raster, frischer unabhängiger
Prüfer mit205 Linienauswertungen. Alle1050 Singletonwerte stimmen mit Matrix
und Hinweisen überein. Damit genau eine Lösung, ohne Suche, Vorbelegung,
Motivwissen oder Symmetrieregel im Löser. Kein weiterer Suchlauf erforderlich.
Erster RP5-Versuch mit maximal2 Dachspitzenänderungen:33 Kandidaten/128 Vorschläge,
budget_exhausted, unabhängig replayt, kein Fund. Anschließend fester motivischer
Plan:2 Fensterfarben allein stocken mit166 offenen Zellen; beige Dachfüllung
löst vollständig. Größere kombinierte Änderung wegen Erfolg nicht ausgewählt.
Ein Designversuch scheitert vor Import an zu langer source_id, kein Proof behauptet.

Schwierigkeit vorläufig L3, Bereich L1–L4, low-Vertrauen: begründete redaktionelle
Schätzung, keine validierte schwächere Technikklassifikation. Alle verfügbaren
Linien an jedem Proofstand beobachtet; keine definierte numerische Engstelle.
Keine Lösungszeit, kein menschliches Probespiel oder Kalibrierung behauptet.

Fünf Vordergrundfarben plus Leer: Zielunterstützung in Issue144 weiterhin offen;
keine Adapter-/Runtimeänderung in diesem Paket. Neue Motiv-/Endabnahme offen.
Kein content_ready-/ZA-1-Erfolg behauptet, kein Export/Integration/Merge.
Authoring0.5.0/Revision11. Vollständige Referenz-, RP3-/RP5-Bündel und unabhängige
Prüfungen enthalten; alte versiegelte Pakete unverändert, kein ZIP im ZIP.
