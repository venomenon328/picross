# Warnemünde · 30×35 mit Strand

Der tatsächliche Auftrag steht in request.txt. Ausgang ist das vollständige
r06-Raster aus dem gebundenen versiegelten Paket, keine neue Motivinterpretation.
Beiger Strand als Untergrund der Zeilen30–35. Beide Gebäude unverändert um eine
Zeile nach oben verschoben: Fußpunkte in Zeile33, zwei Strandzeilen darunter.
Außenraum darüber leer; bestehende Fensterfarben erhalten. Sonne symmetrisch
aus einem senkrechten 2×4- und einem waagerechten 4×2-Rechteck,12 Zellen.
Die fünf Farben bleiben gemäß color-support-request.txt erhalten; Erweiterung
des Zieladapters/Spiels separat in #144 erfasst. Keine Runtime-Integration.
