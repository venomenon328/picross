# Mehr als vier Vordergrundfarben vom Produktionsadapter bis ins Spiel unterstützen

## Auftrag und Problem

Der Nutzer beauftragt am 15.10.2026 ausdrücklich die Unterstützung von mehr als vier Farben; diese notwendige Erweiterung darf separat als Issue erfasst werden. Anlass ist `pz-8ecddf77e80c4543bf4ec714fe3d`, Variante r07 in Draft-PR #142: Blau, Gold, Grün, Navy und ein eigener beiger Strand benötigen **fünf Vordergrundfarben plus Leer**. Eine automatische Farbreduktion würde die gewünschte Gestaltung ändern.

Die allgemeine Produktion unterstützt bereits 1–8 Vordergrund-IDs (`tools/puzzle_production/contract.py`, `MAX_COLORS = 8`). ZA-1 und das Spiel begrenzen neue Produktionsrätsel dagegen auf vier Farben. Das verhindert eine spätere Integration selbst nach einer erfolgreichen Logikkorrektur.

Untersucht am Branch-Head `de0127db75411ac90105bc59621a96f755813eaa`, Basis `3b64e1368735a1e9221389a48c51eaed0b881515`:

- `tools/puzzle_production/target_adapter.py:236`: `inspect_candidate`/Zielprüfung verlangt höchstens vier Paletteinträge; Export/Plan/Registrierung hängen an dieser Prüfung.
- `tools/puzzle_production/color_derivation.py:185`: Die Prüfung abgeleiteter Farbkinder enthält ebenfalls eine Vierfarbgrenze.
- `game/model/definition.gd:106`: Laufzeitvalidierung lehnt `pz-`-Definitionen mit mehr als vier Farben ab.
- `game/ui/main.gd:846`: Das Palettenfeld hat für alle mehrfarbigen Rätsel eine feste Höhe für zwei Reihen. Ab der fünften Farbe entstehen weitere Reihen; Werkzeugbereich und Rahmen müssen deren tatsächlichen Platz berücksichtigen.
- `tests/puzzle_production/test_target_adapter.py:338` ff. erwartet derzeit die Ablehnung von fünf Farben.

## Ziel und Umfang

Mehr als vier Vordergrundfarben durchgängig unterstützen: Zielprofil, Herkunfts-/Ableitungsprüfung, Export, Plan/Registrierung, Laufzeitvalidierung und benutzbare Farbauswahl. Als technische Obergrenze **acht** vorschlagen, passend zum bestehenden Prüfkern; ausdrücklich beschlossen ist bislang „mehr als vier“, mindestens fünf. Die endgültige Obergrenze vor der betroffenen Umsetzung konsistent im Fachvertrag festhalten.

Die notwendige UI-Anpassung bleibt auf die Farbauswahl und deren Platzbedarf begrenzt. Farbsymbole, Hinweise, Zellen und Miniatur müssen alle unterstützten IDs korrekt unterscheiden und anzeigen. Bestehende Rätsel mit 1–4 Farben und ihre Spielstände bleiben kompatibel. Dokumentierte aktuelle Grenzen in ZA-1, Produkt-/Authoring-Regeln und Werkzeuganleitung konsistent aktualisieren; historische P1-Festprofile nicht nachträglich umdefinieren.

## Akzeptanz

1. Ein festes **synthetisches** Fünffarben-Rätsel plus Leer lässt sich mit vollständigem gültigem Herkunfts-/Logik-/Freigabepaket exportieren, planen, registrieren und im Spiel laden. Kein Gate wird übersprungen oder abgeschwächt.
2. Für die beschlossene Obergrenze gibt es einen positiven Grenzfall und oberhalb davon eine klare Ablehnung. Bei Wahl von acht: gültige Fälle mit 5 und 8 Farben, ungültiger Fall mit 9 Farben.
3. Alle unterstützten Farben können mit den vorhandenen Eingabewegen ausgewählt, gesetzt und entfernt werden. Palettenrahmen, Werkzeuge und übrige Bedienelemente überlappen auch an den verbindlichen Zielgrößen/Skalierungen nicht; Farbsymbole, Hinweise und Miniatur sind korrekt.
4. Adapter-, Ableitungs-, Laufzeit- und relevante UI-/Darstellungstests nutzen ausschließlich synthetische Inputs. Bestehende Mono-/Vierfarbfälle und Save-Kompatibilität bleiben erhalten. Prüfweg und CI-Auswahl folgen PROJECT_PROFILE und CI_POLICY; bei Zellrendering zusätzlich CELL_RENDERING vollständig lesen.
5. Keine stille Farbzusammenlegung, neue Leer-Semantik, Vorbelegung oder Umgehung der Deduktions-/Eindeutigkeitsprüfung.

## Grenzen und Abhängigkeiten

Dieses Issue ist **erfasst, noch nicht implementiert**. Es ersetzt keine Rätselabnahme und integriert r07 nicht. r07 hat zusätzlich zwei unabhängig bestätigte Lösungen; diese redaktionelle Logikkorrektur gehört zu einem eigenen Auftrag und wird durch mehr Farben allein nicht gelöst. Das bestehende r05 im Spiel bleibt unverändert.

Keine Erweiterung von Rastermaßen, Spielmechanik, Rendererarchitektur oder allgemeinen Produktionslimits. Vor Umsetzung aktuellen Main-/Issue-/PR-Stand und einschlägige Bereichsregeln lesen. Merge erst mit passendem Auftrag und aktuellen Pflichtprüfungen.
