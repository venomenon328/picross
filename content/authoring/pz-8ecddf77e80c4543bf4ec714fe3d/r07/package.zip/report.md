# Warnemünde r07 · 30×35 mit Strand

**Rasterentwurf erstellt; logisch nicht freigabefähig.** pz-8ecddf77e80c4543bf4ec714fe3d · r07.
[Raster](review/raster.png), [Layoutprüfung](layout-validation.json),
[frische Herkunftsprüfung](origin-verification.json), [Diagnoseprüfung](diagnosis-verification.json).

30 Spalten ×35 Zeilen. Beiger Untergrund in Zeilen30–35; Gebäude enden in
Zeile33, zwei vollständige Strandzeilen darunter. Außenraum über dem Strand
leer. Gebäude aus r06 exakt um (0,-1) verschoben; ihre Formen/Farben/Symmetrie
unverändert. Turm maximal9/Schaft5, AchseSpalte6; Teepott AchseSpalte20.
34 blaue Fensterzellen erhalten. Sonne Zeilen5–8/Spalten24–27,12 Goldzellen:
`.YY. / YYYY / YYYY / .YY.`. 1050 Zellen,352 gefüllt/698 leer;
Navy121,Gold70,Grün20,Blau34,Sand107. Fünf Vordergrundfarben plus Leer.
Randregel links/rechts/unten erfüllt; Sichtkriterien im Selbstreview erfüllt.

Linienproof frisch geprüft: Fixpunkt,116 Schritte/181 Linienauswertungen,
keine vollständige Deduktion. Paarprofil mit vorher gespeicherten Budgets
versucht: **aborted/pair_work_limit, proof_verified=false**. Kein verifizierter
Paarfixpunkt behauptet. Separate Suche findet zwei verschiedene Lösungen;
frischer unabhängiger Zeugenchecker bestätigt beide und ihre Dateibindungen.
Die Suche ist kein Deduktionsnachweis. Keine Schwierigkeit, keine Lösungszeit,
kein Probespiel oder menschliche Kalibrierung behauptet.

Zielunterstützung aktuell nur vier Farben. Die ausdrücklich beauftragte
Erweiterung ist in [Issue144](https://github.com/venomenon328/picross/issues/144)
mit Adapter-, Laufzeit- und UI-Grenzen erfasst, noch nicht umgesetzt.
Keine stille Farbreduktion; kein ZA-1-Export. Unabhängig davon bleibt die
Mehrdeutigkeit eine separate redaktionelle Aufgabe. Abschlussbild und dessen
echte Freigabe unverändert; neue Motiv-/Endabnahme offen. Ein gezielter
Änderungsentwurf statt vier künstlicher Varianten ist in decisions.json begründet.

Authoring0.5.0/Revision11; Produzentenstand `de0127db75411ac90105bc59621a96f755813eaa`, technische Basis
`3b64e1368735a1e9221389a48c51eaed0b881515`. Alle Quellen, vollständigen
Import-/Negativbelege, Diagnose und Prüfergebnisse im Paket. Keine Tool-/
Runtimeänderung oder Registrierung; Draft-PR, kein Merge dieser Revision.
