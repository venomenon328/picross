# Warnemünde · Motivvorlage

ID pz-8ecddf77e80c4543bf4ec714fe3d, Paket r02, Status motif_review; 2026-10-14T00:06:13.355196Z.
Maßgebliche Arbeitsanweisung 0.4.1 / Dokumentrevision 5 auf main f666f87d36a0ea7fa3740202d08706f2215bc303; vorheriges Paket auf e195066318376aa9c697e681ef8c2e7176a9ebe2.

Der Nutzer hat C-r02 ausdrücklich freigegeben und Standardauftrag 2 beauftragt. Beleg approvals/reveal-approval.json, tatsächliche Erklärung in approvals/reveal-evidence.txt.
Kategorie gebaeude-bauwerke. Leuchtturm, Teepott, blauer Himmel und Sonne gelten als gewünschte Motivbestandteile.

MA-r01 ist die gezielte vorlagentreue Abstraktion aus den gespeicherten C-r02-Bytes. Beide Bilder 1086 × 1448 (3:4), getrennte unveränderte PNGs. Invarianten und Detailverluste in motif-derivation.json.
Empfehlung 30 × 40, color, vier Vordergrundfarben plus Leer. Exakter vollständiger Crop; keine Streckung. Vorgeschlagener Korridor 27 × 36, 30 × 40, 33 × 44, 36 × 48 mit vier getrennten strikten Design-JSONs. Erst menschliche Motivfreigabe macht diese Parameter freigegeben.

Die native Motivdatei enthält noch leichte Tonvariation und Antialiasing; es ist eine Illustration, keine Zellmatrix. Der spätere deterministische area-Import nutzt die explizite diskrete Palette aus configuration.json.

Aktueller Scope: Freigabebindung, Bildabstraktion, Konfiguration, Dateipaket, Index, bestehender Draft-PR #113. Keine Rasterproduktion oder technische Rätselzertifizierung. Keine Werkzeuge, Runtime, Testsuite oder Merge ändern.
Nächster erlaubter Schritt: Motivdatei MA-r01 samt vorgeschlagenem Korridor ausdrücklich freigeben und Standardauftrag 3 beauftragen.
