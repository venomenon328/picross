# Codex-Übergabe · Warnemünde

Vollständige Quellenprüfung, Freigabebindung, Paketablage und vorgesehene Designs liegen vor. Startblocker für Rasterproduktion: menschliche Freigabe MA-r01 samt Parameterkorridor. Kein Implementierungsauftrag ist aus dieser Datei allein abzuleiten.

Repository venomenon328/picross. Bestehender Draft-PR #113, Branch content/warnemuende-reveal-r01, Ziel main.
Paket pz-8ecddf77e80c4543bf4ec714fe3d / r02; erst über content/authoring/index.json auflösen und Record-/ZIP-/Handoff-/Inventar-/Bildhashes kontrollieren. Die r01-Historie liegt auf festem Commit e195066318376aa9c697e681ef8c2e7176a9ebe2; keine alten ZIPs in das neue Paket kopieren.

Einsteigen über aktuelle AGENTS.md und PUZZLE_AUTHORING. Auftrag 3 folgt Abschnitten 4–7 bis content_ready, ohne Runtimeintegration.
Die tatsächliche menschliche Erklärung zur Freigabe MA-r01 als Beleg speichern; Motivdatei/hash und C-r02-Ableitung binden. Vorgeschlagene Parameter stehen in configuration.json, vier strikte Designs unter designs/. Die spätere exakte Parameterbindung im Motivfreigabebeleg muss aus der wirklich erteilten Korridorfreigabe stammen, nicht erfunden werden.

Vier Kandidaten nach den dokumentierten Größenhypothesen vergleichen. area-Schwellen sind im Farbmodus wirkungslos; keine Scheinkandidaten daraus bilden. Diskrete Raster/Hinweise erst jetzt erzeugen. Bei unzureichender visueller oder deduktiver Qualität Workflow-Rücksprung statt stiller Motivänderung.
Vollständige Logik, unabhängige Prüfung, Herkunft, Randregel, Motivtreue, Schwierigkeit und Endraster dateigebunden belegen. Keine rätselspezifischen Tests oder CI-Replays anlegen; reine Inhalte bleiben content_only.

Erforderliche Produktionsumgebung: Python 3.11+, isoliertes Pillow exakt 12.3.0 nach tools/puzzle_production/README.md. Ausführbarkeit in der konkreten Codex-Umgebung vor Start prüfen. Aktuelle Bildphase hat diese spätere Produktionsfähigkeit nicht durch Solver/Import behauptet.

Kompakter Folgeauftrag nach Zustimmung:
Arbeite nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross.
PR #113 / Branch content/warnemuende-reveal-r01; Paket pz-8ecddf77e80c4543bf4ec714fe3d / r02.
Ich gebe MA-r01 samt dem in configuration.json vorgeschlagenen Parameterkorridor frei.
Führe Standardauftrag 3 bis zum geprüften content_ready-Paket zur Endabnahme aus.
Repositoryablage nach §6, bestehenden Draft-PR fortführen; kein Merge.
