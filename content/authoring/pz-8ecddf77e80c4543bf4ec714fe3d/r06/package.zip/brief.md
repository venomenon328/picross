# Warnemünde · Himmel entfernen

Der aktuelle Nutzerauftrag ist in edit-plan.json wortgetreu gebunden. Ausgang
ist ausschließlich das registrierte r05-Runtime-Raster vom gebundenen Mainstand.
674 außenverbundene blaue Himmelszellen werden leer. Alle übrigen Zellen bleiben
identisch, einschließlich 34 blauer Fensterzellen, Sonne und Gebäudesymmetrie.
Zusätzlich vorgeschlagen: kompakte 28×32-Fassung durch Abschneiden ausschließlich
leerer Außenstreifen; eine 30×40-Ansicht bleibt enthalten. Kein neuer Reveal,
keine Logikreparatur an Gebäuden, keine Integration oder Merge dieses Entwurfs.
