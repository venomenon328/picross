# Standardauftrag 4 · erst nach tatsächlicher Endabnahme

ID pz-7635c2e042e349fc90ad9ae55681de0f, r03, content_ready, wasserwelt.
Aktuellen main/AGENTS.md, PUZZLE_AUTHORING und auftragsbezogene Quellen lesen.
Paket/Record/Inventar/Handoff und äußere ZIP-Inspektion auflösen und Hashes prüfen.
Die Endabnahme ist bisher nicht erteilt; keine Spielregistrierung vorwegnehmen.

Die menschliche Erklärung muss genau r03 samt Originalhandoff-/Inventarhash,
repair-r01/candidate-001, Matrix-/Logikhash und reveals/B-r01.png binden.
Eine Freigabe der Repositoryablage ersetzt diese Inhaltsentscheidung nicht.
Original-ZIP/Handoff/Inventar danach unverändert, Freigabe separat approval.json.

Nach tatsächlicher Endabnahme §8: export mit explizitem Titel Seepferdchen,
kollisionsfreiem stem/slot, Runtime-Revision 1, --category-id wasserwelt und
aktueller content/categories.json. Keine manuellen Matrix-/Registryänderungen.
Das technische Paket verwendet RP-5 v2 und paired-lines-mono, aber die finale
full-line-mono-Baseline ist ebenfalls solved, R4=false. Alle Baseline-/Paarproofs,
Assessments und Replayinputs sind enthalten. Keine neue motivische Freigabe nötig
bei unveränderten Bytes. Schwierigkeit 0.2 bleibt historisch gebunden.

Aktuellen geprüften difficulty-checked.json (0.3, instrumented/medium, L3) nach
Export ausdrücklich an die tatsächlichen Definitionsbytes rebind; gleiche ID,
Produktionsmodus mono, Matrix und Logik prüfen. Keine wiederholte Analyse nötig.
Dann plan/register mit demselben neuen geprüften Input gemäß §8. Autorisierten
Merge nach Pflicht-CI durchführen und erst nach tatsächlichem Integrationsmerge
die eigene Cleanup-/Mergefolge nach §9 ausführen. Reine Authoringablage r03 führt
noch keinen Produktionscleanup aus. Keine echten Saves oder Spielerbuildpflicht.
