# Tatsächliche Variantenwahl

Vier Kandidaten aus den zwei freigegebenen Größen und zwei Monoschwellen:
13×25/128 und /160 sowie 14×27/128 verlieren die geschützte Augenöffnung.
14×27/160 erhält sie und wird nach unverändertem Paarfixpunkt gezielt repariert.
Die Empfehlung 13×25 ist durch die ebenso freigegebene Alternative ersetzt.
Nur eine Zelle Z6/S11 hinzugefügt; die vollständigen Originalbündel und der
RP-5-v2-Replay bleiben erhalten. Entscheidungen und Hashes: decisions.json,
qa/candidate-verification.json, qa/repair-replay.json.
