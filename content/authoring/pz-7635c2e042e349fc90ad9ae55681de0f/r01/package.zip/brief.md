# Seepferdchen · Abschlussbildauswahl

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING; Motiv Seepferdchen.
Ziel: Rasterbreite offen, Rasterhöhe ungefähr 25; monochrom (genau eine Vordergrundfarbe plus Leer).
Das Abschlussbild bleibt farbig. Kategorie: wasserwelt / Wasserwelt.
Arbeitsweise free: freie Motivinterpretation ohne bereitgestellte Bildreferenz.
Neue eigenständige KI-Illustrationen, keine Fremdassets oder geschützte Figurenvorlage.

Unverzichtbar: eindeutiger Seepferdchenkopf mit Röhrenschnauze und Auge,
gebogener Hals, gegliederter Körper, Rückenflosse, verjüngter eingerollter
Greifschwanz mit sichtbarem Freiraum. Ganze Figur ohne angeschnittene Teile.
Ruhige warme gezeichnete 2D-Albumästhetik, saubere Kontur und farbige Binnenzeichnung.
Echte transparente Außenfläche und Schwanzöffnungen, keine Kulisse oder Beschriftung.

Pose, Blickrichtung, Körperproportionen und Farbgebung variieren zwischen A/B/C.
Keine Motivabstraktion, Zellmatrix, Hinweise, Rasterreparatur oder Registrierung beauftragt.
Noch keine Variante gewählt oder freigegeben. Die Bildfreigabe muss die exakte
Dateirevision aus reveals/ samt den zu bewahrenden Merkmalen binden.
