# Seepferdchen · Standardauftrag 2

B-r01 aus Paket r01 ist durch den Nutzer ausdrücklich freigegeben; Datensatz und
Wortlaut stehen in reveal-approval.json und approval-evidence.md.
Die farbigen Abschlussbildbytes bleiben unverändert. Kategorie wasserwelt.
Ziel: offene Breite × ungefähr 25 hoch, monochrom, genau 1 Vordergrundfarbe plus Leer.
MA-r01 ist eine vorlagentreue native Abstraktion aus genau diesen Bildbytes.
Rechtsgerichtete Seitenpose, Röhrenschnauze, Auge, Halsbogen, Bauch, linke Flosse,
verjüngter Greifschwanz und offener Innenraum bleiben der Identitätskern.
Detailverlust: Farbe, Panzerzeichnung, Oberflächentextur, feine Zacken und Flossenstrahlen.
Iris/Pupille werden zu einer einzelnen hellen Augenöffnung zusammengefasst.
Das Weiß der Motivvorlage ist leerer Bildgrund/Leerfläche, keine zweite Vordergrundfarbe.
Allein der vorgeschlagene Korridor in parameter-corridor.json steht zur Motivfreigabe.
Noch keine Motivfreigabe, Zellmatrix, Hinweise, Solver, Rasterreparatur oder Spielregistrierung.
