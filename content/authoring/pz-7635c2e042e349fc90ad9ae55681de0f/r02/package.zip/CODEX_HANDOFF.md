# Codex-Übergabe · erst nach tatsächlicher Motivfreigabe

Paket pz-7635c2e042e349fc90ad9ae55681de0f / r02, Zustand motif_review. Einstieg AGENTS.md auf aktuellem main;
PUZZLE_AUTHORING samt auftragsbezogenen Pflichtquellen tatsächlich lesen.
Die vorliegende Übergabe ist vollständig vorbereitet, aber die Rasterproduktion
ist noch durch die fehlende menschliche Motiv-/Parameterfreigabe gesperrt.

## Startpunkt nach Freigabe

1. Index/Record, r02-ZIP/Inventar/Handoff sowie reveal-approval.json und die neue
   tatsächliche Nutzererklärung zur Datei motifs/MA-r01.png samt Parameterkorridor prüfen.
2. Freigabe mit echtem Akteur/Zeit/Wortlaut separat binden; vorgeschlagene Parameter
   nicht im Voraus als approved markieren. Für jede tatsächlich freigegebene exakte
   Konfiguration ein passendes human_motif_approval-Objekt nach vorhandenem Vertrag
   aus derselben echten Erklärung ableiten; die spätere Endauswahl bindet genau ihre
   Maße/Modus/Farbzahl/Methode. Keine neue menschliche Entscheidung erfinden.
3. Auf neuem isoliertem Produktionsbranch Standardauftrag 3 ausführen. Eingangsdatei
   unverändert motifs/MA-r01.png; Designs für 13×25 und 14×27, je area-128/160, vorhanden.
   Bevorzugt 13×25. Profilwahl, vollständiger unabhängiger Nachweis, Randregel,
   Motivprüfung, begrenzte Reparatur und SD-Bewertung gemäß Regelwerk. Keine blinde
   Parametersuche, kein zusätzlicher Randrahmen, keine Motivwissens-Startfelder.
4. Bis content_ready samt echtem Endraster, Abschlussbild und Endabnahmepaket liefern.
   Noch nicht registrieren oder ins Spiel integrieren. Bestandsrätsel nicht replayen,
   keine rätselspezifischen Unit-Tests; reiner Inhaltspfad und beauftragter Ablagemerge.

Die ursprüngliche Abschlussbildfreigabe gilt unverändert für dac1d788f3f143d9dde976f7dc7b8fd02099eea872f759872b0ee58b1360937c.
MA-r01-SHA-256: 4a74418d367e588d2e719cca18d68679142f2c5c042e3e0d3498179116c834b5. Korridor: 13×25 oder 14×27, Mono genau 1,
area, contain, Crop [82,40,860,1653], Schwellwerte 128/160. Keine Randregel-Ausnahme.
Diese geplanten Parameter sind keine Zusage über Lösbarkeit oder Schwierigkeit.
Modell/Reasoning wird in der Codex-Oberfläche gewählt, keine Modell-API.
