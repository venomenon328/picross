# Konfigurationsvergleich

| Konfiguration | Motivtreue / Darstellbarkeit | Erwartetes Logikrisiko | Spielgefühl |
| --- | --- | --- | --- |
| 13×25, Mono/1 (empfohlen) | Kompakte Seitenfigur, Auge und offener Schwanzbogen bewusst vereinfacht. Gute Nähe zum Höhenwunsch. | Schmale Schnauze und Schwanzspitze können Engstellen erzeugen; noch ungeprüft. | 325 Zellen, kurze bis mittlere Bearbeitungsmenge, keine Schwierigkeit behauptet. |
| 14×27, Mono/1 (zugelassene Alternative) | Etwas mehr Abtastplatz für Hals, Auge und Schwanzöffnung bei nahezu gleichem Zielverhältnis. | Mehr Platz hilft der Darstellung, garantiert keine leichtere oder vollständige Deduktion. | 378 Zellen, etwas mehr Zeichenarbeit. |
| 12×23, Mono/1 (verworfen, nicht im Korridor) | Stärkere Reduktion; Auge/Schwanzöffnung und Schnauze werden anfälliger. | Kompakter heißt nicht automatisch logischer lösbar; unbekannt. | 276 Zellen, weniger Arbeit bei höherem Darstellungsrisiko. |

Genau eine Vordergrundfarbe ist verbindlich; Weiß/Leer zählt nicht. Das Abschlussbild bleibt farbig.
Die neue native Motivvorlage ist schlank; die Größen begründen sich primär aus
erhaltenen Hauptformen, nicht aus einer behaupteten Raster- oder Logikprüfung.
Vier geplante Kandidaten: zwei exakte Größen × area-128/area-160. Doppelte Matrizen
später erkennen und ihre Entstehungswege behalten, nicht als vier Lösungen zählen.
Keine Zellmatrix und keine Rastervorschau in dieser Phase erstellt.
