# Brandenburger Tor – Korrektur B-r02

ID pz-2a8481f61e6443bda174bd3da67c, Paket r02, Status reveal_review, 2026-10-13T20:47:28.941759Z.
Regelwerk 0.4.1 / Dokumentrevision 5; Quell-/Toolcommit 8c27e2729c09799092ac9f1f1823316a88e734f0.
Kategorie Gebäude & Bauwerke; Mono; Rastermaße und Schwierigkeit offen.

B-r01 wurde als Korrekturbasis gewählt, nicht als Abschlussbild freigegeben.
Niedrige Flügel links/rechts und deren Dachansätze entfernt. Haupttor,
Schrägansicht, sechs Frontsäulen, fünf Passagen und Quadriga bleiben visuell
erhalten. Kleinere Binnenzeichnungsdetails variieren durch native Bearbeitung;
keine pixelidentische Bewahrung behauptet. Alle fünf Gestaltungsachsen erfüllt,
Einzelbelege in visual-review.json. B-r02 ist das aktuelle Angebot.

input/B-r01.png sind die gebundenen Originalbytes. reveals/B-r02.png ist die
unverändert gespeicherte native Ausgabe. Bearbeitungsanweisung in generation.json.
Die ursprünglichen A/B/C-Dateien, Entscheidungen und Hashes bleiben in r01.
Kein altes ZIP eingebettet und keine ältere Revision überschrieben.

ZIP-/Inventar-/Dateihash-/Handoffkopieprüfung erfolgt am geschriebenen Archiv.
Alle Freigaben offen; keine Motivvorlage, Matrix, Hinweise, Randregel, Logik,
Proof, Schwierigkeit, Adapterprüfung, Export oder Registrierung vorweggenommen.
Probespiel nicht durchgeführt, optional. Aktive Menschenzeit nicht erfasst.
Nächster erlaubter Schritt: B-r02 ausdrücklich freigeben und Standardauftrag 2.
