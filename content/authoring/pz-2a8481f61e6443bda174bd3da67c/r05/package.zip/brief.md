# Brandenburger Tor · Standardauftrag 3

pz-2a8481f61e6443bda174bd3da67c, r05, Kategorie gebaeude-bauwerke. Aktuelle menschliche Freigabe MA-r02 mit ausdrücklichem Maß 40×30 ersetzt die vorgeschlagenen 42×30/49×35 aus r04. Mono/ink, area und Motivinvarianten bleiben bestehen. A-r02 und beide Motivableitungsbytes bleiben unverändert.

Frontalansicht, breite Hauptproportionen, sechs Stützen/fünf offene Passagen, breiterer Mittelgang, zentrale Vierpferdegruppe mit Lenker und Stab/Adler sowie fehlende Seitengebäude bewahren. Reliefs, Textur, Schatten, Pflaster, Zügel und kleinste Skulpturdetails dürfen entfallen. Keine Spiegelungsannahmen im Solver.

Der notwendige 4:3-Crop [122,15,1414,984] enthält die vollständige gemessene Vordergrundbox [124,17,1413,933]. Nur Außenweiß entfernt; exakter Fit, kein Strecken oder Abschneiden. Zahlenkoordinaten sind eine dokumentierte Umsetzung der neuen Maße, keine wörtlich erteilte separate Cropfreigabe.

Produktion bis Endabnahmevorlage samt Repositoryablage/Draft-PR beauftragt; keine Endfreigabe, Spielregistrierung oder Merge. Herkunft/Nutzungsgrundlage in den Bildprovenienzen, tatsächliche Nutzererklärung in motif-approval-evidence.json.
