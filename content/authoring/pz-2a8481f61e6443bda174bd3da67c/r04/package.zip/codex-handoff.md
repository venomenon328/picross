# Codex-Übergabe – noch keine Motivfreigabe

Aktueller Stand: motif_review, ID pz-2a8481f61e6443bda174bd3da67c, Paket r04.
Arbeitsbranch content/brandenburger-tor-reveal-r01, ursprüngliche Zielbasis main.
Fundort: content/authoring/pz-2a8481f61e6443bda174bd3da67c/r04/record.json.
Bytegebundene Dateien: reveals/A-r02.png (b2d10a0490dbce384ab9fd5df94c523b901c3d79731931fbebe60d790be2519a),
motifs/MA-r02.png (dab4dbd6882627e96c61c376c684f9b30ac5b7c89932e6f263ea56512e4eb779). Abschlussbildfreigabe vorhanden;
Motivfreigabe und sämtliche Raster-/Inhaltsnachweise offen.

Nach der tatsächlichen menschlichen Motivfreigabe beide Bildbytes, Herkunft,
Inventar, getrennte Abschlussbild-/Motivfreigaben und configuration.json binden.
Nächster Auftrag ist Standardauftrag 3, noch keine Runtime-Integration.
Vier gezielte Kandidaten: 42×30 und 49×35 jeweils area mit 128/176; innerhalb
des ausdrücklich bestätigten Korridors bleiben. Keine automatisch leere
contour-Randlinie. Native Produktionsprüfung, unabhängiger Proof, Herkunft,
Randregel, Sichtprüfung und Schwierigkeit nach aktuellem Regelwerk.
Die alte MA-r01-Datei ist allein Bearbeitungseingang, keine freigegebene Quelle.
Keine neuen rätselspezifischen Unit-Tests oder CI-Korpora. Paket r04 unverändert
bewahren, nächste Revision erzeugen. Gleichen Draft-PR fortführen; kein Merge.

Kopierbare Nutzervorlage, erst bei tatsächlicher Freigabe verwenden:

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Ich gebe die Motivvorlage MA-r02 aus Paket r04 für pz-2a8481f61e6443bda174bd3da67c frei,
einschließlich des Parameterkorridors in configuration.json (42×30 oder 49×35, monochrom).
Führe Standardauftrag 3 aus. Repositoryablage nach §6; bestehender Draft-PR, kein Merge.
```
