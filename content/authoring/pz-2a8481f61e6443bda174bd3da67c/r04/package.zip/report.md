# Brandenburger Tor – Motivfreigabe

ID pz-2a8481f61e6443bda174bd3da67c, Paket r04, Status motif_review, 2026-10-13T21:03:48.621820Z.
Regelwerk 0.4.1 / Dokumentrevision 5; Quell-/Toolcommit e7152544bf1ba2453fcf3a2add8c03aab1e8cf8a.
Abschlussbild A-r02 freigegeben, Datei unverändert. Motiv MA-r02 noch offen.
Empfehlung 42×30 (1260 Zellen), Alternative 49×35 (1715); Mono mit ink/Leer.
35×25 im Vergleich verworfen wegen begrenzter Quadriga-Trennung.
configuration.json vergleicht Motivtreue, Darstellbarkeit, Lösbarkeitsrisiko und
Bearbeitungsgefühl getrennt. Schwierigkeit/Zeiten noch nicht geschätzt.

Zwei native Motivbearbeitungen: MA-r01 zu stark vereinfachte Tiefenflächen,
MA-r02 korrigiert. Fünf Gestaltungskriterien einzeln in visual-review.json.
Detailverluste: Relief, Flutung, Steinzeichnung, Schatten und Pflaster entfernt;
Quadriga-Binnenzeichnung und Durchgangstiefe reduziert. Kein Pixelgleichheitsanspruch.
comparison.html stellt Abschlussbild und Motiv nebeneinander.

Belege: reveal-approval.json plus tatsächliche Erklärung, getrennte Bildprovenienzen,
beide Originaldateien/Hashes, generation.json und sources.json. Motivfreigabevorlage
ausdrücklich ausstehend. Inventar/Handoff binden das geschriebene sichere ZIP.
Keine Matrix, Hinweise, Logikprüfung, Randregelzertifizierung, Schwierigkeit,
Endabnahme, Export oder Spielregistrierung vorweggenommen. Probespiel optional.

Nächster erlaubter Schritt: MA-r02 mit configuration.json freigeben und
Standardauftrag 3; vollständige Vorbereitung in codex-handoff.md.
