# Codex-Übergabe

Aktuelle AGENTS.md / PUZZLE_AUTHORING.md in venomenon328/picross@main lesen. Paket-ID pz-e45e2e0d67a34f6aa8368f477454, Revision r03, Status motif_review. Noch kein Remote-Branch/PR; Übergabedatei enthält neue Paketdateien und additiven Indexeintrag. Aktuellen Index niemals durch ältere Kopie ersetzen.
F-r01 ist datei-/hashgebunden freigegeben. MA-r02 ist lediglich zur Freigabe vorgelegt. Belege, konfigurierte Empfehlung, beide Bilder, Invarianten und Herkunft liegen im Paket. r02-Recoverygrenzen ausdrücklich berücksichtigen; für Auftrag 3 ist r03 mit allen nötigen Bildbytes vollständig.
Vor Rasterproduktion die tatsächliche Nutzerfreigabe von motif/MA-r02.png samt Parametern protokollieren. Vorgeschlagen 28×46 oder 30×50, Mono, area/contain, weißes Außenraum-Crop ohne Silhouettenverlust. Zunächst vier gezielte Rasterkandidaten (zwei Größen × zwei sinnvolle Schwellen); vorhandene Werkzeugverträge, motivgeschützte Reparatur und einmalige Produktionsprüfung nach Regelwerk. Keine Rätsel-Unit-Tests oder Bestands-Replays. Keine Registrierung.
Repositoryablage beauftragt: eigenen Arbeitsbranch verwenden, Paket/Record/Handoff/Index gemeinsam committen/pushen, Draft-PR; kein Merge. Reiner Inhaltspfad docs/ci-required.

