# Kölner Dom · Motivvorlage

Standardauftrag 2 nach Regelwerk 0.4.1 / Dokumentrevision 5. Abschlussbild F-r01 ausdrücklich freigegeben; Datei und Hash in approvals/reveal-approval.json. Mono, Kategorie gebaeude-bauwerke.

Invarianten: Kölner Dom als alleinstehendes Gebäude ohne Umgebung oder andere Bauwerke; Strikt frontale Westfassade; Zwei gleich hohe schlanke Westtürme samt vollständigen Spitzen und breitem offenem Zwischenraum; Turmhöhen, Turmabstand, Mittelgiebel und breite gestufte Basis; Lage der großen Spitzbogenfenster und drei Portale; Keine Streckung, kein Wechsel der Perspektive.

Erlaubte Reduktion: Farbe, Steintextur, Maßwerk, Skulpturen und feine Konturornamente zusammenfassen; wichtige Silhouette und Fenster-/Portalräume erhalten. Vorgeschlagen: 30×50, Produktionsvergleich 28×46 / 30×50, area/contain, monochrom. Maße/Parameter sind noch nicht menschlich freigegeben.

Keine Rasterproduktion bis zur konkreten Motivfreigabe. Repositoryablage samt Draft-PR beauftragt, kein Merge. Remote-Push weiterhin nicht möglich. ZIP r02 beschädigt, F-r01 aus vollständig inventargeprüften Einzelbytes erhalten.
