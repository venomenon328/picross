# Kölner Dom · Abschlussbildauswahl

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.4.1, Dokumentrevision 5.
Rätselmodus: monochrom; Abschlussbilder bleiben farbig. Maße offen. Kategorie: gebaeude-bauwerke.

Nutzerwunsch: Alleinstehendes Gebäude, keine Umgebung, keine anderen Bauwerke.
Invarianten: eindeutig erkennbarer Kölner Dom, zwei hohe gotische Westtürme, vollständige Spitzen, charakteristische Turmproportionen und Abstand, Spitzbogenfenster und gegliederte Fassade. In Schrägansichten gehört das Langhaus zum selben Gebäude.
Arbeitsweise: free aus Motivtext, ohne vorgegebenes Ausgangsbild; nach Freigabe vorlagentreue Ableitung. Keine Rekonstruktionszeichnung oder Vermessungsgenauigkeit zugesagt.
Erlaubt: perspektivische/stilistische Varianten und ruhige Farbgestaltung, Zusammenfassung kleinteiliger Architektur in der späteren Abstraktion.
Nicht erlaubt: Umgebung, andere Bauwerke, abgeschnittene Türme, Motivänderung nach Freigabe ohne neue Freigabe.

Befugnis: Paketsicherung, Index, Commit, Push, Draft-PR. Kein Merge. Nächster Stopp: ausdrückliche Freigabe einer angebotenen Datei. Noch keine Motivvorlage, Raster, Hinweise oder Spielregistrierung.
