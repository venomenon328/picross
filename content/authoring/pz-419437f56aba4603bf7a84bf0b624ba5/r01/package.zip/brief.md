# Huhn · Abschlussbildauswahl r01

Standardauftrag 1; Status `reveal_review`. Kategorie: Vögel (`voegel`).
Auftrag: drei farbige detaillierte Abschlussbilder für ein später monochromes Rätsel.
Breite und Höhe sind offen; regulär höchstens 50 Zellen je Achse. Keine Rastergröße,
Schwierigkeit oder Lösbarkeit zugesagt. Monochrom bedeutet später eine Vordergrundfarbe
plus Leer; das Abschlussbild bleibt vollständig farbig und transparent.

Freie Motivübertragung (`free`) aus dem Wortmotiv Huhn, ohne externe Bildreferenz.
Reversible Auslegung: erwachsenes weibliches Haushuhn, keine bestimmte Rasse.
Unverzichtbar: erkennbarer Kopf mit Kamm, Kehllappen, kurzem Schnabel und Auge;
gerundeter Körper, gefalteter Flügel, kurzer aufgerichteter Schwanz, zwei Beine/Füße
und klare Aussparung zwischen den Beinen. Natürliche Proportionen und saubere Konturen.
Keine Requisiten, Eier, Schrift oder dekorative Umgebung. Gefiederfarbe und Pose
variieren in dieser Auswahl; eine menschliche Auswahl bindet anschließend ihre
konkrete Pose, Blickrichtung, Hauptproportionen, Flügel-/Schwanzform und Negativräume.

Warme ruhige handgezeichnete 2D-Albumillustration, ausgearbeitete Binnenzeichnung,
natürliche kräftige Farbflächen, zurückhaltende Schattierung. Echte PNG-Transparenz
außen und zwischen den Beinen; helle Federn bleiben sichtbar. Die spätere
Abstraktion reduziert Federtextur und Zehendetails, ohne den gewählten Bildaufbau
materiell zu verändern. Es wurden noch keine Motivvorlage, Zellmatrix oder Hinweise erzeugt.
