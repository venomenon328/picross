# Huhn · Abschlussbildauswahl r01

ID `pz-419437f56aba4603bf7a84bf0b624ba5` · Kategorie Vögel · Status `reveal_review` · 2026-10-28T18:20:02Z
Regelwerk 0.5.0 / Dokumentrevision 23; Repository-/Toolstand `056c05073664e72a40f9fc8e68ec80d96f838f98`.
Inventarbindung im Handoff; das Inventar bindet diesen Bericht ohne Selbstreferenz.

Drei farbige transparente Einzelbilder: [A](images/reveal-a-r01.png),
[B](images/reveal-b-r01.png), [C](images/reveal-c-r01.png).
Empfehlung A: klassische Seitenansicht mit klaren Hauptformen für Mono.
B: rotbraune Dreiviertelansicht mit kräftiger Farbwirkung; C: geschecktes Gefieder
und gesenkter Kopf, dessen Flecken bei Mono gezielt zusammengefasst werden müssten.
Keine Variante verworfen oder ausgewählt; alle Originalbytes vollständig erhalten.

Bilddateien jeweils 1254×1254 RGBA-PNG. Dekodierung, Alphakanal, Dateigrenzen
und sichtbarer vollständiger Ausschnitt geprüft. Die [Papiermontage](review/paper-comparison.png)
zeigt große Ansichten auf dem tatsächlichen Buchpapier und kleine Ansichten bei
112/140 px auf normalen und gehoverten Katalogfarben. Erkennbarkeit,
Silhouette/Proportionen, wichtige Details/Negativräume, Farb-/Mono-Komposition und
Serienästhetik sind pro Variante im [Sichtbericht](visual-review.json) begründet.
Statischer redaktioneller Beleg, kein nativer Laufzeit- oder Animationsnachweis.

Rätselmodus: monochrom, später genau eine Vordergrundfarbe plus Leer.
Rastermaße, Zellzahl, tatsächliche Matrixpalette, Schwierigkeit und Lösungszeit
sind noch offen. Bildfreigabe, Motivfreigabe und Endabnahme sind offen.
Motivvorlage, Rasterimport, Kandidatenwahl, Randregel, Hinweise, Logik-/Proofprüfung,
Herkunftsrekonstruktion und Zieladapterexport sind in dieser frühen Bildphase
noch nicht anwendbar. Keine Reparatur, da noch keine Rasterproduktion.

Herkunft/Nutzungsgrundlage: auf Auftrag neu generierte Bilder ohne externe
Bildreferenz; [Provenienz](provenance.json). Native Bildgenerierung mit drei
gespeicherten Prompts und exponierten Einstellungen in [generation.json](generation.json).
Keine Bildnacharbeit; aktive Menschenzeit nicht erfasst. Probespiel nicht durchgeführt, optional.

Blocker für Auftrag 2: tatsächliche menschliche Auswahl und ausdrückliche Freigabe
einer konkreten Bilddatei r01. Nächster Schritt: **2 · Bild freigeben & abstrahieren**.
Die beauftragte Repositoryablage und der bedingte Ablage-Merge sind keine Bildfreigabe.
