# Huhn · Produktionsprüfung r03

Standardauftrag 3, Kategorie Vögel (`voegel`). M-r01 und der ursprüngliche
Parameterkorridor sind durch die tatsächliche Nutzererklärung freigegeben.
Vier Importe wurden ausgeführt. Kein freigabefähiger Endkandidat innerhalb
des bisherigen Korridors; Crop-/Gestaltungsentscheidung offen.
Abschlussbild A-r01 und Motivdatei M-r01 bleiben bytegleich.
Invarianten und Nutzungsgrundlage aus r02 bleiben bindend.
