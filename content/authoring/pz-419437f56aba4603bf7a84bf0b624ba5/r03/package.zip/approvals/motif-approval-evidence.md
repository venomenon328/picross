# Tatsächliche Motivfreigabe

> Ich gebe die Motivvorlage images/motif-m-r01.png · M-r01 frei; Parameter: 24×26 oder 30×32; mono, genau 1 Vordergrundfarbe plus Leer; area-Schwellen 140/180; contain; Alpha 128; Crop [72,27,1222,1233]. Empfehlung: 30×32.. Führe Standardauftrag 3 vollständig bis zur Endabnahmevorlage aus.

Paket r02, main / 57d69efe75672530e1e18dae022106d278b296b8.
Farbanzahl: 1 (Genau, ohne Leer). Repositoryablage nach §6 und bedingter Ablage-/Integrations-PR-Merge nach erfolgreichen Pflichtprüfungen beauftragt.
Endabnahme des noch zu erzeugenden Rasters liegt nicht vor. UTC ist Protokollierungszeit, kein behaupteter Nachrichtenversandzeitpunkt.
