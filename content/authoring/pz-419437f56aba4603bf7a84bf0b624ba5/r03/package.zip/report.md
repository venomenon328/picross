# Huhn · Produktionsprüfung r03

ID `pz-419437f56aba4603bf7a84bf0b624ba5` · 28.10.2026 · Status `blocked`.
Regelwerk 0.5.0 · Tool-/Quellcommit `57d69efe75672530e1e18dae022106d278b296b8`.
Inventarhash steht im [Handoff](handoff.json), ohne Selbstreferenz dieses Berichts.

[A-r01](images/reveal-a-r01.png) und [M-r01](images/motif-m-r01.png) sind durch
[Bildfreigabe](approvals/reveal-approval.json) und [Motivfreigabe](approvals/motif-approval.json)
mit tatsächlichem Wortlaut gebunden. Beide Bilddateien bleiben unverändert.

| Kandidat | Zellen | Ink / Leer | Liniennachweis | Randregel | Entscheidung |
| --- | ---: | ---: | --- | --- | --- |
| 24×26 area-140 | 624 | 276 / 348 | solved, 126 Schritte | pass (rechts + oben) | Auge verloren |
| 24×26 area-180 | 624 | 278 / 346 | solved, 127 Schritte | pass (rechts + oben) | Auge verloren |
| 30×32 area-140 | 960 | 426 / 534 | solved, 151 Schritte | fail (oben/unten leer) | keine Endauswahl |
| 30×32 area-180 | 960 | 432 / 528 | solved, 151 Schritte | fail (oben/unten leer) | keine Endauswahl |

Alle vier Matrizen sind verschieden, mono und verwenden genau eine gewünschte
Vordergrundfarbe `ink` (`#242424`) plus `empty`. Crop `[72,27,1222,1233]`,
contain, Alpha 128 und Schwellen 140/180 unverändert.
[Echte Raster](review/candidates-grid.png), [Sichtprüfung](visual-review.json) und
[Datei-/Herkunfts-/Proofbeleg](verification/original-candidates.json) zeigen den Stand.
Frischer unabhängiger Prüferprozess rekonstruiert Original → Normalisierung →
Matrix → Hinweise und den vollständigen `full-line-mono`-Proof; Enddomains exakt
gleich der jeweiligen Matrix. Eindeutigkeit folgt der vollständigen Deduktion.
Keine Paarprüfung oder Suchdiagnose nötig.

Silhouette, Pose, gerundeter Körper, Fächerschwanz und zwei getrennte Beine sind
erkennbar; Kopf/Auge und Flügelzeichnung verlieren zu viel Binnenform.
Vereinzelte Flügel-/Zehenzellen sind motivbezogene Warnbefunde, keine künstlichen
Logikanker. Kein final visuell abgenommener Kandidat.
Keine RP5-Alibisuche: Das vorhandene Verfahren stoppt bereits an einer logisch
zertifizierten unveränderten Referenz. Hauptmerkmalkorrekturen benötigen nach
Authoring §2.4/§4.4 passende neue Abstraktions-/Parameterfreigabe.

**Blocker:** engere Cropvarianten für 30×32 sind angefragt, bisher nicht freigegeben.
Keine Rand-Ausnahme oder Motivabweichung selbst erteilt. Schwierigkeit nicht
bestimmt: noch kein endgültiges Raster; Methode 0.4 ist für die Fortsetzung gebunden.
Lösungszeit und aktive Menschenzeit nicht erfasst; Probespiel optional und nicht
durchgeführt. Keine neuen Bildaufrufe, zwei Importe/vier Kandidaten, keine Reparatur.
Nutzungsbasis: eigene beauftragte generierte Illustrationen ohne externe Bildassets.

ZA-1-inspect/Export/Registrierung nicht ausgeführt: kein `content_ready`-Eingang,
keine Endabnahme. Native Tests/Spielerbuild nicht erforderlich: reine Produktionsablage.
**Nächster Schritt: Korrigieren oder Fehler beheben** – Croperweiterung entscheiden,
danach gezielte neue Kandidaten, vollständige Prüfung und Schwierigkeit bis zur
echten Endabnahmevorlage. Keine Spielintegration oder Bereinigung vor Endabnahme.
