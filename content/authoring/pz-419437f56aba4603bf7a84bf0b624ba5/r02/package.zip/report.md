# Huhn · Motivvorlage r02

ID `pz-419437f56aba4603bf7a84bf0b624ba5` · 2026-10-28T19:02:14Z · Kategorie Vögel · Status `motif_review`.
Regelwerk 0.5.0 / Dokumentrevision 23 · Tool-/Quellcommit `0be037585fa222496ce9c8d1d1021d459657c13e`.
Inventarhash im Handoff; dieser Bericht ist darin ohne Selbstreferenz gebunden.

**A-r01 ist menschlich freigegeben**: [Abschlussbild](images/reveal-a-r01.png),
[Freigabe](approvals/reveal-approval.json) und [Wortlaut](approvals/reveal-approval-evidence.md).
Die native daraus abgeleitete [Motivvorlage M-r01](images/motif-m-r01.png) bewahrt Pose und
Hauptformen. [Bildvergleich](review/reveal-motif-comparison.png),
[Sichtprüfung](visual-review.json) und [Invarianten](invariants.json) zeigen die
gewollte Reduktion von Federtextur, Schattierung, Schuppen und Zehendetails.
M-r01 und der vorgeschlagene Parameterkorridor warten auf menschliche Freigabe;
abschließende redaktionelle Endabnahme ist ebenfalls noch offen.

Empfehlung **30×32**, 960 Zellen; kompakte Alternative **24×26**, 624 Zellen.
**36×38** wurde mitbetrachtet und mangels zusätzlichem Motivnutzen nicht gewählt.
Die [Konfiguration](configuration.json) trennt Motivtreue, Darstellbarkeit,
ungeprüftes erwartetes Lösbarkeitsrisiko und Spielgefühl. Vorgeschlagen: genau
eine Vordergrundfarbe `ink` plus Leer; keine Abweichung vom Nutzerwunsch.
Zwei Größen mit je Mono-Flächenschwelle 140/180, `contain`, Alpha 128 und
Crop `[72,27,1222,1233]` sind vorbereitet. Eine tatsächlich verwendete Farbzahl
wird erst in der Matrix gezählt. Die PNG-Abstraktion hat geglättete Kanten.

Beide Bilder sind 1254×1254 RGBA-PNGs; Abschlussbildbytes unverändert.
Herkunft/Generierung und tatsächliche Freigabe sind dateigebunden. Zwei strikte
Designformate wurden validiert; **keine** Rasterproduktion, Hinweise, Randprüfung,
Solver-/Proof-/Schwierigkeitsanalyse, Reparatur oder Zielintegration ausgeführt:
Diese Schritte folgen erst nach Motivannahme. Schwierigkeit und Lösungszeit nicht
geschätzt; Probespiel nicht durchgeführt und optional. Ein nativer Bildbearbeitungs-
aufruf in dieser Phase, insgesamt vier Bildaufrufe; Menschenzeit nicht erfasst.

B/C bleiben mit Hash und exaktem früherem Paketfundort in den Entscheidungen
erreichbar; ihre Bildbytes werden nicht erneut verpackt. Original r01 bleibt unverändert.
Das neue r02-Paket enthält alle für Auftrag 3 benötigten Bild-/Freigabeinputs.

Nächster Schritt: **3 · Motiv freigeben & produzieren**. Vollständige konkrete
Weitergabe: [CODEX_HANDOFF.md](CODEX_HANDOFF.md). Blocker ist ausschließlich die
noch offene menschliche Motiv-/Korridorfreigabe vor Rasterproduktion.
