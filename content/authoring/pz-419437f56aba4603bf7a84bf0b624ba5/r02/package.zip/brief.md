# Huhn · Abschlussbildfreigabe und Abstraktion r02

Standardauftrag 2, Kategorie Vögel (`voegel`), ID `pz-419437f56aba4603bf7a84bf0b624ba5`.
Der Nutzer hat A-r01 ausdrücklich freigegeben. Das gespeicherte farbige Abschlussbild
bleibt bytegleich; die monochrome Motivvorlage M-r01 ist daraus per nativer Bildbearbeitung
abgeleitet. Sie ist eine glatte Illustration, keine Zellmatrix und noch kein Rätsel.

Feste Nutzergrenzen: monochrom, genau eine Vordergrundfarbe ohne Leer. Empfehlung:
30×32, zusätzlich kompakte 24×26-Variante im vorgeschlagenen Produktionskorridor.
Kamm, Kopf, Körper, gefalteter Flügel, rechter Schwanz und zwei getrennte Beine
bleiben motivisch zusammengehörig. Erlaubte Detailreduktionen und harte Invarianten
stehen in `invariants.json`; Geometrie und Importparameter in `configuration.json`.
Erst die tatsächliche menschliche Motivfreigabe in Auftrag 3 bestätigt diesen Korridor.

Nutzungsgrundlage: eigenes auf Auftrag generiertes Wortmotiv, keine externen Bildassets.
Keine Rasterproduktion, Hinweise, Solver-/Proof-/Schwierigkeitsanalyse oder Spielregistrierung
in Auftrag 2. Repositoryablage nach §6 und bedingter Ablage-Merge sind beauftragt.
