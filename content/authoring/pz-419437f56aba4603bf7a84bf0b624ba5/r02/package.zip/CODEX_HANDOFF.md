# Codex-Übergabe · Huhn r02

ID `pz-419437f56aba4603bf7a84bf0b624ba5`, Paketrevision r02, Status `motif_review`. Quelle/Toolstand `0be037585fa222496ce9c8d1d1021d459657c13e`.
Regelwerk 0.5.0: `rulebook/PUZZLE_AUTHORING.md`; dessen Hash und Inventarhash stehen
im Handoff. Paket sicher öffnen, ZIP-/Handoff-/Inventarbindungen vor Arbeit prüfen.
Aktuellen `main`, `AGENTS.md` und dessen Pflichtquellen verwenden; der gebundene
historische Bildfreigabebeleg wird nicht geändert.

Abschlussbild A-r01: `images/reveal-a-r01.png`, SHA-256 `2672b5a69ca8b35bb78a0360860cbd415e285c5ba5c113c2867153b7e17c7328`.
Tatsächliche menschliche Freigabe: `approvals/reveal-approval.json` samt Wortlautbeleg.
Motivvorlage M-r01: `images/motif-m-r01.png`, SHA-256 `056edd181366e945126da4a1f46174d42b6c2a5068627ae48daa507074b30ce3`; daraus abgeleitet und noch nicht
menschlich freigegeben. `invariants.json` und `configuration.json` gemeinsam vorlegen.

Nächster Auftrag: **3 · Motiv freigeben & produzieren**. Vor jeglicher Rasterproduktion
die echte menschliche Freigabe genau dieser M-r01-Datei und des vorgeschlagenen
Parameterkorridors erfassen. Aktuell fehlen weder Bilddateien noch die A-Freigabe;
die noch offene Motivfreigabe darf nicht aus dem Auftrag 2 oder aus dem Ablage-Merge
abgeleitet werden. Keine erneute Routinefrage zum Lesen, Packen oder Prüfen.

Empfehlung 30×32; kompakte Alternative 24×26. Exakt eine Vordergrundfarbe `ink`
(`#242424`) plus `empty`; Hintergrund `#ffffff`, Alpha-Grenze 128, `fit=contain`,
Crop `[72,27,1222,1233]` im 1254×1254-Motiv. Die vier vorgeschlagenen Kombinationen
sind zwei Größen mit je `area-140`/`area-180`. Vollständige strikte Designs liegen
unter `proposed-designs/`; nur deren Format wurde geprüft, kein Import ausgeführt.

Nach Motivannahme vier gezielte Importe aus den unveränderten Motivbytes ausführen;
Zellgleichheit/Duplikate erkennen, reale Raster in nativer Größe, vergrößert ohne
Glättung und mit Gitter redaktionell vergleichen. Vom unbekannten Start mit
`full-line-mono` beginnen. Bei geeignetem unabhängig bestätigtem `stalled` erst
Profilwahl nach §4.2.1 prüfen, vor rein logikbedingter Formänderung. Paarprüfung
verlangt dann zusätzlich PAIRED_LINES, explizite Budgets, Baseline/Assessment und
neue passende Produktionsbindung. Keine Paar-/Suchläufe als aktuelle Belege behaupten.

Randregel `(left OR right) AND (top OR bottom)`, Produkthöchstmaße, eine tatsächlich
verwendete Vordergrundfarbe, vollständige Deduktion, frischer unabhängiger Prüfer,
Herkunftsrekonstruktion und exakte Endmatrixgleichheit bleiben Pflicht. Ein möglicher
Leerstreifen aus `contain` ist kein automatischer Fehler; die Randformel entscheidet.
Wenn nötig innerhalb §4.4 und des tatsächlich angenommenen Korridors bis zu zwei
gezielte motivgeschützte Reparaturrunden versuchen. Materielle Änderungen oder
Ausweitung des Korridors erneut zur Entscheidung vorlegen, keine Rand-Ausnahme erfinden.

Nach finaler Deduktionsprüfung die aktuelle Methode 0.4 über den dokumentierten
ausdrücklichen Kandidaten-/Analyseweg prüfen; dazu die Schwierigkeitspflichtquellen
lesen. Größe allein ist weder Schwierigkeit noch Zeitprognose. Keine Analyse in CI.
Technische/redaktionelle Ergebnisse und Aufwände ins neue Produktionspaket führen,
dieses vor Inventarisierung verschlanken, sicher öffnen und ab `content_ready`
ZA-1-`inspect` auf dem geschriebenen ZIP ausführen. Echtes Endraster und farbiges
Abschlussbild zur Endabnahme vorlegen. Auftrag 3 endet ohne Spielregistrierung.

Menschliches Probespielen ist optional. Keine rätselspezifischen Tests, Snapshots,
CI-Replays oder Prüfung unveränderter Bestandsrätsel anlegen. Reine beauftragte
Ablage nutzt `content_only=true`, `docs` und `ci-required`; native Tests/Builds
entstehen nicht automatisch. Standardauftrag 4 benötigt die spätere echte Endabnahme
und einen Integrationsauftrag. Aktueller Ablage-Merge ist beauftragt.
