# Codex-Wiederaufnahme · Huhn r04

Index → record.json → ZIP-/Handoff-/Inventarhash auflösen, aktuelle Regeln lesen.
Produzent `1bc379c56ef3a8b8f743589f1f6f7affb2237b19`; Handoff `content_ready`.
A-r01 und M-r01 bytegleich; tatsächliche engere Cropfreigabe ist dokumentiert.
Final `import-crop-c/area-140`, 30×32, Crop `[78,58,1212,1233]`, mono exakt eine Farbe.
Frischer unabhängiger Herkunfts-/Proof-/Endmatrixvergleich und aktuelle 0.4-Analyse
sind vollständig. Nicht erneut analysieren, wenn relevante Bindungen unverändert sind.
Die äußere ZA-1-Inspektion prüft das geschriebene ZIP; nur Endabnahme darf fehlen.

Nächster Auftrag: **4 · Abnehmen & ins Spiel integrieren**. Zuerst tatsächliche
Endabnahme separat an Originalhandoff, Inventar, Auswahl und Reveal binden.
Erst danach regulärer kategorisierter ZA-1-Export, Rating-Rebind auf echte Definition,
Plan/Register, Dateiprüfung und Integrations-PR. Produktions-ID unverändert,
Runtime-Revision/Stem/Slot explizit wählen. Keine Wiederverwendung vorläufiger
Definitionsbytes als angeblich finaler Export. Kategorie `voegel` aktuell prüfen.
Original ZIP/Handoff/Inventar nicht umschreiben. Bestehende Ablage-/Integrations-
Mergefreigabe gilt nach erfolgreichen Pflichtchecks; danach Authoring §9 separat.
Bis zur echten Endabnahme keine Registrierung oder Produktionsbereinigung.
