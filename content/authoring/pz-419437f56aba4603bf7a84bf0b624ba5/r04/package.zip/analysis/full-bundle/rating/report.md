# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: 97eeb11415b26b2bfc4b30aa0d4d9b43f69afd1fbf3bf3e76ef06af2d29b39f2
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 1 |
| search | 72/121 |
| workload | 1/4 |

Score: 893/484; level: 2 / 5.
Without workload: 193/121; level: 2.
Lower boundary: 1; distance: 409/484.
Upper boundary: 2; distance: 75/484.
Nearest boundary distance: 75/484.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
