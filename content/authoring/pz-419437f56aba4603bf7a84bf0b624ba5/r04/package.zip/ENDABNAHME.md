# Endabnahmevorlage · keine bereits erteilte Freigabe

Bitte das tatsächliche [Endraster](review/final-grid.png) mit dem
[Abschlussbild](images/reveal-a-r01.png) und [Bildvergleich](review/final-comparison.png)
beurteilen. Der [Bericht](report.md) enthält alle Pflichtprüfungen und Reduktionen.

Eine mögliche Erklärung nach eigener Prüfung lautet:

> Ich nehme Paket r04 für Huhn einschließlich Endraster Crop C / area-140 und
> unverändertem Abschlussbild A-r01 ab. Führe Standardauftrag 4 aus.

Dies ist ausschließlich eine Vorlage, keine tatsächliche Eigentümererklärung.
Die spätere separate Freigabe bindet die dann aus den Originaldateien ermittelten
Handoff-/Inventarhashes, Variante, Matrix-/Logikhash und Revealdatei/-hash.
Der Mensch muss die Hashes nicht abtippen. Der bisherige bedingte Mergeauftrag
ersetzt diese Endabnahme nicht. Kein Export oder Registrierung vor dieser Erklärung.
