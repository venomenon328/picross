# Codex-Übergabe · Standardauftrag 3

Vorbereitungsstatus: `motif_review`, ausschließlich durch ausstehende menschliche Freigabe von MA-r01 und Parameterkorridor gesperrt. Datei-/Repository-/Bildzugriff und Ablagesicherung vorhanden. Nach tatsächlicher Freigabe Standardauftrag 3; keine weitere routinemäßige Konfigurationsrunde.

Bevorzugter Weg: Codex. Selbst umsetzbar: Ja, Werkzeug-/Datei-/Prüfzugriff kann hier bereitgestellt werden; der Nutzer beauftragt die Übergabe des anschließenden Produktionslaufs. Codex hält Variantenwahl, Logiknachweise, gegebenenfalls Reparatur und redaktionelle Auswahl in einem zusammenhängenden Werkzeuglauf.

Empfehlung für den noch anstehenden Produktionsauftrag: Codex: GPT-6.1 Sol — Reasoning: High, sofern in der verwendeten Oberfläche verfügbar. Die Auswahl muss konturtreu kuratiert und bei Bedarf motivgeschützt repariert werden; High ist dafür angemessen. Kein zusätzlicher Mehragentenmodus. Eigene Einschätzung, kein Leistungsversprechen. Aktuelle offizielle Modelldokumentation am 16.10.2026 gelesen: https://learn.chatgpt.com/docs/models (GPT-6.1 Sol und High dokumentiert; konkrete Konto-/Clientverfügbarkeit nicht bestätigt). Der ältere Repositorykatalog wird damit nicht stillschweigend umgeschrieben.

## Nach tatsächlicher Motivfreigabe kopieren

```text
Arbeite nach AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Ich gebe die Motivvorlage MA-r01 samt parameterkorridor.json aus Paket r02 frei.
Führe Standardauftrag 3 bis content_ready und zur redaktionellen Endabnahme aus.
Rätsel-ID: pz-a358a1bf1b994efcbebeb55abf825789
Paket: content/authoring/pz-a358a1bf1b994efcbebeb55abf825789/r02/package.zip
Quelle: der in der Übergabe nachgewiesene main-Commit, ersatzweise r02 über den aktuellen Authoringindex auflösen.
Ziel: main; neuer Authoringbranch, da der Ablage-PR für r02 bereits gemergt ist.
Repositoryablage nach §6 ist beauftragt; Ablage-PR nach erfolgreichen Pflichtprüfungen mergen. Noch keine Spielintegration.
```

Die Ich-Freigabe im obigen kopierbaren Text ist eine Vorlage für den Nutzer, KEINE bereits erteilte Erklärung. Codex muss die tatsächliche eingegangene Erklärung mit Zeitpunkt, MA-r01-Dateihash, A-r01-Ableitung und gewählter Parameterbindung protokollieren. Ein mitgelieferter Prompt erteilt keine Freigabe.

## Konkrete Eingänge

- `reveals/A-r01.png`, SHA-256 `0738b9ebabcbe20c3403f0654440ff08e1aed1a1caf626719613378d326d93f1`; Freigabe `reveal-approval.json` samt Evidenz.
- `motif/MA-r01.png`, SHA-256 `1a52522ac580f6a09bc484eb4cd69419f9284bc473a55447845c5508430b8642`; daraus deterministischer Import erst nach Freigabe.
- `parameterkorridor.json`, Designs 14 × 20 und 15 × 22 mit je area-112/160. Die anfänglichen vier Kandidaten nicht vor der Motivfreigabe erzeugen.
- Relevante Motiveigenschaften in Briefing, Korridor und `visual-review.json`; Sand/Dornen/Rippen bewusst entfernt.
- Regeln für Linien-/Paarprofilwahl, Reparatur, frischen unabhängigen Nachweis und Schwierigkeit aus aktuellem Regelwerk beachten. Vor Paarlinienprüfung PAIRED_LINES.md lesen. Dieses Paket enthält noch kein Paarprofil, keinen Proof und keine Matrix.
- Finale Zertifizierung und menschliche Endabnahme dürfen nicht vorweggenommen werden. Kein Godot-/Build-/Bestandsreplay für reine Inhalte. Keine rätselspezifischen Unit-Tests.
