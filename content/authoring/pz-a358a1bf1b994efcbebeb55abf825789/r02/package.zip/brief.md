# Kaktus · Standardauftrag 2

ID `pz-a358a1bf1b994efcbebeb55abf825789`, Kategorie `blumen-pflanzen`. Nutzerwunsch ungefähr 15 × 20, monochrom; Abschlussbild immer farbig.
Quelle und Toolstand: venomenon328/picross@main `8171954ce4ff3694d09adb013176ac3f829c3e33`. Aktuelle Regeln vollständig aus dem Repository gebunden; Dokumentrevision 14 / Version 0.5.0.

Die tatsächliche menschliche Freigabe von A-r01 ist in `reveal-approval.json` datei- und hashgebunden. Aus genau diesen gespeicherten Bytes wurde mit einem nativen Bildedit die separate kontinuierliche Motivillustration MA-r01 erzeugt. Die aktuelle Vorlage ist noch nicht menschlich freigegeben.

Die Hauptsilhouette trägt die Identität. Mittelstamm, Armhöhen, gebogene Arme und beide Negativräume bleiben. Dornen, Areolen, Rippen, Grüntöne, Schattierung, Oberflächentexturen und Sand sind entfernt. Kein Topf hinzugefügt. Das Abschlussbild bleibt bytegleich. Feine Konturen und Tonunterschiede sind keine Zellwerte; die technische Normalisierung erfolgt erst nach Motivfreigabe.

Auswahl/Konfiguration: 14 × 20 empfohlen, 15 × 22 als zweite Produktionsgröße; 18 × 26 als gestalterischer Vergleich ohne Produktionsfreigabe. 15 × 20 würde bei der tatsächlichen schmalen Silhouette durch `contain` zwei vollständig leere Randspalten erzwingen und ist daher nicht als unveränderter Produktionsweg vorgesehen. 12 × 16 wäre noch gröber. Der vorgeschlagene Korridor bindet ausschließlich die zwei genannten Produktionsgrößen, eine Vordergrundfarbe plus Leer, area/contain und den konkreten Crop. Keine Streckung oder Randregel-Ausnahme.

Auftrag: Bildvergleich, Konfiguration, vollständige Codex-Übergabe und Repositoryablage einschließlich bedingtem Merge. Stopp bei `motif_review`; noch keine Matrix, Hinweise, Logikprüfung, Schwierigkeit, Reparatur oder Spielregistrierung.
