# Kaktus · Abschlussbildauswahl

## Tatsächlicher Auftrag

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Starte Standardauftrag 1: Abschlussbildauswahl.
Motiv: Kaktus
Rasterbreite × Rasterhöhe: 15 × 20 Zellen (ungefähr).
Rätselmodus (Abschlussbild immer farbig): monochrom.
Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.

## Briefing und Grenzen

Freie Interpretation (`free`), keine externe Bildreferenz. Kategorie `blumen-pflanzen` (Blumen & Pflanzen), prägender Hauptgegenstand Kaktus. Kleine hochformatige Komposition für ungefähr 15 × 20, später genau eine Vordergrundfarbe plus Leer. Die konkrete Matrix existiert noch nicht; keine Lösbarkeits- oder Schwierigkeitszusage.

Identitätskern: aufrechter sukkulenter Kaktuskörper mit charakteristischer Verzweigung beziehungsweise Gliederung und sichtbaren Dornen/Areolen im farbigen Abschlussbild. Jede angebotene Variante hat eigene Forminvarianten in `reveals.json`. Nach der Auswahl müssen konkrete Perspektive, Hauptproportionen und wesentliche Negativräume erhalten bleiben. Oberflächentexturen und feine Dornen dürfen in einer später separat freizugebenden Motivvorlage entfallen oder zusammengefasst werden.

Ruhige warme handgezeichnete 2D-Illustration mit deutlichen Konturen, kräftigen zusammenhängenden grünen Flächen, ausgearbeiteter Binnenzeichnung und zurückhaltender Schattierung. Ruhiger elfenbeinfarbener Hintergrund, keine Schrift oder Rahmendekoration. Die Illustration ist farbig und noch keine Abstraktion.

Beauftragt sind Auswahlbilder, dateigebundene Übergabe und Repositoryablage einschließlich bedingtem Merge des Ablage-PR. Keine menschliche Bild-, Motiv- oder Endfreigabe liegt vor. Kein Raster, keine Hinweise, keine Spielregistrierung und keine Veröffentlichung in dieser Phase.
