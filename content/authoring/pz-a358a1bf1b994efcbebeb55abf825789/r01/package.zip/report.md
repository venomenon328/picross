# Kaktus · r01 · reveal_review

Datum: 2026-10-16T08:00:22.503586+00:00. Regelwerk 0.5.0 / Dokumentrevision 14. Repository-/Toolcommit: `bdf22e5e226a058ce47d00cea59853ec2db01a8b`.

Drei farbige Einzeldateien A-r01, B-r01, C-r01 erzeugt und visuell geprüft. Native Bildfunktion `image_gen.imagegen`; vollständige tatsächliche Prompts und sichtbare Einstellungen in `prompts.json`. Original-PNG-Bytes unverändert aufbewahrt. Dateihashes, Größen und Bildmaße in `reveals.json` und `inventory.json`. Kein Kontaktblatt und keine doppelte Bildgalerie nötig.

Empfehlung: A-r01 (Armkaktus). Die beiden Arme mit offenen Zwischenräumen ergeben die deutlichste kleine Mono-Silhouette. B-r01 (Feigenkaktus) variiert die Gliederform, C-r01 (Säulenkaktus im Topf) die Gesamtkontur und Palette. Alle fünf vorgeschriebenen Bildkriterien mit Einzelbegründungen je Variante in `visual-review.json`; Abstraktionsrisiken sind dort ausdrücklich benannt.

Ziel: ungefähr 15 × 20 = 300 Zellen, monochrom. Rasterfarbzahl später genau eins plus Leer; nicht als verwendete Farbzahl gemeldet, da keine Matrix existiert. Kategorie Blumen & Pflanzen. Tatsächliche Rastermaße, Hinweise, Randregel, Solverprofil, deduktiver Nachweis, Eindeutigkeit, Endmatrix, Schwierigkeit, Reparatur und Zielintegration: noch nicht anwendbar. Keine Probespiele; in dieser Phase nicht erforderlich.

Abschlussbildfreigabe, Motivvorlage/-freigabe und Endabnahme: offen. Keine Auswahl oder Freigabe erfunden. Es gibt keine Rasterkandidaten und keine verworfenen Bilddateien. Nächster erlaubter Schritt ist Standardauftrag 2 nach ausdrücklicher Freigabe einer konkreten Bildrevision. Diese Ablage ist keine Runtime-Registrierung.

Paketprüfung: ZIP sicher neu öffnen; vollständige Dateimenge, Dateigrößen, SHA-256, identische Handoffkopie, unveränderter Regelwerksnapshot und Kollisionsfreiheit prüfen. Frühphase ist noch kein ZA-1-Eingang, daher keine Adapterzertifizierung behaupten. Für den reinen Inhaltspfad nur Pfad-/Dateimodusprüfung und `ci-required`; CI ist keine Inhaltsabnahme.
