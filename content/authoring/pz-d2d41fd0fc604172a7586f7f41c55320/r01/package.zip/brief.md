# Lemmy Kilmister · Abschlussbildauswahl

Standardauftrag 1, 28.10.2026. Wunsch: Rasterbreite offen, Rasterhöhe ungefähr 35 Zellen, Rätselmodus farbig, Farbzahl offen. Das Abschlussbild ist stets detailliert und farbig. Keine festen Maße oder freigegebene Rasterparameter vorhanden.

Prägender Hauptgegenstand ist die Person Lemmy Kilmister; Kategorie `menschen-berufe`. Der Bass in C ist ein Nebenobjekt. Arbeitsweise `free` auf Grundlage des Motivtexts ohne fremdes Ausgangsbild. Nach einer Bildfreigabe gilt genau deren gespeicherte Fassung als verbindliche Referenz.

Zu bewahrende Identitätsmerkmale: längliches reifes Gesicht, breiter schwarzer Westernhut, langes dunkles Haar, markante Backenbart-/Schnurrbartform mit freiem mittlerem Kinn, charakteristische Wangenmerkmale. A: frontale Büste und schwarzes Hemd. B: Dreiviertelansicht und bordeauxfarbenes Hemd. C: Halbfigur mit bernsteinfarbenem viersaitigem Bass, natürliche Arm-/Handhaltung und diagonaler Instrumentenhals.

Gestalterischer Rahmen: warme handgezeichnete 2D-Illustration, deutliche Konturen, ruhige kräftige Farbflächen, ausgearbeitete Binnenzeichnung und zurückhaltende Schattierung, echter transparenter PNG-Bildgrund. Keine Schrift oder Rasterdarstellung.

Erlaubt sind zunächst freie Kompositionen und Stilkorrekturen innerhalb dieses Motivs. Noch keine Abschlussbildauswahl, keine menschliche Bildfreigabe, keine Motivvorlage und kein Lösungsraster. Rasterkonfiguration und Palette werden nach Bildfreigabe in Auftrag 2 verglichen.

Beauftragte Sicherung: Paket, Handoffkopie, Record und Index gemäß §6; Ablage-PR nach erfolgreichen Pflichtprüfungen mergen. Der natürliche Haltepunkt ist die ausdrücklich vom Menschen zu erteilende Abschlussbildfreigabe. Die Ablagesicherung nimmt keine spätere Bild-, Motiv- oder Endfreigabe vorweg.
