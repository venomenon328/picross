# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: cc988d10b90224b77205256b1aad4cd6b6a538aa98422cd819cd5914eca56c1a
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 411/188 |
| search | 176777/171680 |
| workload | 1/4 |

Score: 27965879/8068960; level: 4 / 5.
Without workload: 25948639/8068960; level: 4.
Lower boundary: 3; distance: 3758999/8068960.
Upper boundary: 4; distance: 4309961/8068960.
Nearest boundary distance: 3758999/8068960.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
