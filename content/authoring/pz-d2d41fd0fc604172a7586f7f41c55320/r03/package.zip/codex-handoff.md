# Codex-Übergabe · nach menschlicher Motivfreigabe

Dies ist eine Arbeitsübergabe, keine bereits erteilte Motivfreigabe. Vor Auftrag 3 muss die tatsächliche Nutzererklärung M-r02 und den Korridor binden. Bild-/Paketdateien sind verfügbar; keinen erneuten Upload verlangen.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Lade für pz-d2d41fd0fc604172a7586f7f41c55320 die Revision r03 über content/authoring/index.json und prüfe Record, ZIP, Handoff und Inventar.
Die Abschlussbildfreigabe gilt ausschließlich B-r01. Motivvorlage M-r02: images/motif-m-r02.png, SHA-256 6dd7d0fd08c5155c77d36f0f593537fcf8c120dda000f6a9cec6740b8b629400.
Nach ausdrücklicher menschlicher Freigabe von M-r02 samt configuration.json führe Standardauftrag 3 bis content_ready aus. Empfehlung 33×35, farbig, drei Vordergrundfarben; zulässige Paare 32×34, 33×35, 34×36, 35×37; area, contain, voller Crop [0, 0, 1222, 1287]. Keine andere Pose oder Abschlussbildfassung einsetzen.
Beide Bilddateien, Herkunft und tatsächliche Freigaben übernehmen. Vier gezielte Kandidaten sowie alle technischen/redaktionellen Pflichtprüfungen gemäß aktuellem Workflow; keine Spielregistrierung. Neue Revision nach §6 sichern. Befugnisse für Ablage/PR/Merge aus dem dann aktuellen Nutzerauftrag übernehmen.
```
