# Lemmy Kilmister · r03 · motif_review

28.10.2026 · `pz-d2d41fd0fc604172a7586f7f41c55320` · Authoring 0.5.0 / Dokumentrevision 23 · Quellen-/Toolcommit `7f676557ad507f2bc6b14508ee9df84d2f9c39fa`. Inventar-Dateihash im Handoff und äußeren Record.

**Abschlussbildfreigabe vorhanden:** Nutzer wählt ausdrücklich B-r01 (`d55d58cf043788e9e7b343921871acc3ab3111b3f3a0d082d092bd2449e9ecad`). Die ursprüngliche Fassung ist im von r02 referenzierten Quellenpaket r01 gespeichert und wird bytegleich übernommen; B-r02 wird nicht stillschweigend ersetzt. Tatsächlicher Wortlaut, Akteur, Protokollierungszeit und Dateibindung: `approvals/`. Der historische realistischere Stilbefund bleibt unverändert erhalten.

**Vorgelegt:** Motivvorlage M-r02 (`6dd7d0fd08c5155c77d36f0f593537fcf8c120dda000f6a9cec6740b8b629400`), originalgetreu aus diesen gespeicherten B-r01-Bytes abgeleitet. Gleiche Dreiviertelansicht, Hut/Haar, Gesicht und Backenbart mit freiem Kinn, Bordeauxhemd und Transparenz. Verloren gehen feine Haut-/Haartextur, Stickerei, Paspeln, Kettenglieder und Metallweiß als eigener Ton. Zwei native Bildaufrufe; eine gezielte Kinn-/Haarkorrektur, M-r01 als Editquelle erhalten. Aktive Menschenzeit nicht erfasst.

**Empfehlung:** 33×35 = 1155 Zellen, farbig, drei Vordergrundfarben: Dunkel für Hut/Haar/Bart/Konturen, Haut für Gesicht/Hals und helle Akzente, Bordeaux für das von Haar getrennte Hemd. Reduzierte Alternative: 33×35 mit zwei Farben (Hemd und Haar verschmelzen). Größere Alternative: 38×40 mit drei Farben, mehr Detailraum und rund 32 Prozent mehr Zellen. Motivtreue, Darstellbarkeit, ungeprüftes Logikrisiko und Spielgefühl sind in `configuration.json` getrennt verglichen.

**Vorgeschlagener Freigabekorridor:** genau 32×34, 33×35, 34×36 oder 35×37; color, drei Vordergrundfarben, `area`, `contain`, voller Crop `[0, 0, 1222, 1287]`. Keine Streckung/Poseänderung, keine neue Farbe oder andere Abschlussbildfassung. K2/K3 sind Vergleichsalternativen und nicht automatisch Teil dieses Korridors.

**Prüfung:** Dateibindungen/PNG/RGBA/Alpha/Ressourcengrenzen und Herkunft geprüft; fünf Gestaltungskriterien M-r02 erfüllt, Vergleich groß auf Originalpapier und bei 140 px Bildhöhe gesichtet. Belege in `review/`. Noch keine Matrix: tatsächliche Farbzahl, Hinweise, Randregel, Solver/Verifier, Endmatrixgleichheit und Schwierigkeit bleiben offen/nicht anwendbar. Keine Raster-/Reparaturrunde oder Zeitprognose. Kein Zieladapterexport, keine ZA-1-Zertifizierung und keine Spielregistrierung.

**Offen:** menschliche Motivfreigabe von M-r02 samt Korridor und spätere Endabnahme. Nächster Auftrag: **3 · Motiv freigeben & produzieren**. Beide Bilddateien, Abschlussbildfreigabe, Invarianten, Konfiguration und `codex-handoff.md` liegen vor. Die beauftragte §6-Ablage samt bedingtem PR-Merge nimmt diese Freigabe nicht vorweg.
