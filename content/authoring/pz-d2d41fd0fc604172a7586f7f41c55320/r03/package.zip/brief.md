# Lemmy Kilmister · Auftrag 2 · r03

Neue tatsächliche Abschlussbildfreigabe: B-r01, `d55d58cf043788e9e7b343921871acc3ab3111b3f3a0d082d092bd2449e9ecad`. Die ausdrücklich benannte ursprüngliche Bildfassung ist über r02 mit dem Quellenpaket r01 verbunden und wird hier bytegleich mitgeführt. B-r02 wird nicht stillschweigend eingesetzt. Originalpakete/Freigabestände bleiben unverändert.

Nutzerwunsch: Breite offen, Höhe ungefähr 35 Zellen, Rätselmodus farbig, Rasterfarbzahl offen. Kategorie `menschen-berufe`, prägender Gegenstand ist die Person. Empfehlung: 33×35 mit drei Vordergrundfarben; Variantenvergleich und genaue vorgeschlagene Importparameter in `configuration.json`.

Arbeitsweise der Motivvorlage `faithful`: Identität, Dreiviertelperspektive, Kopf-/Gesichtsproportionen, Hut, Haar, Backenbart mit freiem Kinn, Wangenmerkmale, offener Kragen und Bordeauxhemd bewahren. Zulässige Detailverluste und Invarianten in `invariants.json` und `decisions.json`. Der frühere realistischere Stilbefund des Originals bleibt historisch dokumentiert.

Die native Abstraktion M-r02 ist eine gespeicherte kontinuierliche Illustration, kein Zellraster. Sie ist mit `6dd7d0fd08c5155c77d36f0f593537fcf8c120dda000f6a9cec6740b8b629400` an B-r01 gebunden. Menschenfreigabe dieser Motivdatei und des vorgeschlagenen Korridors ist noch offen. Nur Auftrag 2 samt §6-Ablage und bedingtem Ablage-PR-Merge ist beauftragt; keine Rasterproduktion oder Spielregistrierung.
