# Pentagramm · Abschlussbildauswahl

Auftrag: Standardauftrag 1 nach PUZZLE_AUTHORING 0.5.0, Dokumentrevision 23.
Motiv: Pentagramm. Rasterbreite offen, Höhe ungefähr 20 Zellen. Monochrom;
das Abschlussbild bleibt farbig. Repositoryablage nach §6 und Ablagemerge nach
bestandenen Pflichtprüfungen sind ausdrücklich beauftragt.

Kategorie: mythen-fantasie (Mythen & Fantasie). Hauptgegenstand ist das Symbol,
kein allgemeines Schmuckstück. Kein Fremdbild, keine bindende Referenz.
Arbeitsweise für die erstmalige Motivgestaltung: free. Danach bildet erst das
menschlich freigegebene Abschlussbild die verbindliche Referenz.

Gestaltungsannahme: aufrechtes Pentagramm mit genau fünf Spitzen, einer nach oben,
fünf durchgehenden sich kreuzenden Bändern und offenem zentralem Fünfeck.
A ohne Kreis; B/C mit jeweils einem motivisch begründeten Kreis. Dieser Kreis
gehört zum angebotenen Gegenstand und ist kein Randrahmen zur Logikverbesserung.
Keine Schrift, Zusatzsymbole, Kerzen, Schädel oder weitere Requisiten.

Drei ausgearbeitete farbige 2D-Illustrationen, tatsächlich freigestellt mit Alpha.
Für die spätere Abstraktion Hauptgeometrie, Orientierung, Kreuzungen, fünf Spitzen
und charakteristische Negativflächen erhalten. Oberflächentextur und feine
Lichtkanten können später entfallen. Die Breite wird erst in Auftrag 2 empfohlen.
Vor menschlicher Bildfreigabe keine Motivvorlage, Matrix oder Hinweise erzeugen.
