# Vorlage für Standardauftrag 3

Erst nach tatsächlicher Sichtprüfung und ausdrücklicher Motiv-/Korridorfreigabe durch den Nutzer senden. Dieser gespeicherte Text ist keine bereits erteilte Freigabe. Den erreichbaren r02-Paketstand über den aktuellen Index auflösen.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Ich gebe die Motivvorlage MA-r01 frei: motif/MA-r01.png, SHA-256 6f6ec5ec68b7c039296566b6dfd4a5f39c5b6a0dd24f203abc2bd107f11c0cb0, abgeleitet aus dem bereits freigegebenen Abschlussbild B-r01, SHA-256 7754db5a3214634db0eb41a4cbb5ed8496b2cce812fc0ec9ae2102d017a388f2.
Rätsel-ID: pz-51405ea1ad194507a60c9b6701d802f0. Paketrevision: r02. Paket: content/authoring/pz-51405ea1ad194507a60c9b6701d802f0/r02/package.zip. Lade den aktuellen Index und prüfe Paket, Inventar, tatsächliche Bilder sowie reveal-approval.json.
Ich bestätige den in parameters.json vorgeschlagenen Korridor: empfohlen 30×25, zulässig 28×23 oder 30×25; monochrom, genau 1 Vordergrundfarbe ohne Leer. Nur äußeren Leerraum beschneiden, keine Streckung; große Henkelöffnung, Knopftrennung, Korpusproportionen und linker Ausguss erhalten. Die in parameters.json benannten Oberflächendetails dürfen entfallen.
Führe Standardauftrag 3 bis content_ready und zur redaktionellen Endabnahme aus. Nutze den gespeicherten Vier-Kandidatenplan, aktuelle Profilwahl und nötigenfalls begrenzte motivgeschützte Reparatur gemäß Regelwerk. Keine Spielregistrierung vor gesonderter Endabnahme.
Repositoryablage nach §6 ist beauftragt. Ablage-PR nach erfolgreichen Pflichtprüfungen mergen.
```
