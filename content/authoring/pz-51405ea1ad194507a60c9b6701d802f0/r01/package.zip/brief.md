# Japanische Teekanne – Abschlussbildauswahl

Auftrag: Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main. Starte Standardauftrag 1: Abschlussbildauswahl. Motiv: Japanische Teekanne. Rasterbreite × Rasterhöhe: 30 × 20 Zellen (ungefähr). Rätselmodus (Abschlussbild immer farbig): monochrom. Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.

ID: pz-51405ea1ad194507a60c9b6701d802f0; Paketrevision: r01; Status: reveal_review.
Quellsnapshot: c93b4075ae3df2ec8053d74182d310c129bf3e80; Regelwerk 0.5.0, Dokumentrevision 14.
Kategorie: haushalt-alltag / Haushalt & Alltag, weil ein Gebrauchsgefäß der Hauptgegenstand ist.
Rasterwunsch: 30 Zellen breit × 20 hoch, ungefähr; monochrom (genau eine Vordergrundfarbe plus Leer). Keine Zellmatrix vorhanden.
Abschlussbilder immer farbig und detailliert. Freie Motivübertragung (free), keine bindende Bildreferenz vorhanden.

Unverzichtbar: eine japanische Teekanne, Korpus, Deckel mit Knopf, Ausguss, plausibel verbundener Griff/Henkel und dessen wichtige Negativräume. Keine Tassen, Schrift, Szene oder Dekoration als Füllmaterial.
Erlaubt: in der Auswahl unterschiedliche Kannenbauformen, Perspektive und Materialfarbe. Nach einer Freigabe werden genau deren Perspektive, Hauptproportionen, Silhouette, Ausguss-/Griffrichtung und wichtige Innenräume verbindlich; die feinen Oberflächendetails dürfen bei der späteren Abstraktion reduziert werden.

Nutzungsgrundlage: drei neue native Bildgenerierungen innerhalb dieses beauftragten Projekts, ohne externe Referenzbilder, Marken oder übernommene Fremdassets. Keine Garantie von Exklusivität oder eigenständiger urheberrechtlicher Schutzfähigkeit behauptet. Herkunft und tatsächlich übermittelte Prompts stehen in generation.json.

Autorisierung: Standardauftrag 1: Abschlussbildauswahl; Repositoryablage nach §6. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen. Keine Abschlussbild-, Motiv- oder Endfreigabe erteilt.
Die Ablagefreigabe ist keine Bild-, Motiv- oder Endabnahme. Vor Standardauftrag 2 ist eine konkrete ausdrückliche Abschlussbildfreigabe erforderlich.
