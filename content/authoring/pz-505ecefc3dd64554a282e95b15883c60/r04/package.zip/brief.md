# Essstäbchen · MA-r02 · r04

`pz-505ecefc3dd64554a282e95b15883c60` · Kategorie `haushalt-alltag` · Quellen-/Toolstand `f7196e2213e042c0d224248780260b3c218e9395`.
Revisionsauftrag: „Erstelle eine neue Motivvorlage MA-r02, Dimensionen maximal 30x30.“ Die Größenbegrenzung bezeichnet das spätere Zellraster (beide Achsen <=30); die gespeicherte Motivillustration bleibt für den bestehenden Bildimport hochaufgelöst (1254x1254 RGBA).

C-r01 bleibt ausdrücklich freigegeben und bytegleich. MA-r02 wurde nativ bildgebunden über eine gespeicherte erste Fassung erzeugt. Nach kaum verändertem Abstand im ersten Versuch erweitert ein gezielter zweiter Aufruf den durchgehenden Zwischenraum sichtbar. Genau zwei Stäbchen, diagonale Richtung, Längsversatz, Verjüngung und gerundete Griff-/Essenden bleiben erhalten; seitliche Trennung ist bewusst stärker als im Abschlussbild. Holzfarbe, Maserung, Glanz, Facetten und Rillen bleiben nur im Abschlussbild.

Die frühere Motivfreigabe MA-r01 und die r03-Fehlversuche bleiben historisch; sie gelten nicht als Freigabe/Zertifikat der neuen Datei. Vorschlag: 30x30, alternativ 25x25, mono genau eine Vordergrundfarbe ohne Leer, area, contain, gebundener neuer Crop. Keine Produktion oder Lösbarkeitszusage vor der tatsächlichen neuen Motiv-/Parameterfreigabe. 3 · Motiv freigeben & produzieren: konkrete motifs/MA-r02.png · MA-r02 samt parameters.json (maximal 30 je Achse; 30x30 empfohlen, 25x25 Alternative; mono genau 1, area, contain, Crop [30,42,1239,1219]) menschlich freigeben. Erst danach neue Rasterproduktion.
