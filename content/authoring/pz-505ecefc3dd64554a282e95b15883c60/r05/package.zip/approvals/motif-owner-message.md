# Tatsächlicher Auftrag 3 für MA-r02

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.

Paket: content/authoring/pz-505ecefc3dd64554a282e95b15883c60/r04/package.zip · r04.
Ich gebe die Motivvorlage motifs/MA-r02.png · MA-r02 frei; Parameter: Maximal 30 je Achse; 30×30 empfohlen, alternativ 25×25; mono, genau 1 Vordergrundfarbe; area, contain; Crop [30,42,1239,1219]; Freigabe offen.. Führe Standardauftrag 3 vollständig bis zur Endabnahmevorlage aus.
Farbanzahl: 1 (Genau, ohne Leer).
Quellbranch / Commit: 1260578fde94fc7bee14efe4b6636061d36238c7.

Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.
