# Tatsächlicher Revisionsauftrag

Erstelle eine neue Motivvorlage MA-r02, Dimensionen maximal 30x30.

Dies ist ein Herstellungsauftrag, keine Freigabe der erst danach erzeugten MA-r02. Bereits erteilte Repositoryablage-/Mergebefugnis aus Auftrag 3 gilt weiter.
