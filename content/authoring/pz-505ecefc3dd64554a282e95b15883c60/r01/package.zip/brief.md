# Essstäbchen · Abschlussbildauswahl

ID: `pz-505ecefc3dd64554a282e95b15883c60` · Paket `r01` · Kategorie `haushalt-alltag` (Haushalt & Alltag).

Auftrag: Standardauftrag 1; drei farbige, detaillierte Abschlussbilder für ein später monochromes Rätsel. Größe offen; Mono bedeutet genau eine Vordergrundfarbe ohne Leer. Keine Rastergröße oder Schwierigkeit vorab festgelegt. Freie Motivübertragung aus Text, keine bindende Bildreferenz.

Unverzichtbar: genau zwei als Essbesteck erkennbare lange Stäbchen mit kräftigeren stumpfen Griffenden und sich verjüngenden Essenden; beide vollständig sichtbar. Lage und wichtige Negativräume der später ausgewählten Fassung bewahren. Holz-/Bambuszeichnung und Lackdetails dienen dem Abschlussbild; später gezielt reduzieren. Keine Hände, Speisen, Schüsseln, Schrift oder Zusatzobjekte.

Gemeinsamer Stil: warme ausgearbeitete handgezeichnete 2D-Illustration, klare geführte Konturen, zusammenhängende Farben und zurückhaltende Schattierung. Echter transparenter Außenraum und transparente Zwischenräume. Keine bereits erzeugte Motivvorlage, Matrix oder Hinweise.

Varianten: A-r01 honigfarbener Bambus schräg nebeneinander; B-r01 roter Lack mit goldfarbenen Ringen, als X gekreuzt; C-r01 dunkles Walnussholz als versetztes Paar. B hat die markanteste Silhouette, ist aber noch nicht gewählt oder freigegeben.

Nutzungsgrundlage und tatsächliche Prompts: `sources.json`, `prompts.json`. Bildfunktion: integrierte native image_gen.imagegen; drei Aufrufe, keine direkte Modell-API. Unbekannte Einstellungen sind ausdrücklich `not_exposed`.

2 · Bild freigeben & abstrahieren: Mensch wählt und genehmigt reveals/A-r01.png, reveals/B-r01.png oder reveals/C-r01.png ausdrücklich. Erst danach Standardauftrag 2; keine Abstraktion oder Rasterproduktion vorwegnehmen.
