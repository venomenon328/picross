# Essstäbchen · Motivvorlage MA-r01

`pz-505ecefc3dd64554a282e95b15883c60` · Paket r02 · Kategorie Haushalt & Alltag (`haushalt-alltag`). Quelle: main `f76b13e3d8124991cf418c4ea6ad576810f7dc76`. Regelwerk 0.5.0 / Dokumentrevision 22.

Der Nutzer hat C-r01 aus Paket r01 ausdrücklich freigegeben und Standardauftrag 2 sowie Ablage-Merge beauftragt. Das farbige transparente Original liegt bytegleich unter `reveals/C-r01.png`; tatsächliche Erklärung und Bildhash in `approvals/reveal-C-r01.json`. Die neue Motivvorlage `motifs/MA-r01.png` ist nativ aus diesen Bildbytes abstrahiert; keine Matrix oder Hinweise erzeugt.

Empfehlung 30×30, zulässige vorgeschlagene Alternativen 25×25 / 35×35, jeweils quadratisch und monochrom mit genau 1 Vordergrundfarbe ohne Leer. Vollständiger noch freizugebender Korridor samt Crop, Schwellen und Invarianten: `parameters.json`. Designs sind gültige vorbereitete Werkzeugeingaben, noch nicht ausgeführt.

Identitätskern: genau zwei getrennte durchgehende Stäbchen, keine Kreuzung; dicke gerundete Griffe links unten und verjüngte Essenden rechts oben; Versatz, diagonale Lage und offener Zwischenraum. Farbe, Maserung, Glanz, feine Rillen und perspektivische Stirnflächen entfallen in der Vorlage. Transparenz und Originalbild bleiben erhalten.

Menschliche Motivfreigabe und Parameterannahme sind offen. Rasterproduktion und technische Prüfung erst nach dieser tatsächlichen Freigabe. Dünne Diagonalen sind logisch riskant; keine Lösbarkeitszusage. Kein Wechsel zu gekreuzten Stäbchen oder zusätzlichen Objekten ohne erneute Freigabe.
