# Zusätzliche Nutzervorgabe

Die bisherige Diagonallage beibehalten.

Antwort auf optionale Frage nach flacherer Lage. Alle gelieferten Kandidaten behalten die bisherige Diagonallage bei; kein Entwurf mit neuer Pose produziert.
