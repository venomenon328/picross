# Tatsächlicher Standardauftrag 3 für MA-r03

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.

Paket: content/authoring/pz-505ecefc3dd64554a282e95b15883c60/r06/package.zip · r06.
Ich gebe die Motivvorlage motifs/MA-r03.png · MA-r03 frei; Parameter: Maximal 30 je Achse; 30×30 empfohlen, alternativ 25×25; mono, genau 1 Vordergrundfarbe; area, contain; Crop [23,42,1240,1221]; Schwellen 160/224. Freigabe offen.. Führe Standardauftrag 3 vollständig bis zur Endabnahmevorlage aus.
Farbanzahl: 1 (Genau, ohne Leer).
Quellbranch / Commit: 63c803fd0e7b06c2ee90690ab0ab607df47451c0.

Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.
