# Tatsächlicher Rasterkorrekturauftrag

Korrigiere das Raster und erzeuge Kandidaten mit einer eindeutigen Lösung.
