# Tatsächlicher Revisionsauftrag

Überarbeite die Motivabstraktion.

Bezieht sich auf den r05-Blocker und MA-r02; neuer Bildherstellungsauftrag, keine Freigabe der erst danach erzeugten MA-r03. Maximal 30 je Achse sowie mono genau eine Vordergrundfarbe werden beibehalten. Bestehende Repositoryablage-/Mergebeauftragung gilt fort.
