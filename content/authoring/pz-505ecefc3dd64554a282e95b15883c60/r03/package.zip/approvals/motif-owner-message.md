# Tatsächlicher Auftrag 3

Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.

Paket: content/authoring/pz-505ecefc3dd64554a282e95b15883c60/r02/package.zip · r02.
Ich gebe die Motivvorlage motifs/MA-r01.png · MA-r01 frei; Parameter: parameters.json: 25×25, 30×30 empfohlen oder 35×35; mono, genau 1 Vordergrundfarbe; area, contain, gebundener Crop; noch nicht freigegeben. Führe Standardauftrag 3 vollständig bis zur Endabnahmevorlage aus.
Farbanzahl: 1 (Genau, ohne Leer).
Quellbranch / Commit: f54727828b3e0af380a3887b822a965f38e1f822.

Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen.
