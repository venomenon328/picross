# Wiederaufnahme Buntspecht

Zuerst Repositoryindex und AGENTS.md lesen. Paket r03/pz-9a79befc7a834e2d9d5896a477328962; Source 67ee204b35a0c5e82ca06a072998cecd25497164. Original-MA-r01 freigegeben, vier Direktimporte vollständig zertifiziert aber visuell verworfen. Neue MA-r02 benötigt echte Freigabe samt parameterkorridor.json. Ohne diese keine Rasterproduktion. A-r01 bleibt unverändert. Keine Endauswahl/Endabnahme, keine Registrierung. Nach Freigabe Standardauftrag3 vollständig mit vier gezielten Kandidaten fortsetzen; bisherige Belege nicht umetikettieren.
