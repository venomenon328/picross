# Buntspecht · Motivvorlage

pz-9a79befc7a834e2d9d5896a477328962 · r02 · motif_review · 2026-10-16T09:21:48.559097+00:00

## Auftrag und Bindung

Standardauftrag 2 bis Motivvorlage samt Konfiguration und Codex-Übergabe.
Ausgangspaket r01 aus main / 3b78d29f5eeefacef1bf49cce2079b67d0a75304; A-r01 ausdrücklich durch Tobias freigegeben.
Freigabe im Originalwortlaut und mit Nachrichtenzeit in user-reveal-approval.md;
reveal-approval.json bindet die tatsächlichen unveränderten Bildbytes.
Kategorie Vögel (voegel). Wunsch: Breite offen × Höhe ungefähr 30, farbig, Farbzahl offen.
Die Quellenprüfung bestätigt unveränderte Pflichtquellen seit Auftrag 1.

## Motivinvarianten

- Ein vollständiger Buntspecht in aufrechter linker Seitenansicht; Schnabel zeigt links.
- Schwarze Kopfkappe, roter Nackenfleck, helle Wange mit schwarzer Bartzeichnung.
- Große helle Schulterfläche, dunkler gefalteter Flügel mit gruppierten hellen Bändern.
- Helle Brust, rote Unterschwanzpartie, langer nach unten gerichteter Stützschwanz.
- Brauner senkrechter Stamm rechts; zwei Füße greifen an denselben ungefähren Höhen.
- Bildaufbau 2:3, keine Spiegelung, keine neuen Objekte, keine Vogelteile abschneiden.

## Ableitung und vorgeschlagene Parameter

Ein nativer Bildbearbeitungsaufruf mit den gespeicherten A-r01-Bytes als Referenz.
MA-r01 ist eine eigene, noch nicht freigegebene Illustration; Original nicht geändert.
Empfehlung 20×30 mit vier Vordergrundfarben: dark/ivory/red/wood plus Leer.
Reduzierte Dreifarbalternative sowie größere Konfiguration verglichen, siehe decisions.json.
Parameterkorridor erlaubt 20×30 und 22×33 sowie zwei vorab definierte Vierfarbzuordnungen;
keine Spiegelung, kein Crop, keine Streckung. Vier gezielte vorbereitete Entwürfe,
noch keine Importe. Identische Matrizen später erkennen und nicht doppelt zählen.
Bloße Schwellenvarianten werden bei Farbe ausdrücklich nicht als Varianten benutzt.

## Nutzungsgrundlage und Befugnis

Native im Nutzerauftrag erzeugte Projektillustration ohne externe Bildreferenz oder übernommene Fremdassets; ursprüngliche PNG-Bytes erhalten. Keine Exklusivität zugesichert.
Repositoryablage nach §6 und Ablagemerge nach erfolgreichen Pflichtprüfungen beauftragt.
Keine Produktion vor echter Motivfreigabe, keine Endabnahme oder Runtimeintegration.
Nächster Schritt: 3 · Motiv freigeben & produzieren.
