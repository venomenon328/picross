# Buntspecht · Abschlussbildauswahl

ID: pz-9a79befc7a834e2d9d5896a477328962 · Revision r01 · Status reveal_review · 2026-10-16T09:05:07.736579+00:00

## Auftrag

Motiv: Buntspecht. Rasterbreite offen × Rasterhöhe ungefähr 30 Zellen; farbig.
Vordergrundfarbzahl offen. Abschlussbild immer farbig. Kategorie Vögel (`voegel`).
Arbeitsweise free: originäre Interpretation des Motivtextes ohne Bildreferenz.
Nach Auswahl ist die konkrete freigegebene Bilddatei für die folgende Ableitung bindend.

## Identitätskern und Grenzen

Ein einzelner Buntspecht mit kräftigem geradem Meißelschnabel, schwarzer Kopfkappe,
heller Wange, schwarzer Bartzeichnung, großen hellen Schulterflächen, schwarz-weiß
gemustertem Flügel, rotem Unterschwanz und langem Stützschwanz. Als reversible
Gestaltungsentscheidung erwachsenes Männchen mit rotem Nackenfleck gewählt.
Pose und minimale Sitz-/Kletterhilfe variieren; Stamm/Ast bleiben Nebenobjekte.
Ruhiger heller Hintergrund, warme ausgearbeitete 2D-Illustration, keine Schrift.
Feather- und Rindendetails dürfen bei der späteren Abstraktion zusammengefasst werden;
Identität, Pose und charakteristische Farbverteilung des ausgewählten Bilds erhalten.
Noch keine Parameterbestätigung, Motivvorlage, Raster, Hinweise oder Solverprüfung.

## Herkunft und Nutzungsgrundlage

Originale native Bildgenerierung aus dem Nutzerauftrag in dieser Sitzung; keine
externen Fotos, Vorlagen oder Fremdassets übernommen. Prompts und Original-PNG-Bytes
samt Hashes liegen bei. Nutzungsgrundlage: im Auftrag generierte eigene Projektassets;
keine Exklusivität oder gesonderte juristische Schutzfähigkeit zugesichert.

## Befugnis

Standardauftrag 1: Abschlussbildauswahl. Repositoryablage nach §6 einschließlich Commit, Push und PR; Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen. Keine menschliche Bild-, Motiv- oder Endfreigabe erteilt; keine Runtimeintegration in dieser Phase.

Nächster erlaubter Schritt: 2 · Bild freigeben & abstrahieren, nach ausdrücklicher Freigabe einer Datei.
