# Buntspecht · Wiederaufnahme r04

AGENTS.md/Index lesen, Source dcbccc725197bb8ec0a5eebba4d48ac229053401. Tatsächliche MA-r02-Freigabe und Nutzervorgabe maximal25×35 erhalten. Sechs MA-r02-Kandidaten logisch vollständig zertifiziert, visuell verworfen. Neue MA-r03 benötigt Freigabe samt parameterkorridor-MA-r03.json (22×33 exact und23×35 contain, zwei bestehende Paletten, voller Crop). Keine MA-r03-Raster vor dieser Freigabe. A-r01 bleibt unverändert. Nach Freigabe Standardauftrag3 vollständig fortsetzen. Kein30×45/32×48, keine Endabnahme/Registrierung erfinden.
