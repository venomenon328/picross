# Buntspecht · Produktionsbericht r04

pz-9a79befc7a834e2d9d5896a477328962 · r04 · blocked · 16.10.2026
Regelwerk 0.5.0 / Dokumentrevision14; Quell-/Toolcommit dcbccc725197bb8ec0a5eebba4d48ac229053401. Inventar-Dateihash im Handoff und äußeren Record.

A-r01-Freigabe: reveal-approval.json. Tatsächliche MA-r02-Freigabe: motif-approval-MA-r02.json; Bildhash 6356b73f4bdb80445ad621d61e45b160cd0eee0025093d9abac3184f3bd1fb53. Freigegebener Korridor parameterkorridor.json, 20×30/22×33, je zwei Vierfarbpaletten. Endabnahme offen.

Vier neue, verschiedene Raster: 20×30 standard/light-feathers, je116 Proofschritte, 332/334 gefüllt von600; 22×33 standard/light-feathers, je131 Schritte, 399/401 gefüllt von726. Wunschfarbzahl offen, Istzahl jeweils4. dark für Gefieder/Auge/Schnabel/Füße, ivory für Wange/Brust/Schulter/Bänder, red für Nacken/Unterschwanz, wood für Stamm. Farbrollen im Raster nicht ausreichend erhalten. Echte Raster/Proofs in production-r04/, Übersicht candidate-comparison-r04.png, unverändertes Abschlussbild reveal/A-r01.png.

Produktmaße, Randregel (right/top/bottom), Quelle→Normalisierung→Matrix→Hinweise, full-line-color-Deduktion aus unbekanntem Start und frische unabhängige Prüfung samt exaktem Endmatrixvergleich: alle vier bestanden; production-audit-r04.json. Vollständige Deduktion belegt Eindeutigkeit, keine Suchdiagnose/Paarprüfung erforderlich. Keine Matrixduplikate. Belegung55–56%; leere Innenspalte2 dient Motivfreiraum neben Schnabel und Stamm. Einzelzellen nur im konkreten Motivkontext bewertet, keine harte Warnschwellenabweichung.

Visuell keiner angenommen: MA-r02 behebt den fehlenden roten Nackenfleck, Auge/Kopfkappe gehen aber weiterhin verloren und wood ersetzt dunkle Flügelzwischenflächen. visual-review.json/decisions.json. Keine Logikreparatur: alle solved; Hauptmerkmale brauchen gemäß §4.4 eine andere Abstraktion/Größe/Palette. RP-5 würde bereits bei zertifizierter Referenz stoppen; keine freie manuelle Matrixkorrektur ohne eigene Autorisierung. Nach zwei Bildrunden jetzt anderer Plan: unveränderte MA-r02 bei30×45/32×48 (1350/1536 Zellen), gleiche vier Farben. Reale Verbesserung noch nicht nachgewiesen. Keine größeren Raster vor echter Freigabe des erweiterten Korridors.

Schwierigkeit noch nicht bewertet: keine angenommene Endauswahl, Profil allein belegt keine R0–R3-Notwendigkeit. Umfang oben; Lösungszeit nicht geschätzt. Probespiel optional/nicht durchgeführt. Diese Phase4 Imports/4 frische Rekonstruktionen, insgesamt8/8; keine neuen Bildaufrufe, aktive Menschenzeit nicht erfasst. Vorherige vollständige Nachweise erhalten, frühere Entscheidungen präzise an r03/dcbccc725197bb8ec0a5eebba4d48ac229053401 gebunden.

ZA-1 inspect/export nicht anwendbar: kein content_ready-Kandidat. Keine Runtimeintegration, nativen Spieltests oder Spielerbuilds. Geschriebenes ZIP auf Hashes/Inventar/CRC/Handoffkopie prüfen; schlanke Pflicht-CI vor Ablagemerge. Nächster Schritt: 3 · Motiv freigeben & produzieren — MA-r02 bleibt freigegeben, Erweiterung auf30×45/32×48 muss bestätigt werden.
