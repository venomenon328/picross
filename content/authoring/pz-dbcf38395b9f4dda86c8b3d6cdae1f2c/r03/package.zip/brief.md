# Chicken Adobo · Korrekturvorlage r03

`pz-dbcf38395b9f4dda86c8b3d6cdae1f2c` · Quelle/Werkzeug `c4bc5b4e0d023e4981198c2a9ce050774dedcc6d` · Kategorie `gerichte-herzhaftes`.

Standardauftrag 3 aus dem freigegebenen r02-Paket: Motiv M-r02 und dessen Korridor wurden tatsächlich freigegeben und vier gezielte Direktimporte erzeugt. Alle sind vollständig in Linienlogik zertifiziert und in einem frischen Prozess samt Herkunft, Hinweisen und Endmatrix geprüft. Redaktionell verletzen sie die geschützte Knoblauchtrennung. Der Nutzer wählte ausdrücklich die korrigierte Motivvorlage statt Annahme dieses Verlusts.

Neue Freigabevorlage `images/motif-M-r04.png` / M-r04 / `bcfb58388f22bef0277bbe48e06aacc0027ba476d3bfafdce2a5e9a19c8d53e3` nach zwei nativen Edits. Erste Korrektur M-r03 war zu zurückhaltend; M-r04 verbreitert die Saucenräume und verkleinert Knoblauch lokal. Vier Fleischbereiche, Keulenrichtung, zwei Blätter, Perspektive und Gefäßform bleiben. B-r01 bleibt bytegleich und freigegeben.

Empfehlung 29×25/4, weiterhin erlaubt 29×25 und 31×27 mit drei/vier Farben, area/contain. Neuer vorgeschlagener enger Crop `[11, 49, 1299, 1154]` aus Alpha≥8 der neuen Datei. Neue Motivdatei und Korridor benötigen tatsächliche Freigabe vor jeder Rasterung. Keine Endabnahme, Registrierung oder Schwierigkeit für einen fertigen Kandidaten vorhanden.
