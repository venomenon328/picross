# Wiederaufnahme nach erneuter Motivfreigabe

Lade `pz-dbcf38395b9f4dda86c8b3d6cdae1f2c/r03/package.zip` und prüfe Record, ZIP, Handoff und Inventar. Quellencommit `c4bc5b4e0d023e4981198c2a9ce050774dedcc6d`; aktuelles main neu abrufen. Der Nutzer hat die Korrektur beauftragt, aber M-r04 noch nicht freigegeben.

Nach tatsächlicher Freigabe von `images/motif-M-r04.png` / M-r04 / `bcfb58388f22bef0277bbe48e06aacc0027ba476d3bfafdce2a5e9a19c8d53e3` und parameters.json/r03 Standardauftrag 3 bis content_ready fortsetzen. Vier zulässige Größen-/Farbkombinationen mit ihren unveränderten Paletten, area/contain und Crop `[11, 49, 1299, 1154]`; neue unabhängige Produktions-/Herkunftsnachweise, Randregel und visuellen Vergleich durchführen. Nicht die alten M-r02-Importe als neue Produktion verwenden. Breite Saucenräume und Knoblauchtrennung sind gezielt zu prüfen; kein Lösbarkeits-/Qualitätsversprechen aus dem neuen Bild ableiten.

Nach finalem Kandidaten instrumentierte Analyse nach aktivem Produktionsstandard 0.4, technischer Paketcheck am geschriebenen ZIP und Endabnahmevorlage. Keine Spielregistrierung ohne tatsächliche separate Endabnahme. Bestehender Ablage-/Mergeauftrag gilt innerhalb dieses Scopes weiter.
