# Erneute Motiv- und Parameterfreigabe

Empfehlung bleibt 29×25, farbig, vier Vordergrundfarben plus Leer. Alternativen 29×25/3, 31×27/4 und 31×27/3; keine neuen Palettenrollen. Die Drei-Farben-Alternative vereint weiterhin Schale/Lorbeer. Vier trennt Sauce/Konturen, Fleisch/Knoblauch, Schale und Lorbeer.

M-r04 ist eine neue gespeicherte Motivdatei. Vorgeschlagener Crop `[11, 49, 1299, 1154]` statt r02 `[9,54,1300,1156]`; so wird ihre leicht verschobene Außensilhouette nicht abgeschnitten. Methode area, Fit contain, Alpha 128 und Hintergrund #ffffff bleiben. parameters.json/r03 ist der neue Freigabegegenstand. parameters-r02.json bleibt als unveränderte Importgrundlage der vier verworfenen Raster.

Breitere dunkle Trennräume sollen Knoblauch und Flügel im nächsten Import erhalten. Native Illustration besitzt weiterhin leichte Tonabstufungen; die vier Rasterfarben sind geplante Rollen, noch keine verwendete Matrixpalette. Es gibt keinen neuen Raster-/Logiknachweis vor Motivfreigabe. Eine erneute Viererproduktion folgt erst danach.
