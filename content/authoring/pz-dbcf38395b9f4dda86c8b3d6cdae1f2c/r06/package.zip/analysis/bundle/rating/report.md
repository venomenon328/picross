# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: 02d67ba4ef4ef8dd0be4744a18fb93aac482ff1d4d9bf4db37541d58b6c837ed
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 1 |
| search | 8/27 |
| workload | 1/4 |

Score: 167/108; level: 2 / 5.
Without workload: 35/27; level: 2.
Lower boundary: 1; distance: 59/108.
Upper boundary: 2; distance: 49/108.
Nearest boundary distance: 49/108.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
