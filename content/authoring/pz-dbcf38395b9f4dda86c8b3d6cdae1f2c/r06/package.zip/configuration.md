# Endkonfiguration r06

29×25 · 725 Zellen · farbig · fünf Vordergrundfarben plus Leer.

| Rolle | RGB | Zellen |
| --- | --- | ---: |
| Lorbeer, ausschließlich zwei Blätter | #7a843c | 26 |
| Schale | #28606b | 180 |
| Huhn | #d69140 | 151 |
| Knoblauch | #f2dfb2 | 7 |
| Sauce / Konturen | #3b241d | 174 |
| Leer, kein Vordergrund | #ffffff | 187 |

Originalimport aus freigegebener M-r05: area/contain, Crop [12,51,1298,1160]. Feste Ableitung: genau 95 bay→sauce-Edits, Schutzmaske für alle 630 anderen Positionen. Beide Blattflächen bleiben mit 12/14 Zellen, beide Knoblauchformen mit 2/5 Zellen erhalten. Kindimport aus exakter Replay-Pixelquelle: area/contain, Crop [0,0,29,25]. Dieser Kindcrop ersetzt nicht den freigegebenen Motivcrop; die Herkunft wird am Originalimport und danach am vollständigen Zellreplay geprüft.
