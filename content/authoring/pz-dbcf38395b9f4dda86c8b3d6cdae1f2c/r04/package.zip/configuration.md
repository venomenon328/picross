# Konfiguration zur erneuten Motivfreigabe

Empfehlung **29×25, farbig, fünf Vordergrundfarben plus Leer**. Eine zusätzliche Farbe hat einen konkreten Nutzen: Knoblauch bleibt als helle Zutat vom goldockerfarbenen Huhn unterscheidbar. Vier weitere Rollen bewahren Schale, Sauce/Konturen, Fleisch und Lorbeer. Keine sechste dekorative Farbe.

| Konfiguration | Nutzen und Verlust |
| --- | --- |
| 29×25/5, empfohlen | Kompakte 725 Zellen; Huhn/Knoblauch und Schale/Lorbeer getrennt. |
| 29×25/4 | Gemeinsames Petrolgrün für Schale/Lorbeer; Huhn/Knoblauch weiterhin getrennt. |
| 31×27/5 | 837 Zellen und mehr Formraum; alle fünf Materialrollen getrennt. |

Als vierter gezielter Kandidat ist 31×27/4 vorgeschlagen. Größere Formauflösung garantiert weder Motivqualität noch Lösbarkeit; geringere Farbzahl kann Logik und Lesbarkeit ändern. Keine entsprechende Analyse vor Motivfreigabe.

Alle Werte in parameters.json/r04: area, contain, Alpha 128, Hintergrund #ffffff, Crop `[12, 51, 1298, 1160]` aus tatsächlichem Alpha≥8. Die alte M-r02-Freigabe auf drei/vier Farben wird nicht umgeschrieben. Nutzerauftrag erlaubt die neue Farbkorrektur; die konkrete neue Datei und der vorgeschlagene Korridor benötigen ihre Freigabe. Native Tonabstufungen sind keine weiteren Rasterfarben; tatsächlich verwendete IDs werden erst an der künftigen Matrix gezählt.
