# Fortsetzung nach Motivfreigabe M-r05

Lade Paket r04 für `pz-dbcf38395b9f4dda86c8b3d6cdae1f2c` über den Authoringindex; ZIP-, Handoff-, Inventar- und Bildbindungen prüfen. Quelle `0ef10739cffa78361b9313c9fa7800bb14c54a5d`, aktuellen main neu abrufen. Aktueller Korrekturauftrag ist keine Freigabe der nachfolgend erzeugten M-r05.

Nach tatsächlicher menschlicher Freigabe von `images/motif-M-r05.png` / M-r05 / `76b25cf3c41d8b5fb1dbac55e72c6ddac2bfac80d82bdd360432e3026c5d8449` und parameters.json/r04 Standardauftrag 3 vollständig bis zur Endabnahmevorlage ausführen. Empfehlung 29×25/5, weiterer Korridor 29×25/4, 31×27/5 und 31×27/4. Huhn goldocker und Knoblauch creme bleiben getrennt; bei vier Farben teilen nur Schale und Lorbeer ihre Rolle. Area/contain, Crop `[12, 51, 1298, 1160]` und konkrete Paletten/Alpha aus parameters.json. Keine übernommenen Proofs der alten Quelle als neue Zertifizierung ausgeben.

Vier gezielte neue Importe, visuelle Farb-/Knoblauch-/Konturprüfung, Hinweise, Randregel, Herkunft, vollständige Deduktion und frischer unabhängiger Prüfer; Paarprofil/Reparatur nur gemäß §4 bei Bedarf. Nach endgültigem Kandidaten aktive Methode 0.4 explizit analysieren. Endabnahmevorlage samt geschriebenem ZIP prüfen. Keine Registrierung ohne tatsächliche Endabnahme. Repositoryablage und bedingter Ablagemerge bleiben beauftragt.
