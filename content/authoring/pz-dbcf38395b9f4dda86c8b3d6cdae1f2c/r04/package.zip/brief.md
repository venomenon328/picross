# Chicken Adobo · farbliche Motivkorrektur r04

`pz-dbcf38395b9f4dda86c8b3d6cdae1f2c` · Quelle/Werkzeug `0ef10739cffa78361b9313c9fa7800bb14c54a5d` · Kategorie `gerichte-herzhaftes`.
Nutzerauftrag: „Bitte sorge für eine farbliche Unterscheidbarkeit von Huhn und Knoblauch. Dafür sollte vmtl. eine weitere Farbe eingeführt werden.“

Die neue Vorlage M-r05 `images/motif-M-r05.png` (`76b25cf3c41d8b5fb1dbac55e72c6ddac2bfac80d82bdd360432e3026c5d8449`) gibt den beiden Knoblauchzehen eine eigene helle Cremefarbe. Das Huhn bleibt goldocker; Schale petrol, Sauce braun, Lorbeer oliv. Breite Trennräume und Geometrie von M-r04 bleiben visuell erhalten. B-r01 ist unverändert und freigegeben.

Vorschlag: 29×25/5, alternativ 31×27/5 oder dieselben Größen mit vier Farben bei gemeinsamer Schale/Lorbeer-Rolle. Huhn/Knoblauch bleiben in jeder vorgeschlagenen Kombination getrennt. area/contain, neuer bildgebundener Crop `[12, 51, 1298, 1160]`. Dies ist ein neuer vorgeschlagener Korridor, keine stillschweigende Änderung der alten M-r02-Freigabe. M-r05 und parameters.json/r04 stehen zur Freigabe; keine neue Rasterproduktion vor dieser Entscheidung.
