# Chicken Adobo · Abschlussbildauswahl r01

`pz-dbcf38395b9f4dda86c8b3d6cdae1f2c` · `reveal_review` · 2026-10-28 · Regelwerk 0.5.0 / Dokumentrevision 23.
Quelle/Werkzeug: `ef32aafe319633ea3dd63c14dcaebe2e3eada52f`. Kategorie: Gerichte & Herzhaftes.

Drei farbige transparente Einzelbilder erzeugt und ohne Bearbeitung erhalten. A: Teller mit Reis; B: tiefe Tealschale; C: breite Terrakottaplatte. **Empfehlung A-r01** wegen deutlicher Flächentrennung; menschliche Auswahl und Freigabe offen.

## Sichtprüfung

Einzelbilder groß sowie statisch auf den echten Projektpapierpixeln in großer Darstellung und 180/225-px-Vorschaurahmen geprüft. Alle fünf Kriterien (Erkennbarkeit, Silhouette/Proportionen, Details/Negativräume, Palette/Lesbarkeit, Serienästhetik) je Bild erfüllt; Einzelbegründungen in `review/visual-review.json`. Transparente Außenflächen ohne sichtbaren Saum, helle Motivteile erhalten. Alpha liegt in Hauptflächen meist bei 251–253; kaum sichtbare Alpha-1-Reste am Rand bleiben unverändert. Keine erforderlichen Innenaussparungen vorhanden.

A bewahrt Reis als helle große Gegenfläche. B konzentriert das Gericht in einer kompakten Schale. C betont zwei Keulen und benötigt voraussichtlich mehr Breite; der warme Gefäßton ist weniger kontrastreich als Teal. Glanz, Hauttextur und Pfefferkörner müssen in Auftrag 2 gezielt reduziert werden.

## Stand und Grenzen

Breite offen × ungefähr 25 Zeilen, farbig; gewünschte Farbzahl offen. Istmaße, Zellzahl und verwendete Rasterfarben: noch nicht vorhanden. Bildvarianten sind keine Raster. Keine Import-/Reparaturrunde erforderlich oder ausgeführt. Herkunft und sichtbare Bildaufrufe dokumentiert; drei native Aufrufe, eine Generierungsrunde, aktive Menschenzeit nicht erfasst.

Bild-, Motiv- und Endfreigabe offen. Noch keine Motivvorlage, Matrix, Hinweise, Nachweise oder Schwierigkeit. ZA-1-inspect, Export, Registrierung und native Prüfungen nicht erforderlich: frühe Bildauswahl. Keine Adapterzertifizierung behauptet.

Schlankes Paket mit Originalbildern, Prompts/Einstellungen, Herkunft, Sichtbelegen, Briefing, Entscheidungen/Aufwand und gebundenem Regelwerk. Inventar und Handoff schließen sich gemäß ZA-1 aus; Inventarhash im Handoff/äußeren Record. ZIP-Dateimenge, sichere Namen, CRC, Dateigrößen/SHA-256 und bytegleiche Handoffkopie werden vor Lieferung am geschriebenen ZIP kontrolliert. Ablage samt bedingtem Merge beauftragt; separate PR-Belege führen CI/Head/Merge.

**Nächster Schritt: 2 · Bild freigeben & abstrahieren.** Eine konkrete Variante samt Datei und Revision ausdrücklich freigeben.
