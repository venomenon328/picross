# Chicken Adobo · Abschlussbildauswahl r01

Auftrag: Standardauftrag 1 nach `docs/ai-workflows/PUZZLE_AUTHORING.md` auf `main`.
Quelle und Werkzeugstand: `ef32aafe319633ea3dd63c14dcaebe2e3eada52f`; Regelwerk 0.5.0, Dokumentrevision 23.
Produktions-ID: `pz-dbcf38395b9f4dda86c8b3d6cdae1f2c`. Kategorie: `gerichte-herzhaftes` (Gerichte & Herzhaftes).

Breite offen × ungefähr 25 Zellen Höhe; späterer Rätselmodus farbig; Farbzahl offen.
Keine feste Breite, Palette oder Parameterfreigabe aus diesem Bildauftrag ableiten.
Arbeitsweise `free`: neue Illustration aus Motivtext ohne bindende Bildreferenz.

Identitätskern: gegarte Hähnchenstücke mit erkennbarer Keulenform, dunkle braune
Adobo-Sauce, Knoblauch, Lorbeer und wenige Pfefferkörner. Unterschiedliche
Anrichtungen sind erlaubt: Teller mit Reis (A), Schale (B), Servierplatte (C).
Warm gezeichnete 2D-Illustration mit klaren Konturen, ausgearbeiteten Oberflächen
und ruhigem transparentem Außenraum. Keine Beschriftung oder zusätzlichen Requisiten.
Weißer Reis und helles Geschirr sind Motivteile und bleiben sichtbar.

Zu bewahren nach Auswahl: konkrete Perspektive, Anordnung und Gefäßsilhouette,
Keulenrichtung und große Hähnchenformen, Sauce-/Reisverteilung sowie Lorbeer und
Knoblauch als charakteristische Zutaten. Kleine Textur/Glanzpunkte werden später
gezielt vereinfacht; keine motivfremden Pixel oder zusätzliche Farben als Logikanker.

Es wurden drei native Bildaufrufe mit `transparent_background=true` ausgeführt.
Originalbytes, Prompts und sichtbare Einstellungen stehen im Paket. Modell, Seed,
interne Auflösungseinstellungen und interne Promptbearbeitung sind `not_exposed`.
Keine externe Bildquelle, keine direkte Modell-API und keine Rasterproduktion.

Befugnis: Standardauftrag 1: Abschlussbildauswahl für Chicken Adobo, Breite offen × ungefähr 25 Zellen Höhe, farbig. Repositoryablage nach §6 ist beauftragt. Ablage-/Integrations-PR nach erfolgreichen Pflichtprüfungen mergen. Dies ist noch keine menschliche Bild-, Motiv- oder Endfreigabe.
Nächster Schritt: 2 · Bild freigeben & abstrahieren; ausdrückliche Freigabe einer konkreten Datei nötig.
