# Chicken Adobo · Motivvorlage r02

`pz-dbcf38395b9f4dda86c8b3d6cdae1f2c` · Quelle/Werkzeug `8c88b322388a996c0ac57a6f738ab96a8e32b576` · Regelwerk 0.5.0 / Dokumentrevision 23.
Kategorie `gerichte-herzhaftes`. Standardauftrag 2 einschließlich Repositoryablage
und Ablagemerge nach erfolgreichen Pflichtchecks. Originalpaket r01 bleibt unverändert.

Die tatsächliche Nutzererklärung „Ich gebe das Abschlussbild B-r01 frei.“ ist an
`images/reveal-B-r01.png` / B-r01 / `d321cb52a6bcda782bba0829d2a7fa5eaeb91f7672807fd12ff6fec92d5113ce` gebunden.
Erklärung, Akteur und UTC-Erfassungszeit samt offen benanntem Zeitbezug stehen in
`approvals/reveal-approval.json`, Wortlaut in `approvals/reveal-evidence.txt`.

Die gespeicherten Originalbytes wurden vor dem nativen Edit geprüft und als echter
Bildeingang verwendet. Arbeitsweise ab dieser Freigabe `faithful`: Perspektive,
Gefäßform, Keulenrichtung, vier große Hähnchenbereiche, zwei Lorbeerblätter und
prägende Knoblauchformen erhalten. Keine Beilage und keine Umkomposition.
Die Vorlage M-r02 reduziert Oberflächen und Binnenzeichnung; bewusst entfallene
Details und Parameter stehen in `parameters.json` und `configuration.md`.

Empfehlung 29 × 25 / Farbe / 4 Vordergrundfarben. Nutzervorgabe bleibt Breite offen,
Höhe ungefähr 25, farbig, Farbzahl offen. Vorgeschlagener Korridor: genau die vier
Kombinationen aus zwei Größen 29 × 25 und 31 × 27 sowie drei/vier Farben,
`area`, `contain`, Crop `[9, 54, 1300, 1156]`. Kein Pixelraster oder Logiknachweis ist entstanden.

Nächster Schritt: `3 · Motiv freigeben & produzieren`; die ausdrückliche Freigabe
von M-r02 und dem Parameterkorridor muss vor jedem Import vorliegen.
