# Chicken Adobo · Motivvorlage r02

`pz-dbcf38395b9f4dda86c8b3d6cdae1f2c` · `motif_review` · 2026-10-28 · Regelwerk 0.5.0 / Dokumentrevision 23.
Quelle/Werkzeug `8c88b322388a996c0ac57a6f738ab96a8e32b576`. Kategorie Gerichte & Herzhaftes.

**B-r01 ist ausdrücklich freigegeben** und unverändert erhalten. Die gespeicherte
Motivvorlage `images/motif-M-r02.png` / M-r02 ist daraus mit zwei nativen Bildaufrufen
abgeleitet. Bildfreigabe in `approvals/reveal-approval.json`; Motiv- und Endfreigabe offen.

Empfehlung **29 × 25, farbig, vier Vordergrundfarben plus Leer**, 725 vorgesehene Zellen.
Alternative 29 × 25 / 3 sowie 31 × 27 / 4 sind in `configuration.md` vergleichend
begründet; der genaue Korridor in `parameters.json` erlaubt auch 31 × 27 / 3.
Nutzerfarbwunsch offen; verwendete Matrixfarben noch nicht vorhanden. Vier Rollen:
Braun Sauce/Konturen, Ocker Fleisch/Knoblauch, Petrol Schale, Oliv Lorbeer. Drei Farben
vereinen nur Schale/Lorbeer zu Petrolgrün. Keine zusätzliche Glanz-/Knoblauchfarbe nötig.

Die hohen Dreiviertelansicht, Schalenproportionen, Keulenrichtung und Hauptzutaten
bleiben erkennbar. Haut-/Glasur-/Keramiktextur, Pfefferkörner und feine Blattadern
entfallen; kleine Falten werden zusammengefasst. Die Korrektur entfernt einen neu
entstandenen Standring. Restliche weiche Tonabstufungen sind Illustrationswerte,
keine fertigen Rasterfarben. Fünf Gestaltungsachsen samt Transparenz erfüllt;
Begründungen in `review/visual-review.json`, große/kleine statische Papieransichten in
`review/reveal-motif-comparison.png`. Kein Laufzeitnachweis.

**Noch keine Matrix, Hinweise, Randprüfung, Lösbarkeit, unabhängiger Proof oder
Schwierigkeit**: erst nach menschlicher Motivfreigabe in Auftrag 3. Keine Import-/
Reparaturrunden in dieser Phase. Keine ZA-1-Zertifizierung, kein Export, keine
Registrierung; native Prüfungen nicht erforderlich: frühe reine Bildablage.
Nutzungsgrundlage und Ableitung sind dateigebunden. Aktive Menschenzeit nicht erfasst;
Modell/Seed/Qualität nicht exponiert. Originale r01 und Abschlussbild unverändert.

Das neue Paket enthält ausgewähltes Abschlussbild, Motivdatei, tatsächlichen
Edit-Zwischenschritt, Freigabe, Herkunft, Prompts, Korridor, Sichtbelege und die direkte
Codex-Übergabe `codex-handoff.md`. Inventar/Handoff werden ohne Selbstreferenz gebunden;
ZIP-Dateimenge, Größen, SHA-256, sichere Namen/Modi und Handoffkopie am geschriebenen ZIP
geprüft. CI/Selbstreview/Merge stehen im Ablage-PR.

**Nächster Schritt: 3 · Motiv freigeben & produzieren.** M-r02 und den vorgelegten
Parameterkorridor ausdrücklich freigeben; bis dahin keine Rasterproduktion.
