# Konfiguration für die Motivfreigabe

Breite offen × ungefähr 25 Zeilen, Rätselmodus farbig, Farbzahl offen.
Empfehlung: **29 × 25 Zellen, vier Vordergrundfarben plus Leer** (725 Zellen).
Der kompakte Schalenumriss hat nach Außenbeschnitt ungefähr das Verhältnis 1,17;
29:25 liegt nahe daran. `contain` erhält Proportionen ohne Strecken.

| Konfiguration | Motivtreue / Darstellbarkeit | Erwartetes Lösbarkeitsrisiko, noch ungeprüft | Spielgefühl |
| --- | --- | --- | --- |
| 29 × 25 / 4 Farben, empfohlen | Schale, Fleisch, Sauce und Lorbeer bleiben getrennt; große Flächen statt Textur. | Dünne Flügel- und Randbänder können bei Rasterung zusammenlaufen; keine Zertifizierung vor Motivfreigabe. | Überschaubare 725 Zellen, vier klar benannte Farbrollen. |
| 29 × 25 / 3 Farben, reduziert | Schale und Lorbeer teilen Petrolgrün; Knoblauch bleibt über seine Form erkennbar. Weniger Materialtrennung. | Weniger Farbanker könnten offene Domains begünstigen; das ist eine Erwartung, kein Solverbefund. | Weniger Farbwechsel und größere gemeinsame Flächen. |
| 31 × 27 / 4 Farben | Mehr Raum für Keule, Flügelbänder und Zutaten, bei weiterhin ungefähr 25 Zeilen (+2). | Mehr Platz garantiert keine Lösbarkeit; kurze Detailblöcke können auch mehr Abhängigkeiten schaffen. | 837 Zellen, rund 15 % mehr Bearbeitungsumfang; keine Zeit-/Schwierigkeitsschätzung. |

Die vierte ausdrücklich erlaubte Produktionskombination ist 31 × 27 / 3 Farben.
So können in Auftrag 3 zwei nahe Größen mit zwei sinnvoll verschiedenen Paletten
verglichen werden, ohne eine neue Motivzeichnung oder zusätzliche Vollmatrixrunde.
Genaue Werte, Farben und Crop stehen ausschließlich in `parameters.json`.

Vier Farben sind die kleinste empfohlene Palette, die alle vier Hauptrollen getrennt
erhält. Eine fünfte Farbe für Knoblauch oder Glanz ist für die vorliegende Vorlage
nicht erforderlich. Drei sind eine bewusst reduzierte Alternative mit benanntem Verlust.
Die Illustrationsdatei enthält noch weiche Tonabstufungen und Kantenglättung;
vier ist die vorgeschlagene Rasterfarbzahl, keine Behauptung exakt vier PNG-Pixelwerte.
Tatsächlich verwendete Vordergrundfarben werden erst in Auftrag 3 an der Matrix gezählt.

Erlaubt sind nur die vier Kombinationen und der eine angegebene Crop. Neue Palette,
andere Perspektive, relevanter Formenverlust oder größere Abweichung erfordern neue
Motivvorlage/Freigabe. Kleinere logikbedingte Änderungen folgen erst nach Motivfreigabe
dem bestehenden Motivschutz-/Reparaturvertrag. Das Abschlussbild bleibt bytegleich.
