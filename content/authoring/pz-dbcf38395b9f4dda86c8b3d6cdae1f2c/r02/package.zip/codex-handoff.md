# Codex-Übergabe · nach tatsächlicher Motivfreigabe

Noch offene Freigabe: `images/motif-M-r02.png` / M-r02 / `d90388576740dc4f6a3d2da33877cc87f62dcabfc9b1b1caa12e79e2255dded5`
und genau der Korridor in `parameters.json` / r02. Diese Datei erteilt keine Freigabe.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Lade zuerst content/authoring/index.json und das r02-Paket für pz-dbcf38395b9f4dda86c8b3d6cdae1f2c.
Prüfe ZIP, Handoff, Inventar, Bildfreigabe B-r01 und beide gespeicherten Bilddateien.
Protokolliere nur eine tatsächlich vorliegende menschliche Freigabe der Motivdatei
images/motif-M-r02.png (M-r02, SHA-256 d90388576740dc4f6a3d2da33877cc87f62dcabfc9b1b1caa12e79e2255dded5)
samt parameters.json r02. Ohne diese Freigabe nicht importieren.

Führe danach Standardauftrag 3 vollständig bis content_ready aus, ohne Registrierung:
Motivtreue und die Invarianten aus parameters.json erhalten; Abschlussbild B-r01
bytegleich lassen. Starte vier gezielte Kandidaten aus den ausdrücklich erlaubten
Kombinationen 29×25 und 31×27, jeweils drei oder vier Vordergrundfarben.
Empfehlung 29×25/4. Verwende ausschließlich area, contain, Crop [9,54,1300,1156],
die dort angegebenen Paletten und Alpha 128. Keine wirkungslosen Farb-Schwellenvarianten.
Alle neuen Design-/Importbindungen im unterstützten Format tatsächlich erzeugen.

Hinweise, Randregel, Herkunft und vollständige Deduktion im passenden Linienprofil
prüfen und in frischem unabhängigen Prozess bestätigen. Bei visuell tragfähigem
Linien-stalled das passende Paarprofil nach §4.2.1 vor rein logikbedingter Änderung
prüfen. Falls kein geeigneter zertifizierter Kandidat vorliegt, den beauftragten
begrenzten Motivschutz-/Reparaturweg nach §4.4 ausschöpfen. Kein Erfolg vortäuschen.
Die technische Zertifizierung und die aktuelle Schwierigkeitsanalyse gemäß dem
dann aktuellen Regelwerk getrennt durchführen. Keine rätselspezifischen Unit-Tests.
Echtes Endraster, Bildvergleich, tatsächliche Farbzahl und vollständige Belege zeigen.
Neue Revision sichern; bei fortbestehendem Ablageauftrag Commit/PR und Pflichtchecks.
Menschliche Endabnahme bleibt offen, keine Runtime-Integration aus diesem Auftrag.
```
