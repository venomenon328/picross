# Chicken Adobo · Produktion r05

`pz-dbcf38395b9f4dda86c8b3d6cdae1f2c` · Quelle/Werkzeug `295f9d0960b45cef0bd2191d2e027211b78c8d63` · Kategorie `gerichte-herzhaftes`.
Menschliche Freigabe der gespeicherten M-r05 samt parameters.json/r04 liegt im aktuellen Auftrag vor und ist mit Akteur, UTC-Erfassungszeit, Wortlaut und Hash in approvals/motif-approval.json gebunden. B-r01 und dessen frühere Freigabe bleiben unverändert. Fünf Farben ungefähr, ohne Leer; zulässige Größen 29×25 und 31×27, vier oder fünf Farben, Huhn/Knoblauch stets getrennt, area/contain, Crop [12,51,1298,1160].

Alle vier Konfigurationen erzeugt und frisch unabhängig geprüft. Gewählt c29x25-5: 29×25, fünf Farben, keine Zelländerung/Reparatur. Echte Endmatrix ist der direkte Import der freigegebenen PNG-Bytes. Motivinvarianten und bewusst erlaubte Detailverluste stehen unverändert in parameters.json/r04; deren historischer Vorschlagsstatus wird durch die neue separate tatsächliche Freigabe erfüllt.

Standardauftrag 3 endet mit content_ready und konkreter Endabnahmevorlage. Keine menschliche Endabnahme oder Spielregistrierung aus dem Produktionsauftrag ableiten. Ablage und bedingter Ablagemerge sind ausdrücklich beauftragt.
