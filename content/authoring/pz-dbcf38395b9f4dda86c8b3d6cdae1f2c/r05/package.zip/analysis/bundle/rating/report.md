# SD2 difficulty model

Method: picross-difficulty-0.4
Method hash: 5508f0742aa858a6adc31aa621433e68298b915fb0fd6b8d9e74e576ba87caaf
Analysis result: c33049d1303150bee10ecc3386d15b8249769cfb61386ad7b3ce01652f61e52d
Status: rated (complete_line)
Profile scope: complete_line

| Contribution | Exact value |
| --- | --- |
| demand | 1 |
| search | 28/75 |
| workload | 1/4 |

Score: 487/300; level: 2 / 5.
Without workload: 103/75; level: 2.
Lower boundary: 1; distance: 187/300.
Upper boundary: 2; distance: 113/300.
Nearest boundary distance: 113/300.

Confidence: medium. Estimated minutes: unavailable.
Model estimate from synthetic references; no human calibration or time estimate. Demand, search and bounded workload use independently checked line profiles.
