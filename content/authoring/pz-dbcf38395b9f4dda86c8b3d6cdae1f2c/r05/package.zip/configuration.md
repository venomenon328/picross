# Gewählte Produktionskonfiguration

**29×25, farbig, fünf Vordergrundfarben plus Leer**, 725 Zellen, Variante `c29x25-5`. Methode area, Fit contain, Crop [12,51,1298,1160], Alpha 128; kein Strecken. Parameter stammen exakt aus der tatsächlichen M-r05-Freigabe, ursprüngliche Parameterdatei bytegleich.

| Rolle | RGB | Tatsächliche Zellen |
| --- | --- | ---: |
| Knoblauch | #f2dfb2 | 7 |
| Huhn | #d69140 | 151 |
| Schale | #28606b | 180 |
| Lorbeer / quantisierte Konturakzente | #7a843c | 121 |
| Sauce / dunkle Konturen | #3b241d | 79 |
| Leer | #ffffff, kein Vordergrund | 187 |

Alle fünf IDs werden tatsächlich verwendet. Knoblauch bildet zwei getrennte Komponenten (2/5 Zellen); kein dekorativer Einzelpunkt zur Erfüllung der Farbzahl. Vier Farben verlieren die Schale/Lorbeer-Trennung; 31×27 bringt keinen entscheidenden Formgewinn gegenüber zusätzlichen 112 Zellen. Vollständige Vergleichsgründe in review/editorial-review.json. Keine Größen-/Palettenänderung nach Prüfung und keine Reparatur.
