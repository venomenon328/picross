# Game Boy · r04 · neuer Rasterentwurf

ID pz-9be288b9b5104da88fc8464184647ae7; Quelle/Toolcommit eb2f6d28bf49fae4f9ada7e95a707efd15bd4349. Aktueller Nutzerauftrag in redraw-plan.json.
Neue Grenze Höhe höchstens 40 ersetzt die früheren Höhen 43/46. Gewählt 26×40,
monochrom. Klare Kreuzform, identische runde und identische schräge Tasten,
getrennte Lautsprecherschlitze sind harte Formvorgaben; geometrisch geprüft.
Der Auftrag erlaubt ausdrücklich neue diskrete Rastergeometrie. Diese ist offen
als manueller Neuentwurf bezeichnet und keine erneute Abtastung von MA-r01.
A-r01 und alle historischen Freigabebytes bleiben unverändert.
Repositoryablage/Merge laufen gemäß fortgeltendem Auftrag. Neue Dateianahme und
Endabnahme bleiben menschlich; kein Spiel-/Zieladapterexport in diesem Auftrag.
