# Game Boy · Standardauftrag 2

ID pz-9be288b9b5104da88fc8464184647ae7, Kategorie technik-erfindungen · Technik & Erfindungen.
Quelle und Toolstand: 5b58306bcf9ccc77aa9aa6e8baf5b4a19df3e0f4. Regelwerk 0.5.0, Dokumentrevision 22.
A-r01 ist ausdrücklich freigegeben und bytegleich erhalten. Aus genau diesem
Bild entstand die neue gespeicherte kontinuierliche Motivvorlage MA-r01.
Motivvorlage und vorgeschlagener Parameterkorridor sind noch nicht freigegeben.

Empfehlung: 24×40, monochrom, eine schwarze Vordergrundfarbe plus Leer.
Vergleich: 20×33 verworfen wegen Detailrisiko; 28×46 als feinere Alternative.
Korridor und vollständige Invarianten/Reduktionen in parameters.json und
provenance/motif.json. Vier geplante Anfangskandidaten: zwei Größen mit zwei
Flächenschwellen. Noch keine Matrix, Hinweise, Logik- oder Schwierigkeitsprüfung.

Repositoryablage §6 und Merge nach Pflichtprüfungen beauftragt. Nächster Stopp
ist die menschliche Motiv-/Parameterfreigabe, danach Standardauftrag 3 bis
zur redaktionellen Endabnahmevorlage. Kein Export/Runtimeeintrag vor Endabnahme.
Herkunft/Nutzungsgrundlage und tatsächliche native Prompts bleiben gebunden.
