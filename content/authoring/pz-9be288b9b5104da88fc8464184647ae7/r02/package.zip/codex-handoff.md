# Codex-Übergabe · nach Motivfreigabe

Vorbereitungsstatus: bis zur Motivvorlage samt Konfiguration vollständig;
Standardauftrag 3 ist durch die noch ausstehende Motiv-/Parameterfreigabe
gesperrt. Der vorbereitete Text ist selbst keine Freigabe.
Bevorzugter Weg: Codex. Selbst umsetzbar: Ja, in der aktuellen Umgebung sind
Bild-, Datei-, Produktionswerkzeuge, GitHub-Schreibzugriff und CI-Leseweg vorhanden.
Codex ist für die zusammenhängenden lokalen Produktions-/Prüf-/Reparaturschleifen
der bevorzugte Folgeweg; menschliche Motiv-/Endabnahmen bleiben separat.
Codex: GPT-6 Astra — Reasoning: High. Die schwierige redaktionelle Auswahl und
Datei-/Proofkette rechtfertigen diesen Qualitätsfokus; kein Max/Ultra.
OpenAI Docs am 21.10.2026 geprüft: https://learn.chatgpt.com/docs/models und
https://developers.openai.com/api/docs/models/gpt-6-astra . In dieser Sitzung
verfügbar; die Auswahl in einer separaten Nutzerinstallation ist nicht geprüft.
Vor tatsächlichem Start dort Verfügbarkeit und aktuelle Projektquellen prüfen.

Nach tatsächlicher Annahme von MA-r01 und parameters.json kopierbar:

```text
Arbeite nach der aktuellen AGENTS.md und docs/ai-workflows/PUZZLE_AUTHORING.md
in venomenon328/picross@main. Ich gebe motifs/MA-r01.png · MA-r01 und den
Korridor aus parameters.json im Paket content/authoring/pz-9be288b9b5104da88fc8464184647ae7/r02/package.zip · r02 frei.
Starte Standardauftrag 3 für pz-9be288b9b5104da88fc8464184647ae7. Löse den aktuellen Index/Record auf,
prüfe alle Bindungen und protokolliere diese tatsächliche Motivfreigabe.
Erhalte A-r01 samt Bildfreigabe unverändert. Empfehlung 24×40 mono;
die zwei Anfangsdesigns liefern vier Kandidaten innerhalb des Korridors.
Führe Produktion samt vorgeschriebenen Profil-/Proof-/Herkunftsprüfungen,
nötiger motivgeschützter Reparatur und aktueller Schwierigkeitsanalyse bis
zur redaktionellen Endabnahmevorlage aus. Sichere die neue Revision nach §6;
Ablage-PR nach erfolgreichen Pflichtprüfungen mergen. Keine Runtime-Integration
vor gesonderter Endabnahme, kein Release oder Deployment.
```
