# Tatsächlicher Korrekturauftrag

Akteur: Nutzer / Repositoryeigentümer Tobias Schröder. Nachrichtenzeitpunkt 2026-10-20T08:38:49Z (10:38:49 Europe/Berlin).

> Bitte überarbeite das Motiv: Die feste Breite von 15 entfällt und darf auch weniger Felder umfassen. Passe die Bildbreite so an, dass kein großer Leerraum auf einer Seite entsteht.

Dies hebt die feste Rasterbreite 15 auf und beauftragt eine schmalere Motivfläche ohne großen einseitigen Leerraum. Die bestehende feste Höhe 20, mono und genau eine Vordergrundfarbe bleiben erhalten. Keine Motivfreigabe erteilt; A-r01 bleibt unverändert freigegeben. Repositoryablage samt Merge aus dem laufenden Standardauftrag 2 bleibt beauftragt.
