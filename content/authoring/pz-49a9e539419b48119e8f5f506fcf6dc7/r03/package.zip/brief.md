# Banane · Breitenkorrektur

pz-49a9e539419b48119e8f5f506fcf6dc7 / r03 · motif_review · Kategorie obst-nuesse · Quelle/Tools 5b371b711d5687ffba51f309c07ddecda585e2d3.

Der Korrekturauftrag width-change-request.md hebt die feste Breite15 auf. Empfehlung jetzt12 ×20, Höhe20 weiterhin fest, mono und genau1 Vordergrundfarbe ohne Leer. 11/12/13 wurden gestalterisch verglichen;12 passt am besten zum schlanken proportionalen Bildfeld. Das ist keine Rasterproduktion oder zusätzliche feste Nutzerbreitenvorgabe.

Abschlussbild A-r01 bleibt bytegleich und ausdrücklich freigegeben. Neue Motivvorlage motifs/MA-r04.png ist eine nativ referenzgebundene Überarbeitung von MA-r02 unter zusätzlicher A-r01-Proportionsreferenz. Kleine gleichmäßige Ränder statt breitem transparentem Streifen rechts. Pose, Hauptproportionen, Stiel, Blütenende und rechter Negativraum erhalten; die native Ausgabe ist keine pixelidentische Ausschneidung. Details bleiben wie zuvor reduziert.

Parameterkorridor: parameter-corridor.json. Empfohlen12×20, area, fit exact, Crop[1,2,970,1617] aus971×1619Pixeln (969×1615=3:5), Alpha32, erste Schwellen112/144/176/208; weitere96–224. Keine Motiv-/Parameterfreigabe, Matrix oder Hinweise vorhanden.

Repositoryablage und zugehöriger Ablagemerge sind aus dem laufenden Standardauftrag2 autorisiert. Menschliche Motivfreigabe und folgende Rasterproduktion bleiben getrennt.
