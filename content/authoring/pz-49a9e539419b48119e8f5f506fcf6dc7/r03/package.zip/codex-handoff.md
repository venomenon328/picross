# Codex-Übergabe · Freigabevorlage

Keine bereits erteilte Motivfreigabe. Nur nach tatsächlicher ausdrücklicher Freigabe von MA-r04 samt parameter-corridor.json produzieren.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Setze Standardauftrag3 für pz-49a9e539419b48119e8f5f506fcf6dc7 aus content/authoring/pz-49a9e539419b48119e8f5f506fcf6dc7/r03/package.zip fort.
Die feste Breite15 ist aufgehoben; die Höhe20 bleibt fest. Empfohlene Konfiguration12×20, mono, genau1 Vordergrundfarbe ohne Leer. MA-r04: 94d74d326caeed8334f032966d4ca141f89b85954f67644364631fe58d561b45.
Erst meine tatsächliche Freigabe von motifs/MA-r04.png und parameter-corridor.json protokollieren; ohne diese keine Rasterproduktion. Danach vier Area-Kandidaten bei12×20 mit fit=exact,Crop[1,2,970,1617],alpha_below32,Schwellen112/144/176/208; weitere Schwellen nur96–224. Motivinvarianten bewahren; keine andere Größe/Pose/Crop ohne neue Vorlage.
Workflow vollständig bis geprüfter Endabnahmevorlage durchführen, keine Spielregistrierung. Repositoryablage und Ablagemerge gemäß ausdrücklich erteiltem Auftrag nach Pflichtprüfungen. Keine Werkzeugänderung,Bestands-Replays,Deployment oder erfundene Freigaben.
```

Quell-/Toolstand 5b371b711d5687ffba51f309c07ddecda585e2d3; Sicherungs-/Main-Mergecommit in äußerer Übergabe/PR.
