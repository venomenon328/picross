# Banane · Korrektur der Motivbreite

pz-49a9e539419b48119e8f5f506fcf6dc7/r03 · motif_review · Regelwerk0.5.0 Dokumentrevision22 · Quelle/Tools 5b371b711d5687ffba51f309c07ddecda585e2d3.

Neue Nutzerentscheidung: feste Breite15 entfällt; Höhe20 und mono/1Farbe bleiben. MA-r04 ist die neue konkrete Motivvorlage zur Freigabe. Schmale proportionale Fläche, Ränder links/rechts je61px bei Alpha>=128; kein großer einseitiger Außenraum. Erhaltene Hauptproportionen anhand A-r01 und MA-r02 geprüft. Die erste schmale Fassung MA-r03 war zu dünn und wurde verworfen; keine pixelidentische Crop-Operation behauptet.

Empfohlen12×20. 11zu knapp,13ohne Motivgewinn mit mehr Außenraum; Details und konkrete Crop-/Importgrenzen im Korridor. Vergleich und fünf Bildkriterien mit Dateimessungen in comparison.png/visual-review.json. A-r01 und seine tatsächliche Freigabe unverändert. Neue Breitenentscheidung mit Wortlaut/UTC getrennt gespeichert.

Zwei native Bildaufrufe und eine Proportionskorrektur; keine Rasterproduktion, Importe, Reparaturen oder Logik-/Rand-/Schwierigkeitszusage. Arbeits-/Lösungszeiten nicht erfasst. Motivfreigabe und Endabnahme offen. Frühphase: kein ZA-1-inspect oder Spielbuild erforderlich. ZIP, vollständiges Inventar, Dateihashes/-größen und Handoffkopie vor Ablage prüfen.

Nächster Schritt: MA-r04 mit empfohlenem12×20-Korridor ausdrücklich freigeben; danach Standardauftrag3 bis Endabnahmevorlage, keine Spielregistrierung.
