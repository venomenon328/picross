# Banane · Standardauftrag 1

pz-49a9e539419b48119e8f5f506fcf6dc7 / r01 · reveal_review · Regelwerk 0.5.0, Dokumentrevision 22.
Quell-/Toolstand: 8dac7a69d360550b0b23a202dced72698babd572.

Drei farbige transparente Einzelbilder A-r01/B-r01/C-r01 sind unverändert in reveals/ enthalten. A ist wegen der klaren Sichelform für 15 × 20 monochrom empfohlen; B zeigt eine halb geschälte Frucht, C eine kräftige diagonale Kurve. Alle bleiben zur Auswahl erhalten, keine Ablehnung oder Auswahl erfunden.

Die fünf Bildkriterien sind in visual-review.json begründet erfüllt. PNG-Dekodierung, Maße/Alpha, Originalhashes und Sichtung auf echtem Spielpapier in großer und kleiner Darstellung wurden durchgeführt. Nutzungsgrundlage und genaue Prompts stehen in provenance.json/prompts.json. Drei Bildaufrufe, keine Korrekturrunde; aktive Menschenzeit und Lösungszeit nicht erfasst.

Offen: menschliche Abschlussbildfreigabe, danach separate Motivfreigabe und Endabnahme. Motivvorlage, Raster, Hinweise, Palette einer tatsächlichen Matrix, Rand-/Logik-/Schwierigkeits-/Adapterprüfung sind noch nicht entstanden; keine Zertifizierung behauptet. Feste Rastervorgabe 15 × 20, mono; Verwendete Farben null.

Das Inventar bindet sämtliche Originaldateien außer inventory.json/handoff.json; der Handoff bindet dessen Dateihash. Der äußere Record bindet das geschriebene ZIP und die bytegleiche Handoffkopie. Frühe Bildphase: sicherer ZIP-/Datei-/Hashcheck, kein ZA-1-inspect. Der Ablagemerge ist keine Runtime-Integration und keine Bildfreigabe.

Nächster Schritt: 2 · Bild freigeben & abstrahieren; zuvor konkrete Variante auswählen/freigeben.
