# Banane · Motivvorlage

pz-49a9e539419b48119e8f5f506fcf6dc7 / r02 · Kategorie obst-nuesse (Obst & Nüsse) · Quell-/Toolstand efc194c504133a73a7565944b199ac051b69e0da.

Der Nutzer hat A-r01 am 20.10.2026 ausdrücklich freigegeben. Originaldatei, Beleg und Hash sind gebunden. Fest beauftragt: 15 Spalten × 20 Zeilen (300 Zellen), monochrom, genau eine Vordergrundfarbe ohne Leer. Abschlussbild bleibt farbig.

Motivvorlage zur nächsten menschlichen Freigabe: motifs/MA-r02.png. Aus A-r01 abgeleitet; warmes farbiges Original bleibt unverändert. Die Pose und Hauptproportionen werden erhalten. Farbe, Schattierung, Glanz, Flecken und feine Schalenlinien entfallen. Enden sind kompaktere gefüllte Formen. MA-r02 bereitet die Silhouette etwas weiter links vor; keine Streckung. Die native Korrektur ist keine behauptete pixelgenaue Translation.

Konfiguration und alle Schutzmerkmale: parameter-corridor.json. Keine Größen-/Modus-/Farbzahlalternative nötig oder zugelassen. Der vollständige 3:4-Crop erhält Proportionen bei fit=exact. Vier gezielte Area-Schwellenkandidaten sind erst nach Motivfreigabe zu erzeugen. Kein vorgezogenes Raster, kein Solver, keine Hinweise.

Arbeitsgrenze dieses Auftrags: Motivvorlage samt Vorschlag, Bildvergleich, gesicherte Codex-Übergabe und Ablagemerge. Die Motivfreigabe erfolgt durch den Nutzer erst in Auftrag 3; genehmigte Bildbytes ersetzen sie nicht.
