# Banane · Standardauftrag 2

pz-49a9e539419b48119e8f5f506fcf6dc7 / r02 · motif_review · Regelwerk 0.5.0, Dokumentrevision 22 · Quelle/Tools efc194c504133a73a7565944b199ac051b69e0da.

A-r01 ist ausdrücklich freigegeben, Originalhash af8ed145889d410fe5d49e9e44bc01765dafadecb9e8e1f6ec026fdac06b65b8 unverändert. Der echte Wortlaut und Nachrichtenzeitpunkt stehen in approvals/. MA-r02 (96eb5dd7428ddfce15cf4cee900cecb809a6ae2e5c94e38426e514dacda94f8c) ist die daraus nativ abgeleitete, noch freizugebende Motivvorlage. Zwischenfassung und tatsächliche Prompts bilden die Ableitungskette. Nicht gewählte B/C bleiben im alten r01-Paket referenziert; keine alten ZIPs eingebettet.

Feste Konfiguration: 15 × 20, mono, genau eine Vordergrundfarbe; area, fit exact, voller Crop, Alpha 32 und vier geplante Flächenschwellen 112/144/176/208. Genaue Grenzen und Invarianten in parameter-corridor.json; Vorschlag, noch keine Motiv-/Parameterfreigabe. Der große transparente Negativraum rechts bleibt bewusst erhalten.

Erhalten: einzelne aufrechte Sichel, rechter Innenbogen, linker konvexer Rücken, Stiel und unteres Ende. Entfernt: Farben, Schalenzeichnung, Flecken, Glanz und Texturen. Konturen beruhigt, Platzierung etwas nach links; keine pixelidentische Translation behauptet. Fünf Bildkriterien mit Gründen und Dateimessungen in visual-review.json; direkter A/MA-Vergleich groß/klein auf echtem Spielpapier gesichtet.

Zwei native Bildaufrufe, eine begründete Platzierungskorrektur; keine Rastervarianten, Importe oder Reparaturen. Aktive Menschenzeit/Lösungszeit nicht erfasst. Herkunft/Freigabe sind gebunden. Motivfreigabe, Matrixfarbzahl, Hinweise, Randregel, vollständige Deduktion, unabhängige Proofprüfung, Schwierigkeit und Endabnahme bleiben offen bzw. noch nicht entstanden. Kein ZA-1-inspect für diese frühe Bildphase, keine Spielregistrierung.

ZIP vor Ablage frisch auf sichere Dateimenge, Hashes/Bytezahlen und Handoffkopie prüfen; äußerer Record bindet Ergebnis. Codex-Übergabe steht in codex-handoff.md und verlangt zuerst die tatsächliche menschliche Motivfreigabe. Nächster Schritt: 3 · Motiv freigeben & produzieren.
