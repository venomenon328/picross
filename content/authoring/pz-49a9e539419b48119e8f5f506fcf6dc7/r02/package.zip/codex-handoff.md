# Codex-Übergabe · nach ausdrücklicher Motivfreigabe

Dies ist eine Auftragvorlage, keine bereits erteilte menschliche Motivfreigabe.

```text
Arbeite nach docs/ai-workflows/PUZZLE_AUTHORING.md in venomenon328/picross@main.
Setze Standardauftrag 3 für pz-49a9e539419b48119e8f5f506fcf6dc7 aus content/authoring/pz-49a9e539419b48119e8f5f506fcf6dc7/r02/package.zip fort.
Motivvorlage: motifs/MA-r02.png, SHA-256 96eb5dd7428ddfce15cf4cee900cecb809a6ae2e5c94e38426e514dacda94f8c. Abschlussbild: reveals/A-r01.png, SHA-256 af8ed145889d410fe5d49e9e44bc01765dafadecb9e8e1f6ec026fdac06b65b8; seine tatsächliche Freigabe liegt im Paket.
Starte die Rasterproduktion erst mit meiner ausdrücklichen Freigabe von MA-r02 samt parameter-corridor.json; protokolliere diese tatsächliche Erklärung dateigebunden. Ohne sie bei der Freigabe stoppen.
Fest 15 × 20, mono, genau 1 Vordergrundfarbe ohne Leer; area, fit=exact, Crop [0,0,1086,1448], alpha_below=32, zunächst Schwellen 112/144/176/208. Weitere Schwellen nur im vorgeschlagenen Bereich 96–224; keine Größen-, Crop-, Pose- oder Farbvarianten. Invarianten und benannte Detailverluste bewahren.
Nach Freigabe vier gezielte Kandidaten vergleichen, vollständige Produktions-/Herkunfts-/Logikprüfung samt unabhängigem Proof, nötigenfalls Profilprüfung und begrenzte Reparatur gemäß Workflow; Schwierigkeit mit dem aktuellen manuellen Bewertungsweg. Keine Lösbarkeitszusage aus der Motivvorlage ableiten.
Bis zur redaktionellen Endabnahme liefern, noch nicht im Spiel registrieren. Repositoryablage und Ablagemerge nach erfolgreichen Pflichtprüfungen gemäß gesondertem Auftrag. Keine Werkzeugänderungen, Bestands-Replays, Deployment oder automatische Freigaben.
```

Quell-/Toolstand dieses Pakets: efc194c504133a73a7565944b199ac051b69e0da; tatsächlichen Sicherungs-/Main-Mergecommit nennt die äußere Übergabe/PR. Regelwerksnapshot ist unverändert.
