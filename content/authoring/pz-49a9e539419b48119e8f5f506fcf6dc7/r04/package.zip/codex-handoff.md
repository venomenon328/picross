# Endabnahme und erlaubte Fortsetzung

Standardauftrag3 beendet; die menschliche Endabnahme ist offen. Endauswahl area-208 aus production/, 12×20 mono, genau1 Vordergrundfarbe. A-r01 und MA-r04 unverändert. Aktueller SD-Input: difficulty/checked.json, vollständig geprüft nach0.3; nach echtem Export bei identischer ID/Modus/Logik/Matrix auf die tatsächlichen Definitionsbytes rebind.

Nach tatsächlicher Freigabe von Paket r04 die separate picross-editorial-approval-v1 nach ZA-1 außen erzeugen: Originalhandoff-/Inventarhash und exakte Auswahl aus handoff.json binden, tatsächliche Erklärung/Akteur/UTC protokollieren. Keine Felder vorab als menschlich freigegeben ausgeben. Erst Standardauftrag4 erlaubt Export→Plan→Registrierung; vorhandenen Ablagemerge nicht als Spielintegration ausgeben.

Werkzeug-/Quellcommit dbab24504c299e10ebe4c8902e35fe073a6db050. Regelwerk und Pflichtquellen am dann aktuellen main auf Änderungen prüfen. ZIP und alte Revisionen nicht umschreiben.
