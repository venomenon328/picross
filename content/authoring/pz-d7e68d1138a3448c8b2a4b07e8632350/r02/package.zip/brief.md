# Rote Nelke · Motivvorlage

pz-d7e68d1138a3448c8b2a4b07e8632350 · r02 · motif_review · 2026-10-14T20:50:03.532999+00:00

Verbindlicher Einstieg: AGENTS.md und Quellen gemäß PUZZLE_AUTHORING 0.4.1/Dokumentrevision 9. Aktueller main 69bf0843fc64db14f92ccd0ffff96ac436845608; vollständig gelesene Pflichtquellen gegenüber vorheriger Lieferung unverändert, über Git verglichen. Aktueller Arbeits-/Paketstand f70be8dcda166bf049303507dce800a042e168e2, Draft-PR #138. Kategorienquelle, Arbeitsindex und Runtime-Registry verfügbar; Kategorie blumen-pflanzen. Keine relevanten späteren PR-Kommentare.

Der Nutzer hat am 2026-10-14T20:44:23Z C-r01 ausdrücklich freigegeben und Standardauftrag 2 mit §6-Ablage bestellt. Der tatsächliche Wortlaut liegt in approval-evidence.txt. Reveal-Originalbytes bleiben unverändert (SHA-256 b2aca07f471a9f49daac505166e2179e4589942ac3850b44345b80f9989e3ffe). Native gezielte Ableitung MA-r01 (SHA-256 bdc2dcb33cce3aa7960423655c487bee5792d75dedd9da0001d167cd1ed23a19), kein Wechsel der Vorlage. Menschliche Motivfreigabe steht aus.

Wunschgröße ungefähr 30×30; farbig. Empfohlen 30×32, alternativ 32×34, vier Vordergrundfarben. Vergleich und enger vorgeschlagener Korridor in configuration.md/configuration.json; invariantengebundene unverzerrte Ausschnitte und zwei Paletten. Der Mensch gibt Motiv und Korridor gemeinsam frei. Keine Rasterproduktion vor dieser Entscheidung.

Auftrag endet an der Motivfreigabevorlage mit Konfiguration, Dateipaket und Codex-Übergabe. Keine Endabnahme, Integration oder Merge. Historische Auswahlvarianten A/B bleiben in r01 mit genauer Fundort-/Hashbindung; keine doppelten ZIPs im neuen ZIP.
