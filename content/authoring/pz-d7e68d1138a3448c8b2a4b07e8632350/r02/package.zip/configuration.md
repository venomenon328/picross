# Konfiguration und Parameterkorridor

| Konfiguration | Motivtreue / Darstellbarkeit | Lösbarkeitsrisiko (unbewiesen) | Spielgefühl |
| --- | --- | --- | --- |
| 30×30, farbig, vier Farben | Wunschformat, aber natürliche Nelke höher als breit; unverzerrtes Einpassen lässt seitlich mehr Leerraum. | Enger Korridor für Blütenfalten; zusätzliche Gefahr leerer Außenlinien. Nicht für Erstproduktion empfohlen. | 900 Zellen, kompakt; keine Schwierigkeitseinstufung. |
| **30×32, vier Farben** | **Empfehlung**: bewahrt Perspektive und Proportionen; enger Ausschnitt ohne Streckung. | Fransen/Falten müssen in wenige tragende Farbbereiche übergehen. Randregel und Deduktion sind noch nachzuweisen. | 960 Zellen; nahezu quadratisch, nur zwei Zeilen über Wunschmaß. |
| 32×34, vier Farben | Etwas mehr Platz für Kelchgliederung und Blütenfalten, unverzerrt. | Zusätzliche Details können Hinweisketten aufsplittern; größer bedeutet nicht automatisch leichter oder schwieriger. | 1088 Zellen; etwas mehr Eintragungsarbeit. |

Die ungefähre Größenangabe gestattet die Empfehlung 30×32. Der vorgeschlagene Korridor umfasst ausschließlich 30×32 und 32×34 mit vier Vordergrundfarben, area und den exakten Ausschnitten aus configuration.json. Zwei definierte Paletten A/B halten denselben Identitätskern (zwei Rot-, zwei Grüntöne); Weiß ist leer. Beide passen zum Zieladapter mit maximal vier Vordergrundfarben. Nicht in approved_parameters eintragen, bevor der Mensch Motiv und Korridor tatsächlich freigibt.

Vier gezielte spätere Importdesigns sind vorbereitet (zwei Größen × zwei Paletten), aber nicht ausgeführt. Im farbigen area-Pfad bewirken unterschiedliche Schwellwerte keine verschiedenen Raster; threshold=128 ist nur gespeichertes Pflichtfeld. Keine Rastervariante, Hinweise, Logik oder Schwierigkeit aus diesem Plan ableiten.

Der Bildvergleich begründet die Reduktion: Petaladern und kleine Lichtkanten entfallen; wichtige Falten, die gezackte Blütenform, Kelch, Stiel und beide Blätter bleiben erhalten. Die KI-Bildfunktion liefert trotz Flächenvorgabe leichte Farbabweichungen und Antialiasing, keine bereits exakt vierfarbige Matrix. Erst der spätere Import quantisiert auf eine definierte Palette. Randregel und Lösbarkeit sind noch offen.
