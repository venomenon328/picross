# Codex-Übergabe · nach Motivfreigabe

Status: motif_review. C-r01 ist freigegeben; MA-r01 und der vorgeschlagene Parameterkorridor sind noch nicht freigegeben. Die folgende Übergabe ist keine menschliche Freigabe. Technische Bild-/Datei-/Repositoryfähigkeiten sind vorhanden, spätere Logiknachweise noch nicht ausgeführt.

Bevorzugter Weg: ChatGPT. Selbst umsetzbar: Ja, die vorhandene Umgebung kann die gespeicherten Bilder, Pillow-12.3.0-Werkzeuge und verbundenen GitHub-Schreibwege nutzen. Der ausdrücklich gewünschte Codex-Prompt ist eine Alternative zur späteren Produktion. Keine Modellentscheidung wird aus dem abgeschlossenen Bildschritt abgeleitet; Auswahl in der jeweiligen Oberfläche.

```text
Repository venomenon328/picross, Ziel main, bestehender Draft-PR #138,
Arbeitsbranch chore/rote-nelke-abschlussbildauswahl.
Lies aktuelle AGENTS.md samt Pflichtquellen und PUZZLE_AUTHORING vollständig.
Lade über content/authoring/index.json das Paket pz-d7e68d1138a3448c8b2a4b07e8632350/r02 (motif_review).
Prüfe die gespeicherten Dateien/Hashes, C-r01-Freigabe, MA-r01-Ableitung,
invariants.json und configuration.json. Kein erneuter Upload nötig.
Standardauftrag 3 erst nach tatsächlicher menschlicher Freigabe von MA-r01
(SHA-256 bdc2dcb33cce3aa7960423655c487bee5792d75dedd9da0001d167cd1ed23a19) samt vorgeschlagenem Korridor:
farbig, vier Vordergrundfarben, 30×32 empfohlen / 32×34 alternativ,
area, exakte Ausschnitte und Paletten A/B aus configuration.json.
Dann vier gezielte Designs produzieren, nach Workflow prüfen und bis zur
Endabnahmevorlage samt §6-Paket fortführen. Kein Merge oder Spielregistrierung.
```
