# Rote Nelke · Wiederprüfung r04

**Alle vier ursprünglichen Nelkenkandidaten sind nachweislich mehrdeutig.** Je zwei unterschiedliche vollständige Lösungen erfüllen dieselben Randhinweise und Farbregeln. Ein frischer unabhängiger Zeugenprüfer bestätigt jeweils beide Lösungen; vollständige Suchraumerschöpfung ist für diesen Mehrdeutigkeitsnachweis nicht erforderlich.

pz-d7e68d1138a3448c8b2a4b07e8632350 · blocked · 15.10.2026 · Authoring 0.5.0 / Revision 11 · Werkzeuge 3b64e1368735a1e9221389a48c51eaed0b881515.

| Kandidat | Offen: Linienprofil | Offen: Paarprofil | Eindeutigkeit | Unterschiedliche Zeugen-Zellen |
| --- | ---: | ---: | --- | ---: |
| 30x32-A | 101 | 61 | multiple, 2 geprüft | 4 |
| 30x32-B | 69 | 51 | multiple, 2 geprüft | 7 |
| 32x34-A | 131 | 44 | multiple, 2 geprüft | 4 |
| 32x34-B | 131 | 44 | multiple, 2 geprüft | 4 |

Alle Baseline- und Paarproofs frisch unabhängig bestätigt, Status jeweils stalled (echter Fixpunkt, kein Budgetabbruch), certified=false. Mehr Paarregeln liefern zusätzliche zwingende Zellen, aber keinen vollständigen Lösungsweg. Keine Schwierigkeit L5 vergeben: bloße Paarverwendung ist kein Nachweis einer vollständigen Lösung mit notwendiger R4.

Herkunft vollständig neu rekonstruiert: identische freigegebene Quelle, Normalisierung, Designs, Kandidaten, Matrizen und Logikbytes. Vier Produktmaße/Randregeln bestanden. Nachweise: candidate-audit.json, verification-*.json, quality-report.json und quality-*.json sowie sämtliche Baseline-/Paarproofs und Assessments in imports/. Die vier Diagnosebundles enthalten insgesamt acht unabhängig geprüfte Lösungszeugen; ambiguity-comparison.png markiert Unterschiede.

Vorab festgelegt: Import und frische Verifikation jeweils 120 s / 100000 Linien, maximal 100000000 Paararbeitsoperationen und 250000 gleichzeitige Struktureinträge; Suchdiagnose 120 s / 100000 Linien / 100000 Knoten je Kandidat. Kein Limit nachträglich gelockert; tatsächliche Ressourcen im Audit/Importresultat.

C-r01- und MA-r01-Freigaben unverändert dateigebunden; Endabnahme offen. Frühere visuelle Einschränkung an dünnen Blattdiagonalen bleibt offen. Keine neue Bildgenerierung, Zelländerung oder Reparatur. Optionales Probespiel nicht durchgeführt; menschliche Lösungszeit nicht geschätzt. Nutzungsgrundlage in den unveränderten Originaldesigns/Provenienzen, keine Fremdassets.

**Folgerung:** Die Hinweise bestimmen keine eindeutige Endmatrix. Ein stärkerer korrekter Solver allein kann diese unveränderten Rätsel nicht eindeutig machen. Für einen freigabefähigen Kandidaten sind Änderungen an Raster/Import beziehungsweise Motiv erforderlich; materielle Motivänderungen brauchen eine neue tatsächliche Freigabe. In diesem Prüfauftrag keine Änderungen vorweggenommen.

Kein freigabefähiges Endraster, keine ZA-1-Inhaltszertifizierung vor content_ready, keine Integration oder Merge. Repositoryablage in fortgeführtem Draft-PR #138; Paket-/Inventarhashes im äußeren Record. Reine Inhalts-CI prüft Pfade/Dateimodi, keine Rätselqualität. Native Spiel-/Render-/PCK-Prüfungen nicht erforderlich.
