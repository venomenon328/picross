# Rote Nelke · gezielte Wiederprüfung

pz-d7e68d1138a3448c8b2a4b07e8632350 · r04 · blocked · 15.10.2026

Auftrag: zunächst 30×32-B mit den aktualisierten Werkzeugen prüfen; anschließend tatsächliche Erweiterung „Bitte prüfe auch die weiteren Nelkenkandidaten.“. Alle vier ursprünglichen Direktimporte erneut geprüft. Keine Raster-/Motivänderung, keine neuen Reparaturen oder Integration. Repositoryablage und fortgeführter Draft-PR sind aus dem ursprünglichen Auftrag weiterhin beauftragt; kein Merge.

Werkzeuge und normative Quellen: main@3b64e1368735a1e9221389a48c51eaed0b881515, Authoring 0.5.0 / Dokumentrevision 11. Veränderte Pflichtquellen gegen den zuvor vollständig gelesenen Stand 69bf084 abgeglichen; neuer Paarlinienvertrag vollständig gelesen. Python 3.13.14, Pillow 12.3.0, isolierte vorhandene Image-Umgebung.

Quelle: r03 bei 3c80f563210ca09ffa6bad5c077c1b4a5bacde00. Geschriebenes Original-ZIP vollständig auf SHA-256, Größe, sichere Dateipfade, Dateimenge sowie Inventar-/Handoffbindungen geprüft (165 Dateien). Die unveränderten vollständigen Referenzimporte liegen unter reference/. Die alten Reparaturen werden hier nicht als Prüfinput benötigt; sie bleiben vollständig in r03 erhalten. Keine alten ZIPs eingebettet.

Motiv-/Abschlussbildbytes und ihre tatsächlichen menschlichen Freigaben werden unverändert wiederverwendet. Configuration/Invarianten und Designs stammen aus dem freigegebenen r02-Korridor. Der historische Vorbereitungstext im Design ist keine neue Befugnis; maßgeblich sind die tatsächliche Motivfreigabe und der aktuelle Wiederprüfauftrag. Budgets vor Ausführung in analysis-plan.json beziehungsweise analysis-plan-additional.json festgehalten.
