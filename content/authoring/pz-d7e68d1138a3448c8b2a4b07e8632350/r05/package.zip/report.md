# Rote Nelke 30×32-B · r05

**Die korrigierte Fassung ist eindeutig und vom unbekannten Raster vollständig mit Linienlogik lösbar.** Vier Zellwerte geändert,956 unverändert;30×32,960 Zellen, dieselben vier tatsächlich verwendeten Vordergrundfarben plus Leer. Blütenkopf, Kelch und Stiel sind unverändert.

| Zeile | Spalte | Vorher | Nachher |
| ---: | ---: | --- | --- |
| 25 | 22 | green_dark | green |
| 22 | 27 | green | green_dark |
| 24 | 13 | green_dark | green |
| 25 | 15 | empty | green |

Alle Koordinaten1-basiert. Drei Schattenkorrekturen und eine lokale Ergänzung an der linken Blattkante; keine zusätzliche Farbe. comparison.png zeigt Original, Ergebnis, markierte Änderungen und freigegebenes Abschlussbild.

Frische unabhängige Prüfung bestätigt full-line-color/solved und paired-lines-color/solved mit exakter Endmatrixgleichheit;224 Schritte,0 Paarschritte,0 offene Zellen. Hinweise aus der exakten Matrix abgeleitet; fixer Replay bestätigt alle Edits und956 geschützte Positionen. Separater Diagnose-Suchlauf: unique/exhausted,1 Knoten; der Suchchecker bestätigt nur Dateibindungen/Zeuge. Der unabhängig vollständige Deduktionsnachweis selbst beweist Eindeutigkeit. Randregel und Produktmaße bestanden. Belege: final-verification.json, final-quality.json, fixed-import/ und final-diagnosis/.

Zwei RP5-v2-Runden (Zellbudgets2/4, Kandidaten64/128, Vorschläge512/1024, Suchbudget600s/1000000 Linien, Abschluss120s/1000000 Linien, jeweils100M Paararbeit/250000 Einträge) endeten regulär mit Ressourcengrund pair_work_limit:4/3 Kandidaten,3/2 Vorschläge. Beide vollständigen Bundles frisch rekonstruiert; keine Aufwertung der Abbrüche. Begrenzte separate Formdiagnosen und endgültiger fester Vier-Zell-Plan sind vollständig protokolliert. Kein dritter Suchlauf, keine Budgetlockerung. Der erfolgreiche feste Import hat eigene Baseline/Paarproof/Assessment und frische Quelle-/Raster-/Hinweisrekonstruktion.

Schwierigkeit vorläufig **L3**, BereichL2–L4, editorial_estimate/low, Methode0.2. Mindestens4 produktive Linien vor jedem relevanten Baselineschritt; keine enge Full-line-Engstelle auf diesem Verlauf. R0–R3-Notwendigkeit nicht vollständig klassifiziert; R4 nicht nötig. Zeit nicht geschätzt, optionales Probespiel nicht durchgeführt.

Status raster_review: dünne Blattdiagonalen bleiben als visueller Befund offen, Endabnahme ausstehend. Außerdem verlangt der vorhandene feste ZA-1-Farbableitungsweg eine zertifizierte Originalbasis;30×32-B ist jedoch multiple. Die tatsächliche feste Ableitung und Endlogik sind geprüft, aber kein zulässiger Adapterexport oder content_ready-Status behauptet. Separate technische Klärung dieses Ableitungswegs vor Integration nötig; kein Werkzeugcode geändert.

C-r01-/MA-r01-Freigaben und Herkunft unverändert erhalten, Nutzungsgrundlage in Originaldesign/Provenienzen.0 neue Bildaufrufe, aktive Menschenzeit unbekannt. Kein Merge oder Spielimport. Quellenstand fbb74f96abc223d3b42437ff5d6c48d54121ef39, Authoring0.5.0/rev13. Paket-/Inventarhashes im äußeren Record. Reine Inhalts-CI prüft nur Pfade/Modi; keine rätselspezifischen Tests oder nativen Spiel-/Render-/PCK-Läufe erforderlich.
