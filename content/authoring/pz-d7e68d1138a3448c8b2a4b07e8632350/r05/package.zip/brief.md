# Rote Nelke · gezielte Korrektur von 30×32-B

pz-d7e68d1138a3448c8b2a4b07e8632350 · r05 · raster_review · 15.10.2026

Aktueller Auftrag: „Bitte versuche, die Variante 30x32-B durch gezielte Anpassungen eindeutig zu machen.“ Bestehende §6-Repositoryablage und Draft-PR #138 werden fortgeführt; kein Merge, keine Integration. Tool-/Mainstand fbb74f96abc223d3b42437ff5d6c48d54121ef39, Authoring 0.5.0 / Dokumentrevision13, Python3.13.14, Pillow12.3.0.

Quelle r04 bei301c0b0e9625027f0602e1d6cc797a564fcc3748, ZIP c95adb6d8ccb83a05957a200f13172cbee1c8e1d3ff027c9e52a4ab9fedd8499. ZIP-/Inventar-/Handoffbindungen und alle164 Inventar-/ZIPdateien geprüft. Nur der vollständige benötigte30×32-B-Import, seine Mehrdeutigkeitszeugen und Bild-/Motiv-/Parameterbindungen übernommen. Andere Nelkenkandidaten und alte Reparaturen bleiben unverändert in ihren vorigen Revisionen; keine neuen Prüfungen daran.

Zwei motivgeschützte RP5-v2-Runden mit vorher gespeicherten Masken, Seed, Operatoren und Budgets. Beide erreichen die harte kumulative Paararbeitsgrenze, ohne zertifizierten Fund. Abbrüche unverändert behalten. Eine separat protokollierte begrenzte Schatten-/Konturdiagnose liefert eine konkrete vierzellige Vorlage. fixed-plan.json führt genau diese festen Edits aus; search=false bezeichnet ausschließlich diesen festen Ableitungsschritt, nicht die dokumentierte Kandidatenfindung.

Originalmotiv und Abschlussbild bleiben bytegleich freigegeben; die30×32-Pixelquelle ist ausdrücklich eine manuelle Replayausgabe, kein unveränderter Motivimport und keine neu freigegebene Motivdatei. Der bestehende ZA-1-Weg setzt eine bereits zertifizierte Originalbasis voraus und wird hier nicht als verfügbar ausgegeben. Keine externe Autorisierung oder Endfreigabe erfunden.
