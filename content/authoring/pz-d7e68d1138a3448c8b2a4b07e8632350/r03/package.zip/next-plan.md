# Geänderter Plan nach zwei erfolglosen Reparaturrunden

Alle vier Importe stagnieren; beide vorab begrenzten RP-5-Suchen enden ohne Zertifikat. Das ist kein Beweis für Mehrdeutigkeit oder Unlösbarkeit außerhalb des Profils. Große Teile der Restunsicherheit liegen in dünnen Blattdiagonalen und kleinen Kelchfarbdetails. Die Suche priorisierte diese Stellen, ohne innerhalb der Grenzen zu lösen.

Empfehlung für einen neuen, separat freizugebenden Motivstand: Blattflächen bei gleichen zwei Ansatzpunkten, Richtung und wichtigen weißen Zwischenräumen kräftiger zusammenfassen; klare, größere zusammenhängende Hell-/Dunkelgrünflächen statt schmaler wechselnder Diagonalen. Zwei bis drei Kelchfalten zu kräftigen Farbgruppen vereinfachen. Rote Krone, Seitenansicht, Kelch/Stielproportionen und Abschlussbild C-r01 beibehalten. Keine bloßen Lösbarkeitspixel.

Das kann geschützte Blattproportionen berühren und benötigt deshalb eine neue konkrete Motivdatei und menschliche Freigabe vor weiterer Rasterproduktion. Die jetzige Freigabe von MA-r01 bleibt historisch gültig. Keine nachträgliche Lockerung der beiden Suchpläne. Danach vier neue gezielte Importe und neue Nachweise, kein neuer CI-Fall. Keine Endabnahme der vorliegenden Diagnosematrix erbitten.
