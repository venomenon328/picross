# Marienkäfer · Motivvorlage M-r02 zur Freigabe

Kategorie: insekten-kleine-tiere. Originalquelle: pz-marienkaefer/r01 am festen Commit 1d348a865444388f069386e6010b110906f1ad70.
Aktuelle Regel-/Toolbasis: main 907d40c8e08f6c7777cd579c8f214921c67efd9b, Authoring 0.8.0 Dokumentrevision 4.
Ursprüngliches Briefing bytegleich in brief-r01.md erhalten. Frühe Wünsche bleiben ungefähr 18 Zellen Breite,
ungefähr 18 Zellen Höhe, farbig und ungefähr drei tatsächlich verwendete Vordergrundfarben ohne Leerfelder.
Tatsächliche neue Erklärung: unverändertes C-r01 gewählt und freigegeben (step2-order.txt/reveal-approval.json).

M-r02 ist eine separate native vorlagentreue ImageGen-Ableitung genau dieses Originals. Geschützte Merkmale:
- Ein einzelner breiter gewölbter Marienkäfer in Schrägansicht nach rechts oben; Kopf rechts oben, keine Drehung, Spiegelung oder symmetrische Draufsicht.
- Zwei geschlossene rote Flügeldecken, gerundete breite Gesamtform und durchgehende dunkle diagonale Mittelnaht mit unveränderten Hauptproportionen.
- Sechs sichtbare dunkle Punkte in der relativen Anordnung des C-r01; die drei linken einschließlich der randnahen Teilpunkte und drei rechte Punkte bleiben unterscheidbar.
- Dunkler Kopf/Halsschild und drei helle Halsschildflecken; helle Flächen sind Vordergrund, keine Löcher.
- Zwei getrennte keulenförmige Fühler und genau fünf sichtbare geknickte Beine in der bestehenden Anordnung; sechstes Bein perspektivisch verdeckt.
- Wichtige leere Zwischenräume zwischen Beinen, Fühlern und Körper sowie Zusammenhalt aller Hauptformen schützen; keine motivfremden Randpixel, Rahmen oder Logikanker.

Bewusste Detailreduktionen:
- Pigment-/Buntstiftstruktur, Schattierung, Glanzlichter, Gelenkglieder, Härchen und Augenreflexe entfallen.
- Braune Beine und Fühler werden mit Kopf, Kontur, Naht und Punkten zu einer dunklen Farbrolle zusammengelegt.
- Fühler und Beine werden gekräftigt; Krallen und feine Gelenke zu runden Enden reduziert. Die drei hellen Flecken werden zu breiten ruhigen Flächen.
- Der Generator belässt geringe Tonvariation und Antialiasing innerhalb der drei Farbrollen; dies sind keine zusätzlichen diskreten Rasterfarben.

## Empfohlener Parameterkorridor · Vorschlag, noch nicht freigegeben

Bevorzugter Importstart 18×18 (324 Zellen): entspricht beiden ungefähren Wünschen; breite Flügeldecken
und Punkte bieten dominante Hauptformen. Fühler, kleine Flecken und Beinzwischenräume sind knapp.
20×20 (400 Zellen) ist die Detailreserve: mehr Raum für die Trennung dieser Merkmale, mehr Eingaben.
18×20 (360 Zellen) berücksichtigt das leicht höhere Motiv einschließlich Fühlern/unterem Bein;
20×18 (360 Zellen) ist die breitere Alternative mit mehr Raum für seitliche Beine, aber geringerer Höhenreserve.
Der quadratische Start nutzt die diagonale Komposition ausgewogen und vermeidet eine unnötige Größensteigerung.
Die Konfigurationen sagen weder Lösbarkeit noch Schwierigkeit voraus; große Flächen können einfache
Linienanker ergeben, kurze dunkle Runs und schmale Negativräume bleiben ein ungemessenes Risiko.

parameters.json schlägt beide Endmaße ausdrücklich ungefähr vor: Ziel 18×18, Breite und Höhe jeweils 16–22.
Diese Grenzen sind hier ein konkreter Freigabevorschlag, keine bereits geltende Prozenttoleranz.
Modus farbig, genau drei tatsächlich verwendete Vordergrundfarben: Rot #e64531 für Decken,
Anthrazit #252b30 für Kopf/Naht/Punkte/Beine/Fühler und Elfenbein #f6dda5 für die drei Halsschildflecken.
Leer/Transparenz zählt nicht. RGB sind der empfohlene Importentwurf; die PNG besitzt Antialiasing und geringe
Tonvariation, keine geprüfte Rasterpalette. Keine vierte Farbe und kein Braun nur für Beintextur.
Eine reduzierte Zweifarbenalternative Rot/Anthrazit würde die charakteristischen hellen Halsschildflecken
verlieren oder in Leerstellen verwandeln; deshalb drei Farben empfohlen. Eine vierte Schattierungsfarbe
hat bei diesem kleinen Motiv keinen ausreichenden Nutzen. Alle tatsächlichen Rasterfarbpaare später prüfen.

Vier explizite Importstarts 18×18, 20×20, 18×20, 20×18 mit area/contain, voller Ausschnitt [0,0,1254,1254].
Proportionaler Fit, keine Verzerrung/Spiegelung oder Motivbeschneidung. Keine blinde Suche aller Korridorwerte.
Zur Freigabe gehört die begrenzte Erlaubnis für motivtreue feste Korrekturen an höchstens zwei Positionen
pro Endkandidat, vorab als fester Plan mit Schutzmaske gebunden, sowie ausschließlich bereits leere
Außenlinien an den vier Seiten nach FIXED_RASTER. Endmaße bleiben innerhalb 16–22 je Achse.
Geschützte gefüllte und leere Merkmale erhalten; gute Raster unverändert lassen, keine Logikanker oder
nachträglich erweiterten Editlisten. Materielle Änderungen benötigen erneut eine konkrete Motivfreigabe.
Jede tatsächliche Matrixänderung verlangt neue vollständige Hinweise, Proofs, Herkunfts- und Qualitätsprüfungen.

Stand motif_review: M-r02 und der gesamte Korridor sind noch nicht freigegeben. Keine Matrix, Hinweise,
Solver/Proofs, Difficulty oder Integration erzeugt. Nächste Entscheidung: M-r02 samt parameters.json
ausdrücklich freigeben oder gezielte Korrektur benennen. Erst danach Schritt 3.
Commit/Push/Draft-PR beauftragt; kein Merge und keine zusätzliche lokale Abschlussbereinigung.
Fachlicher Produktionsabschluss nach Authoring §9 vor Endabnahme und bestätigtem Mainmerge nicht fällig.
