# Produktionssichtung · pz-marienkaefer/r02

Prüfer: Codex, Produktionsakteur/Selbstsichtung. UTC: 2026-11-12T23:37:26Z.
Norm: PUZZLE_QUALITY 1.0 Dokumentrevision 9 am main 907d40c8e08f6c7777cd579c8f214921c67efd9b, SHA-256 8519e16306abad95800cdd40645c5bddf6be1abd79ec4e0eb6504db9d2bb1bea.
Authoring 0.8.0 Dokumentrevision 4. Reveal C-r01: 9ea7f3248efc6d95de6f947c692ee9142d63c7bbe9689fbe57e560c00c662270; Motiv M-r02: 8e66f8589fbbb829d3667aee0b8c2bd2ac8be217fa2d420b9a7df31d3ddf8228.
Methode: beide gespeicherten Originale direkt geöffnet; danach neutralgrauer Großvergleich und kleine
proportionale Ansichten einschließlich Motiv mit 144 und 216 px Kantenlänge. Keine Zellmatrix oder
Hinweise erzeugt. Transparenz, Aussparungen, helle Flecken und Kanten betrachtet. Keine Buch-/Katalogmontagen,
Fadeproben oder Testintegration. Dateidiagnosen in image-checks.json; sie ersetzen keine Sichturteile.

| Kriterium | Urteil | Konkreter Befund |
| --- | --- | --- |
| Q-B01 | erfüllt | Unverändertes C-r01: breiter gewölbter Marienkäfer rechts oben, sechs sichtbare Punkte, fünf sichtbare Beine und zwei Fühler. Verdecktes sechstes Bein bleibt verdeckt. Tatsächliche Bildfreigabe gebunden. |
| Q-B02 | erfüllt | Detailliertes farbiges Original mit ruhiger Binnenzeichnung, Pigmentstruktur und sparsamer Schattierung. |
| Q-B03 | erfüllt | Transparente Außenflächen und Beinzwischenräume; helle Flecken erhalten. Kein störender heller Bildkasten oder sichtbare Randmatte im direkten Groß-/Kleinvergleich. Original bytegleich erhalten. |
| Q-M01 | erfüllt | Diagonalpose, Hauptproportionen, Punktanordnung, drei helle Flecken sowie Bein-/Fühleranordnung stimmen im direkten Vergleich überein. Gezielte Verluste in brief.md; keine neue Pose. |
| Q-M02 | erfüllt | Breite zusammenhängende Decken, klare dunkle Naht, kräftige Punkte und Gliedmaßen auch klein erkennbar. Der schmale linke obere Beinzwischenraum, kleinster heller Fleck und Fühlertrennung müssen am echten Raster in Schritt 3 erneut beurteilt werden; kein vorweggenommener Rasterbefund. |
| Q-M03 | erfüllt | Drei motivische Rollen Rot/Anthrazit/Elfenbein. Braun und Schatten entfallen. Zwei Farben würden helle Halsschildmerkmale aufheben; keine vierte Farbe nötig. Geringe PNG-Tonvariation ist keine zusätzliche Rasterfarbe. |
| H-03 | erfüllt (Phasenumfang) | Selbst erzeugtes Original, wirkliche Freigabe, bytegleiche Quelle, tatsächlicher Editprompt und Ableitungsprovenienz gebunden. Deterministische Matrixrekonstruktion erst später fällig. |
| H-04 | nicht geprüft (Motiventscheidung offen) | Revealfreigabe liegt vor. M-r02 und Korridor werden hier erstmals vorgelegt; keine Motiv-/Parameterfreigabe erfunden. |
| H-01/H-02/H-05/H-06 | nicht geprüft | Noch keine diskrete Matrix, Deduktion, Endabnahme oder Difficulty; erst spätere Phasen. |
| Q-R01–Q-R04 / Q-H01–Q-H03 | nicht geprüft | Keine tatsächliche Raster-/Hinweisansicht; erst nach Motivfreigabe fällig. |

Ein nativer ImageGen-Edit. Keine Lösbarkeits-, Eindeutigkeits-, Difficulty- oder Zeitbehauptung.
Parameterempfehlung, Detailverluste und Grenzen vollständig in brief.md und parameters.json.
A-r01/B-r01 nicht gewählt, weiter im unveränderten r01-Paket am festen Quellcommit erreichbar.
Reine Inhalte: modules=[], evidence.mode=none; keine neuen Dauertests, Bestandsreplays oder Player-Bauten.
Builder prüft tatsächliche Dateien, Inventar, geschriebenes ZIP, Projektion und Pointer. Frühe Phase ist
kein technisches Inhaltszertifikat. Laufinterne Prüfgrundansichten enden nach Sichtung; Produktionsquellen
und eigene Anschlussdaten bleiben für die offene Motiventscheidung erhalten. Keine zusätzliche lokale
Abschlussbereinigung beauftragt; fachlicher Abschluss nach Authoring §9 noch nicht fällig.
