# Marienkäfer · MK-R-r03 · Schritt 3

Matrix SHA-256 d10d913c512c010227c4782b1b4fd0c37c06f678e2bec8d289a7481a0bc96a2f

Logik SHA-256 d7894ac7ea2dd8093a6c83cb9864b19b01cef180c9e10667db294e0674931934

Q-B01: erfüllt. Unverändertes C-r01 direkt geöffnet: ein breiter gewölbter Marienkäfer nach rechts oben, geschlossene rote Flügeldecken, sechs Punkte, zwei Fühler und fünf sichtbare Beine. Identität, Pose und Perspektive bleiben.

Q-B02: erfüllt. Ausgearbeitete warme farbige Illustration mit Pigmentstrichen, Oberflächendetails, Reflexen und dezenter Schattierung unverändert; Raster ist bewusst gröber. Keine nachträgliche Revealänderung.

Q-B03: erfüllt. Original erneut direkt angesehen; transparente Außenflächen und offene Zwischenräume, helle Motivflecken bleiben Vordergrund. Vorhandene bytegebundene r02-Bilddiagnose und Freigabe erhalten; keine neue Freistellung.

Q-M01: erfüllt. M-r02 neben C-r01 direkt verglichen: breite Schrägansicht, diagonale Naht und charakteristische Punkt-/Fleckanordnung stimmen überein. Im freigegebenen M-r02 entfallene Textur, Reflexe und Gliederdetails werden nicht neu erfunden.

Q-M02: erfüllt. Die kräftige freigegebene Flächenvorlage ist als 20×20 tragfähig. Direkter Import verliert dünne Formen; der vorab gebundene feste Plan stellt diese entlang der vorhandenen Vorlage wieder her, ohne Streckung oder neues Motiv.

Q-M03: erfüllt. Genau drei tatsächlich benutzte Vordergrundrollen: dark #283238 für Kopf, Kontur, Naht, Punkte und Anhänge; red #ed452e für die Flügeldecken; light #f6dca5 für drei Halsschildflecken. Leer separat, keine vierte Farbe.

Q-R01: erfüllt. Endmatrix als echtes 20×20-PNG, Nearest-Vergrößerung, Gitter und native Ansicht geöffnet: Marienkäfer selbst erkennbar, breite Form und Blickrichtung rechts oben bleiben. Stufige Konturen und reduzierte Punktformen sind größenbedingte Abstraktion.

Q-R02: erfüllt. Sechs sichtbare Punkte mit drei links und drei rechts bleiben getrennt erkennbar; diagonale Naht teilt rote Flügeldecken. Drei helle Flecken, zwei getrennte Fühler und fünf sichtbare Beine mit freien Zwischenräumen erhalten. Fühler-/Beindetails stark vereinfacht. Markierter 33-Zell-Diff mit M-r02 verglichen: ausschließlich vorhandene Kontur-/Innenformen restauriert, kein zusätzlicher Logikanker.

Q-R03: erfüllt. 192/400 Zellen belegt (48.0 %). Keine vollständig leere Innenzeile; äußerste Spalte rechts bleibt leer, zulässig bei belegter linker und oberer/unterer Kante. Isolierte Füllzellen []: jede konkrete Position im Gitter geprüft; diagonale Kontur-/Nahttreppen sind motivisch, kein zufälliges Pixelrauschen.

Q-R04: erfüllt. Alle drei tatsächlichen Farbpaare direkt an Raster und nativen kleinen Ansichten geprüft: dark/light, dark/red und light/red klar verschieden. Hellflecken sind bewusst hell, mit Zellenkontur von Papier getrennt. Exakte Ist-Paarprüfung wird zusätzlich frisch im Paketreader rekonstruiert; keine Farbsinnsimulation behauptet.

Q-H01: erfüllt. Aktueller full_view_board-/Atlaspfad auf aktuellem Papier-Shader nativ betrachtet: 24 und gemessen 16,6 px Zellen, aktuelle Kontur/Schraffur, Leer-X und Fünferlinien. Alle drei Zellfarben sowie Papier bleiben unterscheidbar; helle Füllungen benötigen ihre vorhandene Kontur.

Q-H02: erfüllt. Aktuelle Delight-Coffee-Schrift mit gemessen 19/10 px auf Papier tatsächlich betrachtet: beide Achsen, normal/abgeschwächt/ausgekreuzt und alle Farbzuordnungen lesbar. Helle Hinweisfarbe bleibt dank bestehender C1-Kontur erkennbar, bei 10 px entsprechend klein. Alle tatsächlichen Hinweiszahlen dieser Matrix sind einstellig (1–9); keine erfundene mehrstellige Produktionshinweisfolge.

Q-H03: erfüllt. 175 Hinweisblöcke, 131 Länge 1–2, 123 angrenzende Farbwechsel. Aktuelle Analyse: 28 Wellen, höchste Familie E2, zwei einzelne enge Wellen. Viele kurze Farbfolgen und Naht-/Punktkreuzungen führen zu kombinierter Zuordnung; L4 ist separat gebunden. Keine menschliche Lösungszeit.

H-01: erfüllt. 20×20, ausschließlich empty/dark/light/red, genau drei genutzte Farben; freigegebener Korridor unverändert erfüllt. Hinweise deterministisch aus exakter Matrix; Rand links, oben und unten belegt. Kein Ausnahmeweg.

H-02: erfüllt. Vollständiger full-line-color-Endproof vom unbekannten Start: 105 Schritte, frischer unabhängiger Prüferprozess, exakter Endmatrixvergleich. Feste Ableitung zusätzlich erneut inspect-geprüft: solved und certified. Eindeutigkeit folgt aus vollständiger Deduktion, kein Paar-/Suchlauf nötig.

H-03: erfüllt. Unveränderte freigegebene Bildbytes, native ImageGen-Herkunft/Nutzungsgrundlage und Prompts erhalten. RP-3-Original→Normalisierung→Matrix/Hinweise und fester Plan mit Schutzmaske/Replay frisch rekonstruiert; import18/import20 samt ihren negativen Befunden erhalten.

H-04: erfüllt. Tatsächlicher Schritt-3-Wortlaut in step3-order.txt; motif-approval.json bindet M-r02, dessen Revealabstammung und kanonisch identischen vollständigen Korridor. 33 feste Änderungen vorher gespeichert; jede andere Zelle einschließlich wichtiger Leerstellen geschützt. Keine Änderung der Bildoriginale oder materiellen Motivmerkmale.

H-05: erfüllt. Einzelkandidatenrevision r03 mit expliziter Dateiliste/Inventar. Erst erfolgreiche frische ZA-1-Prüfung des geschriebenen Builder-ZIPs erlaubt raster_ready. Angebot erklärt keine menschliche Rasterwahl oder Endabnahme.

H-06: erfüllt. Methode 0.4 explizit aus endgültigem Design/Matrix/Logik: vollständiger Analyse-/Bewertungsbeleg unabhängig geprüft und in separatem CLI-Prozess neu importiert. Checked-v3 L4, medium, Score 299761/89440; keine freie Ersatzbewertung. Originalbundle in evidence/r03-analysis.

Ein geeignetes qualifiziertes Angebot genügt. Offen: tatsächliche Wahl MK-R-r03.
