# Motivbriefing · Marienkäfer · Schritt 1

Neues Motiv ohne bisherigen Produktionsdatensatz. Freie Motivinterpretation
(`free`), keine externe Bildreferenz. Hauptgegenstand ist ein einzelner roter
Marienkäfer mit dunklen Punkten, geschlossenen gerundeten Flügeldecken samt
Mittelnaht, dunklem Kopf/Halsschild, hellen Halsschildflecken, gegliederten Beinen
und zwei Fühlern. Natürliche, freundlich wirkende Proportionen ohne menschliches
Gesicht. Keine verbindliche Artbestimmung oder bestimmte Punktzahl beauftragt.

Ruhige warme handgezeichnete 2D-Illustration, kräftige zusammenhängende Farbflächen,
saubere Konturen, sorgfältige Binnenzeichnung, feine Oberflächendetails und
zurückhaltende Schattierung. Detailliertes farbiges Abschlussbild, keine Zellgrafik.
Echte transparente Außenfläche und Zwischenräume, helle Motivteile erhalten.

## Verbindlich überlieferte Wünsche für den Folgeauftrag

- Breite: ungefähr 18 Zellen.
- Höhe: ungefähr 18 Zellen.
- Rastermodus: farbig.
- Vordergrundfarbzahl: ungefähr 3, ohne Leerfelder.

Diese Angaben sind frühe Wünsche, noch kein freigegebener Parameterkorridor.
Das Abschlussbild bleibt unabhängig davon detailliert und farbig. Erst nach
ausdrücklicher Wahl/Freigabe einer konkreten unveränderten Bilddatei darf
Schritt 2 daraus die Motivvorlage ableiten und den Korridor zur Freigabe vorlegen.
Identität, Pose, Proportionen, Punktanordnung und wichtige Negativräume der
gewählten Fassung bewahren; feine Texturen/Glanzlichter dürfen später gezielt
zusammengefasst werden. Keine Lösbarkeit oder Schwierigkeit vorweg zugesagt.

## Umfang und Befugnisse

Drei unterschiedliche Abschlussbilder, direkte Originalprüfung, Repositoryablage
mit Commit, Push und Draft-PR. Kein Merge. Keine Abstraktion, Rasterproduktion
oder Integration in diesem Schritt. Keine zusätzliche lokale Abschlussbereinigung;
der fachliche Produktionsabschluss nach Authoring §9 bleibt getrennt.
