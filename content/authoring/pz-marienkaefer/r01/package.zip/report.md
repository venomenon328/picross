# Produktionsbericht · Marienkäfer · r01

Quell-/Toolstand: `187e37bb2471c03f75a2b365ed3e341150b94f66`. Authoring 0.8.0, Dokumentrevision 4.
Prüfer: Codex; UTC: 2026-11-12T20:48:44.077300+00:00.
Qualitätsvertrag: docs/PUZZLE_QUALITY.md, Vertrag 1.0/Dokumentrevision 9, SHA-256 `8519e16306abad95800cdd40645c5bddf6be1abd79ec4e0eb6504db9d2bb1bea` am selben Quellcommit.

Phase: `reveal_review`. Drei echte native ImageGen-Einzelbilder. Keine menschliche Auswahl/Freigabe vorhanden. Empfehlung: A-r01 wegen der klaren Hauptform und ruhigen Punktanordnung für das ungefähre 18 × 18-Farbraster. Empfehlung ist keine Wahl.

Methode: gespeicherte Originale direkt geöffnet; zusätzlich unveränderte Pixel auf neutralgrauem Grund groß und proportional mit 224 px Kantenlänge auf Grau/Hellgrau betrachtet. Außenflächen, Zwischenräume, helle Flecken, Fühler/Beine und Randverlauf geprüft. Die Prüfgründe sind reine lokale Ansichten, keine neuen Abschlussbilder.

## A-r01

Ruhige frontale Draufsicht, annähernd symmetrisch, sieben stilisierte dunkle Punkte.

Original: `originals/A-r01.png`, SHA-256 `d0dfc8879d2dce1364547901b811bdde9cf7ec897a18bb419bc3110512558a8f`, 1750968 Bytes, RGBA 1254 × 1254.

- Q-B01: **erfüllt** — Marienkäfer unmittelbar erkennbar; zwei Fühler, sechs getrennte Beine, geschlossene rote Decken mit dunkler Naht und Punkten. Die sieben Punkte sind frei stilisiert; keine zoologisch exakte Siebenpunkt-Artabbildung zugesagt.
- Q-B02: **erfüllt** — Satte rote Hauptflächen, saubere dunkle Kontur, sichtbare Buntstift-/Pigmentdetails und sparsame Glanzlichter. Auch klein klare Silhouette; keine Schrift oder dekorative Füllobjekte.
- Q-B03: **erfüllt** — Außenraum und Beingabeln frei; cremefarbene Halsschildflecken und kleine helle Glanzlichter erhalten. Auf Grau/Hellgrau groß/klein keine störenden hellen Matten oder ausgeschnittenen Konturteile sichtbar.

Alphadiagnose: 870915 vollständig transparente, 701254 teiltransparente und 347 voll deckende Pixel; alle vier Ecken Alpha 0. Die vielen teiltransparenten Pixel sind Generatorausgabe und wurden nicht nachbearbeitet. Alpha-Zählung ergänzt die Sichtung, ersetzt sie nicht. Sehr schwache Alphaspuren reichen bis an einzelne Leinwandränder; sichtbare Gliedmaßen sind vollständig und nicht abgeschnitten.

## B-r01

Diagonale Gehpose nach links oben, deutlich versetzte Beine und schräge Flügelnaht.

Original: `originals/B-r01.png`, SHA-256 `ff5dad29b09548af958fbf79670824f4148dccf046d1e58f7b2d89d07f0120c1`, 1531430 Bytes, RGBA 1254 × 1254.

- Q-B01: **erfüllt** — Klarer Marienkäfer in diagonaler Gehpose; zwei Fühler und sechs erkennbare gegliederte Beine. Hauptkörper, dunkle Punkte und geschlossene Naht stimmen in der Perspektive zusammen.
- Q-B02: **erfüllt** — Ausgearbeitete warme Zeichnung mit kräftigen Farbflächen, feiner Oberflächentextur und zurückhaltendem Glanz. Die Gehpose unterscheidet sich von A; klein weiterhin lesbar.
- Q-B03: **erfüllt** — Transparenter Außenraum und echte Zwischenräume zwischen Beinen/Körper. Helle Halsschildteile erhalten. Keine sichtbare helle Randmatte oder ausgefransten Doppelkonturen auf den neutralen Prüfgründen.

Alphadiagnose: 961598 vollständig transparente, 610635 teiltransparente und 283 voll deckende Pixel; alle vier Ecken Alpha 0. Die vielen teiltransparenten Pixel sind Generatorausgabe und wurden nicht nachbearbeitet. Alpha-Zählung ergänzt die Sichtung, ersetzt sie nicht. Sehr schwache Alphaspuren reichen bis an einzelne Leinwandränder; sichtbare Gliedmaßen sind vollständig und nicht abgeschnitten.

## C-r01

Breite gewölbte Schrägansicht nach rechts oben, kräftiger kompakter Körper.

Original: `originals/C-r01.png`, SHA-256 `9ea7f3248efc6d95de6f947c692ee9142d63c7bbe9689fbe57e560c00c662270`, 1799222 Bytes, RGBA 1254 × 1254.

- Q-B01: **erfüllt** — Kompakter Marienkäfer nach rechts oben; zwei Fühler, fünf sichtbare Beine, ein ferner Beinansatz perspektivisch vom breiten Körper verdeckt. Das ist keine sechsbeinige Lehrtafel; in der Schrägansicht kein zusätzlicher oder abgetrennter Gliedmaßenrest sichtbar.
- Q-B02: **erfüllt** — Breite gewölbte rote Decken, klarer dunkler Mittelspalt, kräftige Punkte und feine gerichtete Pigmentzeichnung. Farbige ausgearbeitete Illustration; klein bleiben Körper und Kopf gut unterscheidbar.
- Q-B03: **erfüllt** — Außenfläche und sichtbare Beinzwischenräume transparent; helle Flecken nicht durch Schlüsselfarbe entfernt. An Fühlerenden/Beinen und Körperrand groß/klein keine störenden hellen Säume auf Grau/Hellgrau sichtbar.

Alphadiagnose: 871177 vollständig transparente, 701061 teiltransparente und 278 voll deckende Pixel; alle vier Ecken Alpha 0. Die vielen teiltransparenten Pixel sind Generatorausgabe und wurden nicht nachbearbeitet. Alpha-Zählung ergänzt die Sichtung, ersetzt sie nicht. Sehr schwache Alphaspuren reichen bis an einzelne Leinwandränder; sichtbare Gliedmaßen sind vollständig und nicht abgeschnitten.

## Weitere Voraussetzungen und nächste Entscheidung

H-03, Herkunft/Nutzungsgrundlage für diese Bildphase: erfüllt für die gesicherten Originalbytes, je eigener Provenienzrecord und gespeicherter Prompt; keine externen Vorlagen. Spätere deterministische Rasterrekonstruktion noch nicht fällig.
H-04: nicht geprüft/offen — tatsächliche menschliche Bildfreigabe fehlt und ist vor Abstraktion nötig. A-r01, B-r01 oder C-r01 samt unverändertem Hash ausdrücklich wählen/freigeben oder gezielte Korrektur beauftragen.
Q-M01–Q-M03, Q-R01–Q-R04, Q-H01–Q-H03 und H-01/H-02/H-05/H-06: nicht geprüft, für spätere Motiv-/Raster-/Abnahmephasen fällig. Keine Matrix, Hinweise, Proofs, Difficulty oder endgültige Palette erzeugt.
Die Rasterwünsche stehen vollständig in brief.md. Kein freigegebener Korridor und keine fachliche Integration behauptet. Alle Gates bleiben pending. Keine Buch-/Katalogmontage, Überblendungsprobe oder Testintegration ausgeführt oder als spätere Pflicht vorgesehen.

## Prüfung, Aufwand und Aufbewahrung

Drei native ImageGen-Aufrufe, drei gespeicherte farbige Originale; kein Bildedit. Menschliche Arbeitszeit und Lösungszeit nicht gemessen. Die originalen Generatorausgaben bleiben bytegleich. Der Builder prüft Dateien, Inventar, geschriebenes ZIP, Projektion und Ansichtsverweis beim Bau; frühe Phasen sind keine Inhaltszertifizierung.
Reine Inhaltsproduktion: modules=[], evidence.mode=none, keine neuen Dauerprüfungen oder Player-Builds. Allgemeiner Quellen-/Plankern über Package CI. Vorhandene fremde Daten erhalten. Keine zusätzliche lokale Abschlussbereinigung beauftragt. Reine lokale Prüfgrundbilder enden nach Sichtung; Auswahloriginale und benötigte Produktionsbindungen bleiben bis zum fachlichen Abschluss nach Authoring §9 erreichbar.
