# Entscheidungen r06

Tatsächlicher Eigentümerauftrag in evidence/r06-order.md; ausgewählt ist ausschließlich das qualifizierte r05/fixed am festen Quellcommit. Quellrecord/Projektion byteidentisch in selection kopiert. Die früheren Bild-/Motiv-/Rasterfreigaben bleiben unverändert.

Drei eigenständige Kontextentwürfe im nativen Bildtool erzeugt und einzeln vorgelegt. IDs A, B, C; Bildrevision jeweils b01, gemeinsames Manifest bg01. Keine automatische Hintergrundwahl, kein none, keine Endabnahme oder Integration. Empfehlung bei Bedarf A wegen unmittelbarem Gartenbezug und ruhiger niedriger Komposition; dies ist keine Wahl.
