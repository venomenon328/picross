# Erdbeere r06 · Kontextangebote

Regelstand Authoring 0.8.0 Dokumentrevision 4 im aktuellen main bf1cb75993307345fcd26747c818170c92ad2692. Rasterwahl nach tatsächlichem Auftrag exakt an r05/fixed gebunden. Unveränderte Matrix, Palette, Reveal, Motiv, Proofs, Herkunft und 0.4-Bewertung L1 werden aus r05 erhalten. Die vollständigen nativen Raster-/Hinweisurteile stehen unverändert in source/r05-review.md und den dort gebundenen Originalen. Keine neue Suche oder Schwierigkeitserzeugung.

Drei native ImageGen-Aufrufe; A Gartenbeet, B Ernteplatz, C Gartentisch. Alle vier isolierten Q-HG-Urteile je Original mit Datei/Hash, Normstand, Methode, Akteur und Aufzeichnungszeit in background/work/bg01.json. Alle erfüllt. Wirkliche PNG-Bytes groß auf neutralem Grund und mittels Alphaansicht/Innenproben betrachtet. Die sichtbare Zeichnung ist hell und neutral; sehr niedrigdeckende Randpixel können abweichende RGB-Werte enthalten. Kein Eingriff in Originale. Dateidiagnose separat in checks/r06-image-diagnostics.json.

Rechteherkunft und tatsächliche Prompts im Hintergrundmanifest; Modell/Seed nicht offengelegt. Nur neuer Kontext, kein Rätselsubjekt, keine Lösungskopie. Gemeinsamer 4:1-Fit ohne Crop/individuelle Parameter. Kein Kandidat wurde abgeleitet, gewählt oder testintegriert. Keine Buchvorschau oder zusätzliche persönliche Buchabnahme.

Geschriebenes ZIP, gesamte Referenzmenge, Inventar, Auswahloriginale am Quellcommit und technische Rasterreife sind durch den Builder frisch zu prüfen. Fachlicher Endstand background_review: Hintergrundentscheidung, deren spätere Ableitung und finale Gesamtpaketabnahme bleiben offen.

Exakte unveränderte Rasterbindung: Matrix 4ce02fc7b0e03dc837eeba766b2b706e049f4a07f36ab578406212089cfb0e3c; Logik 083e33629b41e4f36d8cd66a38350de7c27213ecb660b997f568e0666be74f21. Vorhandene zu diesen Identitäten passende Sichturteile unverändert übernommen.
