# Vollständiges unverändertes Analyseoriginal

Der vollständige native 0.4-Bundle liegt unverändert auf demselben Produktionsbranch in `content/authoring/pz-erdbeere/evidence/r03-analysis/`: `catalog-context.json`, `rating/rating.json`, `rating/report.md`, `rating/analysis/{input,logic,report,trace}.json`. Historischer Gitanker: 42b8704efed237fc4141f2dac5659d0275a1c29b. Diese Originale wurden für r05 frisch nativ importiert. Vorläufiger Input und frisch geprüftes Checked-v3-Objekt sind hier unter checks/ inventarisiert.

Der vollständige native SD2-Report verwendet ein anderes `files`-Objekt als der RP3-Paketmanifestvertrag. Er wird unverändert außerhalb des Einzel-ZIP erhalten; keine Umbenennung technischer Formate und kein abgeschwächter Validator. Sämtliche Originalbytes bleiben im PR erreichbar.
