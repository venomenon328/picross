# Einzelurteile · D-A-r04

Prüfer Codex, 2026-11-12T11:54:07.947851Z. PUZZLE_QUALITY 1.0 Dokumentrevision 9, aktueller main f9016cf5ded630ae20e243873c867181d501739e, Norm-Dateihash e97b8bdb87eec476249cd0906df30a41dec396b950a2fe75e44f7ab63f305016. Unveränderte Kandidaten-ID c2226ef13fe883094630ba727a9824b23e084a8af934f7f3c30b342027f14d88; Matrix-/Logikbindung siehe checks/resume-verification.json.

Tatsächlich geöffnet: views/raster-grid.png (234f11fc10f75dc7a4d7c90fc680fcd25fc9fffcf9e9aac13d060607dd826650), images/reveal-A.png (cc202e928cc2f64a8c78a02e56fac3c9e61103c1973ebae64c98d16ffbac1809), images/motif-A.png (21c6dd76bce0220f3061849f969d93c990716da247dc0162eadd37b8b706228f). Kleine verlustfreie Rasteransicht und ungeglättete Gittervergrößerung; keine native Papier-/Hinweiszustandsansicht. Bilddateien und geschützte Formen unverändert.

| Kriterium | Urteil | Begründung / Beleg |
| --- | --- | --- |
| Q-M01 | erfüllt | Fruchtform, gefächerter Kelch und gebogener Stiel gehören visuell zu Reveal und Motiv. Historische Bild-/Motivfreigaben unverändert. |
| Q-M02 | Warnung | Kleine Details werden in 13×22 auf Einzelzellen reduziert; Stiel nur diagonal verbunden. Keine materielle Änderung oder neue Abstraktion. |
| Q-M03 | erfüllt | Rot Frucht, Grün Kelch/Stiel, Gold Nüsschen; alle drei Rollen tatsächlich genutzt. |
| Q-R01 | erfüllt | Erdbeere bereits im Farbraster erkennbar; zugespitzte Frucht, breiter grüner Kelch, Binnenpunkte. |
| Q-R02 | erfüllt | Zusammenhängende Frucht; bewusst verlangter diagonaler Stiel. Nüsschen sind motivisch begründete Einzelzellen, keine Logikanker. |
| Q-R03 | erfüllt | 59,09 Prozent belegt; keine leere Innenlinie. Obere Leerzeile unverändert; nur leere Außenspalten entfallen, keine motivfremde Randfüllung. |
| Q-R04 | erfüllt | gold #de8623 / green #37733d / red #b81e29 visuell getrennt; alle drei Paare frisch positiv, Einzelwerte in checks/resume-verification.json. |
| Q-H01 | nicht geprüft | Papier, aktuelle Kontur/Schraffur und kleine native Zellansicht fehlen. Vor Rasterqualifikation gezielt sichten. |
| Q-H02 | nicht geprüft | Tatsächliche Hinweise beider Achsen in allen drei Zuständen fehlen; numerische Palette ersetzt dies nicht. |
| Q-H03 | erfüllt | 286 Zellen, 169 Füllungen, 116 Hinweise, davon 70 Länge 1–2; flüssiger E1-Verlauf mit 11 Wellen, keine Engstellen im 0.4-Modell. Keine hohe Schwierigkeit aus Kleinteiligkeit abgeleitet. |
| H-01 | erfüllt | Maße/Farben, Farbhinweise und Randregel frisch rekonstruiert; Trim ausdrücklich beauftragt. |
| H-02 | erfüllt | Separater frischer Prüfer: full-line-color solved, 62 Schritte, 97 Linienprüfungen; Endmatrix exakt. |
| H-03 | nicht erfüllt | Exakte Einzelableitung geprüft, vollständiger nativer ZA-1-Herkunftsweg für Maßänderung fehlt. Nutzungs-/Bildoriginale erhalten. Separater Werkzeugauftrag erforderlich. |
| H-04 | erfüllt im bisherigen Produktionsscope | Echte ursprüngliche Bild-/Motivfreigaben und konkreter Korrekturauftrag gelesen; keine neue Rasterwahl oder Endabnahme behauptet. |
| H-05 | nicht geprüft | Neue geschriebene ZIP-/Inventar-/Projektionsprüfung erfolgt durch Builder; fehlende Inhaltsqualifikation und echte Endabnahme bleiben getrennt offen. |
| H-06 | erfüllt als gebundene Vergleichsbewertung | Exakter vorläufiger Input und unabhängiger vollständiger Import des Original-0.4-Bündels: L1, medium. Kein Export-/Katalogstand. |

Keine redaktionelle Ausnahme beantragt oder erfunden. Q-M02 ist ein offengelegter Detailvorbehalt, keine neue Abnahme. H-03 und die fehlenden Q-H-Sichtungen verhindern ein qualifiziertes Angebot.
