# Drei isolierte Kontextangebote · bg01

A-b01: Gartenbeet mit Gießkanne.
B-b01: Ernteplatz mit leerem Korb und Werkzeug.
C-b01: Gartentisch mit Tasse und Margeriten.

Alle drei tatsächlichen ImageGen-Ausgaben wurden einzeln im Chat angezeigt und als unveränderte Einzeldateien gesichert: background/original/A-b01.png, background/original/B-b01.png und background/original/C-b01.png. Zusätzlich werden bytegleiche direkte Originale in content/authoring/pz-erdbeere/evidence/r06-background bereitgestellt. Keine Kontaktmontage, Buchvorschau oder Kandidaten-Testintegration. Die neue Paketprojektion bietet dieselben drei Originale an.

Keine Empfehlung gilt als menschliche Wahl. Hintergrundentscheidung und Endabnahme sind offen. Auswahl: A, B, C, gezielte Korrektur oder ausdrücklich none.
