"""Compact background authority, separate from historical production.

A freshly verified v6 registration creates v1. An authorized HP-I1b2 change
retains that exact initial authority in v2 and replaces only the current image
binding. After retirement inner references are identities, not file requests.
"""
from copy import deepcopy
from io import BytesIO
from pathlib import Path
import os
import re
import stat
import zipfile

from . import authoring_package as ap, background_contract as bc, background_package as bp
from . import catalog_io as io, catalog_rating as rating
from .contract import canonical_bytes, exact_keys, integer, InvalidInput

FORMAT = "picross-catalog-background-v1"
CHANGE_FORMAT = "picross-catalog-background-v2"
CHANGE_JOURNAL = "picross-background-adoption-journal-v1"
REGISTRY_FORMAT = "picross-content-registry-v3"
REBIND_FORMATS = ("picross-catalog-background-v3", "picross-catalog-background-v4")
EDITOR_FORMAT = "picross-catalog-background-v5"
RUNTIME_FORMAT = "picross-runtime-registry-v6"
RECEIPT_FORMAT = "picross-integrated-content-v2"
PATH = "content/backgrounds"
ASSET_PATH = "game/art/backgrounds"
CAPABILITY = "game/data/background-capability.json"
CAPABILITY_FORMAT = "picross-runtime-background-capability-v1"
LIMIT = 1024 * 1024
CAPABILITY_LIMIT = 4096
IMAGE_FIELDS = ("image_revision", "candidate_revision", "decision", "derivation",
                "provenance", "review", "asset", "notice")


def initial(source):
    """Return the immutable first-registration authority of a validated source."""
    if source["format"] == EDITOR_FORMAT:
        previous = source["origin"]["source"]
        return initial(previous) if previous is not None else None
    if source["format"] in REBIND_FORMATS: return initial(source["base"])
    return source["initial"] if source["format"] == CHANGE_FORMAT else source


def current(source):
    """Return current image fields without changing the serialized source form."""
    if source["format"] in REBIND_FORMATS:
        from .background_rebind import image
        return image(source)
    return source["current"] if source["format"] in (CHANGE_FORMAT, EDITOR_FORMAT) else source


def effective(source):
    """Internal view only: original identity plus effective current image fields."""
    if source["format"] == EDITOR_FORMAT:
        return {**current(source), "identity": source["binding"]["identity"]}
    result = {**initial(source), **{field: current(source)[field] for field in IMAGE_FIELDS}}
    if source["format"] in REBIND_FORMATS:
        result["identity"] = source["events"][-1]["binding"]["identity"]
    return result


def initial_ref(source):
    original = initial(source)
    ap.require(original is not None, "Source-free editor background has no historical HP initial source")
    return ref(path(original["puzzle_id"]), encoded(original))


def path(identifier):
    return PATH + "/" + rating.identity(identifier) + ".json"


def asset_path(identifier):
    return ASSET_PATH + "/" + rating.identity(identifier) + ".png"


def notice_path(identifier):
    return ASSET_PATH + "/" + rating.identity(identifier) + ".txt"


def encoded(value):
    return canonical_bytes(value) + b"\n"


def ref(name, raw):
    return {"file": name, "sha256": io.checksum(raw), "bytes": len(raw)}


def _ref(value, *, name=None, limit=ap.MAX_FILE):
    exact_keys(value, {"file", "sha256", "bytes"})
    ap.relative(value["file"]); ap.sha(value["sha256"])
    integer(value["bytes"], 0, limit, "background reference bytes")
    ap.require(name is None or value["file"] == name, "Wrong background reference path")
    return value


def _bound(value, raw, *, name=None, limit=ap.MAX_FILE):
    _ref(value, name=name, limit=limit)
    ap.require(raw is not None and value["bytes"] == len(raw) and value["sha256"] == io.checksum(raw),
               "Background reference size/hash differs: " + value["file"])
    return raw


def _raw(root, name, limit, texts=None, *, missing=False):
    if texts is not None and name in texts:
        raw = texts[name]
        raw = raw.encode("utf-8") if isinstance(raw, str) else raw
        ap.require(raw is None and missing or isinstance(raw, bytes) and len(raw) <= limit,
                   "Missing/oversized background text: " + name)
        return raw
    ap.require(root is not None, "Missing bound background text: " + name)
    return io.read(root, name, limit, missing=missing)


def capability(root, texts=None, *, required=False):
    raw = _raw(root, CAPABILITY, CAPABILITY_LIMIT, texts, missing=True)
    enabled = False
    if raw is not None:
        value = exact_keys(io.json_bytes(raw, CAPABILITY_LIMIT), {"format", "runtime_format", "profile_id", "enabled"})
        ap.require(value["format"] == CAPABILITY_FORMAT and value["runtime_format"] == RUNTIME_FORMAT and
                   value["profile_id"] == bc.PROFILE["id"] and type(value["enabled"]) is bool,
                   "Invalid background capability")
        enabled = value["enabled"]
    ap.require(not required or enabled, "Background export v6 requires enabled compatible target capability")
    return enabled


def index(registry):
    rows = registry.get("backgrounds", [])
    ap.require(isinstance(rows, list) and len(rows) <= len(registry["entries"]), "Invalid background index")
    ids = {e["id"] for e in registry["entries"]}
    found = {}
    for row in rows:
        exact_keys(row, {"id", "source"})
        identifier = rating.identity(row["id"])
        ap.require(identifier in ids and identifier not in found, "Unknown/duplicate background ID")
        found[identifier] = _ref(row["source"], name=path(identifier), limit=LIMIT)
    ap.require(list(found) == sorted(found), "Background index must be sorted")
    return found


def text_names(registry):
    return {CAPABILITY} | {name for e in registry["entries"] for name in (path(e["id"]), notice_path(e["id"]))}


def source_paths(root, *registries, temporary=()):
    ids = {identifier for registry in registries for identifier in index(registry)}
    allowed = ({path(i) for i in ids}, {p for i in ids for p in (asset_path(i), notice_path(i))})
    result = []
    for base_name, names in zip((PATH, ASSET_PATH), allowed):
        base = io.safe(root, base_name)
        found = set()
        if base.exists():
            ap.require(base.is_dir(), "Background namespace must be a directory")
            for child in base.iterdir():
                name = child.relative_to(root).as_posix()
                child = io.safe(root, name)
                ap.require(name in names or name in temporary, "Unknown/noncanonical background source: " + name)
                ap.require(child.is_file() and (os.name == "nt" or not child.stat().st_mode & 0o111),
                           "Background source must be regular nonexecutable data")
                if name not in temporary: found.add(name)
        ap.require(len(found) <= 20000, "Too many background sources")
        result.append(found)
    return tuple(result)


def _approval(value, package, test_only):
    exact_keys(value, {"format", "actor", "timestamp_utc", "statement", "puzzle_id", "revision",
                       "handoff_sha256", "inventory_sha256", "selection", "test_only", "original_zip_sha256", "background"})
    ap.require(value["format"] == "picross-editorial-approval-v2", "Wrong historical background approval format")
    for field in ("actor", "statement"): ap.string(value[field], "approval " + field)
    ap.timestamp(value["timestamp_utc"])
    ap.require(all(value[k] == package[k] for k in package) and type(value["test_only"]) is bool and
               value["test_only"] == test_only, "Historical background approval identity differs")
    selection = exact_keys(value["selection"], {"variant", "matrix_hash", "logic_hash", "reveal"})
    ap.string(selection["variant"], "approval variant")
    for field in ("matrix_hash", "logic_hash"): ap.sha(selection[field])
    exact_keys(selection["reveal"], {"file", "sha256"})
    ap.relative(selection["reveal"]["file"]); ap.sha(selection["reveal"]["sha256"])
    background = exact_keys(value["background"], {"manifest", "decision", "derivation", "outcome", "candidate_id",
                                                 "original", "output", "profile_sha256"})
    for field in ("manifest", "decision", "derivation"):
        bp._stored(background[field], False)
    ap.sha(background["profile_sha256"])
    return background


def _diagnostics(value, selected):
    exact_keys(value, {"source", "output", "upscaled"})
    if not selected:
        ap.require(all(v is None for v in value.values()), "none has image diagnostics")
        return
    ap.require(type(value["upscaled"]) is bool, "Invalid background upscale diagnostic")
    for key in ("source", "output"):
        d = exact_keys(value[key], {"format", "mode", "width", "height", "alpha"})
        ap.require(d["format"] == "PNG" and d["mode"] == "RGBA", "Invalid background image diagnostic")
        for field in ("width", "height"): integer(d[field], 1, 16384, "background axis")
        alpha = exact_keys(d["alpha"], {"min", "max", "transparent_pixels", "partial_pixels", "opaque_pixels"})
        integer(alpha["min"], 0, 255, "alpha minimum"); integer(alpha["max"], 0, 255, "alpha maximum")
        for field in ("transparent_pixels", "partial_pixels", "opaque_pixels"):
            integer(alpha[field], 0, d["width"] * d["height"], "alpha pixels")
        ap.require(alpha["min"] == 0 < alpha["max"] and alpha["transparent_pixels"] > 0 and
                   sum(alpha[f] for f in ("transparent_pixels", "partial_pixels", "opaque_pixels")) == d["width"] * d["height"] and
                   alpha["transparent_pixels"] < d["width"] * d["height"], "Invalid background alpha diagnostic")
        if key == "output": ap.require((d["width"], d["height"]) == (2304, 576), "Wrong background output dimensions")


def _derivation(value, decision, approval, test_only):
    exact_keys(value, {"format", "request_sha256", "request", "puzzle_id", "job_id", "background_revision", "manifest",
                       "decision", "outcome", "candidate_id", "source", "profile", "profile_sha256", "tool", "tool_sha256",
                       "output", "diagnostics", "test_only"})
    ap.require(value["format"] == "picross-background-derivation-v1", "Wrong historical background derivation format")
    request = bc.validate_request(value["request"])
    ap.require(ap.sha(value["request_sha256"]) == bc.digest(request) and
               all(value[k] == request[k] for k in ("manifest", "decision", "source", "profile")) and
               value["manifest"] == decision["manifest"] == approval["manifest"]["ref"] and
               value["decision"] == approval["decision"]["ref"] and
               value["source"] == decision["original"] == approval["original"] and
               all(value[k] == decision[k] for k in ("puzzle_id", "job_id", "background_revision", "outcome", "candidate_id")) and
               value["outcome"] == approval["outcome"] and value["candidate_id"] == approval["candidate_id"] and
               value["output"] == approval["output"] and
               value["profile_sha256"] == approval["profile_sha256"] == bc.digest(bc.PROFILE) and
               type(value["test_only"]) is bool and value["test_only"] == test_only,
               "Historical background derivation binding differs")
    tool = exact_keys(value["tool"], {"id", "commit", "dirty", "versions", "modules"})
    ap.require(tool["id"] == "picross-background-1" and isinstance(tool["commit"], str) and
               re.fullmatch(r"[0-9a-f]{40}", tool["commit"]) and type(tool["dirty"]) is bool,
               "Invalid historical background tool")
    versions = exact_keys(tool["versions"], {"python", "pillow", "zlib", "littlecms"})
    for v in versions.values(): ap.string(v, "historical codec")
    ap.require(versions["pillow"] == "12.3.0", "Wrong historical background Pillow contract")
    modules = tool["modules"]
    ap.require(isinstance(modules, list) and len(modules) == 9, "Invalid historical background module inventory")
    names = []
    for row in modules:
        exact_keys(row, {"file", "sha256"}); ap.relative(row["file"]); ap.sha(row["sha256"]); names.append(row["file"])
    expected_modules = ["tools/puzzle_production/" + name + ".py" for name in (
        "__init__", "authoring_package", "background_assets", "background_contract", "background_io", "catalog_io",
        "contract", "image_normalization", "operation_diagnostics")]
    ap.require(names == expected_modules and
               ap.sha(value["tool_sha256"]) == request["expected_tool_sha256"] == bc.digest(tool),
               "Historical background tool binding differs")
    _diagnostics(value["diagnostics"], decision["outcome"] == "selected")
    return value


def _active(value, entry, binding, test_only):
    decision = bc.validate_decision(value["decision"])
    ap.require(decision["puzzle_id"] == entry["id"] and decision["test_only"] == test_only and
               decision["outcome"] in ("selected", "none"), "Wrong active background decision")
    derivation = _derivation(value["derivation"], decision, binding, test_only)
    if decision["outcome"] == "selected":
        bc._revision(value["candidate_revision"])
        bc._provenance(value["provenance"]); bc._review(value["review"], decision["original"])
        ap.require(value["provenance"]["rights_status"] == "resolved" and value["review"] is not None,
                   "Background requires resolved rights and review")
        accepted = {r["criterion"] for r in decision["accepted_deviations"]}
        ap.require(all(row["result"] == "erfüllt" or key != "Q-HG01" and key in accepted and
                       row["result"] in ("Warnung", "nicht erfüllt") for key, row in value["review"].items()),
                   "Background review is not ready")
        _ref(derivation["output"], name="background.png", limit=bc.MAX_PNG)
        _ref(value["asset"], name=asset_path(entry["id"]), limit=bc.MAX_PNG)
        _ref(value["notice"], name=notice_path(entry["id"]), limit=65536)
        ap.require(all(value["asset"][k] == derivation["output"][k] for k in ("sha256", "bytes")),
                   "Background output binding differs")
    else:
        ap.require(all(value[k] is None for k in ("candidate_revision", "provenance", "review", "asset", "notice")) and
                   derivation["output"] is None, "none must not carry an image, notice or candidate")


def _validate_v1(value, entry):
    try:
        # The existing background JSON parser enforces depth 32, bounded keys,
        # duplicate-key rejection and exact JSON scalar types, without I/O.
        bc._json_tree(value)
        raw = encoded(value)
        ap.require(len(raw) <= LIMIT, "Background source exceeds 1 MiB")
        value = bc.parse_json(raw)
        exact_keys(value, {"format", "puzzle_id", "identity", "origin", "image_revision", "candidate_revision",
                           "decision", "derivation", "provenance", "review", "asset", "notice", "test_only"})
        ap.require(value["format"] == FORMAT and value["puzzle_id"] == entry["id"] and
                   type(value["test_only"]) is bool and value["test_only"] == entry["production"]["test_only"],
                   "Wrong background source identity")
        identity = exact_keys(value["identity"], {"key", "save_slot", "definition", "runtime_revision"})
        ap.require(all(identity[k] == entry[k] for k in ("key", "save_slot")), "Background slot/key differs")
        _ref(identity["definition"], name="game/" + entry["definition"], limit=2 * LIMIT)
        ap.require(identity["definition"]["sha256"] == entry["production"]["definition_sha256"], "Background definition binding differs")
        integer(identity["runtime_revision"], 1, 1000000, "background runtime revision")
        integer(value["image_revision"], 1, 1000000, "active background revision")
        ap.require(value["image_revision"] == 1, "Background replacement requires HP-I1b2")
        origin = exact_keys(value["origin"], {"package", "export_manifest_sha256", "original_package", "manifest", "approval_ref", "approval"})
        ap.require(origin["package"] == entry["production"]["package"] ==
                   "content/packages/" + entry["id"] + "/" + entry["production"]["revision"], "Background package path differs")
        ap.sha(origin["export_manifest_sha256"])
        package = exact_keys(origin["original_package"], {"puzzle_id", "revision", "original_zip_sha256", "handoff_sha256", "inventory_sha256"})
        ap.require(package["puzzle_id"] == entry["id"] and package["revision"] == entry["production"]["revision"], "Background original identity differs")
        for field in ("original_zip_sha256", "handoff_sha256", "inventory_sha256"): ap.sha(package[field])
        bp._stored(origin["manifest"], False)
        _ref(origin["approval_ref"], name="approval.json", limit=128 * 1024)
        approval = _approval(origin["approval"], package, value["test_only"])
        ap.require(origin["manifest"] == approval["manifest"], "Background original manifest differs")
        ap.require(origin["approval"]["selection"]["reveal"]["sha256"] == entry["production"]["reveal_sha256"],
                   "Historical background approval binds another reveal")
        _active(value, entry, approval, value["test_only"])
        return value
    except bc.BackgroundError as exc:
        raise InvalidInput("Background source: " + str(exc)) from exc


def _adoption(value, original, *, rebound=False):
    exact_keys(value, {"request", "revision", "target", "background", "authorization"})
    bc._revision(value["revision"])
    directory = "content/authoring/" + original["puzzle_id"] + "/" + value["revision"]
    _ref(value["request"], name=directory + "/record.json", limit=bc.MAX_JSON)
    target = exact_keys(value["target"], {"source", "origin_sha256", "image_revision"})
    _ref(target["source"], name=path(original["puzzle_id"]), limit=LIMIT)
    ap.sha(target["origin_sha256"])
    integer(target["image_revision"], 1, 999999, "previous background revision")
    ap.require(target["origin_sha256"] == origin_hash(original), "Background change has another origin")
    if target["image_revision"] == 1 and not rebound:
        ap.require(target["source"] == initial_ref(original), "First background change has another initial source")
    binding = bp.validate_binding(value["background"], package_only=False)
    ap.require(binding["history"] is None, "Background change cannot omit historical candidates")
    for field in ("manifest", "decision", "derivation"):
        stored = binding[field]
        ap.require(stored is not None and stored["storage"] == "external" and
                   bp._join(stored["root"], stored["ref"]["file"]).startswith(directory + "/"),
                   "Background change reference leaves its authoring revision")
    bc._human(value["authorization"])
    ap.relative(directory + "/" + value["authorization"]["evidence"]["file"])
    return binding


def validate(value, entry):
    """Validate both closed generations without opening historical file refs."""
    try:
        bc._json_tree(value)
        raw = encoded(value)
        ap.require(len(raw) <= LIMIT, "Background source exceeds 1 MiB")
        value = bc.parse_json(raw)
        ap.require(isinstance(value, dict), "Background source must be an object")
        if value.get("format") in REBIND_FORMATS:
            from . import background_rebind
            return background_rebind.validate(value, entry)
        if value.get("format") == EDITOR_FORMAT:
            from . import editor_image_source as editor
            editor.validate(value)
            expected = deepcopy(entry)
            expected["production"]["package_sha256"] = value["binding"]["entry"]["production"]["package_sha256"]
            ap.require(expected == value["binding"]["entry"], "Current editor background production differs")
            return value
        if value.get("format") != CHANGE_FORMAT:
            return _validate_v1(value, entry)
        exact_keys(value, {"format", "initial", "current"})
        original = _validate_v1(value["initial"], entry)
        validate_image(value["current"], original, entry)
        return value
    except bc.BackgroundError as exc:
        raise InvalidInput("Background source: " + str(exc)) from exc


def validate_image(active, original, entry, *, rebound=False):
    active = exact_keys(active, set(IMAGE_FIELDS) | {"adoption"})
    integer(active["image_revision"], 2, 1000000, "active background revision")
    binding = _adoption(active["adoption"], original, rebound=rebound)
    target = active["adoption"]["target"]
    ap.require(active["image_revision"] == target["image_revision"] + 1,
               "Background revision must follow its bound predecessor")
    decision = bc.validate_decision(active["decision"])
    derivation = active["derivation"]
    ap.require(isinstance(derivation, dict), "Invalid current background derivation")
    # Preserve the complete original decision and report. The new adoption
    # binds their locations; it is not a rewritten raster end approval.
    authority = {**{key: binding[key] for key in ("manifest", "decision", "derivation")},
                 "outcome": decision["outcome"], "candidate_id": decision["candidate_id"],
                 "original": decision["original"], "output": derivation.get("output"),
                 "profile_sha256": derivation.get("profile_sha256")}
    _active(active, entry, authority, original["test_only"])
    ap.require(binding["decision"]["ref"] == ref(binding["decision"]["ref"]["file"], encoded(decision)),
               "Current background decision ref differs from its retained bytes")
    ap.require(binding["derivation"]["ref"] == ref(binding["derivation"]["ref"]["file"], encoded(derivation)),
               "Current background derivation ref differs from its retained bytes")
    if decision["outcome"] == "selected":
        candidate = {"id": decision["candidate_id"], "revision": active["candidate_revision"],
                     "provenance": active["provenance"]}
        _bound(active["notice"], notice_bytes(entry["id"], candidate), name=notice_path(entry["id"]), limit=65536)
    return active


def notice_bytes(identifier, candidate):
    """Use the original background notice wording for a checked candidate."""
    if candidate is None:
        return None
    p = candidate["provenance"]
    lines = ["Production ID: " + identifier, "Background: " + candidate["id"],
             "Image revision: " + candidate["revision"], "Artwork: " + p["author"], "Source: " + p["source"],
             "Usage basis: " + p["usage_basis"]]
    if p["attribution"] is not None:
        lines.append("Attribution: " + p["attribution"])
    raw = ("\n".join(lines) + "\n").encode("utf-8")
    ap.require(len(raw) <= 65536, "Background notice exceeds byte limit")
    return raw


def _transition(previous, following):
    if following["format"] == EDITOR_FORMAT and previous["format"] != EDITOR_FORMAT:
        from . import editor_image_source as editor
        editor.validate(following)
        adoption = following["current"]["authority"].get("adoption")
        target = adoption.get("target") if isinstance(adoption, dict) else None
        ap.require(following["origin"]["source"] == previous and
                   following["binding"] == {key: following["origin"][key] for key in ("entry", "identity")} and
                   following["current"]["authority"]["kind"] == "production" and
                   following["record_revision"] == max(previous.get("record_revision", 0), current(previous)["image_revision"]) + 1 and
                   following["current"]["image_revision"] == current(previous)["image_revision"] + 1 and
                   target == {"source": ref(path(following["id"]), encoded(previous)),
                              "origin_sha256": origin_hash(previous), "image_revision": current(previous)["image_revision"]},
                   "First editor background adoption changes its actual predecessor")
        ap.require(not (current(previous)["decision"]["outcome"] == following["current"]["status"] == "none"),
                   "Unchanged none cannot create another image revision")
        return
    if previous["format"] == EDITOR_FORMAT:
        from . import editor_image_source as editor
        editor.transition(previous, following, operation="background-adoption")
        target = following["current"]["authority"]["adoption"]["target"]
        ap.require(target == {"source": ref(path(previous["id"]), encoded(previous)),
                              "origin_sha256": origin_hash(previous), "image_revision": current(previous)["image_revision"]},
                   "Background adoption does not bind its immediately previous source")
        return
    if previous["format"] in REBIND_FORMATS:
        from .background_rebind import transition, normalized
        ap.require(following["format"] == previous["format"], "Background change cannot downgrade or change rebind source generation")
        transition(previous, following, normalized(previous), normalized(following), "background-adoption")
        return
    ap.require(following["format"] == CHANGE_FORMAT and
               encoded(initial(previous)) == encoded(initial(following)),
               "Background change modifies its immutable initial authority")
    old, new = current(previous), current(following)
    target = new["adoption"]["target"]
    ap.require(target == {"source": ref(path(initial(previous)["puzzle_id"]), encoded(previous)),
                          "origin_sha256": origin_hash(previous), "image_revision": old["image_revision"]},
               "Background change does not bind the immediately previous source")
    ap.require(not (old["decision"]["outcome"] == new["decision"]["outcome"] == "none"),
               "An unchanged none decision cannot create another image revision")
    ap.require(any(encoded(old[k]) != encoded(new[k]) for k in IMAGE_FIELDS if k != "image_revision"),
               "Background change has no new active binding")


def build_change(old_source, entry, request, request_ref, graph, notice_raw):
    """Project freshly checked change inputs; graph is never a persisted proof.

    The caller must run background_package.validate_change with the actual
    working files and bind the exact immutable request bytes before publication.
    """
    old_source = validate(old_source, entry)
    exact_keys(request, {"format", "puzzle_id", "revision", "target", "background", "authorization", "files", "test_only"})
    ap.require(request["format"] == "picross-background-adoption-request-v1" and
               request["puzzle_id"] == entry["id"] and type(request["test_only"]) is bool and
               request["test_only"] == initial(old_source)["test_only"], "Wrong background change request identity")
    bc._revision(request["revision"])
    directory = "content/authoring/" + entry["id"] + "/" + request["revision"]
    _bound(request_ref, encoded(request), name=directory + "/record.json", limit=bc.MAX_JSON)
    ap.require(graph["ready"] is True and encoded(graph["binding"]) == encoded(request["background"]),
               "Background change needs the freshly checked exact binding")
    work = bc.validate_manifest(graph["manifest"])
    decision = bc.validate_decision(graph["decision"])
    ap.require(work["puzzle_id"] == entry["id"] and work["test_only"] == request["test_only"],
               "Background work identity differs from target")
    candidate = bc._bind_decision(work, decision)
    ap.require(not bp._readiness(work, decision, candidate, graph["derivation"])[1],
               "Background change is not ready")
    ap.require(notice_raw == notice_bytes(entry["id"], candidate), "Background notice differs from checked provenance")
    png = graph["asset_bytes"]
    if candidate is None:
        ap.require(png is None, "none change cannot carry image bytes")
    else:
        _bound(graph["derivation"]["output"], png, name="background.png", limit=bc.MAX_PNG)
    active = {"image_revision": current(old_source)["image_revision"] + 1,
              "candidate_revision": candidate["revision"] if candidate else None,
              "decision": deepcopy(decision), "derivation": deepcopy(graph["derivation"]),
              "provenance": deepcopy(candidate["provenance"]) if candidate else None,
              "review": deepcopy(candidate["review"]) if candidate else None,
              "asset": ref(asset_path(entry["id"]), png) if png is not None else None,
              "notice": ref(notice_path(entry["id"]), notice_raw) if notice_raw is not None else None,
              "adoption": {"request": deepcopy(request_ref),
                           **{key: deepcopy(request[key]) for key in ("revision", "target", "background", "authorization")}}}
    if old_source["format"] in REBIND_FORMATS:
        from .background_rebind import append
        source = append(old_source, entry, old_source["events"][-1]["binding"], "background-adoption", image=active)
    else:
        source = validate({"format": CHANGE_FORMAT, "initial": deepcopy(initial(old_source)), "current": active}, entry)
    _transition(old_source, source)
    return source


def validate_delta(journal, before, after, root=None):
    """Close the one-target image mutation independently of authoring files.

    Recovery reads compact old/new authorities and the journal's bound binary
    sides; it does not need a retired working directory or raster ZIP.
    """
    from . import background_rebind as rebind
    from .catalog_transaction import PE_FORMATS, IMAGE_FORMATS
    from .content_registry import METADATA_FORMAT
    pe = journal["format"] in (PE_FORMATS["background-adoption"], IMAGE_FORMATS["background-adoption"])
    images = journal["format"] == IMAGE_FORMATS["background-adoption"]
    ap.require(journal["format"] in (CHANGE_JOURNAL, rebind.BACKGROUND, PE_FORMATS["background-adoption"], IMAGE_FORMATS["background-adoption"]) and journal["operation"] == "background-adoption" and
               journal["additions"] == {} and journal["report_run"] is None,
               "Invalid background adoption journal operation")
    ap.require(before["format"] == after["format"] == (METADATA_FORMAT if pe else REGISTRY_FORMAT) and
               encoded(before["entries"]) == encoded(after["entries"]),
               "Background adoption changes catalog entries")
    previous_index, following_index = index(before), index(after)
    ap.require(previous_index.keys() == following_index.keys(), "Background adoption changes declared target IDs")
    changed = [identifier for identifier in previous_index if previous_index[identifier] != following_index[identifier]]
    ap.require(len(changed) == 1, "Background adoption requires exactly one changed source")
    identifier = changed[0]
    entry = next(e for e in before["entries"] if e["id"] == identifier)
    previous = _source(None, before, entry, journal["old"])
    following = _source(None, after, entry, journal["new"])
    ap.require(images or previous["format"] != EDITOR_FORMAT and following["format"] != EDITOR_FORMAT,
               "Editor background source requires its explicit journal generation")
    ap.require(pe or rebind.is_rebound(previous) == (journal["format"] == rebind.BACKGROUND),
               "Background journal generation differs from target")
    _transition(previous, following)
    for side, source in (("old", previous), ("new", following)):
        capability(root, journal[side], required=True)
        value = current(source)
        raw = _raw(None, notice_path(identifier), 65536, journal[side], missing=True)
        if value["notice"] is None:
            ap.require(raw is None, "none background journal has a notice")
        else:
            _bound(value["notice"], raw, name=notice_path(identifier), limit=65536)
    old_asset, new_asset = current(previous)["asset"], current(following)["asset"]
    replacements = journal["replacements"]
    if old_asset == new_asset:
        ap.require(replacements == {}, "Unchanged background bytes are not a replacement")
    else:
        ap.require(set(replacements) == {asset_path(identifier)}, "Wrong background replacement paths")
        pair = exact_keys(replacements[asset_path(identifier)], {"old", "new"})
        for side, asset in (("old", old_asset), ("new", new_asset)):
            binary = pair[side]
            if asset is None:
                ap.require(binary is None, "Background absence requires a null binary side")
            else:
                ap.require(isinstance(binary, dict) and
                           all(binary.get(k) == asset[k] for k in ("sha256", "bytes")),
                           "Background binary side differs from its active source")
    return {path(identifier), notice_path(identifier), "content/registry.json", "game/data/registry.json"}


def build(export_dir, manifest, report, entry):
    """Project the actual bound originals; caller must first fully verify v6.

    This reads only the active original metadata; it never synthesizes a proof,
    approval or tool identity. Full input/stage replay remains the caller's gate.
    """
    try:
        return _build(export_dir, manifest, entry)
    except (bc.BackgroundError, zipfile.BadZipFile) as exc:
        raise InvalidInput("Invalid background production metadata: " + str(exc)) from exc


def _build(export_dir, manifest, entry):
    ap.require(manifest.get("format") == "picross-target-export-v6", "Background source requires a v6 export")
    approval_raw = io.read(export_dir, "approval.json", 128 * 1024)
    approval = io.json_bytes(approval_raw, 128 * 1024)
    binding = approval["background"]
    original_ref = manifest["input"]["original_package"]
    original_raw = io.read(export_dir, "input/package.zip", ap.MAX_ZIP)
    _bound(original_ref, original_raw, name="input/package.zip", limit=ap.MAX_ZIP)
    ap.require(approval["original_zip_sha256"] == original_ref["sha256"] and
               manifest["approval_sha256"] == io.checksum(approval_raw) and
               all(canonical_bytes(approval[k]) == canonical_bytes(manifest[k]) for k in ("background", "selection", "handoff_sha256", "inventory_sha256", "test_only")),
               "Original background approval/export bindings differ")
    with zipfile.ZipFile(BytesIO(original_raw)) as archive:
        # Match the existing original-ZIP namespace, including its permitted
        # single outer package directory, without extracting/replaying images.
        infos = archive.infolist()
        ap.require(len(infos) <= ap.MAX_FILES * 2, "Too many original ZIP members")
        seen, leaves, total = set(), [], 0
        for info in infos:
            name = ap.relative(info.filename.rstrip("/"))
            ap.require(name.casefold() not in seen, "Duplicate original ZIP member")
            seen.add(name.casefold())
            ap.require(stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG, stat.S_IFDIR) and
                       not info.flag_bits & 1 and info.file_size <= ap.MAX_FILE,
                       "Unsafe/oversized original ZIP member")
            total += info.file_size
            ap.require(total <= ap.MAX_TOTAL, "Expanded original ZIP exceeds limit")
            if not info.is_dir(): leaves.append(name)
        ap.require(len(leaves) <= ap.MAX_FILES, "Too many original ZIP files")
        keys = {name.casefold() for name in leaves}
        ap.require(all(not any("/".join(name.casefold().split("/")[:n]) in keys
                       for n in range(1, len(name.split("/")))) for name in leaves), "Original ZIP file/directory collision")
        roots = {name.split("/")[0] for name in leaves}
        ap.require("handoff.json" in keys or len(roots) == 1, "Original ZIP requires a single package root")
        prefix = "" if "handoff.json" in keys else next(iter(roots)) + "/"
        def read(stored):
            bp._stored(stored, False)
            r = stored["ref"]
            name = bp._join(stored["root"], r["file"])
            if stored["storage"] == "package":
                info = archive.getinfo(prefix + name)
                ap.require(info.file_size <= bc.MAX_JSON, "Background metadata ZIP member exceeds limit")
                with archive.open(info) as stream: raw = stream.read(bc.MAX_JSON + 1)
            else:
                raw = io.read(export_dir, "external/" + name, bc.MAX_JSON)
            _bound(r, raw, limit=bc.MAX_JSON)
            return io.json_bytes(raw, bc.MAX_JSON)
        work = bc.validate_manifest(read(binding["manifest"]))
        decision = read(binding["decision"])
        derivation = read(binding["derivation"])
    decision = bc.validate_decision(decision)
    ap.require(work["puzzle_id"] == entry["id"] and work["test_only"] == manifest["test_only"], "Original background work identity differs")
    candidate = bc._bind_decision(work, decision)
    def live(field):
        r = manifest[field]
        if r is None: return None
        raw = io.read(export_dir, r["file"], bc.MAX_PNG if field == "background_asset" else 65536)
        _bound(r, raw)
        return {**r, "file": "game/" + r["file"].removeprefix("runtime/")}
    definition = io.read(export_dir, manifest["definition"], 2 * LIMIT)
    source = {"format": FORMAT, "puzzle_id": entry["id"],
        "identity": {"key": entry["key"], "save_slot": entry["save_slot"],
                     "definition": ref("game/" + entry["definition"], definition), "runtime_revision": manifest["runtime_revision"]},
        "origin": {"package": entry["production"]["package"],
                   "export_manifest_sha256": io.file_hash(export_dir, "manifest.json", 8 * LIMIT),
                   "original_package": {k: approval[k] for k in ("puzzle_id", "revision", "original_zip_sha256", "handoff_sha256", "inventory_sha256")},
                   "manifest": deepcopy(binding["manifest"]), "approval_ref": ref("approval.json", approval_raw), "approval": approval},
        "image_revision": 1, "candidate_revision": candidate["revision"] if candidate else None,
        "decision": decision, "derivation": derivation,
        "provenance": deepcopy(candidate["provenance"]) if candidate else None,
        "review": deepcopy(candidate["review"]) if candidate else None,
        "asset": live("background_asset"), "notice": live("background_notice"), "test_only": manifest["test_only"]}
    return validate(source, entry)


def _source(root, registry, entry, texts=None):
    refs = index(registry)
    r = refs.get(entry["id"])
    raw = _raw(root, path(entry["id"]), LIMIT, texts, missing=True)
    if r is None:
        ap.require(raw is None, "Undeclared background source")
        return None
    _bound(r, raw, name=path(entry["id"]), limit=LIMIT)
    value = validate(io.json_bytes(raw, LIMIT), entry)
    ap.require(value["format"] not in ("picross-catalog-background-v4", EDITOR_FORMAT) or registry["format"] == "picross-content-registry-v4",
               "Background source v4/v5 requires metadata registry v4")
    ap.require(raw == encoded(value), "Noncanonical background source")
    return value


def origin_hash(source):
    if source["format"] == EDITOR_FORMAT:
        return io.checksum(canonical_bytes(source["origin"]))
    return io.checksum(canonical_bytes(initial(source)["origin"]))


def receipt_binding(source, source_ref):
    ap.require(source["format"] != EDITOR_FORMAT,
               "Editor background retirement requires the independently bound receipt-v3 export source")
    return {"origin_sha256": origin_hash(source),
            "source": initial_ref(source)}


def _receipt(source, source_ref, receipt):
    if source["format"] == EDITOR_FORMAT:
        check_editor_receipt(source, receipt, source["binding"]["entry"])
        return
    value = exact_keys(receipt.get("background"), {"origin_sha256", "source"})
    ap.require(value == receipt_binding(source, source_ref), "Background receipt/index/origin binding differs")
    expected = (source["events"][-1]["binding"]["entry"]["production"]["package_sha256"]
                if source["format"] in REBIND_FORMATS else initial(source)["origin"]["export_manifest_sha256"])
    ap.require(receipt["entry"]["production"]["package_sha256"] == expected,
               "Background receipt changed original export anchor")


def check_editor_receipt(source, receipt, normalized_entry):
    """Keep old receipts exact; only v3 describes a later editor-era retirement."""
    from . import reveal_source as at, editor_image_source as editor
    ap.require(source["format"] == EDITOR_FORMAT and source["binding"]["entry"] == normalized_entry,
               "Editor background receipt has another current production")
    at.receipt(receipt, normalized_entry, receipt["notice_sha256"], background=True, editor=True)
    if receipt["format"] == editor.RECEIPT_FORMAT:
        ap.require(receipt["background"]["origin_sha256"] == origin_hash(source),
                   "Editor receipt changes its immutable image origin")
    elif receipt["format"] == RECEIPT_FORMAT:
        previous = source["origin"]["source"]
        ap.require(previous is not None and source["origin"]["entry"] == normalized_entry,
                   "Legacy background receipt cannot describe a later editor production")
        _receipt(previous, initial_ref(previous), receipt)
    else:
        ap.require(receipt["format"] == at.RECEIPT and source["origin"]["source"] is None and
                   source["origin"]["entry"] == normalized_entry,
                   "Source-free receipt cannot replace a background production anchor")
    return source


def _load_editor(root, registry, entry, source, texts=None):
    from . import reveal_source as at
    binding = source["binding"]
    definition = binding["identity"]["definition"]
    raw = _raw(root, definition["file"], 2 * LIMIT, texts)
    _bound(definition, raw, limit=2 * LIMIT)
    parsed = io.json_bytes(raw, 2 * LIMIT)
    ap.require(parsed.get("id") == entry["id"] and parsed.get("revision") == binding["identity"]["runtime_revision"],
               "Editor background current definition identity differs")
    active = current(source)
    capability(root, texts, required=active["status"] in ("selected", "none"))
    notice_raw = None
    for key, name, limit in (("asset", asset_path(entry["id"]), bc.MAX_PNG), ("notice", notice_path(entry["id"]), 65536)):
        raw = _raw(root, name, limit, texts, missing=True)
        if active[key] is None:
            ap.require(raw is None, "Image-free preference has a live background file")
        else:
            _bound(active[key], raw, name=name, limit=limit)
        if key == "notice":
            notice_raw = raw
    if notice_raw is not None and active["authority"]["kind"] == "manual":
        from . import editor_image_source as editor
        at.make_notice(notice_raw)
        original = source["origin"]["notice"]
        ap.require(original is None or notice_raw.startswith(original["text"].encode("utf-8")),
                   "Manual background notice removes origin attribution")
        block = editor.manual_notice(b"", active["authority"]["provenance"], active["authority"]["decision"])
        ap.require(notice_raw.endswith(block), "Manual background notice differs from its decision")
    original, _, _, _ = at.package(root, entry, background_snapshot=(registry, texts))
    ap.require(binding["entry"] == original, "Editor background normalized production differs")
    historical = source["origin"]["source"]
    if historical is not None and historical["format"] in REBIND_FORMATS:
        from .background_rebind import historical as check_historical
        check_historical(root, historical, texts)
    return source


def load(root, registry, entry, texts=None):
    source = _source(root, registry, entry, texts)
    if source is None:
        for name in (asset_path(entry["id"]), notice_path(entry["id"])):
            ap.require(not io.safe(root, name).exists(), "Legacy entry has background files")
        return None
    if source["format"] == EDITOR_FORMAT:
        return _load_editor(root, registry, entry, source, texts)
    active = effective(source)
    definition = active["identity"]["definition"]
    raw = _raw(root, definition["file"], 2 * LIMIT, texts)
    _bound(definition, raw, limit=2 * LIMIT)
    ap.require(io.json_bytes(raw, 2 * LIMIT)["revision"] == active["identity"]["runtime_revision"], "Background runtime revision differs")
    for key, name, limit in (("asset", asset_path(entry["id"]), bc.MAX_PNG), ("notice", notice_path(entry["id"]), 65536)):
        raw = _raw(root, name, limit, texts, missing=True)
        if active[key] is None: ap.require(raw is None, "none has a live background file")
        else: _bound(active[key], raw, name=name, limit=limit)
    manifest_raw = io.read(root, entry["production"]["package"] + "/manifest.json", 8 * LIMIT)
    manifest = io.json_bytes(manifest_raw, 8 * LIMIT)
    ap.require(io.checksum(manifest_raw) == entry["production"]["package_sha256"], "Background physical package binding differs")
    if manifest.get("format") == RECEIPT_FORMAT:
        _receipt(source, index(registry)[entry["id"]], manifest)
    elif source["format"] in REBIND_FORMATS:
        from . import background_rebind as rebind
        ap.require(manifest.get("format") in ("picross-target-export-v5", "picross-target-export-v6") and
                   entry["production"]["package_sha256"] == rebind.normalized(source)["production"]["package_sha256"],
                   "Rebound background production differs")
        update = next((e for e in reversed(source["events"]) if e["operation"] == "update"), None)
        exported = update["export_source"] if update else initial(source)
        ap.require((manifest["format"] == "picross-target-export-v6") == (exported is not None),
                   "Rebound export generation differs")
        if exported is not None:
            ap.require(build(io.safe(root, entry["production"]["package"]), manifest, None, entry) == exported,
                       "Rebound v6 export changes its approved background")
    else:
        ap.require(manifest.get("format") == "picross-target-export-v6" and
                   active["origin"]["export_manifest_sha256"] == entry["production"]["package_sha256"],
                   "Background source requires its original v6 export or v2 receipt")
        ap.require(canonical_bytes(build(io.safe(root, entry["production"]["package"]), manifest, None, entry)) == canonical_bytes(initial(source)),
                   "Active background source differs from original approved production")
    if source["format"] in REBIND_FORMATS:
        from .background_rebind import live
        live(root, source, entry, texts)
    return source


def check_receipt(root, registry, entry, receipt, texts=None):
    current_source = _source(root, registry, entry, texts)
    if current_source is not None and current_source["format"] == EDITOR_FORMAT:
        return check_editor_receipt(current_source, receipt, current_source["binding"]["entry"])
    source = load(root, registry, entry, texts)
    ap.require(source is not None and receipt.get("format") == RECEIPT_FORMAT, "Missing background receipt authority")
    _receipt(source, index(registry)[entry["id"]], receipt)
    return source


def retained_names(root, registry, texts=None):
    return {current(source)["asset"]["file"] for entry in registry["entries"]
            if (source := _source(root, registry, entry, texts)) is not None and current(source)["asset"] is not None}


def projection(registry, texts):
    result = {}
    for entry in registry["entries"]:
        source = _source(None, registry, entry, texts)
        source = current(source) if source is not None else None
        result[entry["id"]] = {"status": source.get("status", source.get("decision", {}).get("outcome")) if source else "legacy",
                               "image_revision": source["image_revision"] if source else None,
                               "asset": {**source["asset"], "file": source["asset"]["file"].removeprefix("game/")}
                               if source and source["asset"] else None}
    return result
