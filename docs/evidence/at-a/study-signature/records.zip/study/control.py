import json,subprocess,sys
from pathlib import Path
sys.path[:0]=['tools','.']
import p1_preflight as tc
from p1_product import require_clean_output
root=Path.cwd();ws=root/'artifacts/at-a-final/study-signature-fix';engine=next((root/'artifacts/at-a-start/native-dev/engine').glob('*console.exe'));project=ws/'game';env=tc.isolated_environment(ws/'smoke-profile','Windows')
r=subprocess.run([str(engine),'--headless','--path',str(project),'res://study/main.tscn','--','--zs1-smoke'],env=env,capture_output=True,timeout=300)
raw=r.stdout+r.stderr;(ws/'study-start.log').write_bytes(raw);output=raw.decode('utf-8');require_clean_output({'exit_code':r.returncode,'output':output,'name':'study-start'},'ZS1_STUDY_OK');print('STUDY_START_OK',len(raw),'original bytes',flush=True)
for relative in ('ui/main.gd','study/main.gd'):
 (project/relative).write_bytes(subprocess.check_output(['git','show','9cc58651518e3a28e97f46932d69554210b0abcb:game/'+relative]))
env=tc.isolated_environment(ws/'baseline-profile','Windows')
r=subprocess.run([str(engine),'--headless','--path',str(project),'--script','res://tests/zs1_tests.gd','--','--p1-capture'],env=env,capture_output=True,timeout=300)
raw=r.stdout+r.stderr;(ws/'baseline-zs1.log').write_bytes(raw);output=raw.decode('utf-8');print('BASELINE_STUDY_RESULT',r.returncode,flush=True);print('\n'.join(s for s in output.splitlines() if any(k in s for k in ('ZS1_TESTS','Invalid access','ZS1 FAIL'))),flush=True)
assert r.returncode==1 and "Invalid access of index '22'" in output and 'ZS1_TESTS checks=1062 failures=1' in output
print('HISTORICAL_STUDY_FAILURE_IDENTICAL_ON_BASE',flush=True)
