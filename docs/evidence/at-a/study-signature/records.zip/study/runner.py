import json,subprocess,sys
from pathlib import Path
sys.path[:0]=['tools','.']
import p1_preflight as tc
from p1_product import require_clean_output
from product_fixtures import copy_regression_game
from p1_evidence import source_identity
root=Path.cwd();ws=root/'artifacts/at-a-final/study-signature-fix';ws.mkdir();project=ws/'game'
copy_regression_game(root,project)
engine=next((root/'artifacts/at-a-start/native-dev/engine').glob('*console.exe'))
env=tc.isolated_environment(ws,'Windows')
identity=source_identity(root)
for name,args,marker in [('import',['--import'],None),('zs1',['--script','res://tests/zs1_tests.gd','--','--p1-capture'],'ZS1_TESTS_OK')]:
 r=subprocess.run([str(engine),'--headless','--path',str(project),*args],env=env,capture_output=True,timeout=300)
 raw=r.stdout+r.stderr;(ws/(name+'.log')).write_bytes(raw)
 text=raw.decode('utf-8',errors='strict')
 require_clean_output({'exit_code':r.returncode,'output':text,'name':name},marker)
 print(name,'PASS',len(raw),'original bytes',flush=True)
 record={'identity':identity,'files':{str(p.relative_to(root)).replace('\\','/'):tc.sha256_file(p) for p in [root/'game/ui/main.gd',root/'game/study/main.gd']},'engine_sha256':tc.sha256_file(engine),'phase':name,'log_sha256':tc.sha256_file(ws/(name+'.log'))}
 (ws/(name+'-binding.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('STUDY_SIGNATURE_REGRESSION_OK',flush=True)
