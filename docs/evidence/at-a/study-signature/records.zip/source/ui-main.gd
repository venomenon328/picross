extends Control
const Registry = preload("res://model/content_registry.gd")
const CatalogView = preload("res://ui/catalog.gd")
const Definition = preload("res://model/definition.gd")
const Session = preload("res://model/session.gd")
const Board = preload("res://ui/board.gd")
const ChalkboardBoard = preload("res://ui/chalkboard_board.gd")
const FullViewBoard = preload("res://ui/full_view_board.gd")
const Miniature = preload("res://ui/miniature.gd")
const Reveal = preload("res://ui/reveal.gd")
const Completion = preload("res://ui/completion.gd")
const SaveStore = preload("res://model/save_store.gd")
const WebStorage = preload("res://model/web_storage.gd")
var web_lifecycle_callback: JavaScriptObject
var web_leaving: bool = false
const BookButton = preload("res://ui/book_button.gd")
const BookSurface = preload("res://ui/book_surface.gd")
const BODY_FONT = preload("res://art/book/PlexSans.ttf")
const TITLE_FONT = preload("res://art/book/Fraunces.ttf")
const WORK_TITLE_FONT = preload("res://art/drawing/BaksoDaging-Regular.ttf")
const TOOL_IDS: Array[String] = ["fill","erase","undo","redo","minus","plus"]
var tools_scroll: ScrollContainer
var tools_column: GridContainer
var surface: BookSurface
var information: Control
var information_section: String = "settings"
var settings_panel: VBoxContainer
var help_panel: VBoxContainer
var info_scroll: ScrollContainer
var information_origin: String = "album"
var view_choice: OptionButton
var ui_scale_button: Button
var actions: Dictionary = {}
var laying_out: bool = false
var sessions: Array[Session] = []
var store: SaveStore
var slot_status: Array[String] = []
var slot_errors: Array[String] = []
var save_error: String = ""
var save_timer: Timer
var status_label: Label
var reset_dialog: ConfirmationDialog
var repair_dialog: ConfirmationDialog
var work_repair_button: Button
var session: Session
var board: Board
var mini: Miniature
var reveal_view: Completion
var album: CatalogView
var catalog_error: String = ""
var session_indices: Dictionary = {}
var reset_id: String = ""
var reset_origin: String = "album"
var repair_id: String = ""
var work: Control
var ending: Control
var completion_reset: BookButton
var title: Label
var album_button: Button
var undo_button: Button
var redo_button: Button
var coordinate: Label
var completion_title: Label
var layout_warning: Label
var stress_label: Label
var palette_row: Control
var sidebar: Control
var page: Control
var minimum_message: Label
var clue_reset_button: Button
var animation_toggle: CheckBox
var clue_completion_toggle: CheckBox
var mark_completed_clues: bool = true
var ui_scale: float = 1.0
var choices: Array[Button]:
	get: return album.choices
var album_previews: Array[Miniature]:
	get: return album.previews
var album_reveals: Array[Reveal]:
	get: return album.reveals
var album_slot_status: Array[Label]:
	get: return album.notes

static func bounded_start(usable: Rect2i, decorations: Vector2i) -> Vector2i:
	return Vector2i(1920, 1080).min((usable.size - decorations).max(Vector2i.ONE))

static func bounded_position(usable: Rect2i, client: Vector2i, decorations: Vector2i, client_offset: Vector2i) -> Vector2i:
	# Window.position is the client origin. Center the entire decorated window.
	return usable.position + (usable.size - client - decorations) / 2 + client_offset

func create_store() -> SaveStore:
	return SaveStore.new(SaveStore.test_root_override if not SaveStore.test_root_override.is_empty() else "user://p1/saves")

func puzzle_definitions() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for id: String in Definition.catalog_ids():
		result.append(Definition.load_fixture(id))
	return result

func validate_definition(data: Dictionary) -> String:
	return Definition.validate(data)

func _ready() -> void:
	if OS.has_feature("web"):
		if not JavaScriptBridge.eval("window.picrossStorage.attach(FS, GodotFS, IDBFS)"):
			return
		web_lifecycle_callback = JavaScriptBridge.create_callback(_web_lifecycle)
		JavaScriptBridge.get_interface("window").picrossLifecycle = web_lifecycle_callback
	var work_font: FontFile = WORK_TITLE_FONT
	work_font.allow_system_fallback = false
	# Bakso lacks only the middle dot in real work titles; all other title
	# glyphs are verified on its own RID. Use the existing offline Plex dot.
	var punctuation: FontFile = BODY_FONT.duplicate()
	punctuation.allow_system_fallback = false
	work_font.fallbacks = [punctuation]
	get_tree().auto_accept_quit = false
	store = create_store()
	if not OS.has_feature("web") and DisplayServer.get_name() != "headless" and not OS.get_cmdline_user_args().has("--p1-capture"):
		var usable: Rect2i = DisplayServer.screen_get_usable_rect()
		var decorations: Vector2i = (DisplayServer.window_get_size_with_decorations() - DisplayServer.window_get_size()).max(Vector2i(16, 48))
		var client_offset: Vector2i = DisplayServer.window_get_position() - DisplayServer.window_get_position_with_decorations()
		get_window().size = bounded_start(usable, decorations)
		get_window().position = bounded_position(usable, get_window().size, decorations, client_offset)
	var definitions: Array[Dictionary] = puzzle_definitions()
	catalog_error = Registry.load_error
	for data: Dictionary in definitions:
		var error: String = validate_definition(data)
		if not error.is_empty():
			catalog_error = "Rätseldaten ungültig: " + error
			sessions.clear()
			slot_status.clear()
			slot_errors.clear()
			session_indices.clear()
			break
		var item: Session = Session.new(data)
		var result: Dictionary = store.load_slot(data)
		if result.status in ["loaded", "recovered", "backup_invalid"]:
			SaveStore.apply(result.data, item)
		session_indices[str(data.id)] = sessions.size()
		sessions.append(item)
		slot_status.append(str(result.status))
		slot_errors.append("")
	session = sessions[0] if not sessions.is_empty() else null
	_build()
	save_timer = Timer.new()
	save_timer.one_shot = true
	save_timer.wait_time = 0.35
	save_timer.timeout.connect(_save_current)
	add_child(save_timer)
	resized.connect(_check_minimum)
	_check_minimum()
	if session != null:
		board.restore_view(session.view_state)
		session.view_state = board.capture_view()
	show_album()
	if OS.get_cmdline_user_args().has("--p1-smoke"):
		call_deferred("_smoke")

func _build() -> void:
	theme = Theme.new()
	theme.default_font = BODY_FONT
	theme.default_font_size = 14
	theme.set_color("font_color", "Label", Board.INK)
	for type_name: String in ["Button", "CheckBox"]:
		for color_name: String in ["font_color", "font_focus_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color"]:
			theme.set_color(color_name, type_name, BookButton.INK)
	for state: String in ["normal", "hover", "pressed", "disabled"]:
		var style: StyleBoxFlat = StyleBoxFlat.new()
		style.bg_color = Color("e3e7d6") if state == "normal" else Color("d1d9be")
		style.content_margin_left = 10
		style.content_margin_right = 10
		style.content_margin_top = 5
		style.content_margin_bottom = 5
		style.corner_radius_top_left = 0
		style.corner_radius_bottom_right = 0
		theme.set_stylebox(state, "Button", style)
		theme.set_color("font_color" if state == "normal" else "font_" + state + "_color", "Button", Board.INK)
	var dialog_paper: StyleBoxFlat = StyleBoxFlat.new()
	dialog_paper.bg_color = Color("fffaf0")
	dialog_paper.set_content_margin_all(16)
	theme.set_stylebox("panel","AcceptDialog",dialog_paper)
	var tooltip_paper: StyleBoxFlat = dialog_paper.duplicate()
	tooltip_paper.set_content_margin_all(4)
	theme.set_stylebox("panel","TooltipPanel",tooltip_paper)
	theme.set_color("font_color","TooltipLabel",Board.INK)
	surface = BookSurface.new()
	surface.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(surface)
	page = Control.new()
	page.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	page.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(page)
	title = label("Sammlung", 28)
	var heading: FontVariation = FontVariation.new()
	heading.base_font = TITLE_FONT
	heading.variation_opentype = {"wght": 600.0}
	title.add_theme_font_override("font", heading)
	page.add_child(title)
	status_label = label("", 14)
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page.add_child(status_label)
	stress_label = label("UI-Testdatensatz – Rätselqualität nicht abgenommen", 14)
	page.add_child(stress_label)
	album = CatalogView.new()
	page.add_child(album)
	album.opened.connect(select_by_id)
	album.reset_requested.connect(_ask_reset_id)
	album.repair_requested.connect(_ask_repair_id)
	album.information_requested.connect(show_information.bind("settings"))
	album.quit_requested.connect(leave_app)
	reset_dialog = ConfirmationDialog.new()
	reset_dialog.title = "Arbeitsstand zurücksetzen?"
	reset_dialog.dialog_text = "Nur das ausgewählte Blatt wird vollständig zurückgesetzt."
	reset_dialog.confirmed.connect(_reset_selected)
	reset_dialog.canceled.connect(_cancel_reset)
	add_child(reset_dialog)
	reset_dialog.get_ok_button().text = "Zurücksetzen"
	reset_dialog.get_cancel_button().text = "Abbrechen"
	repair_dialog = ConfirmationDialog.new()
	repair_dialog.title = "Backup übernehmen?"
	repair_dialog.dialog_text = "Der beschädigte Primärstand dieses Blatts wird durch das gültige Backup ersetzt."
	repair_dialog.confirmed.connect(_repair_selected)
	repair_dialog.canceled.connect(func() -> void: repair_id = "")
	add_child(repair_dialog)
	repair_dialog.get_cancel_button().text = "Abbrechen"
	_build_work()
	_build_information()
	ending = Control.new()
	ending.mouse_filter = Control.MOUSE_FILTER_IGNORE
	page.add_child(ending)
	reveal_view = Completion.new()
	ending.add_child(reveal_view)
	reveal_view.progressed.connect(_completion_progress)
	reveal_view.finished.connect(_completion_finished)
	completion_title = label("", 28)
	completion_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	completion_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ending.add_child(completion_title)
	completion_reset = _icon_button("reset", func() -> void: _ask_reset_id(str(session.definition.id), "ending"), ending)
	completion_reset.tooltip_text = "Rätsel zurücksetzen"

	minimum_message = label("Mindestens 1280 × 720 logische Fensterfläche benötigt.\nBitte das Fenster vergrößern oder die Anzeigeskalierung prüfen.", 20)
	minimum_message.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	minimum_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	minimum_message.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	add_child(minimum_message)
	# Recovery must remain above either page, including a failed N1 return flush.
	page.move_child(status_label,page.get_child_count()-1)
	page.move_child(work_repair_button,page.get_child_count()-1)
	_update_palette()
	resized.connect(_layout_book)
	_layout_book()

func _check_minimum() -> void:
	var small: bool = size.x < 1280 or size.y < 720
	minimum_message.visible = small
	page.visible = not small
	surface.work_visible = work.visible and not small
	surface.queue_redraw()
	if small:
		_cancel_interaction()

func set_clue_completion(enabled: bool) -> void:
	mark_completed_clues = enabled
	clue_completion_toggle.set_pressed_no_signal(enabled)
	board.mark_completed_clues = enabled
	board.queue_redraw()

func set_ui_scale(value: float) -> void:
	_cancel_interaction()
	ui_scale = value
	theme.default_font_size = roundi(14 * value)
	_scale_labels(self)
	board.ui_scale = value
	ui_scale_button.text = "UI %d %%" % roundi(ui_scale * 100)
	_layout_book()
	board.queue_redraw()

func _scale_labels(node: Node) -> void:
	if node is Label:
		if not node.has_meta("base_font"):
			node.set_meta("base_font", node.get_theme_font_size("font_size"))
		node.add_theme_font_size_override("font_size", roundi(float(node.get_meta("base_font")) * ui_scale))
	for child: Node in node.get_children():
		_scale_labels(child)

func set_tool(tool: String) -> void:
	board.eraser = tool == "erase"
	board.hand = false
	_update_actions()
	if save_timer != null:
		_save_current()

func _update_palette() -> void:
	for key: String in actions.keys():
		if key.begins_with("color-"):
			actions.erase(key)
	for child: Node in palette_row.get_children():
		palette_row.remove_child(child)
		child.queue_free()
	for entry: Dictionary in session.definition.palette if session != null else []:
		var item: BookButton = _icon_button("color-%d" % int(entry.id), func() -> void: board.active_color = int(entry.id); set_tool("fill"), palette_row)
		item.swatch = Color(entry.color)
		item.tooltip_text = "Farbe %d wählen · aktiviert Füllen" % int(entry.id)
	_update_actions()
	_layout_book()

func select_by_id(id: String) -> void:
	if session_indices.has(id): select_puzzle(int(session_indices[id]))

func _activate_session(index: int) -> bool:
	if index < 0 or index >= sessions.size(): return false
	_cancel_interaction()
	if not _flush_current(): return false
	if session != null and _puzzle_view_active(): session.view_state = board.capture_view()
	reveal_view.clear()
	session = sessions[index]
	board.session = session
	# Restoring slot-bound clue positions still needs the current work geometry.
	_layout_book(true)
	board.hover = Vector2i(-1, -1)
	board.restore_view(session.view_state)
	# A restored default view is not an edit merely because this slot was selected.
	session.view_state = board.capture_view()
	_update_palette()
	_update_status()
	return true

func select_puzzle(index: int) -> void:
	if _activate_session(index): open_puzzle()

func show_album() -> void:
	_cancel_interaction()
	if not _flush_current(): return
	board.clear_clue_hover()
	information.hide()
	album.show()
	work.hide()
	ending.hide()
	album_button.hide()
	stress_label.hide()
	title.text = "Rätselkatalog"
	# Hidden completion views must release their textures as well as old cards.
	reveal_view.clear()
	album.present(sessions, slot_status, slot_errors, catalog_error, str(session.definition.id) if session != null else "")
	_scale_labels(album)
	_update_status()
	_layout_book()

func open_puzzle() -> void:
	if session == null or slot_status[sessions.find(session)] == "error": return
	information.hide()
	album.hide()
	album.suspend()
	album_button.show()
	work.modulate.a = 1
	surface.work_alpha = 1
	work.visible = not session.completed
	ending.visible = session.completed
	stress_label.visible = session.definition.get("stress", false)
	title.text = session.neutral_title()
	completion_title.text = session.album_title() if session.completed else ""
	_layout_book()
	refresh()

func refresh() -> void:
	if mini == null or undo_button == null or session == null:
		return
	_update_actions()
	mini.cells = session.visible_cells()
	mini.width = session.player.width
	mini.height = session.player.height
	mini.palette = session.definition.palette
	mini.style_identity = str(session.definition.id) + "/miniature"
	mini.view_rect = board.view.normalized_view()
	mini.queue_redraw()
	board.queue_redraw()
	layout_warning.text = ""
	if board is FullViewBoard and (not board.layout_valid or board.glyph_risk or board.view.cell_size < 16):
		layout_warning.text = ("Zu wenig Platz" if not board.layout_valid else "Kleine / eng stehende Hinweise")
	layout_warning.visible = not layout_warning.text.is_empty()
	undo_button.disabled = session.completed or session.gesture.active or session.player.cursor == 0
	redo_button.disabled = session.completed or session.gesture.active or session.player.cursor == session.player.history.size()
	if session.completed and (work.visible or ending.visible) and not reveal_view.active:
		work.hide()
		ending.show()
		completion_title.text = session.album_title()
		_layout_completion()
		reveal_view.finish()
		surface.work_visible = false
		surface.queue_redraw()
	elif not session.completed:
		reveal_view.clear()

func _layout_completion() -> void:
	if reveal_view == null or session == null: return
	var paper: Rect2 = surface.material_rect()
	var u := ui_scale
	var left := paper.position.x + 100*u
	var width := paper.size.x - 200*u
	var top := paper.position.y + maxf(paper.size.y*0.039+57*u, 94*u)
	if status_label.visible:
		top = maxf(top, paper.position.y+85+78*u+(56*u if work_repair_button.visible else 0.0))
	_place(ending, Rect2(Vector2.ZERO, size))
	_place(reveal_view, Rect2(Vector2.ZERO, size))
	completion_title.size = Vector2(width, 0)
	var caption_height := completion_title.get_minimum_size().y
	var bottom := paper.end.y - 68*u
	_place(completion_reset, Rect2(Vector2(paper.get_center().x-22*u,bottom-44*u),Vector2.ONE*44*u))
	_place(completion_title, Rect2(Vector2(left,bottom-56*u-caption_height),Vector2(width,caption_height)))
	var bounds := Rect2(Vector2(left,top),Vector2(width,maxf(1,completion_title.position.y-16*u-top)))
	var matrix: Array = []
	if session.completed:
		for y: int in range(session.player.height):
			matrix.append(session.player.cells.slice(y*session.player.width,(y+1)*session.player.width))
	reveal_view.configure(session.reveal(),matrix,session.definition.palette,bounds)

func _completion_progress(work_alpha: float, caption_alpha: float) -> void:
	work.modulate.a = work_alpha
	if work_alpha <= 0: work.hide()
	surface.work_alpha = work_alpha
	surface.queue_redraw()
	completion_title.visible = caption_alpha > 0
	completion_reset.visible = caption_alpha > 0
	completion_title.modulate.a = caption_alpha
	completion_reset.modulate.a = caption_alpha
	completion_reset.disabled = reveal_view.active

func _completion_finished() -> void:
	work.hide()
	work.modulate.a = 1
	surface.work_alpha = 1
	surface.work_visible = false
	surface.queue_redraw()
	board.marks.hide_fills = false

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and board != null:
		_cancel_interaction()
	if what == NOTIFICATION_WM_CLOSE_REQUEST and board != null:
		leave_app()

func _on_commit() -> void:
	# Capture before saving: a new error card may change the board layout.
	var animate: bool = session.completed and work.visible and not reveal_view.active
	var origin: Rect2
	var commands: Array = []
	if animate:
		BookButton.dismiss_all(get_tree())
		board.clear_effects()
		board.preview.clear()
		board.marks.sync()
		origin = Rect2(board.position+board.view.origin,Vector2(session.player.width,session.player.height)*board.view.cell_size)
		for i: int in range(session.player.cells.size()):
			if session.player.cells[i] <= 0: continue
			var command: Array = board.marks.paint_command(i,session.player.cells[i],23,1.0)
			if not command.is_empty():
				command[1].position -= board.view.origin
				commands.append(command)
	_save_current()
	if animate:
		ending.show()
		completion_title.text = session.album_title()
		_layout_completion()
		board.marks.hide_fills = true
		reveal_view.begin(origin,commands,board.marks.ink_material)

func _puzzle_view_active() -> bool:
	# An internal session on the catalog is not an opened puzzle. Information
	# inherits its origin even though opening it hides both catalog and work.
	return work.visible or ending.visible or (information.visible and information_origin != "album")

func _schedule_view_save() -> void:
	if save_timer != null and session != null and _puzzle_view_active():
		WebStorage.view_changed()
		save_timer.start()

func _undo() -> void:
	if session.completed: return
	board.clear_effects()
	var old: int = session.player.cursor
	session.undo()
	if session.player.cursor != old:
		_save_current()
	refresh()

func _redo() -> void:
	if session.completed: return
	board.clear_effects()
	var old: int = session.player.cursor
	session.redo()
	if session.player.cursor != old:
		_on_commit()
	refresh()

func _save_current() -> bool:
	if store == null or board == null or session == null:
		return true
	if save_timer != null:
		save_timer.stop()
	session.view_state = board.capture_view()
	save_error = "Backup vor weiterem Speichern bewusst übernehmen." if slot_status[sessions.find(session)] == "recovered" else store.write_slot(session, session.view_state)
	if slot_status[sessions.find(session)] == "recovered": WebStorage.finished(str(session.definition.id), save_error)
	slot_errors[sessions.find(session)] = save_error
	if save_error.is_empty():
		slot_status[sessions.find(session)] = "loaded"
	else:
		var disk_state: String = str(store.load_slot(session.definition).status)
		if disk_state in ["recovered", "backup_invalid"]:
			slot_status[sessions.find(session)] = disk_state
	_update_status()
	return save_error.is_empty()

func _flush_current() -> bool:
	if (save_timer != null and not save_timer.is_stopped()) or (board != null and session != null and ((_puzzle_view_active() and board.capture_view() != session.view_state) or not slot_errors[sessions.find(session)].is_empty())):
		return _save_current()
	return true

func _update_status() -> void:
	if status_label == null or session == null:
		return
	var previous_visibility: bool = status_label.visible
	var previous_repair: bool = work_repair_button.visible if work_repair_button != null else false
	var state: String = slot_status[sessions.find(session)]
	var error: String = slot_errors[sessions.find(session)]
	status_label.text = "Speicherfehler: " + error if not error.is_empty() else ("Backup geladen; Primärstand beschädigt. Vor weiterem Speichern Backup bewusst übernehmen." if state == "recovered" else ("Backup beschädigt; gültiger Primärstand geladen. Backup vor weiterem Speichern bewusst erneuern." if state == "backup_invalid" else ("Speicherdaten ungültig. Nur bestätigter Reset dieses Blatts ist möglich." if state == "error" else "")))
	status_label.visible = not status_label.text.is_empty() and not album.visible
	if album.visible and not error.is_empty(): album.show_error(str(session.definition.id), error)
	status_label.add_theme_color_override("font_color", Color("682e24"))
	if work_repair_button != null:
		work_repair_button.visible = state in ["recovered", "backup_invalid"] and not album.visible
		work_repair_button.text = "Backup erneuern" if state == "backup_invalid" else "Backup zum Speichern übernehmen"
	if work != null and (work.visible or ending.visible) and (previous_visibility != status_label.visible or previous_repair != work_repair_button.visible):
		_layout_book()

func _ask_reset() -> void:
	if session != null: _ask_reset_id(str(session.definition.id))

func _cancel_reset() -> void:
	reset_id = ""
	reset_origin = "album"

func _ask_reset_id(id: String, origin: String = "album") -> void:
	if not session_indices.has(id): return
	_cancel_interaction()
	reset_id = id
	reset_origin = origin
	reset_dialog.dialog_text = sessions[int(session_indices[id])].album_title() + " vollständig zurücksetzen? Nur dieses Blatt wird verändert."
	reset_dialog.popup_centered()

func _reset_selected() -> void:
	# The dialog owns the stable ID; a filter/page/selection change cannot retarget it.
	var id: String = reset_id if not reset_id.is_empty() else (str(session.definition.id) if session != null else "")
	if not session_indices.has(id): return
	var index: int = int(session_indices[id])
	var target: Session = sessions[index]
	if target != session and not _flush_current(): return
	if target == session and save_timer != null: save_timer.stop()
	var error: String = store.reset_slot(store.key_for_definition(id))
	if not error.is_empty():
		slot_errors[index] = error
		if target == session: save_error = error
		_update_status()
		if album.visible: album.present(sessions, slot_status, slot_errors, catalog_error, id)
		return
	sessions[index] = Session.new(target.definition)
	slot_status[index] = "fresh"
	slot_errors[index] = ""
	if target == session:
		session = sessions[index]
		board.session = session
		board.restore_view(session.view_state)
		session.view_state = board.capture_view()
		save_error = ""
	var reopen := reset_origin == "ending"
	_cancel_reset()
	if reopen:
		select_puzzle(index)
	else:
		show_album()

func _ask_repair() -> void:
	if session != null: _ask_repair_id(str(session.definition.id))

func _ask_repair_id(id: String) -> void:
	if not session_indices.has(id): return
	_cancel_interaction()
	repair_id = id
	var index: int = int(session_indices[id])
	var renew: bool = slot_status[index] == "backup_invalid"
	repair_dialog.title = "Backup erneuern?" if renew else "Backup übernehmen?"
	repair_dialog.dialog_text = sessions[index].album_title() + "\n" + ("Das beschädigte Backup wird aus dem gültigen Primärstand neu erstellt." if renew else "Der beschädigte oder fehlende Primärstand wird durch das gültige Backup ersetzt.")
	repair_dialog.get_ok_button().text = "Erneuern" if renew else "Übernehmen"
	repair_dialog.popup_centered()

func _repair_selected() -> void:
	var id: String = repair_id if not repair_id.is_empty() else (str(session.definition.id) if session != null else "")
	if not session_indices.has(id): return
	var index: int = int(session_indices[id])
	var target: Session = sessions[index]
	if target != session and not _flush_current(): return
	var renew: bool = slot_status[index] == "backup_invalid"
	var error: String = store.discard_invalid_backup(target.definition) if renew else store.repair_from_backup(target.definition)
	# Renewal previously used _save_current() because only the active slot had
	# a repair action. A card can target another slot: rotate that valid primary
	# into a new backup without switching the board or writing the active slot.
	if error.is_empty() and renew and target != session:
		error = store.write_slot(target, target.view_state)
		var disk_state: String = str(store.load_slot(target.definition).status)
		slot_status[index] = disk_state
	if error.is_empty():
		slot_status[index] = "loaded"
		slot_errors[index] = ""
		if target == session:
			save_error = ""
			_save_current()
	else:
		slot_errors[index] = error
		if target == session: save_error = error
	repair_id = ""
	show_album()

func leave_app() -> void:
	if web_leaving: return
	_cancel_interaction()
	if _flush_current():
		if OS.has_feature("web"):
			web_leaving = true
			get_tree().paused = true
			WebStorage.changed()
			JavaScriptBridge.eval("window.picrossStorage.preferenceRetry()", true)
			var deadline: int = Time.get_ticks_msec() + 15000
			while JavaScriptBridge.eval("window.picrossStorage.pending || window.picrossStorage.preferencePending", true):
				if not str(JavaScriptBridge.eval("window.picrossStorage.error || window.picrossStorage.preferenceError", true)).is_empty() or Time.get_ticks_msec() > deadline:
					JavaScriptBridge.eval("if (!picrossStorage.preferenceError) { picrossStorage.syncError = 'Beenden nicht möglich: Sicherung ausstehend. Erneut versuchen.'; picrossStorage.render(); }", true)
					get_tree().paused = false
					web_leaving = false
					return
				await get_tree().create_timer(0.05).timeout
		get_tree().quit()

func _web_lifecycle(_arguments: Array) -> void:
	if web_leaving: return
	_cancel_interaction()
	_flush_current()

static func label(text: String, font_size: int) -> Label:
	var item: Label = Label.new()
	item.text = text
	item.add_theme_font_size_override("font_size", font_size)
	if font_size >= 26:
		var heading: FontVariation = FontVariation.new()
		heading.base_font = TITLE_FONT
		heading.variation_opentype = {"wght":600.0}
		item.add_theme_font_override("font",heading)
	return item

static func button(text: String, action: Callable) -> Button:
	var item: Button = Button.new()
	item.text = text
	item.focus_mode = Control.FOCUS_NONE
	item.pressed.connect(action)
	return item

func _smoke() -> void:
	if board is ChalkboardBoard:
		var digest: HashingContext = HashingContext.new()
		digest.start(HashingContext.HASH_SHA256)
		digest.update(board.clue_font().data)
		if digest.finish().hex_encode() != FullViewBoard.Typography.SHA256:
			push_error("ZS2 selected embedded font bytes differ")
			get_tree().quit(10)
			return
		if not OS.has_feature("editor") and (ResourceLoader.exists("res://study/main.tscn") or ResourceLoader.exists("res://study/fonts/BaksoDaging-Regular.ttf")):
			push_error("ZS2 regular export contains the isolated study")
			get_tree().quit(11)
			return
		print("ZS2_REGULAR_RESOURCES_OK DelightCoffee=", FullViewBoard.Typography.SHA256)
	if BODY_FONT.get_font_name() != "IBM Plex Sans" or TITLE_FONT.get_font_name() != "Fraunces" or surface.ART.get_width() != 2560:
		push_error("Z2 bundled offline resource mismatch")
		get_tree().quit(8)
		return
	if not album.visible or work.visible or ending.visible:
		get_tree().quit(12)
		return
	print("KAT2_CATALOG_START_OK")
	print("Z2_OFFLINE_RESOURCES body=",BODY_FONT.get_font_name()," title=",TITLE_FONT.get_font_name()," A_dimensions=",surface.ART.get_size())
	if DisplayServer.get_name() == "headless":
		get_window().size = Vector2i(1920, 1080)
	else:
		var outer: Rect2i = Rect2i(DisplayServer.window_get_position_with_decorations(), DisplayServer.window_get_size_with_decorations())
		var usable: Rect2i = DisplayServer.screen_get_usable_rect()
		print("P1_WINDOW_INFO client=", get_window().size, " outer=", outer, " usable=", usable, " screen=", DisplayServer.screen_get_size())
		if not usable.encloses(outer):
			push_error("Decorated start window exceeds usable monitor area")
			get_tree().quit(7)
			return
	for i: int in range(sessions.size()):
		select_puzzle(i)
		await get_tree().process_frame
		await get_tree().process_frame
		var cell: Vector2i = board.view.hit(board.view.viewport.get_center())
		var point: Vector2 = board.view.cell_rect(cell).get_center()
		board.pointer_press(point, MOUSE_BUTTON_LEFT)
		board.pointer_release(point, true)
		if session.player.cells.count(1) != 1 or session.completed != session.is_solution() or (not session.completed and not session.reveal().is_empty()):
			get_tree().quit(3)
			return
		_undo()
		show_information("settings")
		if not information.visible or work.visible:
			get_tree().quit(9)
			return
		return_to_work()
	show_album()
	print("P1_START_OK: ", sessions.size(), " registered fixtures -> mouse -> undo -> album; isolated persistence")
	get_tree().quit(0)

func _icon_button(id: String, action: Callable, parent: Control) -> BookButton:
	var item: BookButton = BookButton.new()
	item.action_id = id
	item.name = id
	if not id.begins_with("color-"):
		item.image = load("res://art/book/" + id + ".svg")
		var icons: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://art/book/icons.json"))
		item.tooltip_text = icons[id][1]
	item.pressed.connect(action)
	parent.add_child(item)
	actions[id] = item
	return item

func create_board() -> Board:
	return FullViewBoard.new()

func _build_work() -> void:
	work = Control.new()
	work.mouse_filter = Control.MOUSE_FILTER_IGNORE
	page.add_child(work)
	board = create_board()
	board.book_layout = true
	board.session = session
	board.edited.connect(refresh)
	board.committed.connect(_on_commit)
	board.view_changed.connect(_schedule_view_save)
	board.viewport_layout_requested.connect(_layout_book)
	board.pointed.connect(func(cell: Vector2i) -> void: coordinate.text = "Zeile %d · Spalte %d" % [cell.y+1,cell.x+1])
	work.add_child(board)
	sidebar = Control.new()
	sidebar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	work.add_child(sidebar)
	mini = Miniature.new()
	mini.interactive = false
	mini.draw_frame = false
	sidebar.add_child(mini)
	coordinate = label("Zeile – · Spalte –",13)
	coordinate.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sidebar.add_child(coordinate)
	layout_warning = label("",12)
	work.add_child(layout_warning)
	palette_row = Control.new()
	palette_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sidebar.add_child(palette_row)
	tools_scroll = ScrollContainer.new()
	tools_scroll.name = "tools-scroll"
	tools_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	tools_scroll.mouse_filter = Control.MOUSE_FILTER_STOP
	tools_scroll.mouse_force_pass_scroll_events = false
	work.add_child(tools_scroll)
	tools_column = GridContainer.new()
	tools_column.columns = 2
	tools_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tools_scroll.add_child(tools_column)
	for id: String in ["fill","erase"]:
		_icon_button(id,set_tool.bind(id),tools_column)
	undo_button = _icon_button("undo",_undo,tools_column)
	redo_button = _icon_button("redo",_redo,tools_column)
	_icon_button("minus",func() -> void: board.zoom(-1,board.view.viewport.get_center()),tools_column)
	_icon_button("plus",func() -> void: board.zoom(1,board.view.viewport.get_center()),tools_column)
	_icon_button("help",show_information.bind("help"),work)
	_icon_button("menu",show_information.bind("settings"),work)
	_icon_button("nav-information",show_information.bind("settings"),work)
	album_button = _icon_button("nav-album",show_album,page)
	# Kept on the visible page even when a failed flush blocks access to N1.
	work_repair_button = button("Backup zum Speichern übernehmen",_ask_repair)
	page.add_child(work_repair_button)
	work_repair_button.hide()

func _build_information() -> void:
	information = Control.new()
	information.mouse_filter = Control.MOUSE_FILTER_STOP
	page.add_child(information)
	_icon_button("nav-work",return_to_work,information)
	var settings_access: Button = _text_button("Einstellungen",_information_section.bind("settings"))
	settings_access.name = "settings-access"
	information.add_child(settings_access)
	var help_access: Button = _text_button("Hilfe",_information_section.bind("help"))
	help_access.name = "help-access"
	information.add_child(help_access)
	info_scroll = ScrollContainer.new()
	info_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	information.add_child(info_scroll)
	var content: VBoxContainer = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_scroll.add_child(content)
	settings_panel = VBoxContainer.new()
	settings_panel.add_theme_constant_override("separation",16)
	content.add_child(settings_panel)
	settings_panel.add_child(label("Einstellungen",26))
	ui_scale_button = _text_button("UI 100 %",func() -> void: set_ui_scale(1.25 if ui_scale == 1 else 1.0))
	settings_panel.add_child(ui_scale_button)
	settings_panel.add_child(label("Rätselansicht",20))
	view_choice = OptionButton.new()
	view_choice.name = "puzzle-view"
	view_choice.add_item("Rasteransicht")
	view_choice.add_item("Gesamtansicht mit allen Hinweisen")
	view_choice.item_selected.connect(set_puzzle_view)
	settings_panel.add_child(view_choice)
	var explanation: Label = label("Rasteransicht hält das ganze Raster sichtbar; lange Hinweise lassen sich einzeln verschieben. Die Gesamtansicht zeigt alle Hinweise und kann kleinere Zellen benötigen.",16)
	explanation.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	settings_panel.add_child(explanation)
	clue_reset_button = _text_button("Hinweise rasterseitig ausrichten",func() -> void:
		if session != null: board.reset_clue_pan())
	settings_panel.add_child(clue_reset_button)
	clue_completion_toggle = CheckBox.new()
	clue_completion_toggle.text = "Erfüllte Hinweise markieren"
	clue_completion_toggle.button_pressed = mark_completed_clues
	clue_completion_toggle.add_theme_color_override("font_color",BookButton.INK)
	clue_completion_toggle.toggled.connect(set_clue_completion)
	settings_panel.add_child(clue_completion_toggle)
	animation_toggle = CheckBox.new()
	animation_toggle.text = "Zellanimationen"
	animation_toggle.button_pressed = true
	animation_toggle.add_theme_color_override("font_color", BookButton.INK)
	animation_toggle.toggled.connect(func(enabled: bool) -> void: board.set_animations(enabled))
	settings_panel.add_child(animation_toggle)
	settings_panel.add_child(_text_button("Beenden",leave_app))
	help_panel = VBoxContainer.new()
	help_panel.add_theme_constant_override("separation",16)
	content.add_child(help_panel)
	help_panel.add_child(label("Maus und Hinweise",26))
	var help_text: Label = label("Links: Farbe setzen, Füllung zurücknehmen, X in Farbe umwandeln.\nRechts: X setzen, X zurücknehmen, Füllung in X umwandeln.\n\nStart auf unbekannt schützt X und Füllungen. Bewusste Umwandlung startet auf X (links) oder Füllung (rechts). Rücknahmestriche löschen nur ihren Starttyp.\n\nModus und Farbe bleiben im Strich fest. Zurückziehen verkürzt die Vorschau. Bei Rückkehr zur Startzelle lässt sich die Achse neu wählen. Loslassen übernimmt einen Schritt; Undo/Redo nimmt ganze Striche zurück. Begonnene Striche folgen auch über der Seitenleiste bis zum Rasterrand; die letzte Loslassposition zählt.\n\nAb Länge 2 folgt die Zahl mit heller Kontur dem Zeiger; bei Länge 1 verschwindet sie. Vorbelegte Felder zählen mit. Am Fensterrand bleibt die vollständige Zahl innen sichtbar. Der Zeiger bleibt frei. Bei erhaltenem Spielfokus übernimmt auch Loslassen außerhalb des Fensters den Strich. Fokusverlust verwirft ihn vollständig.\n\nDie Werkzeuge stehen rechts unter den Farben: zwei Spalten und drei Zeilen: Füllen / Radieren, Undo / Redo, Verkleinern / Vergrößern. Auswahlmarkierungen zeigen Werkzeug und Farbe.\n\nRad über dem Raster und +/−: Zoom bis zur Vollsichtgrenze. Raster und eigene Miniatur bleiben fest. Die Miniatur zeigt nur eigene Füllungen in Originalfarben, auch Fehler und die aktuelle Vorschau. X und unbekannt bleiben gleich neutral. Die Rätselansicht wird nur unter Einstellungen gewählt.\n\nLinke Taste auf überlaufenden Hinweisen: nur die angefasste Zeile waagerecht oder Spalte senkrecht ziehen. Loslassen rastet ein. MMB navigiert keine Hinweise. Beim Ziehen über Raster oder Buttons bleibt die Geste Hinweisnavigation und löst dort keine Aktion aus. Im Raster sind Zeile und Spalte markiert, über Hinweisen nur deren eine Linie, auch im Vollhinweis. Während Hinweisdrag bleibt seine Quellenlinie markiert. Freie Breite und Höhe zeigen nach dem Fit zusätzliche ganze Hinweise, ohne kleinere Zellen. Vollständig passende Folgen haben keine Marker und lassen sich nicht verschieben. … markiert verborgene Zahlen; darüberfahren zeigt die vollständige Folge auf Papier mit gezeichnetem Rahmen und kleinerer Überschrift. Die Overlaylesegröße folgt der UI-Skalierung unabhängig vom Rasterzoom. Vorübergehende Vollanzeige bewahrt die Leseposition auch beim Speichern.\n\nDie Vorschau bleibt statisch und heller. Beim Loslassen wird alles sofort übernommen; die Striche zeichnen sich vom Start zum Ende in höchstens 390 ms. Entfernen dauert 120 ms. Zellanimationen lassen sich für diese Sitzung abschalten.\n\nEsc, Fokusverlust oder Drücken der anderen Maustaste verwirft die laufende Zellgeste. Nach Gegentasten-Abbruch beide Tasten loslassen, dann neu beginnen.\nHinweise: normal = offen; deutlich blasser = eindeutig vollständig gesetzt; gleich blass mit handschriftlichem X über der ganzen Zahl = zusätzlich an beiden Enden abgegrenzt. … und – bleiben unmarkiert. X, echter Rasterrand oder direkt andere Füllfarbe zählen; unbekannte Nachbarn und Ausschnittränder nicht. Nur die eigene vollständige Linie zählt – keine Fehlerprüfung der Lösung. Der Schalter gilt für diese Sitzung.\n\nDer Arbeitsstand wird lokal gespeichert. Speicherfehler bleiben sichtbar; eine Backupübernahme braucht deine Bestätigung.",16)
	help_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	help_panel.add_child(help_text)
	information.hide()
	_information_section("settings")

func _text_button(caption: String, action: Callable) -> BookButton:
	var item: BookButton = BookButton.new()
	item.text = caption
	item.pressed.connect(action)
	return item

func _cancel_interaction() -> void:
	BookButton.dismiss_all(get_tree())
	if board == null: return
	if reveal_view != null and reveal_view.active: reveal_view.finish()
	board.cancel_gesture()
	board.clear_pointer_hover()
	if mini != null:
		mini.dragging = false

func show_information(section: String = "settings") -> void:
	_cancel_interaction()
	if not _flush_current():
		return
	information_origin = "album" if album.visible else ("ending" if ending.visible else "work")
	work.hide()
	album.hide()
	ending.hide()
	reveal_view.clear()
	information.show()
	album_button.hide()
	_information_section(section)
	title.text = "Information" if information_origin == "album" else "Information / " + str(session.definition.id)
	_layout_book()

func _information_section(section: String) -> void:
	information_section = section
	settings_panel.visible = section == "settings"
	help_panel.visible = section == "help"
	info_scroll.scroll_vertical = 0
	# One shared settings instance; shortcuts change only the visible section.
	if information.visible:
		var target: Control = ui_scale_button if section == "settings" else information.get_node("help-access")
		target.focus_mode = Control.FOCUS_ALL
		target.grab_focus()

func return_to_work() -> void:
	_cancel_interaction()
	if not _flush_current():
		return
	if information_origin == "album":
		show_album()
	else:
		open_puzzle()

func set_puzzle_view(index: int) -> void:
	_cancel_interaction()
	board.set_mode("V" if index == 1 else "G")
	view_choice.select(1 if board.mode == "V" else 0)
	refresh()

func _update_actions() -> void:
	if board == null:
		return
	var selected_tool: String = "erase" if board.eraser else "fill"
	for key: String in actions:
		if not is_instance_valid(actions[key]):
			continue
		var item: BookButton = actions[key]
		item.selected = key == selected_tool or key == "color-%d" % board.active_color
		item.ui_scale = ui_scale
		item.queue_redraw()

func _place(item: Control, box: Rect2) -> void:
	item.position = box.position
	item.size = box.size

func _layout_book(prepare_board: bool = false) -> void:
	if laying_out or board == null or information == null or ui_scale_button == null:
		return
	if size.x < 1280 or size.y < 720:
		return
	laying_out = true
	if reveal_view != null and reveal_view.active: reveal_view.finish()
	BookButton.dismiss_all(get_tree())
	var u: float = ui_scale
	var material: Rect2 = surface.material_rect()
	var o: Vector2 = material.position
	var w: float = material.size.x
	var h: float = material.size.y
	var compact: bool = w < 1700
	var hit: float = 44*u
	work.position = Vector2.ZERO
	work.size = Vector2(size.x,size.y-28)
	sidebar.position = Vector2.ZERO
	sidebar.size = work.size
	var left: float = 68*u
	var rail: float = w-260*u
	var top: float = maxf(h*0.039+45*u+6*u,82*u)
	var bottom: float = h-68*u
	var rail_top: float = top
	if work.visible and status_label.visible:
		top += 106*u
		if work_repair_button.visible:
			top += 50*u
	# Album, information and earned artwork need no hidden grid/font fit.
	# Opening work or restoring a selected slot prepares the current geometry.
	var layout_work: bool = work.visible or prepare_board
	if layout_work:
		_place(board,Rect2(o+Vector2(left,top),Vector2(rail-left-24*u,bottom-top-10*u)))
		board._layout()
	var mini_extent: float = (86.0 if compact or (bottom-rail_top)/u < 600 else 132.0)*u
	var nav_x: float = w-(187.5 if compact else 150)
	for i: int in range(3):
		_place(actions[["help","menu","nav-information"][i]],Rect2(o+Vector2(nav_x-(2-i)*58*u-20*u,h/30+12*u),Vector2.ONE*hit))
	# SL-R01/B-01: follow the unchanged navigation at every breakpoint/UI scale.
	# Cropped alpha envelopes and symmetric safe interiors share this content axis.
	var axis: float = actions["menu"].get_rect().get_center().x
	if layout_work and session != null and board is FullViewBoard and board.layout_valid and mini_extent > 86*u:
		var ink: Rect2 = board.composition_envelope()
		ink.position += board.position
		var left_room: float = maxf(0,ink.position.x-(o.x+w*0.03125))
		var preview: Rect2 = surface.frame_rect(Rect2(Vector2(axis-mini_extent/2,o.y+rail_top+26*u),Vector2.ONE*mini_extent),"preview")
		if preview.intersects(ink) and ink.end.x-preview.position.x+0.1 > left_room:
			mini_extent = 86*u
	var mini_position: Vector2 = Vector2(axis-mini_extent/2, o.y+rail_top+26*u)
	_place(mini,Rect2(mini_position,Vector2.ONE*mini_extent))
	_place(coordinate,Rect2(Vector2(axis-95*u,mini_position.y+mini_extent+20*u),Vector2(190,26)*u))
	coordinate.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var palette_count: int = session.definition.palette.size() if session != null else 1
	# Extra colors use a wider two-row group, retaining the existing vertical
	# budget and 44px targets at the smallest supported window/UI scale.
	var palette_columns: int = 4 if palette_count > 4 else 2
	var palette_extent: Vector2 = Vector2.ONE*44*u if palette_count == 1 else Vector2((palette_columns-1)*54+44,98)*u
	var palette_pos: Vector2 = Vector2(axis-palette_extent.x/2,coordinate.position.y+coordinate.size.y+18*u)
	_place(palette_row,Rect2(palette_pos,palette_extent))
	for i: int in range(palette_row.get_child_count()):
		_place(palette_row.get_child(i),Rect2(Vector2(i%palette_columns,i/palette_columns)*54*u,Vector2.ONE*hit))
	# The former bottom toolbar now holds only conditional non-numeric notices.
	# Both notices share the cleared footer horizontally. Stacking them would
	# cross the sloped paper edge on taller canvases; the board keeps its budget.
	var notice_left: float = maxf(left,w*0.03125+2*u)
	var notice_width: float = rail-notice_left-24*u
	var warning_width: float = notice_width*0.42
	_place(layout_warning,Rect2(o+Vector2(notice_left,bottom-6*u),Vector2(warning_width,24*u)))
	layout_warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var tools_top: float = palette_pos.y+palette_extent.y+40*u
	var tools_extent: Vector2 = Vector2(92,140)*u
	_place(tools_scroll,Rect2(Vector2(axis-tools_extent.x/2,tools_top),tools_extent))
	tools_column.add_theme_constant_override("h_separation",roundi(4*u))
	tools_column.add_theme_constant_override("v_separation",roundi(4*u))
	for id: String in TOOL_IDS:
		actions[id].custom_minimum_size = Vector2.ONE*hit
		actions[id].size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	surface.wells.assign([surface.frame_rect(tools_scroll.get_rect())])
	_place(album_button,Rect2(o+Vector2(w/320,h*7/72),Vector2.ONE*hit))
	# The shared heading changes font with page context, never globally.
	if work.visible or album.visible or ending.visible:
		title.add_theme_font_override("font",WORK_TITLE_FONT)
	else:
		var heading: FontVariation = FontVariation.new()
		heading.base_font = TITLE_FONT
		heading.variation_opentype = {"wght":600.0}
		title.add_theme_font_override("font",heading)
	_place(title,Rect2(o+Vector2(w*0.043,h*0.039),Vector2(w*0.6,45*u)))
	stress_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_place(stress_label,Rect2(o+Vector2(notice_left+warning_width+12*u,bottom-6*u),Vector2(notice_width-warning_width-12*u,24*u)))
	album.ui_scale = u
	_place(album,Rect2(o+Vector2(90,100)*u,Vector2(w-180*u,h-155*u)))
	album._layout_cards()
	if ending != null and ending.visible: _layout_completion()
	_place(information,Rect2(Vector2.ZERO,size))
	_place(actions["nav-work"],Rect2(o+Vector2(100,110),Vector2.ONE*hit))
	_place(information.get_node("settings-access"),Rect2(o+Vector2(180,110),Vector2(210*u,hit)))
	_place(information.get_node("help-access"),Rect2(o+Vector2(410*u,110),Vector2(140*u,hit)))
	_place(info_scroll,Rect2(o+Vector2(180,190),Vector2(w-360,h-300)))
	for item: Control in [ui_scale_button,clue_reset_button,clue_completion_toggle]:
		item.custom_minimum_size.y = hit
	for item: Node in information.find_children("*","Button",true,false):
		item.custom_minimum_size.y = hit
		if item is BookButton:
			item.ui_scale = u
			item.queue_redraw()
	# Local error card stays reachable on a blocked work->information transition.
	_place(status_label,Rect2(o+Vector2(180,h-104 if information.visible else 85),Vector2(w-660 if information.visible else w-550,70*u)))
	var repair_position: Vector2 = o+Vector2(w-430,h-80*u) if information.visible else o+Vector2(180,85+78*u)
	_place(work_repair_button,Rect2(repair_position,Vector2(340*u,hit)))
	surface.card = surface.frame_rect(mini.get_rect(),"preview")
	surface.miniature = mini.get_rect()
	surface.palette = surface.frame_rect(palette_row.get_rect(),"palette")
	# Preserve the complete fit/hint budget. Only unused left paper absorbs the
	# clearance required by the aligned sidebar; no cell, font or slot reduction.
	if layout_work and session != null and board is FullViewBoard and board.layout_valid:
		var occupied: Rect2 = board.composition_envelope()
		occupied.position += board.position
		var coordinate_text: String = "Zeile %d · Spalte %d" % [session.player.height,session.player.width]
		var coordinate_width: float = coordinate.get_theme_font("font").get_string_size(coordinate_text,HORIZONTAL_ALIGNMENT_LEFT,-1,coordinate.get_theme_font_size("font_size")).x+2
		var coordinate_ink: Rect2 = Rect2(Vector2(axis-coordinate_width/2,coordinate.position.y),Vector2(coordinate_width,coordinate.size.y))
		var clearance: float = 0
		for box: Rect2 in [surface.card,surface.palette,surface.wells[0],coordinate_ink]:
			if box.intersects(occupied): clearance = maxf(clearance,occupied.end.x-box.position.x+0.1)
		board.position.x -= clearance
	board.refresh_clue_hover()
	surface.information = information.visible
	surface.work_visible = work.visible and page.visible
	surface.queue_redraw()
	_update_status()
	_update_actions()
	laying_out = false
