import sys,subprocess,json
from pathlib import Path
sys.path[:0]=['tools','.']
import p1_preflight as tc
from at_fixtures import install
from p1_evidence import source_identity
import platform,hashlib
from product_fixtures import copy_regression_game
from web_tests.fixtures import adapt
root=Path.cwd();identity=source_identity(root);assert not identity['source_tree_dirty'];ws=root/'artifacts/at-a-final/windows-matrix-5cb2169';ws.mkdir();project=ws/'game'
copy_regression_game(root,project);adapt(project);fixture=install(project)
engine=next((root/'artifacts/at-a-start/native-dev/engine').glob('*console.exe'));out=ws/'out';out.mkdir()
env=tc.isolated_environment(ws,'Windows');env.update(KAT2_OUTPUT=str(out),KAT2_MODE='at',EA_OUTPUT=str(out),EA_MODE='native')
for name,args in [('import',['--headless','--import']),('catalog',['--script','res://tests/kat2_probe.gd','--','--p1-capture']),('completion',['--script','res://tests/ea_probe.gd','--','--p1-capture'])]:
 saves=ws/(name+'-saves');saves.mkdir();env['P1_TEST_SAVE_ROOT']=str(saves)
 p=subprocess.run([str(engine),'--path',str(project),'--rendering-driver','opengl3','--audio-driver','Dummy',*args],env=env,capture_output=True,text=True,timeout=300)
 (ws/(name+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8');print(name,p.returncode,(p.stdout+p.stderr)[-1600:],flush=True)
 if p.returncode or 'SCRIPT ERROR' in p.stdout+p.stderr:raise SystemExit(1)

(out/'at-fixture.json').write_text(json.dumps(fixture,sort_keys=True)+'\n')
import at_evidence
checks={}
for name,kinds in [('at',('small','hover')),('native',('blend','final','reopen'))]:
 report=json.loads((out/(name+'.json')).read_text());checks[name]=at_evidence.native(out,report,kinds)
record=dict(format='picross-at-windows-matrix-v1',status='passed',**identity,platform=platform.platform(),checks=checks,
 engine_sha256=tc.sha256_file(engine),runner_sha256=tc.sha256_file(Path(__file__)),
 files={str(p.relative_to(ws)).replace('\\','/'):{'size':p.stat().st_size,'sha256':tc.sha256_file(p)} for p in sorted(out.iterdir()) if p.is_file()})
(ws/'matrix-binding.json').write_text(json.dumps(record,indent=2)+'\n')
print('WINDOWS_MATRIX_BOUND_OK',identity['source_commit'],checks,flush=True)
