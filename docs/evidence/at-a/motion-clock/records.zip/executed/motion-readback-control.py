from pathlib import Path
import subprocess,sys,json
sys.path[:0]=['tools','.']
import p1_preflight as tc
from p1_product import require_clean_output
from p1_current_visual import verify_motion_clock
from PIL import Image,ImageChops
root=Path.cwd();ws=root/'artifacts/at-a-final/motion-clock-fix';project=ws/'game';out=ws/'delayed-readback';out.mkdir()
script='''extends "res://tests/zs2_capture.gd"
func motion_frame(label: String, committed_at: int, observed_us: Array[int]) -> Dictionary:
	var record: Dictionary = super.motion_frame(label, committed_at, observed_us)
	if label == "parallel-commit-0":
		OS.delay_msec(220)
		record.measurement.readback_finished_ms = float(Time.get_ticks_usec() - committed_at) / 1000.0
	return record
func run() -> void:
	output = OS.get_environment("P1_CAPTURE_DIR")
	variant = 2
	Store.test_root_override = "user://motion-readback-control"
	surface = SubViewport.new()
	surface.size = Vector2i(1920,1080)
	surface.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(surface)
	app = load("res://main.tscn").instantiate()
	surface.add_child(app)
	await process_frame
	await create_timer(0.3).timeout
	await movement()
	FileAccess.open(output.path_join("motion.json"),FileAccess.WRITE).store_string(JSON.stringify({"test_only":true,"delay_ms":220,"frames":frames,"failures":failures},"\\t")+"\\n")
	if failures == 0: print("DELAYED_READBACK_CONTROL_OK")
	quit(0 if failures == 0 else 1)
'''
(project/'tests/motion_readback_control.gd').write_text(script,encoding='utf-8');(out/'executed-probe.gd').write_text(script,encoding='utf-8')
engine=next((root/'artifacts/at-a-start/native-dev/engine').glob('*console.exe'));env=tc.isolated_environment(ws/'delayed-profile','Windows');env['P1_CAPTURE_DIR']=str(out)
r=subprocess.run([str(engine),'--path',str(project),'--rendering-driver','opengl3','--audio-driver','Dummy','--script','res://tests/motion_readback_control.gd','--','--p1-capture'],env=env,capture_output=True,timeout=300)
raw=r.stdout+r.stderr;(out/'native.log').write_bytes(raw);require_clean_output({'exit_code':r.returncode,'output':raw.decode('utf-8'),'name':'delayed-readback'},'DELAYED_READBACK_CONTROL_OK')
d=json.loads((out/'motion.json').read_text());assert d['failures']==0;m=d['frames'][0];early=verify_motion_clock(m);assert early['after_commit_ms']<210<early['readback_finished_ms'];final=next(v for v in m['timeline'] if v['label']=='settled')
with Image.open(out/early['file']) as a,Image.open(out/final['file']) as b:assert ImageChops.difference(a.convert('RGB'),b.convert('RGB')).getbbox()
print('GENUINE_NATIVE_DELAYED_READBACK_VERIFIED',early,flush=True)
