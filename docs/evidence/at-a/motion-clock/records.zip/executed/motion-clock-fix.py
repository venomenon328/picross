import sys,subprocess,json,hashlib
from pathlib import Path
sys.path[:0]=['tools','.']
import p1_preflight as tc
from p1_product import require_clean_output
from product_fixtures import copy_regression_game
from p1_evidence import source_identity
from p1_current_visual import verify_regular_motion
root=Path.cwd();ws=root/'artifacts/at-a-final/motion-clock-fix';ws.mkdir();project=ws/'game';copy_regression_game(root,project)
engine=next((root/'artifacts/at-a-start/native-dev/engine').glob('*console.exe'));out=ws/'out';out.mkdir()
env=tc.isolated_environment(ws,'Windows');env.update(P1_CAPTURE_DIR=str(out),ZS2_VARIANT='after')
identity=source_identity(root)
for name,args,marker in [('import',['--headless','--import'],None),('drawing',['--script','res://tests/zs2_capture.gd','--','--p1-capture'],'ZS2_CAPTURE_OK')]:
 r=subprocess.run([str(engine),'--path',str(project),'--rendering-driver','opengl3','--audio-driver','Dummy',*args],env=env,capture_output=True,timeout=300)
 raw=r.stdout+r.stderr;(ws/(name+'.log')).write_bytes(raw);require_clean_output({'exit_code':r.returncode,'output':raw.decode('utf-8'),'name':name},marker);print(name,'PASS',len(raw),'original bytes',flush=True)
verified=verify_regular_motion(root,out);(out/'current-drawing-report.json').write_text(json.dumps(verified,indent=2)+'\n',encoding='utf-8')
record={'identity':identity,'status':'passed','source_files':{p:tc.sha256_file(root/p) for p in ('game/tests/zs1_capture.gd','game/tests/zs2_capture.gd','tools/p1_current_visual.py')},'engine_sha256':tc.sha256_file(engine),'files':{p.relative_to(ws).as_posix():{'bytes':p.stat().st_size,'sha256':tc.sha256_file(p)} for p in out.iterdir() if p.is_file()}}
(ws/'binding.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('CURRENT_DRAWING_ORIGINALS_VERIFIED',len(verified['cases']),flush=True);print(json.dumps(verified['movements'][0]['timeline'],indent=2),flush=True)
