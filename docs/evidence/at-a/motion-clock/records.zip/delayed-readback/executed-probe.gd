extends "res://tests/zs2_capture.gd"
func motion_frame(label: String, committed_at: int, observed_us: Array[int]) -> Dictionary:
	var record: Dictionary = super.motion_frame(label, committed_at, observed_us)
	if label == "parallel-commit-0":
		OS.delay_msec(220)
		record.measurement.readback_finished_ms = float(Time.get_ticks_usec() - committed_at) / 1000.0
	return record
func run() -> void:
	output = OS.get_environment("P1_CAPTURE_DIR")
	variant = 2
	Store.test_root_override = "user://motion-readback-control"
	surface = SubViewport.new()
	surface.size = Vector2i(1920,1080)
	surface.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(surface)
	app = load("res://main.tscn").instantiate()
	surface.add_child(app)
	await process_frame
	await create_timer(0.3).timeout
	await movement()
	FileAccess.open(output.path_join("motion.json"),FileAccess.WRITE).store_string(JSON.stringify({"test_only":true,"delay_ms":220,"frames":frames,"failures":failures},"\t")+"\n")
	if failures == 0: print("DELAYED_READBACK_CONTROL_OK")
	quit(0 if failures == 0 else 1)
