import os,sys,subprocess,json,shutil,hashlib,zipfile
from pathlib import Path
root=Path('E:/Zeuch/Coding/picross-294')
sys.path[:0]=[str(root),str(root/'tools')]
import p1_preflight as tc
from product_fixtures import copy_regression_game
from build_web_player import extract_web_templates
out=Path(os.environ['TEMP'])/'picross-hzc-comparison-fresh'
out.mkdir()
project=out/'game'
copy_regression_game(root,project)
shutil.copyfile(root/'game/tests/hz_c_sample.gd',project/'ui/hzc_sample.gd')
entry='''extends Control
const Sample = preload("res://ui/hzc_sample.gd")
const Text = preload("res://ui/ui_text.gd")
var sample: Control
func _ready() -> void:
 get_viewport().size_changed.connect(build)
 build()
func build() -> void:
 if sample != null: sample.free()
 var u: float = 1.0 if get_viewport_rect().size.x == 1920 else 1.25
 theme = Theme.new()
 theme.default_font = Text.font()
 theme.default_font_size = roundi(14*u)
 theme.set_stylebox("normal","Label",Text.label_style(u))
 theme.set_constant("line_spacing","Label",roundi(3*u))
 theme.set_color("font_color","Label",Color("293e3d"))
 theme.set_color("font_color","Button",Color("293e3d"))
 sample = Sample.new()
 sample.position = Vector2(24,24)
 sample.ui_scale = u
 add_child(sample)
func _process(_delta: float) -> void:
 var controls: Array = []
 for node: Node in sample.get_children():
  if node is OptionButton:
   var rect: Rect2 = node.get_global_rect()
   controls.append({"center":[rect.get_center().x,rect.get_center().y],"visible":node.get_popup().visible})
 var r: Rect2 = sample.get_global_rect()
 JavaScriptBridge.eval("window.hzcComparison = "+JSON.stringify({"controls":controls,"rect":[r.position.x,r.position.y,r.size.x,r.size.y]}),true)
'''
(project/'ui/hzc_compare_main.gd').write_text(entry,encoding='utf-8')
p=project/'main.tscn';p.write_text(p.read_text(encoding='utf-8').replace('res://ui/main.gd','res://ui/hzc_compare_main.gd'),encoding='utf-8')
p=project/'export_presets.cfg';s=p.read_text(encoding='utf-8').replace('html/canvas_resize_policy=0','html/canvas_resize_policy=2').replace('html/custom_html_shell="res://web/shell.html"','html/custom_html_shell=""');p.write_text(s,encoding='utf-8')
cache=Path(os.environ['TEMP'])/'picross-p1-preflight-cache'
tc.verify_sha256(cache/tc.TEMPLATES.name,tc.TEMPLATES.sha256)
extract_web_templates(cache/tc.TEMPLATES.name,tc.template_directory(out,'Windows'))
engine=Path(os.environ['TEMP'])/'picross-hz-c-access-20261021/engine/Godot_v4.7.2-stable_win64_console.exe'
web=out/'web';web.mkdir()
env=tc.isolated_environment(out,'Windows')
for name,args in [('import',['--headless','--path',str(project),'--import']),('export',['--headless','--path',str(project),'--export-debug','P1 Web',str(web/'index.html')])]:
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:
  p=subprocess.run([str(engine),*args],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 print(name,p.returncode,flush=True)
 if p.returncode: raise RuntimeError(name)
binding=dict(purpose='isolated static comparison only; no gameplay, save profile or deployment',source_files={p.relative_to(root).as_posix():tc.sha256_file(p) for p in sorted((root/'game/ui').glob('*.gd'))},sample_sha256=tc.sha256_file(root/'game/tests/hz_c_sample.gd'),entry=entry,engine_sha256=tc.sha256_file(engine),exports={p.name:tc.sha256_file(p) for p in web.iterdir() if p.is_file()})
(out/'binding.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8')
print('COMPARISON_EXPORT_READY',out,flush=True)
