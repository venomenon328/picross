extends Control
const Sample = preload("res://ui/hzc_sample.gd")
const Text = preload("res://ui/ui_text.gd")
var sample: Control
func _ready() -> void:
 get_viewport().size_changed.connect(build)
 build()
func build() -> void:
 if sample != null: sample.free()
 var u: float = 1.0 if get_viewport_rect().size.x == 1920 else 1.25
 theme = Theme.new()
 theme.default_font = Text.font()
 theme.default_font_size = roundi(14*u)
 theme.set_stylebox("normal","Label",Text.label_style(u))
 theme.set_constant("line_spacing","Label",roundi(3*u))
 theme.set_color("font_color","Label",Color("293e3d"))
 theme.set_color("font_color","Button",Color("293e3d"))
 sample = Sample.new()
 sample.position = Vector2(24,24)
 sample.ui_scale = u
 add_child(sample)
func _process(_delta: float) -> void:
 var controls: Array = []
 for node: Node in sample.get_children():
  if node is OptionButton:
   var rect: Rect2 = node.get_global_rect()
   controls.append({"center":[rect.get_center().x,rect.get_center().y],"visible":node.get_popup().visible})
 var r: Rect2 = sample.get_global_rect()
 JavaScriptBridge.eval("window.hzcComparison = "+JSON.stringify({"controls":controls,"rect":[r.position.x,r.position.y,r.size.x,r.size.y]}),true)
