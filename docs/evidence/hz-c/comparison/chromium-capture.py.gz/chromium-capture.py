import os,json,http.server,threading,functools,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
out=Path(os.environ['TEMP'])/'picross-hzc-comparison-safe'
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args): pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(out/'web')))
threading.Thread(target=server.serve_forever,daemon=True).start()
images=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True)
 for w,h in [(1280,720),(1920,1080),(2560,1440)]:
  page=browser.new_page(viewport=dict(width=w,height=h),device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}/')
  page.wait_for_function('window.hzcComparison && window.hzcComparison.controls.length === 2',timeout=60000)
  page.wait_for_timeout(3000)
  state=page.evaluate('window.hzcComparison')
  x,y,width,height=state['rect']
  image=out/f'chromium-comparison-{w}.png'
  page.screenshot(path=str(image),clip=dict(x=x,y=y,width=width,height=height))
  images.append(image.name)
  for i in range(2):
   page.mouse.click(*state['controls'][i]['center'])
   page.wait_for_function(f'window.hzcComparison.controls[{i}].visible')
   image=out/f'chromium-menu-{14+i}-{w}.png'
   page.screenshot(path=str(image))
   images.append(image.name)
   page.keyboard.press('Escape')
   page.wait_for_function(f'!window.hzcComparison.controls[{i}].visible')
  assert not errors,errors
  page.close()
 version=browser.version
 browser.close()
server.shutdown()
(out/'chromium.json').write_text(json.dumps(dict(browser=version,images={n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in images},errors=[]),indent=2)+'\n',encoding='utf-8')
print('COMPARISON_CHROMIUM_OK',version,len(images))
