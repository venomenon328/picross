from pathlib import Path
from PIL import Image,ImageDraw
p=Path('artifacts/perf-a-probe-04')
q=Path('artifacts/perfa-qa'); q.mkdir(exist_ok=True)
items=['flat-fill-5.1.png','flat-fill-18.77.png','flat-fill-57.73.png','flat-x-5.1.png','flat-x-18.77.png','flat-x-57.73.png']
board=Image.new('RGB',(1050,740),'#f6f0df'); draw=ImageDraw.Draw(board)
for i,name in enumerate(items):
 im=Image.open(p/name).convert('RGBA'); im.thumbnail((330,330)); x=(i%3)*350; y=(i//3)*370
 board.paste(im,(x,y+25),im); draw.text((x+5,y+5),name,fill='black')
board.save(q/'flats.png')
if (p/'probe.json').exists():
 import json
 raw=json.loads((p/'probe.json').read_text())
 frames=[m for m in raw['motion'] if m['kind']=='fill'][::3]
 strip=Image.new('RGB',(1000,len(frames)*54),'#f6f0df'); dr=ImageDraw.Draw(strip)
 for i,m in enumerate(frames):
  im=Image.open(p/m['file']).convert('RGBA'); strip.paste(im,(0,i*54+20),im); dr.text((0,i*54),str(m['elapsed_us'])+' us',fill='black')
 strip.save(q/'motion.png')
